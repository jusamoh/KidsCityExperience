<?php
// functions.php - 유틸리티 함수 모음

// 이 파일에서는 세션 시작 코드를 넣지 않음
// 세션은 index.php에서만 시작됨

// 페이지 리디렉션 함수
function redirect($url) {
    header("Location: $url");
    exit;
}

// 로그아웃 함수
function logout_user() {
    // 세션 변수 제거
    $_SESSION = array();
    
    // 세션 쿠키 삭제
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // 세션 파기
    session_destroy();
}

// 날짜 형식 변환 함수 (예: 2023-06-15 -> 2023년 6월 15일 (목) 14:00)
function format_date($date_str) {
    $date = new DateTime($date_str);
    $weekdays = ['일', '월', '화', '수', '목', '금', '토'];
    $weekday = $weekdays[$date->format('w')];
    
    return $date->format('Y년 n월 j일') . " ({$weekday}) " . $date->format('H:i');
}

// 가격 포맷팅 함수 (예: 30000 -> 30,000원)
function format_price($price) {
    return number_format($price) . '원';
}

// 문자열 이스케이핑 함수
function escape_string($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// 현재 모집 중인 프로그램 가져오기 (상태가 'active'인 프로그램)
function get_active_programs($limit = 3, $use_cache = true) {
    // 캐시 비활성화 설정
    if (!$use_cache && isset($_GET['updated'])) {
        $use_cache = false;
    }
    
    // 데이터베이스 연결 가져오기
    require_once 'config/database.php';
    $conn = get_db_connection();
    
    $sql = "SELECT 
           p.id, p.title, p.description, p.category_id, p.date, 
           p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
           p.duration, p.status, p.image_path, p.created_at,
           c.name as category_name, 
           (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) as current_participants
           FROM programs p
           LEFT JOIN categories c ON p.category_id = c.id
           WHERE p.status = 'active'
           ORDER BY p.date ASC
           LIMIT ?";
           
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("데이터베이스 쿼리 준비 실패: " . $conn->error);
        return [];
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $programs = [];
    while ($row = $result->fetch_assoc()) {
        $programs[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    return $programs;
}

// 준비 중인 프로그램 가져오기 (상태가 'pending'인 프로그램)
function get_pending_programs($limit = 3) {
    // 데이터베이스 연결 가져오기
    require_once 'config/database.php';
    $conn = get_db_connection();
    
    $sql = "SELECT 
           p.id, p.title, p.description, p.category_id, p.date, 
           p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
           p.duration, p.status, p.image_path, p.created_at,
           c.name as category_name, 
           (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) as current_participants
           FROM programs p
           LEFT JOIN categories c ON p.category_id = c.id
           WHERE p.status = 'pending'
           ORDER BY p.date ASC
           LIMIT ?";
           
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("데이터베이스 쿼리 준비 실패: " . $conn->error);
        return [];
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $programs = [];
    while ($row = $result->fetch_assoc()) {
        $programs[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    return $programs;
}

// 세션에 메시지 설정
function set_message($message, $type = 'info') {
    $_SESSION['message'] = [
        'type' => $type,
        'text' => $message
    ];
}

// 메시지 가져오기 및 삭제
function get_message() {
    $message = isset($_SESSION['message']) ? $_SESSION['message'] : null;
    unset($_SESSION['message']);
    return $message;
}

// CSRF 토큰 생성 함수
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRF 토큰 검증 함수
function verify_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        return false;
    }
    return true;
}

// 로그인 상태 확인 함수
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// 카테고리 목록 가져오기
function get_categories() {
    $conn = get_db_connection();
    $sql = "SELECT * FROM categories ORDER BY name";
    $result = $conn->query($sql);
    
    $categories = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
    
    $conn->close();
    return $categories;
}

// 특정 카테고리 가져오기
function get_category($id) {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    
    $sql = "SELECT * FROM categories WHERE id = {$id}";
    $result = $conn->query($sql);
    
    $category = null;
    if ($result && $result->num_rows > 0) {
        $category = $result->fetch_assoc();
    }
    
    $conn->close();
    return $category;
}

// 카테고리 추가
function add_category($name, $description = '') {
    $conn = get_db_connection();
    $name = $conn->real_escape_string($name);
    $description = $conn->real_escape_string($description);
    
    $sql = "INSERT INTO categories (name, description) VALUES ('{$name}', '{$description}')";
    $result = $conn->query($sql);
    
    $id = $result ? $conn->insert_id : null;
    $conn->close();
    
    return $id;
}

// 카테고리 수정
function update_category($id, $name, $description = '') {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    $name = $conn->real_escape_string($name);
    $description = $conn->real_escape_string($description);
    
    $sql = "UPDATE categories SET name = '{$name}', description = '{$description}' WHERE id = {$id}";
    $result = $conn->query($sql);
    
    $conn->close();
    return $result;
}

// 카테고리 삭제
function delete_category($id) {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    
    // 해당 카테고리의 프로그램 수 확인
    $sql = "SELECT COUNT(*) as count FROM programs WHERE category_id = {$id}";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    
    if ($row['count'] > 0) {
        $conn->close();
        return ['success' => false, 'message' => '이 카테고리에 속한 프로그램이 있어 삭제할 수 없습니다.'];
    }
    
    $sql = "DELETE FROM categories WHERE id = {$id}";
    $result = $conn->query($sql);
    
    $conn->close();
    return ['success' => $result, 'message' => $result ? '카테고리가 삭제되었습니다.' : '카테고리 삭제 중 오류가 발생했습니다.'];
}

// 프로그램 목록 가져오기 (카테고리 필터링 지원)
function get_programs($category_id = null, $include_completed = false) {
    $conn = get_db_connection();
    
    $where_clause = '';
    if (!$include_completed) {
        $where_clause = "WHERE p.status != 'completed' AND p.status != 'canceled'";
    } else {
        $where_clause = "WHERE 1=1";
    }
    
    if ($category_id) {
        $category_id = $conn->real_escape_string($category_id);
        $where_clause .= " AND p.category_id = {$category_id}";
    }
    
    $sql = "SELECT 
            p.id, p.title, p.description, p.category_id, p.date, 
            p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
            p.duration, p.status, p.image_path, p.created_at,
            c.name as category_name, 
            (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) as current_participants
            FROM programs p
            LEFT JOIN categories c ON p.category_id = c.id
            {$where_clause}
            ORDER BY 
                CASE p.status 
                    WHEN 'active' THEN 1 
                    WHEN 'pending' THEN 2 
                    ELSE 3 
                END, 
                p.date ASC";
    
    $result = $conn->query($sql);
    
    $programs = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $programs[] = $row;
        }
    }
    
    $conn->close();
    return $programs;
}

// 정렬 기능이 있는 프로그램 목록 가져오기
function get_programs_with_sort($category_id = null, $include_completed = false, $sort_by = 'status', $order = 'asc') {
    $conn = get_db_connection();
    
    $where_clause = '';
    if (!$include_completed) {
        $where_clause = "WHERE p.status != 'completed' AND p.status != 'canceled'";
    } else {
        $where_clause = "WHERE 1=1";
    }
    
    if ($category_id) {
        $category_id = $conn->real_escape_string($category_id);
        $where_clause .= " AND p.category_id = {$category_id}";
    }
    
    // 정렬 처리
    $order_clause = '';
    switch ($sort_by) {
        case 'id':
            $order_clause = "ORDER BY p.id {$order}";
            break;
        case 'title':
            $order_clause = "ORDER BY p.title {$order}";
            break;
        case 'category_name':
            $order_clause = "ORDER BY c.name {$order}";
            break;
        case 'date':
            $order_clause = "ORDER BY p.date {$order}";
            break;
        case 'price':
            $order_clause = "ORDER BY p.price {$order}";
            break;
        case 'status':
        default:
            // 기본 정렬: 상태별 우선순위 + 날짜순
            $order_clause = "ORDER BY 
                CASE p.status 
                    WHEN 'active' THEN 1 
                    WHEN 'pending' THEN 2 
                    ELSE 3 
                END, 
                p.date ASC";
            break;
    }
    
    $sql = "SELECT 
            p.id, p.title, p.description, p.category_id, p.date, 
            p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
            p.duration, p.status, p.image_path, p.created_at,
            c.name as category_name, 
            (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) as current_participants
            FROM programs p
            LEFT JOIN categories c ON p.category_id = c.id
            {$where_clause}
            {$order_clause}";
    
    $result = $conn->query($sql);
    
    $programs = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $programs[] = $row;
        }
    }
    
    $conn->close();
    return $programs;
}

// 특정 프로그램 가져오기
function get_program($id) {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    
    $sql = "SELECT 
            p.id, p.title, p.description, p.category_id, p.date, 
            p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
            p.duration, p.status, p.image_path, p.created_at,
            c.name as category_name, 
            (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) as current_participants
            FROM programs p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.id = {$id}";
    
    $result = $conn->query($sql);
    
    $program = null;
    if ($result && $result->num_rows > 0) {
        $program = $result->fetch_assoc();
    }
    
    $conn->close();
    return $program;
}

// 프로그램 추가
function add_program($data) {
    $conn = get_db_connection();
    
    $title = $conn->real_escape_string($data['title']);
    $description = $conn->real_escape_string($data['description']);
    $category_id = $conn->real_escape_string($data['category_id']);
    $date = $conn->real_escape_string($data['date']);
    $price = $conn->real_escape_string($data['price']);
    $max_participants = $conn->real_escape_string($data['max_participants']);
    $min_participants = $conn->real_escape_string($data['min_participants']);
    $status = $conn->real_escape_string($data['status']);
    
    // 옵션 필드 처리
    $min_age = isset($data['min_age']) ? $conn->real_escape_string($data['min_age']) : 0;
    $max_age = isset($data['max_age']) ? $conn->real_escape_string($data['max_age']) : 24;
    $duration = isset($data['duration']) ? $conn->real_escape_string($data['duration']) : 60;
    
    // 이미지 경로 처리
    $image_path_str = '';
    $image_path_value = '';
    if (isset($data['image_path']) && !empty($data['image_path'])) {
        $image_path = $conn->real_escape_string($data['image_path']);
        $image_path_str = ', image_path';
        $image_path_value = ", '{$image_path}'";
    }
    
    $sql = "INSERT INTO programs (title, description, category_id, date, min_age, max_age, price, max_participants, min_participants, duration, status{$image_path_str}) 
            VALUES ('{$title}', '{$description}', {$category_id}, '{$date}', {$min_age}, {$max_age}, {$price}, {$max_participants}, {$min_participants}, {$duration}, '{$status}'{$image_path_value})";
    
    $result = $conn->query($sql);
    $id = $result ? $conn->insert_id : null;
    
    $conn->close();
    return $id;
}

// 프로그램 상태 업데이트
function update_program_status($id, $status) {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    $status = $conn->real_escape_string($status);
    
    $sql = "UPDATE programs SET status = '{$status}' WHERE id = {$id}";
    $result = $conn->query($sql);
    
    $conn->close();
    return $result;
}

// 프로그램 카테고리 변경
function change_program_category($program_id, $category_id) {
    $conn = get_db_connection();
    $program_id = $conn->real_escape_string($program_id);
    $category_id = $conn->real_escape_string($category_id);
    
    // 프로그램 카테고리 변경
    $sql = "UPDATE programs SET category_id = {$category_id} WHERE id = {$program_id}";
    $result = $conn->query($sql);
    
    // 변경 이력 기록
    if ($result) {
        $sql = "INSERT INTO program_categories (program_id, category_id) VALUES ({$program_id}, {$category_id})";
        $conn->query($sql);
    }
    
    $conn->close();
    return $result;
}

// 특정 등록 정보 가져오기
function get_registration($id) {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    
    $sql = "SELECT r.*, p.title as program_title, p.date as program_date, p.price
            FROM registrations r
            LEFT JOIN programs p ON r.program_id = p.id
            WHERE r.id = {$id}";
    
    $result = $conn->query($sql);
    
    $registration = null;
    if ($result && $result->num_rows > 0) {
        $registration = $result->fetch_assoc();
    }
    
    $conn->close();
    return $registration;
}

// 사용자별 등록 정보 가져오기
function get_user_registrations($email) {
    if (empty($email)) {
        return [];
    }
    
    $conn = get_db_connection();
    $email = $conn->real_escape_string($email);
    
    // 이메일로만 조회 (데이터베이스 호환성 문제 해결)
    $sql = "SELECT r.*, p.title as program_title, p.price, p.date as program_date, p.status as program_status,
                  c.name as category_name
            FROM registrations r
            LEFT JOIN programs p ON r.program_id = p.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE r.email = '{$email}'
            ORDER BY r.created_at DESC";
    
    $result = $conn->query($sql);
    
    if (!$result) {
        error_log("등록 정보 조회 오류: " . $conn->error . " (SQL: {$sql})");
        return [];
    }
    
    $registrations = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $registrations[] = $row;
        }
    }
    
    $conn->close();
    return $registrations;
}

// 등록 정보 추가
function add_registration($data) {
    $conn = get_db_connection();
    
    $program_id = $conn->real_escape_string($data['program_id']);
    $child_name = $conn->real_escape_string($data['child_name']);
    $child_age = $conn->real_escape_string($data['child_age']);
    $parent_name = $conn->real_escape_string($data['parent_name']);
    $phone = $conn->real_escape_string($data['phone']);
    $email = $conn->real_escape_string($data['email']);
    $notes = isset($data['notes']) ? $conn->real_escape_string($data['notes']) : '';
    $payment_status = isset($data['payment_status']) ? $conn->real_escape_string($data['payment_status']) : 'pending';
    
    // 테이블 구조 확인 - user_id 필드 존재 여부 체크
    $check_column_sql = "SHOW COLUMNS FROM registrations LIKE 'user_id'";
    $check_result = $conn->query($check_column_sql);
    $has_user_id_column = $check_result && $check_result->num_rows > 0;
    
    // SQL 문 생성 - user_id 필드가 있는 경우와 없는 경우 분기 처리
    if ($has_user_id_column && isset($data['user_id'])) {
        $user_id = $conn->real_escape_string($data['user_id']);
        $user_id_value = $user_id === 'NULL' ? "NULL" : "{$user_id}";
        
        $sql = "INSERT INTO registrations (program_id, child_name, child_age, parent_name, phone, email, notes, payment_status, user_id) 
                VALUES ({$program_id}, '{$child_name}', {$child_age}, '{$parent_name}', '{$phone}', '{$email}', '{$notes}', '{$payment_status}', {$user_id_value})";
    } else {
        // user_id 필드가 없는 경우 - 필드를 제외
        $sql = "INSERT INTO registrations (program_id, child_name, child_age, parent_name, phone, email, notes, payment_status) 
                VALUES ({$program_id}, '{$child_name}', {$child_age}, '{$parent_name}', '{$phone}', '{$email}', '{$notes}', '{$payment_status}')";
    }
    
    error_log("등록 SQL: " . $sql); // 디버깅용 로그
    
    $result = $conn->query($sql);
    
    if (!$result) {
        error_log("등록 오류: " . $conn->error); // 오류 로깅
    }
    
    $id = $result ? $conn->insert_id : null;
    
    // 등록에 성공하면 프로그램 상태도 확인하여 업데이트
    if ($id) {
        update_program_status_by_registration($program_id);
    }
    
    $conn->close();
    return $id;
}

// 특정 프로그램의 참가자 수 가져오기
function get_program_participants_count($program_id) {
    $conn = get_db_connection();
    $program_id = $conn->real_escape_string($program_id);
    
    $sql = "SELECT COUNT(*) as count FROM registrations WHERE program_id = {$program_id}";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    
    $conn->close();
    return $row['count'];
}

// 등록 정보 결제 상태 업데이트
function update_registration_payment($registration_id, $payment_info) {
    $conn = get_db_connection();
    $registration_id = $conn->real_escape_string($registration_id);
    $payment_status = $conn->real_escape_string($payment_info['payment_status']);
    
    $payment_method = isset($payment_info['payment_method']) ? "'" . $conn->real_escape_string($payment_info['payment_method']) . "'" : 'NULL';
    $payment_id = isset($payment_info['payment_id']) ? "'" . $conn->real_escape_string($payment_info['payment_id']) . "'" : 'NULL';
    $paid_amount = isset($payment_info['paid_amount']) ? $conn->real_escape_string($payment_info['paid_amount']) : 'NULL';
    
    $sql = "UPDATE registrations SET 
            payment_status = '{$payment_status}'";
    
    if ($payment_method != 'NULL') {
        $sql .= ", payment_method = {$payment_method}";
    }
    
    if ($payment_id != 'NULL') {
        $sql .= ", payment_id = {$payment_id}";
    }
    
    if ($paid_amount != 'NULL') {
        $sql .= ", paid_amount = {$paid_amount}";
    }
    
    $sql .= " WHERE id = {$registration_id}";
    
    $result = $conn->query($sql);
    
    // 해당 프로그램의 참가자 수 확인 후 프로그램 상태 업데이트
    if ($result) {
        $sql = "SELECT program_id FROM registrations WHERE id = {$registration_id}";
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $program_id = $row['program_id'];
            update_program_status_by_registration($program_id);
        }
    }
    
    $conn->close();
    return $result;
}

// 특정 결제 정보 가져오기
function get_payment($id) {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    
    $sql = "SELECT * FROM payments WHERE id = {$id}";
    $result = $conn->query($sql);
    
    $payment = null;
    if ($result && $result->num_rows > 0) {
        $payment = $result->fetch_assoc();
    }
    
    $conn->close();
    return $payment;
}

// 주문 ID로 결제 정보 가져오기
function get_payment_by_order_id($order_id) {
    $conn = get_db_connection();
    $order_id = $conn->real_escape_string($order_id);
    
    $sql = "SELECT * FROM payments WHERE order_id = '{$order_id}'";
    $result = $conn->query($sql);
    
    $payment = null;
    if ($result && $result->num_rows > 0) {
        $payment = $result->fetch_assoc();
    }
    
    $conn->close();
    return $payment;
}

// 특정 카테고리에 속한 프로그램 개수 가져오기
function count_programs_by_category($category_id) {
    $conn = get_db_connection();
    $category_id = $conn->real_escape_string($category_id);
    
    $sql = "SELECT COUNT(*) as count FROM programs WHERE category_id = {$category_id}";
    $result = $conn->query($sql);
    
    $count = 0;
    if ($result && $result->num_rows > 0) {
        $count = $result->fetch_assoc()['count'];
    }
    
    $conn->close();
    return $count;
}

// 프로그램별 신청자 목록 가져오기
function get_program_registrations($program_id) {
    $conn = get_db_connection();
    $program_id = $conn->real_escape_string($program_id);
    
    $sql = "SELECT r.* 
            FROM registrations r
            WHERE r.program_id = {$program_id}
            ORDER BY r.created_at DESC";
    
    $result = $conn->query($sql);
    $registrations = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $registrations[] = $row;
        }
    }
    
    $conn->close();
    return $registrations;
}

// 관리자 대시보드 통계 정보 가져오기
function get_admin_dashboard_stats() {
    $conn = get_db_connection();
    $stats = array();
    
    // 총 프로그램 수
    $sql = "SELECT COUNT(*) as count FROM programs";
    $result = $conn->query($sql);
    $stats['total_programs'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['count'] : 0;
    
    // 활성 프로그램 수
    $sql = "SELECT COUNT(*) as count FROM programs WHERE status = 'active'";
    $result = $conn->query($sql);
    $stats['active_programs'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['count'] : 0;
    
    // 총 신청 건수
    $sql = "SELECT COUNT(*) as count FROM registrations";
    $result = $conn->query($sql);
    $stats['total_registrations'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['count'] : 0;
    
    // MySQL 오류 확인 및 로깅
    if ($conn->error) {
        error_log("MySQL 오류 (총 신청 건수): " . $conn->error);
    }
    
    // 결제 완료 건수 - payment_status 값이 'completed'인 경우도 포함
    $sql = "SELECT COUNT(*) as count FROM registrations WHERE payment_status IN ('paid', 'completed')";
    $result = $conn->query($sql);
    $stats['paid_registrations'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['count'] : 0;
    
    // MySQL 오류 확인 및 로깅
    if ($conn->error) {
        error_log("MySQL 오류 (결제 완료 건수): " . $conn->error);
    }
    
    // 프로그램별 신청자 현황
    $sql = "SELECT p.id, p.title, p.max_participants, p.min_participants,
            (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) AS total_registrations,
            (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id AND r.payment_status IN ('paid', 'completed')) AS paid_registrations,
            p.status, p.date
            FROM programs p
            ORDER BY p.date DESC";
    $result = $conn->query($sql);
    $stats['program_registrations'] = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // 프로그램 확정 여부 계산
            $is_confirmed = false;
            if ($row['status'] == 'active' && $row['paid_registrations'] >= $row['min_participants']) {
                $is_confirmed = true;
            }
            
            // 디버깅 정보 기록
            error_log("프로그램 ID: {$row['id']}, 제목: {$row['title']}, 신청 건수: {$row['total_registrations']}, 결제 건수: {$row['paid_registrations']}");
            
            $row['is_confirmed'] = $is_confirmed;
            $stats['program_registrations'][] = $row;
        }
    }
    
    // 최근 신청 내역 (최근 10건)
    $sql = "SELECT r.*, p.title as program_title 
            FROM registrations r
            JOIN programs p ON r.program_id = p.id
            ORDER BY r.created_at DESC 
            LIMIT 10";
    $result = $conn->query($sql);
    
    // 디버깅 정보 로그
    error_log("최근 신청 내역 쿼리: " . $sql);
    if ($conn->error) {
        error_log("SQL 오류: " . $conn->error);
    }
    error_log("쿼리 결과 행 수: " . ($result ? $result->num_rows : 0));
    
    $stats['recent_registrations'] = array();
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            error_log("등록 정보 ID: " . $row['id'] . ", 프로그램: " . $row['program_title'] . ", 아동: " . $row['child_name']);
            $stats['recent_registrations'][] = $row;
        }
    }
    
    $conn->close();
    return $stats;
}

// 결제 정보 추가
function add_payment($data) {
    $conn = get_db_connection();
    
    $registration_id = $conn->real_escape_string($data['registration_id']);
    $status = $conn->real_escape_string($data['status']);
    $amount = $conn->real_escape_string($data['amount']);
    $method = $conn->real_escape_string($data['method']);
    $order_id = $conn->real_escape_string($data['order_id']);
    $order_name = $conn->real_escape_string($data['order_name']);
    
    $payment_key = isset($data['payment_key']) ? "'" . $conn->real_escape_string($data['payment_key']) . "'" : 'NULL';
    $approved_at = isset($data['approved_at']) ? "'" . $conn->real_escape_string($data['approved_at']) . "'" : 'NULL';
    $receipt_url = isset($data['receipt_url']) ? "'" . $conn->real_escape_string($data['receipt_url']) . "'" : 'NULL';
    $extra_data = isset($data['extra_data']) ? "'" . $conn->real_escape_string($data['extra_data']) . "'" : 'NULL';
    
    $sql = "INSERT INTO payments (registration_id, status, amount, method, order_id, order_name, payment_key, approved_at, receipt_url, extra_data) 
            VALUES ({$registration_id}, '{$status}', {$amount}, '{$method}', '{$order_id}', '{$order_name}', {$payment_key}, {$approved_at}, {$receipt_url}, {$extra_data})";
    
    $result = $conn->query($sql);
    $id = $result ? $conn->insert_id : null;
    
    // 등록 정보 결제 상태 업데이트
    if ($id) {
        $sql = "UPDATE registrations SET 
                payment_status = '{$status}', 
                payment_method = '{$method}', 
                payment_id = '{$order_id}', 
                paid_amount = {$amount} 
                WHERE id = {$registration_id}";
        $conn->query($sql);
    }
    
    $conn->close();
    return $id;
}

// 결제 정보 업데이트
function update_payment($id, $data) {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    
    $fields = [];
    
    if (isset($data['status'])) {
        $status = $conn->real_escape_string($data['status']);
        $fields[] = "status = '{$status}'";
    }
    
    if (isset($data['payment_key'])) {
        $payment_key = $conn->real_escape_string($data['payment_key']);
        $fields[] = "payment_key = '{$payment_key}'";
    }
    
    if (isset($data['approved_at'])) {
        $approved_at = $conn->real_escape_string($data['approved_at']);
        $fields[] = "approved_at = '{$approved_at}'";
    }
    
    if (isset($data['receipt_url'])) {
        $receipt_url = $conn->real_escape_string($data['receipt_url']);
        $fields[] = "receipt_url = '{$receipt_url}'";
    }
    
    if (isset($data['extra_data'])) {
        $extra_data = $conn->real_escape_string($data['extra_data']);
        $fields[] = "extra_data = '{$extra_data}'";
    }
    
    if (empty($fields)) {
        return false;
    }
    
    $sql = "UPDATE payments SET " . implode(', ', $fields) . " WHERE id = {$id}";
    $result = $conn->query($sql);
    
    // 결제 상태가 변경된 경우 등록 정보 업데이트
    if ($result && isset($data['status'])) {
        $sql = "SELECT registration_id FROM payments WHERE id = {$id}";
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $registration_id = $row['registration_id'];
            
            $sql = "UPDATE registrations SET payment_status = '{$status}' WHERE id = {$registration_id}";
            $conn->query($sql);
            
            // 프로그램 상태 업데이트
            $sql = "SELECT program_id FROM registrations WHERE id = {$registration_id}";
            $result = $conn->query($sql);
            
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $program_id = $row['program_id'];
                update_program_status_by_registration($program_id);
            }
        }
    }
    
    $conn->close();
    return $result;
}

// 특정 등록에 대한 결제 정보 목록 가져오기
function get_payments_by_registration($registration_id) {
    $conn = get_db_connection();
    $registration_id = $conn->real_escape_string($registration_id);
    
    $sql = "SELECT * FROM payments WHERE registration_id = {$registration_id} ORDER BY requested_at DESC";
    $result = $conn->query($sql);
    
    $payments = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $payments[] = $row;
        }
    }
    
    $conn->close();
    return $payments;
}

// 프로그램 참가자 수에 따른 상태 업데이트
function update_program_status_by_registration($program_id) {
    $conn = get_db_connection();
    $program_id = $conn->real_escape_string($program_id);
    
    // 프로그램 정보 가져오기
    $sql = "SELECT min_participants, max_participants FROM programs WHERE id = {$program_id}";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $program = $result->fetch_assoc();
        
        // 결제 완료된 참가자 수 가져오기
        $sql = "SELECT COUNT(*) as count FROM registrations 
                WHERE program_id = {$program_id} AND payment_status = 'completed'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $confirmed_participants = $row['count'];
        
        // 프로그램 상태 업데이트
        $status = 'pending';
        
        if ($confirmed_participants >= $program['min_participants']) {
            $status = 'confirmed';
        }
        
        if ($confirmed_participants >= $program['max_participants']) {
            $status = 'full';
        }
        
        $sql = "UPDATE programs SET status = '{$status}' WHERE id = {$program_id}";
        $conn->query($sql);
    }
    
    $conn->close();
}

// 사용자 정보 가져오기
function get_user($id) {
    $conn = get_db_connection();
    $id = $conn->real_escape_string($id);
    
    $sql = "SELECT * FROM users WHERE id = {$id}";
    $result = $conn->query($sql);
    
    $user = null;
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // 사용자 테이블에 필요한 필드가 있는지 확인하고 없으면 기본값 설정
        $check_columns = ['name', 'email', 'phone'];
        foreach ($check_columns as $column) {
            if (!array_key_exists($column, $user)) {
                $user[$column] = '';
            }
        }
    }
    
    $conn->close();
    return $user;
}

// 사용자명으로 사용자 정보 가져오기
function get_user_by_username($username) {
    $conn = get_db_connection();
    $username = $conn->real_escape_string($username);
    
    $sql = "SELECT * FROM users WHERE username = '{$username}'";
    $result = $conn->query($sql);
    
    $user = null;
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
    }
    
    $conn->close();
    return $user;
}

// 사용자 등록 함수
function register_user($username, $password, $name = '', $email = '', $phone = '') {
    $conn = get_db_connection();
    
    // 사용자명 중복 확인
    $sql = "SELECT id FROM users WHERE username = '" . $conn->real_escape_string($username) . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $conn->close();
        return ['success' => false, 'message' => '이미 사용 중인 아이디입니다.'];
    }
    
    // 비밀번호 해싱
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // 사용자 테이블 컬럼 확인
    $sql = "SHOW COLUMNS FROM users";
    $result = $conn->query($sql);
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    
    // 기본 필드 (username, password, is_admin)
    $fields = ['username', 'password', 'is_admin'];
    $values = ["'" . $conn->real_escape_string($username) . "'", 
               "'" . $conn->real_escape_string($hashed_password) . "'", 
               "0"];
    
    // 추가 필드 (name, email, phone이 테이블에 있는 경우에만)
    if (in_array('name', $columns) && !empty($name)) {
        $fields[] = 'name';
        $values[] = "'" . $conn->real_escape_string($name) . "'";
    }
    
    if (in_array('email', $columns) && !empty($email)) {
        $fields[] = 'email';
        $values[] = "'" . $conn->real_escape_string($email) . "'";
    }
    
    if (in_array('phone', $columns) && !empty($phone)) {
        $fields[] = 'phone';
        $values[] = "'" . $conn->real_escape_string($phone) . "'";
    }
    
    // SQL 쿼리 생성
    $sql = "INSERT INTO users (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $values) . ")";
    
    if ($conn->query($sql)) {
        $user_id = $conn->insert_id;
        $conn->close();
        return ['success' => true, 'user_id' => $user_id];
    } else {
        $conn->close();
        return ['success' => false, 'message' => '사용자 등록 중 오류가 발생했습니다: ' . $conn->error];
    }
}

// 사용자 로그인 함수
function login_user($username, $password) {
    $conn = get_db_connection();
    $username = $conn->real_escape_string($username);
    
    $sql = "SELECT * FROM users WHERE username = '{$username}'";
    $result = $conn->query($sql);
    
    if ($result->num_rows === 0) {
        $conn->close();
        return ['success' => false, 'message' => '존재하지 않는 사용자입니다.'];
    }
    
    $user = $result->fetch_assoc();
    $conn->close();
    
    if (password_verify($password, $user['password'])) {
        // 세션에 사용자 정보 저장
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['is_admin'] = $user['is_admin'];
        
        return [
            'success' => true,
            'user_id' => $user['id'],
            'is_admin' => $user['is_admin']
        ];
    } else {
        return ['success' => false, 'message' => '비밀번호가 일치하지 않습니다.'];
    }
}

// 사용자 정보 업데이트
function update_user($user_id, $data) {
    $conn = get_db_connection();
    $user_id = $conn->real_escape_string($user_id);
    
    // 사용자 테이블 컬럼 확인
    $sql = "SHOW COLUMNS FROM users";
    $result = $conn->query($sql);
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    
    $updates = [];
    
    // 이름 업데이트
    if (isset($data['name']) && in_array('name', $columns)) {
        $name = $conn->real_escape_string($data['name']);
        $updates[] = "name = '{$name}'";
    }
    
    // 이메일 업데이트
    if (isset($data['email']) && in_array('email', $columns)) {
        $email = $conn->real_escape_string($data['email']);
        $updates[] = "email = '{$email}'";
    }
    
    // 전화번호 업데이트
    if (isset($data['phone']) && in_array('phone', $columns)) {
        $phone = $conn->real_escape_string($data['phone']);
        $updates[] = "phone = '{$phone}'";
    }
    
    // 비밀번호 업데이트
    if (isset($data['password']) && !empty($data['password'])) {
        $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
        $updates[] = "password = '{$hashed_password}'";
    }
    
    if (empty($updates)) {
        $conn->close();
        return ['success' => false, 'message' => '업데이트할 정보가 없습니다.'];
    }
    
    $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = {$user_id}";
    $result = $conn->query($sql);
    
    if ($result) {
        $conn->close();
        return ['success' => true, 'message' => '사용자 정보가 업데이트되었습니다.'];
    } else {
        $conn->close();
        return ['success' => false, 'message' => '사용자 정보 업데이트 중 오류가 발생했습니다: ' . $conn->error];
    }
}