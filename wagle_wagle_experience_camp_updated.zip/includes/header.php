<?php
// 세션이 시작되지 않은 경우에만 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 기본 URL 설정
$base_url = "http://localhost/paju";

// 현재 페이지 확인
$current_page = isset($_GET['page']) ? $_GET['page'] : 'home';

// 사용자 로그인 상태 확인 - 명확하게 세션 변수 체크
$is_logged_in = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

// 디버그 정보 (개발 중에만 사용, 실 서비스에서는 제거)
// echo "<!-- DEBUG: 로그인 상태: " . ($is_logged_in ? "로그인됨" : "로그인 안됨") . " -->";
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>파주 체험 Camp - 유아, 어린이 체험 프로그램</title>
    <meta name="description" content="유아, 어린이를 위한 도시텃밭, 영어놀이, 스포츠 체험 프로그램을 만나보세요. 아이들의 창의력과 상상력을 키우는 체험 프로그램.">
    
    <!-- 오픈그래프 태그 -->
    <meta property="og:title" content="파주 체험 Camp - 유아, 어린이 체험 프로그램">
    <meta property="og:description" content="유아, 어린이를 위한 도시텃밭, 영어놀이, 스포츠 체험 프로그램을 만나보세요.">
    <meta property="og:image" content="<?php echo $base_url; ?>/assets/img/program-default.jpg">
    <meta property="og:url" content="<?php echo $base_url; ?>">
    <meta property="og:type" content="website">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- 폰트어썸 아이콘 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- 구글 폰트: Noto Sans KR -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- 커스텀 CSS -->
    <link href="<?php echo $base_url; ?>/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- 상단 내비게이션 바 -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <!-- 로고 -->
            <a class="navbar-brand" href="index.php">
                <span class="text-primary">파주 체험 Camp</span>
            </a>
            
            <!-- 모바일 토글 버튼 -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- 내비게이션 링크 -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'home' ? 'active' : ''; ?>" href="index.php">
                            홈
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'program_selection' ? 'active' : ''; ?>" href="index.php?page=program_selection">
                            체험프로그램
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'shop' ? 'active' : ''; ?>" href="index.php?page=shop">
                            와글와글쇼핑
                        </a>
                    </li>
                </ul>
                
                <div class="d-flex align-items-center">
                    <!-- 장바구니 아이콘 -->
                    <a href="index.php?page=cart" class="btn btn-outline-success me-2 position-relative">
                        장바구니
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="cart-count">
                            0
                        </span>
                    </a>
                    <?php if($is_logged_in): ?>
                        <?php if($is_admin): ?>
                            <a href="index.php?page=admin_dashboard" class="btn btn-outline-primary me-2">
                                관리자
                            </a>
                        <?php else: ?>
                            <a href="index.php?page=my_page" class="btn btn-outline-primary me-2">
                                마이페이지
                            </a>
                        <?php endif; ?>
                        <a href="index.php?page=logout" class="btn btn-outline-secondary">
                            로그아웃
                        </a>
                    <?php else: ?>
                        <a href="index.php?page=login" class="btn btn-outline-primary me-2">
                            로그인
                        </a>
                        <a href="index.php?page=register" class="btn btn-primary">
                            가입하기
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- 메인 콘텐츠 -->
    <main class="py-4">

<script>
// 장바구니 개수 업데이트 함수
async function updateCartCount() {
    try {
        const response = await fetch('api/cart_count.php');
        const result = await response.json();
        
        if (result.success) {
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = result.count;
                // 카운트가 0이면 숨기고, 0이 아니면 표시
                if (result.count > 0) {
                    cartCountElement.style.display = 'inline';
                } else {
                    cartCountElement.style.display = 'none';
                }
            }
        }
    } catch (error) {
        console.error('Cart count update error:', error);
    }
}

// 페이지 로드시 장바구니 개수 업데이트
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
});

// 전역 함수로 등록하여 다른 페이지에서도 사용 가능
window.updateCartCount = updateCartCount;
</script>