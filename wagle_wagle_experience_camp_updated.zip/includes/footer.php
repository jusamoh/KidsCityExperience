    </main>
    
    <!-- 푸터 -->
    <footer class="bg-dark text-white mt-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-md-4 footer-column">
                    <h5>파주 체험 Camp</h5>
                    <p> 6살 이상 유아, 어린이를 위한 체험 프로그램을 제공합니다. 아이의 성장과 발달을 돕는 파주 체험 Camp와 함께하세요.</p>
                    <div class="social-links mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-youtube"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-kakao"></i></a>
                    </div>
                </div>
                
                <div class="col-md-4 footer-column">
                    <h5>빠른 링크</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php?page=program_selection" class="text-white">체험 프로그램</a></li>
                        <li><a href="index.php?page=faq" class="text-white">자주 묻는 질문</a></li>
                        <li><a href="index.php?page=how_to_use" class="text-white">이용 방법</a></li>
                        <li><a href="index.php?page=refund_policy" class="text-white">환불 정책</a></li>
                        <li><a href="index.php?page=terms_of_service" class="text-white">이용약관</a></li>
                        <li><a href="index.php?page=privacy_policy" class="text-white">개인정보처리방침</a></li>
                    </ul>
                </div>
                
                <div class="col-md-4 footer-column">
                    <h5>연락처</h5>
                    <ul class="list-unstyled contact-info">
                        <li><i class="fas fa-map-marker-alt me-2"></i> 경기도 파주시 송촌동 소라지로 234번길 24</li>
                        <li><i class="fas fa-phone me-2"></i> 031-123-4567</li>
                        <li><i class="fas fa-envelope me-2"></i> info@paju.kr</li>
                        <li><i class="fas fa-clock me-2"></i> 평일 09:00 - 18:00</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom text-center mt-4 pt-4 border-top border-secondary">
                <p>&copy; 2025 파주 체험 Camp. All Rights Reserved.</p>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- 커스텀 자바스크립트 -->
    <script src="<?php echo $base_url; ?>/js/scripts.js"></script>
</body>
</html>