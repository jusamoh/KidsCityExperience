-- 쇼핑몰 관련 테이블 생성

-- 상품 카테고리 테이블
CREATE TABLE IF NOT EXISTS shop_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 상품 테이블
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,0) NOT NULL,
    stock_quantity INT DEFAULT 0,
    category_id INT,
    image_url VARCHAR(500),
    age_group VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES shop_categories(id)
);

-- 장바구니 테이블
CREATE TABLE IF NOT EXISTS cart_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    product_id INT,
    quantity INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_product (user_id, product_id)
);

-- 주문 테이블
CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    order_number VARCHAR(50) UNIQUE,
    total_amount DECIMAL(10,0) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    shipping_address TEXT,
    phone VARCHAR(20),
    recipient_name VARCHAR(100),
    payment_method VARCHAR(50),
    payment_status VARCHAR(20) DEFAULT 'pending',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 주문 상세 테이블
CREATE TABLE IF NOT EXISTS order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id INT,
    quantity INT,
    price DECIMAL(10,0),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- 기본 상품 카테고리 데이터 삽입
INSERT IGNORE INTO shop_categories (name, description) VALUES
('도서/교재', '유아 및 어린이를 위한 교육 도서와 교재'),
('교구/완구', '창의력과 학습을 도와주는 교육용 교구 및 완구'),
('미술용품', '그리기, 만들기 등 창작 활동을 위한 미술 도구'),
('음악교구', '음악 감상과 연주를 위한 악기 및 교구'),
('체육용품', '신체 발달을 위한 운동 기구 및 체육 도구'),
('생활용품', '안전하고 실용적인 유아용 생활 용품');

-- 샘플 상품 데이터 삽입
INSERT IGNORE INTO products (name, description, price, stock_quantity, category_id, age_group, image_url) VALUES
('갈색 곰아 갈색 곰아 무엇을 보고 있니?', '에릭 칼의 대표작으로 색깔과 동물을 배울 수 있는 영어 그림책', 15000, 50, 1, '2-5세', 'assets/img/brown_bear.jpg'),
('무지개 물고기', '친구와의 우정을 배울 수 있는 아름다운 그림책', 18000, 30, 1, '3-7세', 'assets/img/rainbow-fish.jpg'),
('배고픈 애벌레', '요일과 숫자를 배우며 성장을 이해하는 그림책', 16000, 40, 1, '2-6세', 'assets/img/The Very Hungry Caterpillar.jpg'),
('원목 블록 세트 (100피스)', '상상력과 창의력을 기르는 천연 원목 블록', 45000, 20, 2, '3-8세', 'assets/img/program-1.jpg'),
('유아용 크레파스 24색', '안전한 소재로 만든 유아 전용 크레파스', 12000, 80, 3, '2-8세', 'assets/img/program-3.jpg'),
('미니 실로폰', '음감 발달을 위한 아이들용 실로폰', 35000, 25, 4, '3-10세', 'assets/img/program-4.jpg'),
('균형 잡기 보드', '균형감각과 코어 근육 발달을 위한 보드', 55000, 15, 5, '4-10세', 'assets/img/program-5.jpg'),
('안전 가위 세트', '둥근 날로 안전하게 만들어진 유아용 가위', 8000, 60, 3, '4-8세', 'assets/img/program-default.jpg'),
('소프트 공 세트 (6개)', '부드러운 재질의 안전한 놀이용 공', 25000, 35, 5, '1-6세', 'assets/img/program-11.jpg'),
('퍼즐 매트 (알파벳)', 'EVA 소재의 안전한 알파벳 학습 매트', 32000, 40, 2, '2-7세', 'assets/img/program-61.jpg');