# XAMPP 환경 설치 가이드

## 시스템 요구사항
- Windows 10/11
- XAMPP 8.0 이상
- PHP 8.0 이상
- MySQL 8.0 이상

## 1. XAMPP 설치
1. https://www.apachefriends.org/download.html 에서 XAMPP 다운로드
2. XAMPP 설치 (기본 설정으로 C:\xampp에 설치)
3. Apache와 MySQL 서비스 시작
4. MySQL root 비밀번호 설정:
   - XAMPP Control Panel에서 MySQL의 "Admin" 버튼 클릭
   - phpMyAdmin에서 "사용자 계정" → "root" → "비밀번호 변경"
   - 새 비밀번호: `$jusam3329OH` 입력 후 저장

## 2. 프로젝트 설치
1. 이 폴더의 모든 파일을 `C:\xampp\htdocs\paju\` 에 복사
2. 브라우저에서 `http://localhost/paju` 접속

## 3. 데이터베이스 설정
- MySQL root 비밀번호: `$jusam3329OH`
- 데이터베이스는 자동으로 생성됩니다 (paju_db)
- 기본 관리자 계정: username=admin, password=admin
- phpMyAdmin 접속: http://localhost/phpmyadmin (root/$jusam3329OH로 로그인)

## 4. 폴더 구조
```
C:\xampp\htdocs\paju\
├── index.php              (메인 페이지)
├── config.php             (환경 설정)
├── config/
│   └── database.php       (데이터베이스 설정)
├── includes/
│   ├── functions.php      (공통 함수)
│   ├── header.php         (헤더)
│   └── footer.php         (푸터)
├── pages/                 (각 페이지 파일들)
├── assets/                (CSS, JS, 이미지)
└── api/                   (API 엔드포인트)
```

## 5. 주요 기능
- 프로그램 등록 및 관리
- 사용자 등록 및 로그인
- 결제 시스템 (TossPayments)
- 관리자 대시보드

## 6. 문제 해결
- Apache 포트 충돌: 포트 80을 다른 프로그램이 사용 중인 경우 포트 변경
- MySQL 접속 오류: XAMPP Control Panel에서 MySQL 서비스 재시작
- 파일 권한 오류: C:\xampp\htdocs\paju 폴더에 읽기/쓰기 권한 확인

## 7. 결제 시스템 설정
실제 운영 시 config.php에서 TossPayments 키를 실제 키로 변경해야 합니다:
```php
define('TOSS_CLIENT_KEY', '실제_클라이언트_키');
define('TOSS_SECRET_KEY', '실제_시크릿_키');
define('PAYMENT_MODE', 'live');
```