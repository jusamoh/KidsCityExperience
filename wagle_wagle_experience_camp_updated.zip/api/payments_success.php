<?php
require_once '../config.php';
header('Content-Type: application/json');

// 결제 성공 처리 API
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // 토스페이먼츠에서 전달받은 파라미터
        $paymentKey = isset($_GET['paymentKey']) ? $_GET['paymentKey'] : null;
        $orderId = isset($_GET['orderId']) ? $_GET['orderId'] : null;
        $amount = isset($_GET['amount']) ? intval($_GET['amount']) : 0;
        
        if (!$paymentKey || !$orderId || $amount <= 0) {
            throw new Exception('필수 정보가 누락되었습니다.');
        }
        
        // 결제 정보 조회
        $stmt = $pdo->prepare("SELECT * FROM payments WHERE order_id = ?");
        $stmt->execute([$orderId]);
        $payment = $stmt->fetch();
        
        if (!$payment) {
            throw new Exception('결제 정보를 찾을 수 없습니다.');
        }
        
        // 금액 확인
        if ($payment['amount'] != $amount) {
            throw new Exception('결제 금액이 일치하지 않습니다.');
        }
        
        // 토스페이먼츠 API에 결제 승인 요청
        $curl = curl_init();
        
        $basicAuth = base64_encode("{$TOSS_PAYMENTS_SECRET_KEY}:");
        
        curl_setopt_array($curl, [
            CURLOPT_URL => "{$TOSS_PAYMENTS_API_URL}/payments/{$paymentKey}",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode([
                'orderId' => $orderId,
                'amount' => $amount
            ]),
            CURLOPT_HTTPHEADER => [
                "Authorization: Basic {$basicAuth}",
                "Content-Type: application/json"
            ],
        ]);
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        if ($httpCode != 200) {
            throw new Exception('토스페이먼츠 결제 승인 실패: ' . $response);
        }
        
        $tossResponse = json_decode($response, true);
        
        // 결제 정보 업데이트
        $stmt = $pdo->prepare("UPDATE payments 
                              SET payment_key = ?, method = ?, status = ?, approved_at = NOW(), 
                                  receipt_url = ?, extra_data = ? 
                              WHERE id = ?");
        $stmt->execute([
            $paymentKey,
            $tossResponse['method'],
            'paid',
            isset($tossResponse['receipt']['url']) ? $tossResponse['receipt']['url'] : null,
            $response,
            $payment['id']
        ]);
        
        // 등록 정보 업데이트
        $stmt = $pdo->prepare("UPDATE registrations 
                              SET payment_status = ?, payment_method = ?, payment_id = ?, paid_amount = ? 
                              WHERE id = ?");
        $stmt->execute([
            'paid',
            $tossResponse['method'],
            $paymentKey,
            $amount,
            $payment['registration_id']
        ]);
        
        // 성공 페이지로 리디렉션
        header("Location: {$SITE_URL}/payment_success.php?orderId={$orderId}");
        
    } catch (Exception $e) {
        // 실패 페이지로 리디렉션
        $errorMessage = urlencode($e->getMessage());
        header("Location: {$SITE_URL}/payment_fail.php?orderId={$orderId}&message={$errorMessage}");
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => '허용되지 않은 메소드입니다.']);
}
?>