<?php
require_once '../config.php';
header('Content-Type: application/json');

// 테스트 결제 처리 API
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['registrationId']) || !isset($data['amount']) || !isset($data['paymentKey']) || !isset($data['orderId'])) {
            throw new Exception('필수 정보가 누락되었습니다.');
        }
        
        $registrationId = intval($data['registrationId']);
        $amount = intval($data['amount']);
        $paymentKey = $data['paymentKey'];
        $orderId = $data['orderId'];
        
        // 등록 정보 조회
        $stmt = $pdo->prepare("SELECT * FROM registrations WHERE id = ?");
        $stmt->execute([$registrationId]);
        $registration = $stmt->fetch();
        
        if (!$registration) {
            throw new Exception('등록 정보를 찾을 수 없습니다.');
        }
        
        // 주문명 생성
        $stmt = $pdo->prepare("SELECT title FROM programs WHERE id = ?");
        $stmt->execute([$registration['program_id']]);
        $program = $stmt->fetch();
        $orderName = isset($program['title']) ? 
            $program['title'] . " 신청 - " . $registration['child_name'] : 
            "테스트 결제 - " . $registration['child_name'];
        
        // 가상 결제 정보 생성
        $stmt = $pdo->prepare("INSERT INTO payments 
                              (registration_id, amount, method, status, payment_key, order_id, order_name, 
                               approved_at, extra_data) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)");
        $stmt->execute([
            $registrationId,
            $amount,
            'CARD',
            'paid',
            $paymentKey,
            $orderId,
            $orderName,
            json_encode([
                'type' => 'TEST_PAYMENT',
                'testPaymentKey' => $paymentKey,
                'testAmount' => $amount,
                'message' => '이것은 테스트 결제입니다.'
            ])
        ]);
        
        // 등록 정보에도 결제 상태 업데이트
        $stmt = $pdo->prepare("UPDATE registrations 
                              SET payment_status = ?, payment_method = ?, payment_id = ?, paid_amount = ? 
                              WHERE id = ?");
        $stmt->execute([
            'paid',
            'CARD',
            $paymentKey,
            $amount,
            $registrationId
        ]);
        
        // 프로그램 상태 업데이트 (수요 기반 프로그램 운영)
        updateProgramStatus($pdo, $registrationId);
        
        // 응답
        echo json_encode([
            'success' => true,
            'message' => '테스트 결제가 완료되었습니다.',
            'paymentKey' => $paymentKey,
            'orderId' => $orderId,
            'amount' => $amount
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => '허용되지 않은 메소드입니다.']);
}

// 프로그램 상태 업데이트 함수 (결제 검증 API와 동일)
function updateProgramStatus($pdo, $registrationId) {
    try {
        // 등록 정보에서 프로그램 ID 조회
        $stmt = $pdo->prepare("SELECT program_id FROM registrations WHERE id = ?");
        $stmt->execute([$registrationId]);
        $registration = $stmt->fetch();
        
        if (!$registration) {
            return;
        }
        
        $programId = $registration['program_id'];
        
        // 프로그램 정보 조회
        $stmt = $pdo->prepare("SELECT * FROM programs WHERE id = ?");
        $stmt->execute([$programId]);
        $program = $stmt->fetch();
        
        if (!$program) {
            return;
        }
        
        // 결제 완료된 등록 수 조회
        $stmt = $pdo->prepare("SELECT COUNT(*) as registration_count 
                               FROM registrations 
                               WHERE program_id = ? AND payment_status = 'paid'");
        $stmt->execute([$programId]);
        $result = $stmt->fetch();
        $registrationCount = $result['registration_count'];
        
        // 최소 참가자 수를 충족하면 프로그램 상태를 '확정'으로 변경
        if ($registrationCount >= $program['min_participants'] && $program['status'] === 'pending') {
            $stmt = $pdo->prepare("UPDATE programs SET status = 'confirmed' WHERE id = ?");
            $stmt->execute([$programId]);
        }
    } catch (Exception $e) {
        error_log('Failed to update program status: ' . $e->getMessage());
    }
}
?>