<?php
// cart_count.php - 장바구니 개수 조회 API

header('Content-Type: application/json');
session_start();

require_once '../config/database.php';

// 로그인하지 않은 경우 0 반환
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => true, 'count' => 0]);
    exit;
}

try {
    $conn = get_db_connection();
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("SELECT SUM(quantity) as total FROM cart_items WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    
    $count = $data['total'] ?: 0;
    
    $conn->close();
    
    echo json_encode(['success' => true, 'count' => $count]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'count' => 0, 'message' => $e->getMessage()]);
}
?>