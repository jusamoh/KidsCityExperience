<?php
// cart_update.php - 장바구니 수량 업데이트 API

header('Content-Type: application/json');
session_start();

require_once '../config/database.php';

// POST 요청만 허용
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'login_required']);
    exit;
}

// JSON 데이터 받기
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['cart_id']) || !isset($input['quantity'])) {
    echo json_encode(['success' => false, 'message' => '잘못된 요청입니다.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$cart_id = (int)$input['cart_id'];
$quantity = (int)$input['quantity'];

if ($quantity <= 0) {
    echo json_encode(['success' => false, 'message' => '수량은 1개 이상이어야 합니다.']);
    exit;
}

try {
    $conn = get_db_connection();
    
    // 장바구니 아이템과 상품 정보 확인
    $check_query = "
        SELECT ci.*, p.stock_quantity, p.name 
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.id
        WHERE ci.id = ? AND ci.user_id = ?
    ";
    
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("ii", $cart_id, $user_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => '장바구니 항목을 찾을 수 없습니다.']);
        exit;
    }
    
    $cart_item = $result->fetch_assoc();
    
    if ($quantity > $cart_item['stock_quantity']) {
        echo json_encode(['success' => false, 'message' => '재고가 부족합니다.']);
        exit;
    }
    
    // 수량 업데이트
    $update_stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
    $update_stmt->bind_param("ii", $quantity, $cart_id);
    $update_stmt->execute();
    
    $conn->close();
    
    echo json_encode(['success' => true, 'message' => '수량이 업데이트되었습니다.']);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => '오류가 발생했습니다: ' . $e->getMessage()]);
}
?>