<?php
require_once '../config.php';
header('Content-Type: application/json');

// 결제 취소 API
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['paymentId']) || !isset($data['reason'])) {
            throw new Exception('필수 정보가 누락되었습니다.');
        }
        
        $paymentId = intval($data['paymentId']);
        $reason = $data['reason'];
        
        // 결제 정보 조회
        $stmt = $pdo->prepare("SELECT * FROM payments WHERE id = ?");
        $stmt->execute([$paymentId]);
        $payment = $stmt->fetch();
        
        if (!$payment) {
            throw new Exception('결제 정보를 찾을 수 없습니다.');
        }
        
        if (!$payment['payment_key'] || $payment['status'] !== 'paid') {
            throw new Exception('취소할 수 있는 결제가 아닙니다.');
        }
        
        // 테스트 결제인지 확인
        $isTestPayment = strpos($payment['payment_key'], 'test_payment_') === 0;
        
        if (!$isTestPayment) {
            // 실제 토스페이먼츠 API에 결제 취소 요청
            $curl = curl_init();
            
            $basicAuth = base64_encode("{$TOSS_PAYMENTS_SECRET_KEY}:");
            
            curl_setopt_array($curl, [
                CURLOPT_URL => "{$TOSS_PAYMENTS_API_URL}/payments/{$payment['payment_key']}/cancel",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode([
                    'cancelReason' => $reason
                ]),
                CURLOPT_HTTPHEADER => [
                    "Authorization: Basic {$basicAuth}",
                    "Content-Type: application/json"
                ],
            ]);
            
            $response = curl_exec($curl);
            $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);
            
            if ($httpCode != 200) {
                throw new Exception('토스페이먼츠 결제 취소 실패: ' . $response);
            }
        }
        
        // 결제 정보 업데이트
        $stmt = $pdo->prepare("UPDATE payments SET status = 'canceled' WHERE id = ?");
        $stmt->execute([$paymentId]);
        
        // 등록 정보에도 결제 상태 업데이트
        $stmt = $pdo->prepare("UPDATE registrations SET payment_status = 'canceled' WHERE id = ?");
        $stmt->execute([$payment['registration_id']]);
        
        echo json_encode([
            'success' => true,
            'message' => '결제가 취소되었습니다.'
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => '허용되지 않은 메소드입니다.']);
}
?>