<?php
// payments_prepare.php - 결제 준비 API
header('Content-Type: application/json');
session_start();

require_once '../config/database.php';

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'login_required']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn = get_db_connection();
        $user_id = $_SESSION['user_id'];
        
        // 장바구니 상품들 조회
        $cart_query = "
            SELECT 
                ci.quantity,
                p.id as product_id,
                p.name,
                p.price,
                (ci.quantity * p.price) as subtotal
            FROM cart_items ci
            JOIN products p ON ci.product_id = p.id
            WHERE ci.user_id = ?
        ";
        
        $stmt = $conn->prepare($cart_query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $cart_items = [];
        $total_amount = 0;
        
        while ($row = $result->fetch_assoc()) {
            $cart_items[] = $row;
            $total_amount += $row['subtotal'];
        }
        
        if (empty($cart_items)) {
            throw new Exception('장바구니가 비어있습니다.');
        }
        
        // 고유한 주문 ID 생성
        $timestamp = time();
        $randomString = bin2hex(random_bytes(4));
        $orderId = "shop_order_{$timestamp}_{$randomString}";
        
        // 주문명 생성 (첫 번째 상품명 기준)
        $orderName = $cart_items[0]['name'];
        if (count($cart_items) > 1) {
            $orderName .= " 외 " . (count($cart_items) - 1) . "건";
        }
        
        // 주문 정보를 세션에 저장
        $_SESSION['pending_order'] = [
            'order_id' => $orderId,
            'order_name' => $orderName,
            'amount' => $total_amount,
            'items' => $cart_items
        ];
        
        // 결제 요청 데이터 생성
        $paymentData = [
            'amount' => $total_amount,
            'orderId' => $orderId,
            'orderName' => $orderName
        ];
        
        $conn->close();
        
        echo json_encode([
            'success' => true,
            'payment_data' => $paymentData
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>