<?php
// cart_add.php - 장바구니에 상품 추가 API

header('Content-Type: application/json');
session_start();

require_once '../config/database.php';

// POST 요청만 허용
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'login_required']);
    exit;
}

// JSON 데이터 받기
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['product_id'])) {
    echo json_encode(['success' => false, 'message' => '잘못된 요청입니다.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$product_id = (int)$input['product_id'];
$quantity = isset($input['quantity']) ? (int)$input['quantity'] : 1;

if ($quantity <= 0) {
    echo json_encode(['success' => false, 'message' => '수량은 1개 이상이어야 합니다.']);
    exit;
}

try {
    $conn = get_db_connection();
    
    // 상품 존재 및 재고 확인
    $product_check = $conn->prepare("SELECT stock_quantity, name FROM products WHERE id = ? AND is_active = 1");
    $product_check->bind_param("i", $product_id);
    $product_check->execute();
    $product_result = $product_check->get_result();
    
    if ($product_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => '존재하지 않는 상품입니다.']);
        exit;
    }
    
    $product = $product_result->fetch_assoc();
    
    if ($product['stock_quantity'] < $quantity) {
        echo json_encode(['success' => false, 'message' => '재고가 부족합니다.']);
        exit;
    }
    
    // 장바구니에 이미 있는 상품인지 확인
    $cart_check = $conn->prepare("SELECT id, quantity FROM cart_items WHERE user_id = ? AND product_id = ?");
    $cart_check->bind_param("ii", $user_id, $product_id);
    $cart_check->execute();
    $cart_result = $cart_check->get_result();
    
    if ($cart_result->num_rows > 0) {
        // 기존 상품 수량 업데이트
        $existing_item = $cart_result->fetch_assoc();
        $new_quantity = $existing_item['quantity'] + $quantity;
        
        if ($new_quantity > $product['stock_quantity']) {
            echo json_encode([
                'success' => false, 
                'message' => '재고 수량을 초과할 수 없습니다. (현재 재고: ' . $product['stock_quantity'] . '개)'
            ]);
            exit;
        }
        
        $update_stmt = $conn->prepare("UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE id = ?");
        $update_stmt->bind_param("ii", $new_quantity, $existing_item['id']);
        $update_stmt->execute();
        
        $message = '장바구니에 있는 상품의 수량이 ' . $new_quantity . '개로 증가했습니다.';
        
    } else {
        // 새 상품 추가
        $insert_stmt = $conn->prepare("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)");
        $insert_stmt->bind_param("iii", $user_id, $product_id, $quantity);
        $insert_stmt->execute();
        
        $message = '상품이 장바구니에 추가되었습니다.';
    }
    
    // 장바구니 총 개수 반환
    $count_stmt = $conn->prepare("SELECT SUM(quantity) as total FROM cart_items WHERE user_id = ?");
    $count_stmt->bind_param("i", $user_id);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $count_data = $count_result->fetch_assoc();
    $total_count = $count_data['total'] ?: 0;
    
    $conn->close();
    
    echo json_encode([
        'success' => true, 
        'message' => $message,
        'cart_count' => $total_count
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => '오류가 발생했습니다: ' . $e->getMessage()]);
}
?>