<?php
// create_order.php - 주문 생성 API

header('Content-Type: application/json');
session_start();

require_once '../config/database.php';

// POST 요청만 허용
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'login_required']);
    exit;
}

// JSON 데이터 받기
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'message' => '잘못된 요청입니다.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$recipient_name = trim($input['recipient_name'] ?? '');
$phone = trim($input['phone'] ?? '');
$shipping_address = trim($input['shipping_address'] ?? '');
$delivery_memo = trim($input['delivery_memo'] ?? '');
$payment_method = $input['payment_method'] ?? 'card';
$total_amount = (int)($input['total_amount'] ?? 0);

// 필수 필드 검증
if (empty($recipient_name) || empty($phone) || empty($shipping_address) || $total_amount <= 0) {
    echo json_encode(['success' => false, 'message' => '필수 정보를 모두 입력해주세요.']);
    exit;
}

try {
    $conn = get_db_connection();
    $conn->begin_transaction();
    
    // 장바구니 상품 확인
    $cart_query = "
        SELECT ci.*, p.name, p.price, p.stock_quantity 
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ? AND p.is_active = 1
    ";
    
    $cart_stmt = $conn->prepare($cart_query);
    $cart_stmt->bind_param("i", $user_id);
    $cart_stmt->execute();
    $cart_result = $cart_stmt->get_result();
    
    if ($cart_result->num_rows === 0) {
        throw new Exception('주문할 상품이 없습니다.');
    }
    
    $cart_items = [];
    $calculated_total = 0;
    
    while ($item = $cart_result->fetch_assoc()) {
        if ($item['quantity'] > $item['stock_quantity']) {
            throw new Exception($item['name'] . ' 상품의 재고가 부족합니다.');
        }
        $cart_items[] = $item;
        $calculated_total += $item['quantity'] * $item['price'];
    }
    
    // 배송비 계산
    $shipping_fee = $calculated_total >= 50000 ? 0 : 3000;
    $final_total = $calculated_total + $shipping_fee;
    
    // 금액 검증
    if ($final_total !== $total_amount) {
        throw new Exception('주문 금액이 일치하지 않습니다.');
    }
    
    // 주문번호 생성
    $order_number = 'WG' . date('Ymd') . sprintf('%06d', rand(1, 999999));
    
    // 주문 생성
    $order_query = "
        INSERT INTO orders (user_id, order_number, total_amount, status, 
                           shipping_address, phone, recipient_name, payment_method, order_date)
        VALUES (?, ?, ?, 'pending', ?, ?, ?, ?, NOW())
    ";
    
    $order_stmt = $conn->prepare($order_query);
    $order_stmt->bind_param("isisiss", $user_id, $order_number, $final_total, 
                           $shipping_address, $phone, $recipient_name, $payment_method);
    $order_stmt->execute();
    
    $order_id = $conn->insert_id;
    
    // 주문 상세 항목 생성
    $order_item_query = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
    $order_item_stmt = $conn->prepare($order_item_query);
    
    foreach ($cart_items as $item) {
        $order_item_stmt->bind_param("iiii", $order_id, $item['product_id'], 
                                    $item['quantity'], $item['price']);
        $order_item_stmt->execute();
        
        // 재고 차감
        $stock_update = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
        $stock_update->bind_param("ii", $item['quantity'], $item['product_id']);
        $stock_update->execute();
    }
    
    // 장바구니 비우기
    $clear_cart = $conn->prepare("DELETE FROM cart_items WHERE user_id = ?");
    $clear_cart->bind_param("i", $user_id);
    $clear_cart->execute();
    
    $conn->commit();
    
    echo json_encode([
        'success' => true, 
        'message' => '주문이 생성되었습니다.',
        'order_id' => $order_id,
        'order_number' => $order_number
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    $conn->close();
}
?>