<?php
// cart_remove.php - 장바구니에서 상품 제거 API

header('Content-Type: application/json');
session_start();

require_once '../config/database.php';

// POST 요청만 허용
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'login_required']);
    exit;
}

// JSON 데이터 받기
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['cart_id'])) {
    echo json_encode(['success' => false, 'message' => '잘못된 요청입니다.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$cart_id = (int)$input['cart_id'];

try {
    $conn = get_db_connection();
    
    // 장바구니 아이템 소유권 확인 후 삭제
    $delete_stmt = $conn->prepare("DELETE FROM cart_items WHERE id = ? AND user_id = ?");
    $delete_stmt->bind_param("ii", $cart_id, $user_id);
    $delete_stmt->execute();
    
    if ($delete_stmt->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => '상품이 제거되었습니다.']);
    } else {
        echo json_encode(['success' => false, 'message' => '제거할 상품을 찾을 수 없습니다.']);
    }
    
    $conn->close();
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => '오류가 발생했습니다: ' . $e->getMessage()]);
}
?>