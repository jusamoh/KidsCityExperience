<?php
// program_registration.php - 프로그램 신청 처리

// POST 데이터 확인 및 로깅
error_log("POST 데이터 수신: " . print_r($_POST, true));

// 필수 필드 확인
if(isset($_POST['program_id']) && isset($_POST['child_name']) && isset($_POST['child_age']) && 
   isset($_POST['parent_name']) && isset($_POST['phone']) && isset($_POST['email'])) {
    
    // CSRF 토큰 확인
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        set_message('보안 토큰이 만료되었습니다. 다시 시도해주세요.', 'danger');
        redirect('index.php?page=program_selection');
        exit;
    }
    
    // 폼 데이터 가져오기
    $program_id = (int)$_POST['program_id'];
    $child_name = $_POST['child_name'];
    $child_age = (int)$_POST['child_age'];
    $parent_name = $_POST['parent_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $notes = isset($_POST['notes']) ? $_POST['notes'] : '';
    
    // 유효성 검사
    if (empty($program_id) || empty($child_name) || empty($parent_name) || empty($phone) || empty($email)) {
        set_message('모든 필수 항목을 입력해주세요.', 'danger');
        redirect('index.php?page=registration&program_id=' . $program_id);
        exit;
    }
    
    // 데이터베이스에 등록 정보 저장
    $registration_data = [
        'program_id' => $program_id,
        'child_name' => $child_name,
        'child_age' => $child_age,
        'parent_name' => $parent_name,
        'phone' => $phone,
        'email' => $email,
        'notes' => $notes,
        'payment_status' => 'pending'
    ];
    
    // user_id 컬럼 존재 여부 확인
    $conn = get_db_connection();
    $check_column_sql = "SHOW COLUMNS FROM registrations LIKE 'user_id'";
    $check_result = $conn->query($check_column_sql);
    $has_user_id_column = $check_result && $check_result->num_rows > 0;
    $conn->close();
    
    // 사용자가 로그인한 경우 user_id 추가 (컬럼이 존재하는 경우에만)
    if ($has_user_id_column && isset($_SESSION['user_id'])) {
        $registration_data['user_id'] = $_SESSION['user_id'];
    }
    
    // 데이터베이스에 등록 정보 저장
    $registration_id = add_registration($registration_data);
    
    if ($registration_id) {
        // 세션에 등록 정보 저장 (호환성 유지)
        $_SESSION['program_registered'] = true;
        
        // 마지막 등록 정보 저장
        $_SESSION['last_registration'] = [
            'id' => $registration_id,
            'program_id' => $program_id,
            'timestamp' => time(),
            'created_at' => date('Y-m-d H:i:s'),
            'payment_status' => 'pending'
        ];
        
        // 성공 메시지 설정
        set_message('프로그램 신청이 완료되었습니다. 마이페이지에서 결제를 진행해주세요.', 'success');
    } else {
        // 데이터베이스 저장 실패
        set_message('프로그램 신청 중 오류가 발생했습니다. 다시 시도해주세요.', 'danger');
    }
} else {
    // 필수 필드가 없는 경우
    error_log("필수 필드가 전달되지 않았습니다: " . print_r($_POST, true));
    set_message('신청 정보가 올바르지 않습니다. 다시 시도해주세요.', 'danger');
}

// 마이페이지로 이동
redirect('index.php?page=my_page');
exit;
?>