<?php
// index.php - 메인 진입점

// 출력 버퍼링 시작 - 헤더 관련 오류 방지
ob_start();

// 세션이 시작되지 않은 경우에만 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';
require_once 'includes/functions.php';

// 데이터베이스 테이블 자동 생성
create_tables_if_not_exist();

// 현재 페이지 파라미터 가져오기
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// 프로그램 수정 후 캐시 방지 처리
$updated = isset($_GET['updated']) ? true : false;
if ($updated) {
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
}

// 헤더 표시
include 'includes/header.php';

// 로그아웃 처리
if ($page === 'logout') {
    // 세션 변수 제거
    $_SESSION = array();
    
    // 세션 쿠키 삭제
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // 세션 파기
    session_destroy();
    
    // 성공 메시지 설정
    set_message('성공적으로 로그아웃되었습니다.', 'success');
    
    // 홈페이지로 리다이렉션 (상대 경로 사용)
    header("Location: index.php");
    exit;
}

// 페이지 내용 표시
switch ($page) {
    case 'check_username':
        include 'pages/check_username.php';
        break;
    case 'home':
        include 'pages/home.php';
        break;
    case 'program_selection':
        include 'pages/program_selection.php';
        break;
    case 'program_detail':
        include 'pages/program_detail.php';
        break;
    case 'registration':
        include 'pages/registration.php';
        break;
    case 'program_registration':
        include 'pages/program_registration.php';
        break;
    // 다중 신청 프로그램 기능 제거
    case 'login':
        include 'pages/login.php';
        break;
    case 'login_process':
        // POST로 넘어온 사용자 이름과 비밀번호 확인
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = isset($_POST['username']) ? $_POST['username'] : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            
            $result = login_user($username, $password);
            
            if ($result['success']) {
                // 관리자인 경우 관리자 대시보드로, 일반 사용자인 경우 마이페이지로 이동
                if ($result['is_admin']) {
                    redirect('index.php?page=admin_dashboard');
                } else {
                    redirect('index.php?page=my_page');
                }
            } else {
                // 로그인 실패 시 에러 메시지와 함께 로그인 페이지로 이동
                redirect('index.php?page=login&error=invalid');
            }
        } else {
            // POST가 아닌 방식으로 접근 시 로그인 페이지로 이동
            redirect('index.php?page=login');
        }
        break;
    case 'register':
        include 'pages/register.php';
        break;
    case 'register_process':
        // POST로 넘어온 가입 정보 확인
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = isset($_POST['username']) ? $_POST['username'] : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            $password_confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
            $name = isset($_POST['name']) ? $_POST['name'] : '';
            $email = isset($_POST['email']) ? $_POST['email'] : '';
            $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
            
            // 비밀번호 확인
            if ($password !== $password_confirm) {
                redirect('index.php?page=register&error=password_mismatch');
                exit;
            }
            
            // 사용자 등록 (이름, 이메일, 전화번호 추가)
            $result = register_user($username, $password, $name, $email, $phone);
            
            if ($result['success']) {
                // 회원가입 성공 시 로그인 페이지로 이동
                redirect('index.php?page=login&registered=1');
            } else {
                // 회원가입 실패 시 에러 메시지와 함께 회원가입 페이지로 이동
                if (strpos($result['message'], '이미 사용 중인 아이디') !== false) {
                    redirect('index.php?page=register&error=username_exists');
                } else {
                    redirect('index.php?page=register&error=unknown');
                }
            }
        } else {
            // POST가 아닌 방식으로 접근 시 회원가입 페이지로 이동
            redirect('index.php?page=register');
        }
        break;
    case 'my_page':
        // 로그인 확인
        if (!isset($_SESSION['user_id'])) {
            redirect('index.php?page=login');
        }
        include 'pages/my_page.php';
        break;
    case 'edit_profile':
        // 로그인 확인
        if (!isset($_SESSION['user_id'])) {
            redirect('index.php?page=login');
        }
        include 'pages/edit_profile.php';
        break;
    case 'admin_dashboard':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/admin_dashboard.php';
        break;
    case 'edit_programs':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/edit_programs.php';
        break;
    case 'update_program':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/update_program.php';
        break;
    case 'fix_program_editing':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/fix_program_editing.php';
        break;
    case 'direct_edit_program':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/direct_edit_program.php';
        break;
    case 'faq':
        include 'pages/faq.php';
        break;
    case 'how_to_use':
        include 'pages/how_to_use.php';
        break;
    case 'refund_policy':
        include 'pages/refund_policy.php';
        break;
    case 'terms_of_service':
        include 'pages/terms_of_service.php';
        break;
    case 'privacy_policy':
        include 'pages/privacy_policy.php';
        break;
    case 'add_program':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/add_program.php';
        break;
    case 'program_management':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/program_management.php';
        break;
    case 'payment_success':
        include 'pages/payment_success.php';
        break;
    case 'payment':
        include 'pages/payment.php';
        break;
    case 'payment_popup':
        include 'pages/payment_popup.php';
        break;
    case 'payment_fail':
        include 'pages/payment_fail.php';
        break;
    case 'cancel_payment':
        // 결제 취소 처리
        unset($_SESSION['payment_info']);
        set_message('결제가 취소되었습니다.', 'info');
        redirect('index.php?page=program_selection');
        break;
    case 'cancel_registration':
        // 신청 취소 처리
        include 'pages/cancel_registration.php';
        break;
    case 'batch_payment':
        // 일괄 결제 처리
        include 'pages/batch_payment.php';
        break;
    case 'program_registration_detail':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/program_registration_detail.php';
        break;
    default:
        include 'pages/not_found.php';
}

// 푸터 표시
include 'includes/footer.php';
?>