<?php
// payment.php - 결제 페이지

// 결제 정보 초기화
$payment_info = null;

// 1. registration_id로 결제 정보 조회
if (isset($_GET['registration_id'])) {
    $registration_id = $_GET['registration_id'];
    $registration = get_registration($registration_id);
    
    if ($registration) {
        $program = get_program($registration['program_id']);
        if ($program) {
            // 결제 정보 생성
            $payment_info = [
                'registration_id' => $registration['id'],
                'program_id' => $program['id'],
                'order_name' => $program['title'] . ' 신청',
                'amount' => $program['price'],
                'order_id' => 'ORDER_' . time() . '_' . $registration['id'],
                'customer_name' => $registration['parent_name'],
                'customer_email' => $registration['email'],
                'customer_phone' => $registration['phone']
            ];
            
            // 세션에 결제 정보 저장
            $_SESSION['payment_info'] = $payment_info;
        }
    }
}
// 2. program_id로 결제 정보 생성 (임시 등록 정보)
else if (isset($_GET['program_id'])) {
    $program_id = $_GET['program_id'];
    $program = get_program($program_id);
    
    if ($program && isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $user = get_user($user_id);
        
        if ($user) {
            // 결제 정보 생성
            $payment_info = [
                'program_id' => $program['id'],
                'order_name' => $program['title'] . ' 신청',
                'amount' => $program['price'],
                'order_id' => 'ORDER_' . time() . '_' . $user_id . '_' . $program_id,
                'customer_name' => $user['name'],
                'customer_email' => $user['email'],
                'customer_phone' => $user['phone']
            ];
            
            // 세션에 결제 정보 저장
            $_SESSION['payment_info'] = $payment_info;
        }
    }
}
// 3. 세션에 이미 저장된 결제 정보 사용
else if (isset($_SESSION['payment_info'])) {
    $payment_info = $_SESSION['payment_info'];
}

// 결제 정보가 없으면 프로그램 선택 페이지로 이동
if (!$payment_info) {
    redirect('index.php?page=program_selection');
}
?>

<div class="container">
    <h2 class="mb-4">프로그램 결제</h2>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">결제 정보</h4>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">주문명:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($payment_info['order_name']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">결제 금액:</div>
                        <div class="col-md-8"><?php echo format_price($payment_info['amount']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">주문 번호:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($payment_info['order_id']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">신청자:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($payment_info['customer_name']); ?></div>
                    </div>
                    
                    <hr>
                    
                    <div class="payment-methods">
                        <h5 class="mb-3">결제 방법 선택</h5>
                        
                        <div class="d-grid gap-2">
                            <button type="button" id="payment-button" class="btn btn-primary btn-lg">
                                <i class="fas fa-credit-card me-2"></i> 카드 결제
                            </button>
                            
                            <button type="button" id="virtual-account-button" class="btn btn-outline-primary btn-lg">
                                <i class="fas fa-university me-2"></i> 가상계좌 입금
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between">
                <a href="index.php?page=program_selection" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i> 프로그램 목록으로
                </a>
                
                <a href="index.php?page=cancel_payment" class="btn btn-outline-danger" onclick="return confirm('정말로 결제를 취소하시겠습니까?');">
                    <i class="fas fa-times me-2"></i> 결제 취소
                </a>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">결제 안내</h4>
                </div>
                <div class="card-body">
                    <p><i class="fas fa-info-circle text-primary me-2"></i> 결제 후에는 예약이 확정됩니다.</p>
                    <p><i class="fas fa-info-circle text-primary me-2"></i> 최소 참가 인원이 모이지 않으면 프로그램이 취소될 수 있으며, 이 경우 전액 환불됩니다.</p>
                    <p><i class="fas fa-info-circle text-primary me-2"></i> 프로그램 시작 7일 전까지 취소 시 전액 환불되며, 이후에는 환불 규정에 따라 부분 환불됩니다.</p>
                    <p><i class="fas fa-info-circle text-primary me-2"></i> 결제 관련 문의사항은 고객센터(010-1234-5678)로 연락주세요.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 토스페이먼츠 결제 스크립트 -->
<script src="https://js.tosspayments.com/v1/payment"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const clientKey = '<?php echo getenv("TOSS_PAYMENTS_CLIENT_KEY") ?: "test_ck_D5GePWvyJnrK0W0k6q8gLzN97Eoq"; ?>'; // 토스페이먼츠 클라이언트 키
    const tossPayments = TossPayments(clientKey);
    
    // 카드 결제 버튼 클릭 이벤트
    document.getElementById('payment-button').addEventListener('click', function() {
        tossPayments.requestPayment('카드', {
            amount: <?php echo $payment_info['amount']; ?>,
            orderId: '<?php echo $payment_info['order_id']; ?>',
            orderName: '<?php echo addslashes($payment_info['order_name']); ?>',
            customerName: '<?php echo addslashes($payment_info['customer_name']); ?>',
            customerEmail: '<?php echo addslashes($payment_info['customer_email']); ?>',
            customerMobilePhone: '<?php echo addslashes($payment_info['customer_phone']); ?>',
            successUrl: 'http://<?php echo $_SERVER['HTTP_HOST']; ?>/paju/index.php?page=payment_success',
            failUrl: 'http://<?php echo $_SERVER['HTTP_HOST']; ?>/paju/index.php?page=payment_fail'
        }).catch(function(error) {
            if (error.code === 'USER_CANCEL') {
                alert('결제가 취소되었습니다.');
            } else {
                alert('결제 오류가 발생했습니다: ' + error.message);
            }
        });
    });
    
    // 가상계좌 결제 버튼 클릭 이벤트
    document.getElementById('virtual-account-button').addEventListener('click', function() {
        tossPayments.requestPayment('가상계좌', {
            amount: <?php echo $payment_info['amount']; ?>,
            orderId: '<?php echo $payment_info['order_id']; ?>',
            orderName: '<?php echo addslashes($payment_info['order_name']); ?>',
            customerName: '<?php echo addslashes($payment_info['customer_name']); ?>',
            customerEmail: '<?php echo addslashes($payment_info['customer_email']); ?>',
            customerMobilePhone: '<?php echo addslashes($payment_info['customer_phone']); ?>',
            successUrl: 'http://<?php echo $_SERVER['HTTP_HOST']; ?>/paju/index.php?page=payment_success',
            failUrl: 'http://<?php echo $_SERVER['HTTP_HOST']; ?>/paju/index.php?page=payment_fail',
            validHours: 24,
            cashReceipt: {
                type: '소득공제'
            }
        }).catch(function(error) {
            if (error.code === 'USER_CANCEL') {
                alert('결제가 취소되었습니다.');
            } else {
                alert('결제 오류가 발생했습니다: ' + error.message);
            }
        });
    });
});
</script>