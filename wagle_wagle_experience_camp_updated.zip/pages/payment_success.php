<?php
// payment_success.php - 결제 성공 페이지
session_start();
require_once '../config/database.php';

// 결제 검증 파라미터 받기
$paymentKey = $_GET['paymentKey'] ?? '';
$orderId = $_GET['orderId'] ?? '';
$amount = $_GET['amount'] ?? '';

if (empty($paymentKey) || empty($orderId) || empty($amount)) {
    echo "<script>alert('잘못된 결제 정보입니다.'); window.location.href='../index.php?page=cart';</script>";
    exit;
}

try {
    // TossPayments API로 결제 승인 요청
    $toss_secret_key = $_ENV['TOSS_PAYMENTS_SECRET_KEY'] ?? '';
    
    if (empty($toss_secret_key)) {
        throw new Exception('결제 시스템 설정 오류');
    }
    
    $url = 'https://api.tosspayments.com/v1/payments/confirm';
    $data = json_encode([
        'paymentKey' => $paymentKey,
        'orderId' => $orderId,
        'amount' => (int)$amount
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Basic ' . base64_encode($toss_secret_key . ':'),
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200) {
        $payment_data = json_decode($response, true);
        
        // 데이터베이스에 주문 정보 저장
        $conn = get_db_connection();
        $user_id = $_SESSION['user_id'] ?? 0;
        
        if ($user_id > 0 && isset($_SESSION['pending_order'])) {
            $pending_order = $_SESSION['pending_order'];
            
            // 주문 테이블에 저장
            $order_stmt = $conn->prepare("INSERT INTO shop_orders (user_id, order_id, total_amount, payment_key, status, created_at) VALUES (?, ?, ?, ?, 'completed', NOW())");
            $order_stmt->bind_param("isds", $user_id, $orderId, $amount, $paymentKey);
            $order_stmt->execute();
            $order_db_id = $conn->insert_id;
            
            // 주문 상품 저장
            foreach ($pending_order['items'] as $item) {
                $item_stmt = $conn->prepare("INSERT INTO shop_order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $item_stmt->bind_param("iiid", $order_db_id, $item['product_id'], $item['quantity'], $item['price']);
                $item_stmt->execute();
                
                // 재고 감소
                $stock_stmt = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
                $stock_stmt->bind_param("ii", $item['quantity'], $item['product_id']);
                $stock_stmt->execute();
            }
            
            // 장바구니 비우기
            $clear_cart_stmt = $conn->prepare("DELETE FROM cart_items WHERE user_id = ?");
            $clear_cart_stmt->bind_param("i", $user_id);
            $clear_cart_stmt->execute();
            
            // 세션 정리
            unset($_SESSION['pending_order']);
            
            $conn->close();
        }
        
        $success = true;
        $message = '결제가 성공적으로 완료되었습니다.';
    } else {
        $success = false;
        $error_data = json_decode($response, true);
        $message = $error_data['message'] ?? '결제 승인에 실패했습니다.';
    }
    
} catch (Exception $e) {
    $success = false;
    $message = '결제 처리 중 오류가 발생했습니다: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>결제 완료 - 파주 체험 Camp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body text-center p-5">
                        <?php if ($success): ?>
                            <i class="fas fa-check-circle text-success mb-3" style="font-size: 4rem;"></i>
                            <h2 class="text-success mb-3">결제 완료</h2>
                            <p class="mb-4"><?php echo htmlspecialchars($message); ?></p>
                            <div class="alert alert-info">
                                <strong>주문번호:</strong> <?php echo htmlspecialchars($orderId); ?><br>
                                <strong>결제금액:</strong> <?php echo number_format($amount); ?>원
                            </div>
                        <?php else: ?>
                            <i class="fas fa-times-circle text-danger mb-3" style="font-size: 4rem;"></i>
                            <h2 class="text-danger mb-3">결제 실패</h2>
                            <p class="mb-4"><?php echo htmlspecialchars($message); ?></p>
                        <?php endif; ?>
                        
                        <div class="d-grid gap-2">
                            <a href="../index.php?page=shop" class="btn btn-primary">
                                <i class="fas fa-shopping-cart"></i> 쇼핑 계속하기
                            </a>
                            <a href="../index.php" class="btn btn-outline-secondary">
                                <i class="fas fa-home"></i> 홈으로 가기
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>