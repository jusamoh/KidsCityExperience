<?php
// 검색어 처리
$search = isset($_GET['search']) ? $_GET['search'] : '';

// 카테고리 필터 처리
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : null;

// 항상 최신 데이터를 가져오기 위해 직접 데이터베이스 쿼리 실행
$conn = get_db_connection();

// 프로그램 가져오기
$programs = [];
$where_clause = "WHERE p.status != 'completed' AND p.status != 'canceled'";

if ($category_filter) {
    $where_clause .= " AND p.category_id = {$category_filter}";
}

$sql = "SELECT 
        p.id, p.title, p.description, p.category_id, p.date, 
        p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
        p.duration, p.status, p.image_path, p.created_at,
        c.name as category_name, 
        (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) as current_participants
        FROM programs p
        LEFT JOIN categories c ON p.category_id = c.id
        {$where_clause}
        ORDER BY 
            CASE p.status 
                WHEN 'active' THEN 1 
                WHEN 'pending' THEN 2 
                ELSE 3 
            END, 
            p.date ASC";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $programs[] = $row;
    }
}

$conn->close();

// 검색어가 있으면 필터링
if (!empty($search)) {
    $filtered_programs = [];
    $search_terms = explode(' ', $search);
    
    foreach ($programs as $program) {
        $match = true;
        
        foreach ($search_terms as $term) {
            $term = trim($term);
            if (empty($term)) continue;
            
            // 제목, 설명에서 검색어 찾기
            $title_match = stripos($program['title'], $term) !== false;
            $desc_match = stripos($program['description'], $term) !== false;
            
            if (!$title_match && !$desc_match) {
                $match = false;
                break;
            }
        }
        
        if ($match) {
            $filtered_programs[] = $program;
        }
    }
    
    $programs = $filtered_programs;
}

// 모든 카테고리 가져오기
$categories = get_categories();

// 중복 카테고리 제거를 위한 배열 생성
$unique_categories = [];
$unique_category_ids = [];

// 중복 없는 카테고리 배열 생성
foreach($categories as $category) {
    if(!in_array($category['id'], $unique_category_ids)) {
        $unique_categories[] = $category;
        $unique_category_ids[] = $category['id'];
    }
}

// 기존 카테고리 배열 교체
$categories = $unique_categories;
?>

<!-- 페이지 헤더 섹션 - 깔끔한 분위기 -->
<div class="program-header-section py-5 mb-5 position-relative overflow-hidden bg-light">
    <div class="animated-background"></div>
    <div class="container position-relative">
        <div class="row align-items-center">
            <div class="col-12 text-center">
                <h1 class="display-4 fw-bold text-primary mb-3 program-title">
                    신나는 체험 프로그램
                </h1>
                <p class="lead text-secondary mb-4 program-subtitle">
                    아이들의 꿈과 호기심을 키우는 체험이 가득해요! 
                    친구들과 함께 뛰어놀고, 배우고, 성장하는 특별한 시간을 만나보세요!
                </p>
                <div class="program-badges">
                    <span class="badge bg-warning text-dark me-2 fs-6 bouncing-badge">창의력 UP!</span>
                    <span class="badge bg-success text-white me-2 fs-6 bouncing-badge">자연과 친해져요</span>
                    <span class="badge bg-info text-white fs-6 bouncing-badge">몸도 튼튼!</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <?php if (!empty($search)): ?>
        <div class="alert alert-info border-0 shadow-sm mb-4">
            <div class="d-flex align-items-center">
                <div class="flex-grow-1">
                    <strong>"<?php echo htmlspecialchars($search); ?>"</strong> 검색 결과: <?php echo count($programs); ?>개 프로그램
                </div>
                <a href="index.php?page=program_selection" class="btn btn-outline-info btn-sm">
                    검색 초기화
                </a>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- 카테고리 필터 섹션 -->
    <div class="category-filter-section">
        <div class="text-center mb-4">
            <h4 class="category-filter-title mb-2">어떤 재미있는 체험을 해볼까요?</h4>
            <p class="text-white opacity-75 mb-0">카테고리를 선택해서 원하는 체험을 찾아보세요!</p>
        </div>
        <div class="d-flex flex-wrap justify-content-center gap-3">
            <a href="index.php?page=program_selection" 
               class="category-btn <?php echo empty($category_filter) ? 'active' : ''; ?>">
               모든 체험
            </a>
            
            <?php 
            foreach($categories as $category): 
            ?>
                <a href="index.php?page=program_selection&category=<?php echo $category['id']; ?>" 
                   class="category-btn <?php echo $category_filter == $category['id'] ? 'active' : ''; ?>">
                    <?php echo $category['name']; ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- 즐거운 통계 -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card border-0 bg-gradient-primary text-white h-100 fun-stat-card">
                <div class="card-body text-center py-4">
                    <div class="fun-stat-icon mb-2">🎪</div>
                    <h2 class="fw-bold mb-1"><?php echo count($programs); ?>개</h2>
                    <p class="mb-0 opacity-75">재미있는 체험이 준비되어 있어요!</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card border-0 bg-gradient-success text-white h-100 fun-stat-card">
                <div class="card-body text-center py-4">
                    <div class="fun-stat-icon mb-2">🚀</div>
                    <h2 class="fw-bold mb-1">
                        <?php echo count(array_filter($programs, function($p) { return $p['status'] === 'active'; })); ?>개
                    </h2>
                    <p class="mb-0 opacity-75">지금 바로 신청할 수 있어요!</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card border-0 bg-gradient-info text-white h-100 fun-stat-card">
                <div class="card-body text-center py-4">
                    <div class="fun-stat-icon mb-2">⏰</div>
                    <h2 class="fw-bold mb-1">
                        <?php echo count(array_filter($programs, function($p) { return $p['status'] === 'pending'; })); ?>개
                    </h2>
                    <p class="mb-0 opacity-75">곧 만날 수 있는 새로운 체험!</p>
                </div>
            </div>
        </div>
    </div>
            
    <div class="row">
        <?php if(empty($programs)): ?>
            <div class="col-12">
                <div class="text-center py-5">

                    <h4 class="text-muted">
                        <?php if(!empty($search)): ?>
                            "<?php echo htmlspecialchars($search); ?>" 검색어에 맞는 프로그램이 없습니다.
                        <?php elseif(!empty($category_filter)): ?>
                            선택한 카테고리에 프로그램이 없습니다.
                        <?php else: ?>
                            등록된 프로그램이 없습니다.
                        <?php endif; ?>
                    </h4>
                    <p class="text-muted">새로운 프로그램이 곧 추가될 예정입니다.</p>
                </div>
            </div>
        <?php else: ?>
                    <?php foreach($programs as $program): 
                        // 프로그램 상태 결정
                        $status_class = '';
                        $status_text = '';
                        
                        if($program['current_participants'] >= $program['max_participants']) {
                            $status_class = 'status-full';
                            $status_text = '마감';
                        } elseif($program['status'] === 'active') {
                            $status_class = 'status-active';
                            $status_text = '모집중';
                        } else {
                            $status_class = 'status-pending';
                            $status_text = '준비중';
                        }
                        
                        // 현재 카테고리 찾기
                        $current_category = null;
                        foreach($categories as $category) {
                            if($category['id'] == $program['category_id']) {
                                $current_category = $category;
                                break;
                            }
                        }
                    ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card program-card h-100">
                        <!-- 프로그램 이미지 -->
                        <div class="position-relative">
                            <img src="<?php echo !empty($program['image_path']) ? $program['image_path'] : 'assets/img/programs/program-default.jpg'; ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo htmlspecialchars($program['title']); ?>"
                                 onerror="this.src='assets/img/programs/program-default.jpg'">
                            
                            <!-- 상태 배지 -->
                            <span class="program-status-badge <?php echo $status_class == 'status-active' ? 'bg-success' : ($status_class == 'status-full' ? 'bg-danger' : 'bg-secondary'); ?>">
                                <?php echo $status_text; ?>
                            </span>
                            

                        </div>

                        <div class="card-body p-4 d-flex flex-column">
                            <!-- 카테고리와 연령대 -->
                            <div class="mb-3">
                                <span class="badge bg-primary me-2"><?php echo $current_category ? htmlspecialchars($current_category['name']) : '기타'; ?></span>
                                <span class="badge bg-secondary"><?php echo $program['min_age']; ?>~<?php echo $program['max_age']; ?>세</span>
                            </div>

                            <!-- 프로그램명 -->
                            <h5 class="card-title fw-bold text-dark mb-3">
                                <?php echo htmlspecialchars($program['title']); ?>
                            </h5>

                            <!-- 프로그램 설명 -->
                            <p class="card-text text-muted mb-4 flex-grow-1">
                                <?php echo htmlspecialchars(mb_substr($program['description'], 0, 100) . '...'); ?>
                            </p>

                            <!-- 프로그램 정보 -->
                            <div class="program-info mb-3">
                                <div class="row g-2 text-center">
                                    <div class="col-4">
                                        <div class="p-2 bg-light rounded">
                                            <div class="fw-bold text-success"><?php echo number_format($program['price']); ?>원</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="p-2 bg-light rounded">
                                            <div class="fw-bold text-info"><?php echo $program['max_participants']; ?>명</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="p-2 bg-light rounded">
                                            <div class="fw-bold text-warning"><?php echo $program['duration']; ?>분</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- 액션 버튼 -->
                            <div class="mt-auto">
                                <a href="index.php?page=program_detail&id=<?php echo $program['id']; ?>" 
                                   class="btn btn-primary w-100 fw-bold">
                                    체험하고 싶어요!
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>