<?php
// logout.php - 로그아웃 처리

// 로그아웃 함수 호출
logout_user();

// 성공 메시지 설정
set_message('로그아웃 되었습니다.');

// 홈페이지로 리디렉션
redirect('index.php');
?>