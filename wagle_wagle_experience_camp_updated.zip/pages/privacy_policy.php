<?php
// privacy_policy.php - 개인정보 처리방침 페이지
?>

<div class="container">
    <h2 class="mb-4">개인정보 처리방침</h2>
    
    <div class="alert alert-info mb-4">
        <p class="mb-0"><i class="fas fa-info-circle me-2"></i> 와글와글 체험Camp는 이용자의 개인정보를 중요시하며, 「개인정보 보호법」을 준수하기 위해 노력하고 있습니다. 본 방침은 개인정보 처리에 관한 사항을 안내해 드립니다.</p>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">1. 개인정보의 처리 목적</h4>
            <p class="card-text">와글와글 체험Camp는 다음의 목적을 위하여 개인정보를 처리합니다. 처리하고 있는 개인정보는 다음의 목적 이외의 용도로는 이용되지 않으며, 이용 목적이 변경되는 경우에는 개인정보 보호법 제18조에 따라 별도의 동의를 받는 등 필요한 조치를 이행할 예정입니다.</p>
            <ol>
                <li>회원 가입 및 관리: 회원제 서비스 이용에 따른 본인확인, 개인 식별, 불량회원의 부정이용 방지와 비인가 사용방지, 가입의사 확인, 연령확인, 불만처리 등 민원처리, 고지사항 전달</li>
                <li>프로그램 신청 및 결제 서비스: 프로그램 신청, 결제, 환불, 프로그램 운영 관련 정보 제공</li>
                <li>마케팅 및 광고에의 활용: 신규 서비스 개발 및 맞춤 서비스 제공, 이벤트 및 광고성 정보 제공 (단, 별도 동의를 얻은 경우에 한함)</li>
            </ol>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">2. 개인정보의 처리 및 보유기간</h4>
            <p>① 와글와글 체험Camp는 법령에 따른 개인정보 보유·이용 기간 또는 정보주체로부터 개인정보를 수집 시에 동의 받은 개인정보 보유·이용 기간 내에서 개인정보를 처리·보유합니다.</p>
            <p>② 각각의 개인정보 처리 및 보유 기간은 다음과 같습니다.</p>
            <ul>
                <li>회원 정보: 회원 탈퇴 시까지 (단, 관계 법령에 따라 보존할 필요가 있는 경우 해당 기간 동안 보존)</li>
                <li>프로그램 신청 정보: 프로그램 종료 후 1년</li>
                <li>결제 정보: 전자상거래법에 따라 5년간 보관</li>
            </ul>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">3. 개인정보의 제3자 제공</h4>
            <p>와글와글 체험Camp는 정보주체의 개인정보를 제1조(개인정보의 처리 목적)에서 명시한 범위 내에서만 처리하며, 정보주체의 동의, 법률의 특별한 규정 등 개인정보 보호법 제17조 및 제18조에 해당하는 경우에만 개인정보를 제3자에게 제공합니다.</p>
            <p>현재 제3자에게 제공하는 개인정보는 없습니다.</p>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">4. 개인정보처리 위탁</h4>
            <p>① 와글와글 체험Camp는 원활한 개인정보 업무처리를 위하여 다음과 같이 개인정보 처리업무를 위탁하고 있습니다.</p>
            <table class="table table-bordered mt-3">
                <thead class="table-light">
                    <tr>
                        <th>수탁업체</th>
                        <th>위탁업무 내용</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>토스페이먼츠(주)</td>
                        <td>결제처리 및 결제도용 방지</td>
                    </tr>
                </tbody>
            </table>
            <p>② 와글와글 체험Camp는 위탁계약 체결 시 개인정보 보호법 제26조에 따라 위탁업무 수행목적 외 개인정보 처리금지, 기술적·관리적 보호조치, 재위탁 제한, 수탁자에 대한 관리·감독, 손해배상 등 책임에 관한 사항을 계약서 등 문서에 명시하고, 수탁자가 개인정보를 안전하게 처리하는지를 감독하고 있습니다.</p>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">5. 정보주체의 권리·의무 및 행사방법</h4>
            <p>정보주체는 와글와글 체험Camp에 대해 언제든지 다음 각 호의 개인정보 보호 관련 권리를 행사할 수 있습니다.</p>
            <ol>
                <li>개인정보 열람 요구</li>
                <li>오류 등이 있을 경우 정정 요구</li>
                <li>삭제 요구</li>
                <li>처리정지 요구</li>
            </ol>
            <p>권리 행사는 와글와글 체험Camp에 대해 서면, 전화, 전자우편, 모사전송(FAX) 등을 통하여 하실 수 있으며 와글와글 체험Camp는 이에 대해 지체없이 조치하겠습니다.</p>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">6. 처리하는 개인정보 항목</h4>
            <p>와글와글 체험Camp는 다음의 개인정보 항목을 처리하고 있습니다.</p>
            <table class="table table-bordered mt-3">
                <thead class="table-light">
                    <tr>
                        <th>구분</th>
                        <th>수집항목</th>
                        <th>수집목적</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>회원가입</td>
                        <td>필수: 아이디, 비밀번호, 이름, 연락처, 이메일<br>선택: 주소</td>
                        <td>회원제 서비스 제공, 본인 확인</td>
                    </tr>
                    <tr>
                        <td>프로그램 신청</td>
                        <td>필수: 참가자명(아이 이름), 참가자 나이, 보호자명, 연락처, 이메일<br>선택: 특이사항</td>
                        <td>프로그램 신청 및 운영</td>
                    </tr>
                    <tr>
                        <td>결제</td>
                        <td>결제수단 정보</td>
                        <td>프로그램 이용대금 결제</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">7. 개인정보의 안전성 확보조치</h4>
            <p>파주 체험 Camp는 개인정보의 안전성 확보를 위해 다음과 같은 조치를 취하고 있습니다.</p>
            <ol>
                <li>관리적 조치: 내부관리계획 수립·시행, 정기적인 직원 교육</li>
                <li>기술적 조치: 개인정보처리시스템 등의 접근권한 관리, 접속기록 보관, 보안프로그램 설치</li>
                <li>물리적 조치: 전산실, 자료보관실 등의 접근통제</li>
            </ol>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">8. 개인정보 자동 수집 장치의 설치·운영 및 거부에 관한 사항</h4>
            <p>① 파주 체험 Camp는 이용자에게 개별적인 맞춤서비스를 제공하기 위해 이용정보를 저장하고 수시로 불러오는 '쿠키(cookie)'를 사용합니다.</p>
            <p>② 쿠키는 웹사이트를 운영하는데 이용되는 서버가 이용자의 컴퓨터 브라우저에게 보내는 소량의 정보이며 이용자의 PC 컴퓨터내의 하드디스크에 저장되기도 합니다.</p>
            <p>③ 이용자는 쿠키 설치에 대한 선택권을 가지고 있습니다. 따라서 이용자는 웹브라우저에서 옵션을 설정함으로써 모든 쿠키를 허용하거나, 쿠키가 저장될 때마다 확인을 거치거나, 아니면 모든 쿠키의 저장을 거부할 수도 있습니다.</p>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title">9. 개인정보 보호책임자</h4>
            <p>파주 체험 Camp는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 정보주체의 불만처리 및 피해구제 등을 위하여 아래와 같이 개인정보 보호책임자를 지정하고 있습니다.</p>
            <div class="mt-3">
                <p><strong>■ 개인정보 보호책임자</strong></p>
                <p>성명: 홍길동<br>직책: 개인정보보호팀장<br>연락처: 02-123-4567, privacy@paju.kr</p>
            </div>
        </div>
    </div>
    
    <div class="card mb-5">
        <div class="card-body">
            <h4 class="card-title">10. 개인정보 처리방침 변경</h4>
            <p>이 개인정보 처리방침은 2025년 1월 1일부터 적용됩니다.</p>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-md-6 mb-4 mb-md-0">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4>관련 정책 바로가기</h4>
                    <ul class="list-unstyled">
                        <li><a href="index.php?page=terms_of_service">이용약관</a></li>
                        <li><a href="index.php?page=refund_policy">환불정책</a></li>
                        <li><a href="index.php?page=faq">자주 묻는 질문</a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4>문의하기</h4>
                    <p>개인정보에 관한 문의사항이 있으시면 아래 연락처로 문의해주세요.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-phone me-2"></i> 02-123-4567 (평일 9:00-18:00)</li>
                        <li><i class="fas fa-envelope me-2"></i> privacy@paju.kr</li>
                    </ul>
                </div>
                <div class="card-footer">
                    <a href="index.php?page=contact" class="btn btn-primary">문의하기</a>
                </div>
            </div>
        </div>
    </div>
</div>