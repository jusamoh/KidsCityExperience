<?php
// login.php - 로그인 페이지

// 로그아웃 액션 처리
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    // 로그아웃 함수 호출
    logout_user();
    
    // 홈페이지로 리다이렉션
    redirect($base_url);
    exit;
}
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">로그인</h4>
                </div>
                <div class="card-body">
                    <?php if(isset($_GET['error']) && $_GET['error'] == 'invalid'): ?>
                        <div class="alert alert-danger">
                            아이디 또는 비밀번호가 올바르지 않습니다.
                        </div>
                    <?php endif; ?>
                    
                    <?php 
                    // 시스템 메시지 표시
                    $message = get_message();
                    if($message): 
                    ?>
                        <div class="alert alert-<?php echo $message['type'] == 'success' ? 'success' : 'danger'; ?>">
                            <?php echo escape_string($message['text']); ?>
                        </div>
                    <?php endif; ?>

                    <form action="index.php?page=login_process" method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">아이디</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">비밀번호</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">로그인</button>
                        </div>
                    </form>
                </div>
                <div class="card-footer text-center">
                    <p class="mb-0">계정이 없으신가요? <a href="index.php?page=register">회원가입</a></p>
                </div>
            </div>
        </div>
    </div>
</div>