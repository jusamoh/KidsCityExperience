<?php
// registration.php - 프로그램 등록 페이지

// 프로그램 선택이 없는 경우, 먼저 프로그램을 선택하도록 리다이렉트
if(!isset($_GET['program_id'])) {
    redirect('index.php?page=program_selection');
}

$program_id = (int)$_GET['program_id'];
$program = get_program($program_id);

// 프로그램이 없거나 유효하지 않은 경우 
if(!$program) {
    set_message('존재하지 않는 프로그램입니다.', 'danger');
    redirect('index.php?page=program_selection');
}

// 마감된 프로그램인 경우
if($program['current_participants'] >= $program['max_participants']) {
    set_message('이미 마감된 프로그램입니다.', 'warning');
    redirect('index.php?page=program_detail&id=' . $program_id);
}

// CSRF 토큰 생성
$csrf_token = generate_csrf_token();
?>

<div class="container">
    <h2 class="mb-4">프로그램 신청하기</h2>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">신청 정보 입력</h4>
                </div>
                <div class="card-body">
                    <form method="post" action="index.php?page=program_registration" id="registrationForm" enctype="application/x-www-form-urlencoded">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="program_id" value="<?php echo $program_id; ?>">
                        
                        <h5 class="mb-3">참가자 정보</h5>
                        <div class="mb-3">
                            <label for="child_name" class="form-label">아이 이름 <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="child_name" name="child_name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="child_age" class="form-label">아이 나이(세) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="child_age" name="child_age" min="0" max="6" required>
                            <small class="text-muted">이 프로그램은 <?php echo $program['min_age']; ?>~<?php echo $program['max_age']; ?>세 영유아를 대상으로 합니다.</small>
                        </div>
                        
                        <h5 class="mb-3 mt-4">보호자 정보</h5>
                        <?php if(is_logged_in()): ?>
                            <?php 
                            // 로그인된 사용자 정보 가져오기
                            $user = get_user($_SESSION['user_id']);
                            ?>
                            <div class="mb-3">
                                <label for="parent_name" class="form-label">보호자 이름 <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="parent_name" name="parent_name" value="<?php echo isset($user['name']) ? htmlspecialchars($user['name']) : ''; ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="phone" class="form-label">연락처 <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo isset($user['phone']) ? htmlspecialchars($user['phone']) : ''; ?>" placeholder="010-0000-0000" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">이메일 <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($user['email']) ? htmlspecialchars($user['email']) : ''; ?>" required>
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <label for="parent_name" class="form-label">보호자 이름 <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="parent_name" name="parent_name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="phone" class="form-label">연락처 <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" id="phone" name="phone" placeholder="010-0000-0000" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">이메일 <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">특이사항</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="아이의 알레르기, 특이사항 등이 있으면 작성해주세요."></textarea>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="agree_terms" name="agree_terms" required>
                            <label class="form-check-label" for="agree_terms">
                                <a href="index.php?page=terms_of_service" target="_blank">이용약관</a>, 
                                <a href="index.php?page=privacy_policy" target="_blank">개인정보처리방침</a>에 동의합니다.
                            </label>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="agree_refund" name="agree_refund" required>
                            <label class="form-check-label" for="agree_refund">
                                <a href="index.php?page=refund_policy" target="_blank">환불정책</a>에 동의합니다.
                            </label>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">신청하기</button>
                            <a href="index.php?page=program_detail&id=<?php echo $program_id; ?>" class="btn btn-outline-secondary">돌아가기</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card program-summary">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">프로그램 정보</h4>
                </div>
                <div class="card-body">
                    <h5><?php echo htmlspecialchars($program['title']); ?></h5>
                    <p><span class="badge bg-primary"><?php echo htmlspecialchars($program['category_name']); ?></span></p>
                    <p><i class="far fa-calendar-alt"></i> <?php echo format_date($program['date']); ?></p>
                    
                    <?php /* location 필드 제거됨 */ ?>
                    
                    <?php if(isset($program['image_path']) && !empty($program['image_path'])): ?>
                    <p><i class="fas fa-image"></i> <?php echo htmlspecialchars($program['image_path']); ?></p>
                    <?php endif; ?>

                    <p><i class="fas fa-clock"></i> 소요시간: <?php echo $program['duration']; ?>분</p>
                    <p><i class="fas fa-child"></i> 대상: <?php echo $program['min_age']; ?>~<?php echo $program['max_age']; ?>개월</p>
                    <p><i class="fas fa-users"></i> 모집: <?php echo $program['current_participants']; ?>/<?php echo $program['max_participants']; ?>명</p>
                    <div class="progress mb-3">
                        <?php $percentage = ($program['current_participants'] / $program['max_participants']) * 100; ?>
                        <div class="progress-bar" role="progressbar" style="width: <?php echo $percentage; ?>%;" 
                             aria-valuenow="<?php echo $program['current_participants']; ?>" 
                             aria-valuemin="0" 
                             aria-valuemax="<?php echo $program['max_participants']; ?>">
                            <?php echo $program['current_participants']; ?>/<?php echo $program['max_participants']; ?>
                        </div>
                    </div>
                    <hr>
                    <p class="price"><strong>참가비용: <?php echo format_price($program['price']); ?></strong></p>
                </div>
            </div>
        </div>
    </div>
</div>