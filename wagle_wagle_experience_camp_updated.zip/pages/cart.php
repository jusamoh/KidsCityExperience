<?php
// cart.php - 장바구니 페이지

// 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// TossPayments SDK 추가
echo '<script src="https://js.tosspayments.com/v1/payment"></script>';

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('로그인이 필요합니다.'); window.location.href='?page=login';</script>";
    exit;
}

require_once 'config/database.php';

$user_id = $_SESSION['user_id'];
$conn = get_db_connection();

// 장바구니 상품 목록 가져오기
$cart_items = [];
$total_amount = 0;

$cart_query = "
    SELECT 
        ci.id as cart_id,
        ci.quantity,
        p.id as product_id,
        p.name,
        p.description,
        p.price,
        p.image_url,
        p.stock_quantity,
        c.name as category_name,
        (ci.quantity * p.price) as subtotal
    FROM cart_items ci
    JOIN products p ON ci.product_id = p.id
    LEFT JOIN shop_categories c ON p.category_id = c.id
    WHERE ci.user_id = ? AND p.is_active = 1
    ORDER BY ci.created_at DESC
";

$stmt = $conn->prepare($cart_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
    $total_amount += $row['subtotal'];
}

$conn->close();
?>

<div class="container mt-4">
    <!-- 페이지 헤더 -->
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="d-flex align-items-center">
 
                장바구니
                <small class="text-muted ms-2">(<?php echo count($cart_items); ?>개 상품)</small>
            </h1>
        </div>
    </div>

    <?php if (empty($cart_items)): ?>
        <!-- 빈 장바구니 -->
        <div class="row">
            <div class="col-12 text-center py-5">

                <h3 class="text-muted mb-3">장바구니가 비어있습니다</h3>
                <p class="text-muted mb-4">와글와글쇼핑에서 아이들을 위한 교육용품을 둘러보세요!</p>
                <a href="?page=shop" class="btn btn-primary btn-lg">
                    쇼핑하러 가기
                </a>
            </div>
        </div>
    <?php else: ?>
        <!-- 장바구니 상품 목록 -->
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            상품 목록
                        </h5>
                    </div>
                    <div class="card-body p-0">
                        <?php foreach ($cart_items as $index => $item): ?>
                            <div class="d-flex align-items-center p-3 <?php echo $index > 0 ? 'border-top' : ''; ?>" 
                                 data-cart-id="<?php echo $item['cart_id']; ?>">
                                
                                <!-- 상품 이미지 -->
                                <div class="flex-shrink-0 me-3">
                                    <img src="<?php echo htmlspecialchars($item['image_url'] ?: 'assets/img/program-default.jpg'); ?>" 
                                         alt="<?php echo htmlspecialchars($item['name']); ?>"
                                         class="rounded"
                                         style="width: 80px; height: 80px; object-fit: cover;">
                                </div>

                                <!-- 상품 정보 -->
                                <div class="flex-grow-1">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($item['name']); ?></h6>
                                    <small class="text-muted">
                                        <?php echo htmlspecialchars($item['category_name']); ?>
                                    </small>
                                    <div class="mt-1">
                                        <span class="text-primary fw-bold">
                                            <?php echo number_format($item['price']); ?>원
                                        </span>
                                    </div>
                                </div>

                                <!-- 수량 조절 -->
                                <div class="flex-shrink-0 me-3">
                                    <div class="d-flex align-items-center">
                                        <button type="button" 
                                                class="btn btn-outline-secondary btn-sm"
                                                onclick="updateQuantity(<?php echo $item['cart_id']; ?>, <?php echo $item['quantity'] - 1; ?>)"
                                                <?php echo $item['quantity'] <= 1 ? 'disabled' : ''; ?>>
                                            -
                                        </button>
                                        <span class="mx-3 fw-bold"><?php echo $item['quantity']; ?></span>
                                        <button type="button" 
                                                class="btn btn-outline-secondary btn-sm"
                                                onclick="updateQuantity(<?php echo $item['cart_id']; ?>, <?php echo $item['quantity'] + 1; ?>)"
                                                <?php echo $item['quantity'] >= $item['stock_quantity'] ? 'disabled' : ''; ?>>
                                            +
                                        </button>
                                    </div>
                                    <small class="text-muted d-block text-center mt-1">
                                        재고: <?php echo $item['stock_quantity']; ?>개
                                    </small>
                                </div>

                                <!-- 소계 -->
                                <div class="flex-shrink-0 me-3 text-end">
                                    <div class="fw-bold text-primary">
                                        <?php echo number_format($item['subtotal']); ?>원
                                    </div>
                                </div>

                                <!-- 삭제 버튼 -->
                                <div class="flex-shrink-0">
                                    <button type="button" 
                                            class="btn btn-outline-danger btn-sm"
                                            onclick="removeFromCart(<?php echo $item['cart_id']; ?>)"
                                            title="상품 삭제">
                                        삭제
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- 계속 쇼핑 버튼 -->
                <div class="mt-3">
                    <a href="?page=shop" class="btn btn-outline-primary">
                        계속 쇼핑하기
                    </a>
                </div>
            </div>

            <!-- 주문 요약 -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            주문 요약
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>상품 총액:</span>
                            <span id="subtotal"><?php echo number_format($total_amount); ?>원</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>배송비:</span>
                            <span><?php echo $total_amount >= 50000 ? '무료' : '3,000원'; ?></span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-3">
                            <strong>총 결제금액:</strong>
                            <strong class="text-primary" id="total">
                                <?php 
                                $shipping_fee = $total_amount >= 50000 ? 0 : 3000;
                                echo number_format($total_amount + $shipping_fee); 
                                ?>원
                            </strong>
                        </div>

                        <?php if ($total_amount < 50000): ?>
                            <div class="alert alert-info small">
 
                                <?php echo number_format(50000 - $total_amount); ?>원 더 구매하시면 무료배송!
                            </div>
                        <?php endif; ?>

                        <div class="d-grid">
                            <button type="button" 
                                    class="btn btn-primary btn-lg"
                                    onclick="proceedToCheckout()">
                                주문하기
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
// 수량 업데이트
async function updateQuantity(cartId, newQuantity) {
    if (newQuantity <= 0) return;
    
    try {
        const response = await fetch('api/cart_update.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                cart_id: cartId,
                quantity: newQuantity
            })
        });

        const result = await response.json();
        
        if (result.success) {
            location.reload(); // 페이지 새로고침으로 업데이트된 내용 표시
        } else {
            alert(result.message || '수량 업데이트에 실패했습니다.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('오류가 발생했습니다.');
    }
}

// 장바구니에서 상품 제거
async function removeFromCart(cartId) {
    if (!confirm('이 상품을 장바구니에서 제거하시겠습니까?')) return;
    
    try {
        const response = await fetch('api/cart_remove.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                cart_id: cartId
            })
        });

        const result = await response.json();
        
        if (result.success) {
            location.reload();
        } else {
            alert(result.message || '상품 제거에 실패했습니다.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('오류가 발생했습니다.');
    }
}

// 주문 진행 (TossPayments 결제)
async function proceedToCheckout() {
    try {
        // 결제 데이터 준비
        const response = await fetch('api/payments_prepare.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({})
        });

        const result = await response.json();
        
        if (!result.success) {
            if (result.message === 'login_required') {
                alert('로그인이 필요합니다.');
                window.location.href = '?page=login';
                return;
            }
            alert(result.message || '결제 준비에 실패했습니다.');
            return;
        }

        // TossPayments SDK 로드 및 결제 요청
        const { amount, orderId, orderName } = result.payment_data;
        
        // TossPayments 결제창 호출
        const tossPayments = TossPayments('<?php echo $_ENV["TOSS_PAYMENTS_CLIENT_KEY"] ?? "test_ck_docs_Ovk5rk1EwkEbP0W43n07xlzm"; ?>');
        
        tossPayments.requestPayment('카드', {
            amount: amount,
            orderId: orderId,
            orderName: orderName,
            customerName: '고객',
            successUrl: window.location.origin + '/xampp_files/pages/payment_success.php',
            failUrl: window.location.origin + '/xampp_files/pages/payment_fail.php',
        });
        
    } catch (error) {
        console.error('Error:', error);
        alert('결제 처리 중 오류가 발생했습니다.');
    }
}
</script>