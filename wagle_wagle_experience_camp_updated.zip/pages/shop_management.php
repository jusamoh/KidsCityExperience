<?php
// shop_management.php - 쇼핑몰 상품 관리 페이지

// 관리자 권한 확인
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    redirect($base_url . '/index.php?page=login');
    exit;
}

// 쇼핑몰 상품 데이터 (파일 기반 관리)
$shop_products_file = __DIR__ . '/../data/shop_products.json';

// 데이터 디렉토리 생성
if (!file_exists(__DIR__ . '/../data')) {
    mkdir(__DIR__ . '/../data', 0755, true);
}

// 기본 상품 데이터
$default_products = [
    ['id' => 1, 'name' => '갈색 곰아 갈색 곰아 무엇을 보고 있니?', 'description' => '에릭 칼의 대표작으로 색깔과 동물을 배울 수 있는 영어 그림책', 'price' => 15000, 'stock_quantity' => 10, 'category_name' => '도서/교재', 'category_id' => 1, 'age_group' => '2-5세', 'image_url' => 'assets/img/brown_bear.jpg'],
    ['id' => 2, 'name' => '무지개 물고기', 'description' => '친구와의 우정을 배울 수 있는 아름다운 그림책', 'price' => 18000, 'stock_quantity' => 10, 'category_name' => '도서/교재', 'category_id' => 1, 'age_group' => '3-7세', 'image_url' => 'assets/img/rainbow-fish.jpg'],
    ['id' => 3, 'name' => '원목 블록 세트 (100피스)', 'description' => '상상력과 창의력을 기르는 천연 원목 블록', 'price' => 45000, 'stock_quantity' => 10, 'category_name' => '교구/완구', 'category_id' => 2, 'age_group' => '3-8세', 'image_url' => 'assets/img/program-1.jpg'],
    ['id' => 4, 'name' => '퍼즐 매트 (알파벳)', 'description' => 'EVA 소재의 안전한 알파벳 학습 매트', 'price' => 32000, 'stock_quantity' => 10, 'category_name' => '교구/완구', 'category_id' => 2, 'age_group' => '2-7세', 'image_url' => 'assets/img/program-61.jpg'],
    ['id' => 5, 'name' => '유아용 크레파스 24색', 'description' => '안전한 소재로 만든 유아 전용 크레파스', 'price' => 12000, 'stock_quantity' => 10, 'category_name' => '미술용품', 'category_id' => 3, 'age_group' => '2-8세', 'image_url' => 'assets/img/program-3.jpg'],
    ['id' => 6, 'name' => '안전 가위 세트', 'description' => '둥근 날로 안전하게 만들어진 유아용 가위', 'price' => 8000, 'stock_quantity' => 10, 'category_name' => '미술용품', 'category_id' => 3, 'age_group' => '4-8세', 'image_url' => 'assets/img/program-default.jpg'],
    ['id' => 7, 'name' => '미니 실로폰', 'description' => '음감 발달을 위한 아이들용 실로폰', 'price' => 35000, 'stock_quantity' => 10, 'category_name' => '음악교구', 'category_id' => 4, 'age_group' => '3-10세', 'image_url' => 'assets/img/program-4.jpg'],
    ['id' => 8, 'name' => '아동용 키보드', 'description' => '음악적 감성을 기르는 키보드', 'price' => 42000, 'stock_quantity' => 10, 'category_name' => '음악교구', 'category_id' => 4, 'age_group' => '4-10세', 'image_url' => 'assets/img/program-10.jpg'],
    ['id' => 9, 'name' => '균형 잡기 보드', 'description' => '균형감각과 코어 근육 발달을 위한 보드', 'price' => 55000, 'stock_quantity' => 10, 'category_name' => '체육용품', 'category_id' => 5, 'age_group' => '4-10세', 'image_url' => 'assets/img/program-5.jpg'],
    ['id' => 10, 'name' => '소프트 공 세트 (6개)', 'description' => '부드러운 재질의 안전한 놀이용 공', 'price' => 25000, 'stock_quantity' => 10, 'category_name' => '체육용품', 'category_id' => 5, 'age_group' => '1-6세', 'image_url' => 'assets/img/program-11.jpg']
];

// 카테고리 정의
$categories = [
    ['id' => 1, 'name' => '도서/교재'],
    ['id' => 2, 'name' => '교구/완구'],
    ['id' => 3, 'name' => '미술용품'],
    ['id' => 4, 'name' => '음악교구'],
    ['id' => 5, 'name' => '체육용품']
];

// 상품 데이터 로드
function load_shop_products() {
    global $shop_products_file, $default_products;
    
    if (file_exists($shop_products_file)) {
        $data = file_get_contents($shop_products_file);
        return json_decode($data, true) ?: $default_products;
    }
    
    return $default_products;
}

// 상품 데이터 저장
function save_shop_products($products) {
    global $shop_products_file;
    
    file_put_contents($shop_products_file, json_encode($products, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// 다음 ID 생성
function get_next_product_id($products) {
    $max_id = 0;
    foreach ($products as $product) {
        if ($product['id'] > $max_id) {
            $max_id = $product['id'];
        }
    }
    return $max_id + 1;
}

$products = load_shop_products();
$message = '';

// 폼 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $new_product = [
            'id' => get_next_product_id($products),
            'name' => $_POST['name'],
            'description' => $_POST['description'],
            'price' => (int)$_POST['price'],
            'stock_quantity' => (int)$_POST['stock_quantity'],
            'category_id' => (int)$_POST['category_id'],
            'category_name' => '',
            'age_group' => $_POST['age_group'],
            'image_url' => $_POST['image_url']
        ];
        
        // 카테고리명 설정
        foreach ($categories as $cat) {
            if ($cat['id'] == $new_product['category_id']) {
                $new_product['category_name'] = $cat['name'];
                break;
            }
        }
        
        $products[] = $new_product;
        save_shop_products($products);
        $message = '<div class="alert alert-success">상품이 성공적으로 추가되었습니다.</div>';
        
    } elseif ($action === 'edit') {
        $product_id = (int)$_POST['product_id'];
        
        for ($i = 0; $i < count($products); $i++) {
            if ($products[$i]['id'] == $product_id) {
                $products[$i]['name'] = $_POST['name'];
                $products[$i]['description'] = $_POST['description'];
                $products[$i]['price'] = (int)$_POST['price'];
                $products[$i]['stock_quantity'] = (int)$_POST['stock_quantity'];
                $products[$i]['category_id'] = (int)$_POST['category_id'];
                $products[$i]['age_group'] = $_POST['age_group'];
                $products[$i]['image_url'] = $_POST['image_url'];
                
                // 카테고리명 업데이트
                foreach ($categories as $cat) {
                    if ($cat['id'] == $products[$i]['category_id']) {
                        $products[$i]['category_name'] = $cat['name'];
                        break;
                    }
                }
                break;
            }
        }
        
        save_shop_products($products);
        $message = '<div class="alert alert-success">상품이 성공적으로 수정되었습니다.</div>';
        
    } elseif ($action === 'delete') {
        $product_id = (int)$_POST['product_id'];
        
        $products = array_filter($products, function($product) use ($product_id) {
            return $product['id'] != $product_id;
        });
        
        save_shop_products(array_values($products));
        $message = '<div class="alert alert-success">상품이 성공적으로 삭제되었습니다.</div>';
    }
    
    // 업데이트된 상품 목록 다시 로드
    $products = load_shop_products();
}

// 편집할 상품 정보
$edit_product = null;
if (isset($_GET['edit']) && $_GET['edit']) {
    $edit_id = (int)$_GET['edit'];
    foreach ($products as $product) {
        if ($product['id'] == $edit_id) {
            $edit_product = $product;
            break;
        }
    }
}
?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>와글와글쇼핑 상품 관리</h2>
                <a href="<?php echo $base_url; ?>/index.php?page=admin_dashboard" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> 관리자 대시보드
                </a>
            </div>
        </div>
    </div>

    <?php echo $message; ?>

    <!-- 상품 추가/수정 폼 -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <?php echo $edit_product ? '상품 수정' : '상품 추가'; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <form method="post" action="">
                        <input type="hidden" name="action" value="<?php echo $edit_product ? 'edit' : 'add'; ?>">
                        <?php if ($edit_product): ?>
                            <input type="hidden" name="product_id" value="<?php echo $edit_product['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">상품명 *</label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       value="<?php echo $edit_product ? escape_string($edit_product['name']) : ''; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="category_id" class="form-label">카테고리 *</label>
                                <select class="form-control" id="category_id" name="category_id" required>
                                    <option value="">카테고리 선택</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" 
                                                <?php echo ($edit_product && $edit_product['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                            <?php echo escape_string($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">상품 설명 *</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required><?php echo $edit_product ? escape_string($edit_product['description']) : ''; ?></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="price" class="form-label">가격 (원) *</label>
                                <input type="number" class="form-control" id="price" name="price" min="0" 
                                       value="<?php echo $edit_product ? $edit_product['price'] : ''; ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="stock_quantity" class="form-label">재고 수량 *</label>
                                <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" min="0" 
                                       value="<?php echo $edit_product ? $edit_product['stock_quantity'] : ''; ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="age_group" class="form-label">연령대 *</label>
                                <input type="text" class="form-control" id="age_group" name="age_group" 
                                       value="<?php echo $edit_product ? escape_string($edit_product['age_group']) : ''; ?>" 
                                       placeholder="예: 2-5세" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="image_url" class="form-label">이미지 URL</label>
                            <input type="text" class="form-control" id="image_url" name="image_url" 
                                   value="<?php echo $edit_product ? escape_string($edit_product['image_url']) : ''; ?>" 
                                   placeholder="assets/img/product.jpg">
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> 
                                <?php echo $edit_product ? '수정하기' : '추가하기'; ?>
                            </button>
                            <?php if ($edit_product): ?>
                                <a href="<?php echo $base_url; ?>/index.php?page=shop_management" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> 취소
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- 상품 목록 -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">등록된 상품 목록 (총 <?php echo count($products); ?>개)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>이미지</th>
                                    <th>상품명</th>
                                    <th>카테고리</th>
                                    <th>가격</th>
                                    <th>재고</th>
                                    <th>연령대</th>
                                    <th>관리</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($products as $product): ?>
                                    <tr>
                                        <td><?php echo $product['id']; ?></td>
                                        <td>
                                            <img src="<?php echo $base_url; ?>/<?php echo $product['image_url']; ?>" 
                                                 alt="상품 이미지" class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                        </td>
                                        <td>
                                            <strong><?php echo escape_string($product['name']); ?></strong><br>
                                            <small class="text-muted"><?php echo escape_string(substr($product['description'], 0, 50)); ?>...</small>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary"><?php echo escape_string($product['category_name']); ?></span>
                                        </td>
                                        <td><?php echo format_price($product['price']); ?></td>
                                        <td>
                                            <span class="badge <?php echo $product['stock_quantity'] > 0 ? 'bg-success' : 'bg-danger'; ?>">
                                                <?php echo $product['stock_quantity']; ?>개
                                            </span>
                                        </td>
                                        <td><?php echo escape_string($product['age_group']); ?></td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="<?php echo $base_url; ?>/index.php?page=shop_management&edit=<?php echo $product['id']; ?>" 
                                                   class="btn btn-outline-primary" title="수정">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form method="post" action="" style="display: inline-block;" 
                                                      onsubmit="return confirm('이 상품을 삭제하시겠습니까?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                                    <button type="submit" class="btn btn-outline-danger" title="삭제">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.btn-group-sm .btn {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}

.table th {
    border-top: none;
    font-weight: 600;
    background-color: #f8f9fa;
}

.img-thumbnail {
    border-radius: 0.375rem;
}

.badge {
    font-size: 0.8rem;
}
</style>