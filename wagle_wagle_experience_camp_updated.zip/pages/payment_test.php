<?php
// payment_test.php - 테스트 결제 페이지 (로컬호스트용)
// 실제 토스페이먼츠 연동 없이 결제 완료 처리를 시뮬레이션합니다.

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    redirect('index.php?page=login');
    exit;
}

// 결제 정보 초기화
$payment_info = null;
$registrations = [];

// 1. registration_id로 결제 정보 조회
if (isset($_GET['registration_id'])) {
    $registration_id = intval($_GET['registration_id']);
    $registration = get_registration($registration_id);
    
    if ($registration) {
        $registrations[] = $registration;
        $program = get_program($registration['program_id']);
        
        if ($program) {
            // 결제 정보 생성
            $payment_info = [
                'registration_id' => $registration['id'],
                'program_id' => $program['id'],
                'program_title' => $program['title'],
                'amount' => $program['price'],
                'order_id' => 'TEST_' . time() . '_' . $registration['id']
            ];
        }
    }
}
// 2. 일괄 결제 (program_ids)
else if (isset($_GET['program_ids'])) {
    $program_ids = explode(',', $_GET['program_ids']);
    $total_amount = 0;
    $programs = [];
    
    foreach ($program_ids as $program_id) {
        $program_id = intval($program_id);
        if ($program_id > 0) {
            $program = get_program($program_id);
            if ($program) {
                $programs[] = $program;
                $total_amount += $program['price'];
                
                // 해당 프로그램에 대한 사용자의 등록 정보 찾기
                $user_id = $_SESSION['user_id'];
                $registrations_for_program = get_user_registrations_for_program($user_id, $program_id);
                
                if (!empty($registrations_for_program)) {
                    foreach ($registrations_for_program as $reg) {
                        if ($reg['payment_status'] === 'pending') {
                            $registrations[] = $reg;
                        }
                    }
                }
            }
        }
    }
    
    if (!empty($programs)) {
        // 결제 정보 생성 (일괄 결제)
        $payment_info = [
            'programs' => $programs,
            'amount' => $total_amount,
            'order_id' => 'TEST_BATCH_' . time() . '_' . $_SESSION['user_id']
        ];
    }
}

// 결제 정보가 없으면 프로그램 선택 페이지로 이동
if (!$payment_info) {
    set_message('결제할 프로그램 정보를 찾을 수 없습니다.', 'warning');
    redirect('index.php?page=program_selection');
    exit;
}

// POST 요청 처리 (결제 처리)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'complete_payment') {
    $conn = get_db_connection();
    
    try {
        // 트랜잭션 시작
        $conn->begin_transaction();
        
        foreach ($registrations as $registration) {
            // 1. 결제 정보 생성
            $sql = "INSERT INTO payments (
                registration_id, amount, payment_method, status, 
                order_id, payment_key, paid_at, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())";
            
            $stmt = $conn->prepare($sql);
            $registration_id = $registration['id'];
            $amount = isset($program) ? $program['price'] : $payment_info['amount'];
            $payment_method = '테스트 결제';
            $status = 'completed';
            $order_id = $payment_info['order_id'];
            $payment_key = 'TEST_KEY_' . time();
            
            $stmt->bind_param('idssss', $registration_id, $amount, $payment_method, $status, $order_id, $payment_key);
            $stmt->execute();
            
            // 2. 등록 정보 업데이트
            $sql = "UPDATE registrations SET 
                    payment_status = 'completed',
                    updated_at = NOW()
                    WHERE id = ?";
                    
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('i', $registration_id);
            $stmt->execute();
            
            // 3. 프로그램 참가자 수 갱신
            $program_id = $registration['program_id'];
            
            // 프로그램 상태 업데이트 함수가 있는 경우 호출
            if (function_exists('update_program_status_by_registration')) {
                update_program_status_by_registration($program_id);
            }
        }
        
        // 트랜잭션 커밋
        $conn->commit();
        
        // 성공 메시지 설정
        set_message('테스트 결제가 성공적으로 완료되었습니다.', 'success');
        
        // 마이페이지로 이동
        redirect('index.php?page=my_page');
        exit;
        
    } catch (Exception $e) {
        // 트랜잭션 롤백
        $conn->rollback();
        
        // 오류 로그 기록 및 메시지 설정
        error_log('결제 처리 오류: ' . $e->getMessage());
        set_message('결제 처리 중 오류가 발생했습니다: ' . $e->getMessage(), 'danger');
    }
    
    $conn->close();
}

// 사용자 등록 정보 조회 함수
function get_user_registrations_for_program($user_id, $program_id) {
    $conn = get_db_connection();
    
    // 데이터베이스에 user_id 컬럼이 있는지 확인
    $check_column_sql = "SHOW COLUMNS FROM registrations LIKE 'user_id'";
    $check_result = $conn->query($check_column_sql);
    $has_user_id_column = $check_result && $check_result->num_rows > 0;
    
    // 사용자 정보 가져오기
    $user = get_user($user_id);
    $email = isset($user['email']) ? $user['email'] : '';
    
    if ($has_user_id_column) {
        // user_id 컬럼이 있는 경우
        $stmt = $conn->prepare("SELECT * FROM registrations WHERE user_id = ? AND program_id = ? AND payment_status = 'pending'");
        $stmt->bind_param('ii', $user_id, $program_id);
    } else {
        // user_id 컬럼이 없는 경우 이메일로 조회
        $stmt = $conn->prepare("SELECT * FROM registrations WHERE email = ? AND program_id = ? AND payment_status = 'pending'");
        $stmt->bind_param('si', $email, $program_id);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $registrations = [];
    while ($row = $result->fetch_assoc()) {
        $registrations[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    return $registrations;
}
?>

<div class="container">
    <h2 class="mb-4">테스트 결제 페이지</h2>
    <div class="alert alert-info">
        <p><i class="fas fa-info-circle"></i> 이 페이지는 로컬 테스트 환경에서 결제를 시뮬레이션하기 위한 페이지입니다.</p>
        <p>실제 토스페이먼츠 연동 없이 결제가 완료된 것으로 처리됩니다.</p>
    </div>
    
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">결제 정보</h4>
        </div>
        <div class="card-body">
            <?php if (isset($payment_info['programs'])): // 일괄 결제 ?>
                <h5 class="mb-3">결제할 프로그램</h5>
                <div class="table-responsive mb-4">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>프로그램</th>
                                <th class="text-end">가격</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payment_info['programs'] as $program): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($program['title']); ?></td>
                                    <td class="text-end"><?php echo number_format($program['price']); ?>원</td>
                                </tr>
                            <?php endforeach; ?>
                            <tr class="table-active">
                                <th>총 결제 금액</th>
                                <th class="text-end"><?php echo number_format($payment_info['amount']); ?>원</th>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php else: // 단일 결제 ?>
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">프로그램:</div>
                    <div class="col-md-8"><?php echo htmlspecialchars($payment_info['program_title']); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">결제 금액:</div>
                    <div class="col-md-8"><?php echo number_format($payment_info['amount']); ?>원</div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 fw-bold">주문 번호:</div>
                    <div class="col-md-8"><?php echo htmlspecialchars($payment_info['order_id']); ?></div>
                </div>
            <?php endif; ?>
            
            <form action="<?php echo $base_url; ?>/index.php?page=payment_test<?php echo isset($_GET['registration_id']) ? '&registration_id=' . $_GET['registration_id'] : (isset($_GET['program_ids']) ? '&program_ids=' . $_GET['program_ids'] : ''); ?>" method="post" class="mt-4">
                <input type="hidden" name="action" value="complete_payment">
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" id="payment_method_card" value="카드" checked>
                            <label class="form-check-label" for="payment_method_card">
                                신용카드 결제
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" id="payment_method_bank" value="계좌이체">
                            <label class="form-check-label" for="payment_method_bank">
                                계좌이체
                            </label>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="<?php echo $base_url; ?>/index.php?page=my_page" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-1"></i> 돌아가기
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check-circle me-1"></i> 테스트 결제 완료
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="alert alert-warning">
        <p><i class="fas fa-exclamation-triangle"></i> 테스트 결제는 실제 결제가 발생하지 않습니다. 데이터베이스에 결제 완료 상태만 기록됩니다.</p>
    </div>
</div>