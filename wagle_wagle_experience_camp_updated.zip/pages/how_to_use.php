<?php
// how_to_use.php - 이용방법 안내 페이지
?>

<div class="container">
    <h2 class="mb-4">와글와글 체험Camp 이용방법</h2>
    
    <div class="row">
        <div class="col-md-12 mb-5">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h3 class="card-title">와글와글 체험Camp 소개</h3>
                    <p class="card-text">
                        와글와글 체험Camp는 2세 이하 영유아를 위한 다양한 체험 프로그램을 제공하는 플랫폼입니다. 
                        아이들의 감각 발달과 창의력 향상을 위한 프로그램들로 구성되어 있습니다.
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-md-12">
            <h3 class="mb-4">프로그램 참여 방법</h3>
            <div class="timeline">
                <div class="row mb-4">
                    <div class="col-md-1 text-center">
                        <div class="timeline-number">1</div>
                    </div>
                    <div class="col-md-11">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">회원가입 및 로그인</h5>
                                <p class="card-text">
                                    와글와글 체험Camp의 서비스를 이용하기 위해 먼저 회원가입을 합니다. 
                                    이미 회원이신 경우에는 로그인을, 새로운 회원은 가입하기를 선택합니다.
                                </p>
                                <div class="d-flex justify-content-end">
                                    <a href="index.php?page=register" class="btn btn-outline-primary me-2">가입하기</a>
                                    <a href="index.php?page=login" class="btn btn-primary">로그인</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-1 text-center">
                        <div class="timeline-number">2</div>
                    </div>
                    <div class="col-md-11">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">프로그램 선택</h5>
                                <p class="card-text">
                                    체험 프로그램 메뉴에서 원하는 프로그램을 찾아봅니다. 
                                    카테고리별로 분류되어 있어 쉽게 찾을 수 있습니다.
                                    자세히 보기를 클릭하여 프로그램의 상세 정보를 확인할 수 있습니다.
                                </p>
                                <div class="d-flex justify-content-end">
                                    <a href="index.php?page=program_selection" class="btn btn-primary">프로그램 보기</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-1 text-center">
                        <div class="timeline-number">3</div>
                    </div>
                    <div class="col-md-11">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">신청 및 결제</h5>
                                <p class="card-text">
                                    원하는 프로그램을 선택한 후 '신청하기' 버튼을 클릭하여 참가 신청을 합니다.
                                    아이의 정보와 보호자 정보를 입력한 후 결제를 진행합니다.
                                    결제는 신용카드, 계좌이체 등 다양한 방법으로 가능합니다.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-1 text-center">
                        <div class="timeline-number">4</div>
                    </div>
                    <div class="col-md-11">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">참여 확정 및 알림</h5>
                                <p class="card-text">
                                    각 프로그램은 최소 인원이 모집되면 진행됩니다.
                                    모집 인원이 충족되면 신청자에게 이메일과 SMS로 알림이 발송됩니다.
                                    최소 인원이 모집되지 않아 취소되는 경우 전액 환불 처리됩니다.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-1 text-center">
                        <div class="timeline-number">5</div>
                    </div>
                    <div class="col-md-11">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">체험 참여</h5>
                                <p class="card-text">
                                    안내된 날짜와 시간에 맞춰 체험 장소에 방문합니다.
                                    체험 시 필요한 준비물이 있다면 미리 준비해주세요.
                                    체험 후 마이페이지에서 신청 내역을 확인할 수 있습니다.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-md-6 mb-4 mb-md-0">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4 class="card-title">자주 묻는 질문</h4>
                    <p class="card-text">
                        프로그램 신청, 결제, 취소 및 환불 등에 관한 자주 묻는 질문들을 확인하세요.
                    </p>
                </div>
                <div class="card-footer">
                    <a href="index.php?page=faq" class="btn btn-primary">FAQ 보기</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4 class="card-title">문의하기</h4>
                    <p class="card-text">
                        추가 문의사항이 있으시면 언제든지 연락주세요.
                    </p>
                    <p><i class="fas fa-phone me-2"></i> 02-123-4567</p>
                    <p><i class="fas fa-envelope me-2"></i> info@paju.kr</p>
                </div>
                <div class="card-footer">
                    <button class="btn btn-secondary" disabled>문의하기</button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.timeline-number {
    width: 40px;
    height: 40px;
    background-color: var(--primary-color);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.2rem;
    margin: 0 auto;
}
</style>