<?php
// shop_management_inline.php - 관리자 대시보드에 통합된 쇼핑몰 상품 관리

// 쇼핑몰 상품 데이터 (파일 기반 관리)
$shop_products_file = __DIR__ . '/../data/shop_products.json';

// 데이터 디렉토리 생성
if (!file_exists(__DIR__ . '/../data')) {
    mkdir(__DIR__ . '/../data', 0755, true);
}

// 기본 상품 데이터
$default_products = [
    ['id' => 1, 'name' => '갈색 곰아 갈색 곰아 무엇을 보고 있니?', 'description' => '에릭 칼의 대표작으로 색깔과 동물을 배울 수 있는 영어 그림책', 'price' => 15000, 'stock_quantity' => 10, 'category_name' => '도서/교재', 'category_id' => 1, 'age_group' => '2-5세', 'image_url' => 'assets/img/shop/brown_bear.jpg'],
    ['id' => 2, 'name' => '무지개 물고기', 'description' => '친구와의 우정을 배울 수 있는 아름다운 그림책', 'price' => 18000, 'stock_quantity' => 10, 'category_name' => '도서/교재', 'category_id' => 1, 'age_group' => '3-7세', 'image_url' => 'assets/img/shop/rainbow-fish.jpg'],
    ['id' => 3, 'name' => '원목 블록 세트 (100피스)', 'description' => '상상력과 창의력을 기르는 천연 원목 블록', 'price' => 45000, 'stock_quantity' => 10, 'category_name' => '교구/완구', 'category_id' => 2, 'age_group' => '3-8세', 'image_url' => 'assets/img/programs/program-1.jpg'],
    ['id' => 4, 'name' => '퍼즐 매트 (알파벳)', 'description' => 'EVA 소재의 안전한 알파벳 학습 매트', 'price' => 32000, 'stock_quantity' => 10, 'category_name' => '교구/완구', 'category_id' => 2, 'age_group' => '2-7세', 'image_url' => 'assets/img/programs/program-61.jpg'],
    ['id' => 5, 'name' => '유아용 크레파스 24색', 'description' => '안전한 소재로 만든 유아 전용 크레파스', 'price' => 12000, 'stock_quantity' => 10, 'category_name' => '미술용품', 'category_id' => 3, 'age_group' => '2-8세', 'image_url' => 'assets/img/programs/program-3.jpg'],
    ['id' => 6, 'name' => '안전 가위 세트', 'description' => '둥근 날로 안전하게 만들어진 유아용 가위', 'price' => 8000, 'stock_quantity' => 10, 'category_name' => '미술용품', 'category_id' => 3, 'age_group' => '4-8세', 'image_url' => 'assets/img/programs/program-default.jpg'],
    ['id' => 7, 'name' => '미니 실로폰', 'description' => '음감 발달을 위한 아이들용 실로폰', 'price' => 35000, 'stock_quantity' => 10, 'category_name' => '음악교구', 'category_id' => 4, 'age_group' => '3-10세', 'image_url' => 'assets/img/programs/program-4.jpg'],
    ['id' => 8, 'name' => '아동용 키보드', 'description' => '음악적 감성을 기르는 키보드', 'price' => 42000, 'stock_quantity' => 10, 'category_name' => '음악교구', 'category_id' => 4, 'age_group' => '4-10세', 'image_url' => 'assets/img/programs/program-10.jpg'],
    ['id' => 9, 'name' => '균형 잡기 보드', 'description' => '균형감각과 코어 근육 발달을 위한 보드', 'price' => 55000, 'stock_quantity' => 10, 'category_name' => '체육용품', 'category_id' => 5, 'age_group' => '4-10세', 'image_url' => 'assets/img/programs/program-5.jpg'],
    ['id' => 10, 'name' => '소프트 공 세트 (6개)', 'description' => '부드러운 재질의 안전한 놀이용 공', 'price' => 25000, 'stock_quantity' => 10, 'category_name' => '체육용품', 'category_id' => 5, 'age_group' => '1-6세', 'image_url' => 'assets/img/programs/program-11.jpg']
];

// 카테고리 정의
$categories = [
    ['id' => 1, 'name' => '도서/교재'],
    ['id' => 2, 'name' => '교구/완구'],
    ['id' => 3, 'name' => '미술용품'],
    ['id' => 4, 'name' => '음악교구'],
    ['id' => 5, 'name' => '체육용품']
];

// 상품 데이터 로드
function load_shop_products_inline() {
    global $shop_products_file, $default_products;
    
    if (file_exists($shop_products_file)) {
        $data = file_get_contents($shop_products_file);
        return json_decode($data, true) ?: $default_products;
    }
    
    return $default_products;
}

// 상품 데이터 저장
function save_shop_products_inline($products) {
    global $shop_products_file;
    
    file_put_contents($shop_products_file, json_encode($products, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// 다음 ID 생성
function get_next_product_id_inline($products) {
    $max_id = 0;
    foreach ($products as $product) {
        if ($product['id'] > $max_id) {
            $max_id = $product['id'];
        }
    }
    return $max_id + 1;
}

$products = load_shop_products_inline();
$message = '';

// 폼 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['shop_action'])) {
    $action = $_POST['shop_action'];
    
    if ($action === 'add') {
        // 파일 업로드 처리
        $image_url = 'assets/img/shop/default-product.jpg'; // 기본 이미지
        
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
            // 허용된 MIME 타입과 확장자
            $allowed_mime_types = [
                'image/jpeg' => ['jpg', 'jpeg'],
                'image/png' => ['png'],
                'image/gif' => ['gif'],
                'image/webp' => ['webp']
            ];
            
            $file_type = $_FILES['product_image']['type'];
            $file_size = $_FILES['product_image']['size'];
            $max_size = 5 * 1024 * 1024; // 5MB
            $original_name = $_FILES['product_image']['name'];
            
            // 파일 확장자 추출 및 검증
            $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
            $is_valid_type = false;
            
            foreach ($allowed_mime_types as $mime => $extensions) {
                if ($file_type === $mime && in_array($file_ext, $extensions)) {
                    $is_valid_type = true;
                    break;
                }
            }
            
            if ($is_valid_type && $file_size <= $max_size) {
                $upload_dir = 'assets/img/shop/';
                
                // 디렉토리가 없으면 생성
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                // 안전한 파일명 생성 (한글 및 특수문자 처리)
                $safe_name = preg_replace('/[^a-zA-Z0-9가-힣._-]/', '', pathinfo($original_name, PATHINFO_FILENAME));
                $safe_name = mb_substr($safe_name, 0, 50); // 파일명 길이 제한
                
                // 고유한 파일명 생성: shop_제품명_타임스탬프.확장자
                $timestamp = date('Ymd_His');
                $new_file_name = 'shop_' . $safe_name . '_' . $timestamp . '.' . $file_ext;
                $file_path = $upload_dir . $new_file_name;
                
                if (move_uploaded_file($_FILES['product_image']['tmp_name'], $file_path)) {
                    $image_url = $file_path;
                } else {
                    $message = '<div class="alert alert-danger">파일 업로드에 실패했습니다. 파일 권한을 확인해주세요.</div>';
                }
            } else {
                if ($file_size > $max_size) {
                    $message = '<div class="alert alert-danger">파일 크기가 너무 큽니다. 최대 5MB까지 허용됩니다. (현재: ' . round($file_size / 1024 / 1024, 2) . 'MB)</div>';
                } else {
                    $valid_extensions = [];
                    foreach ($allowed_mime_types as $extensions) {
                        $valid_extensions = array_merge($valid_extensions, $extensions);
                    }
                    $message = '<div class="alert alert-danger">지원하지 않는 파일 형식입니다. 허용 형식: ' . strtoupper(implode(', ', $valid_extensions)) . '</div>';
                }
            }
        }
        
        $new_product = [
            'id' => get_next_product_id_inline($products),
            'name' => $_POST['name'],
            'description' => $_POST['description'],
            'price' => (int)$_POST['price'],
            'stock_quantity' => (int)$_POST['stock_quantity'],
            'category_id' => (int)$_POST['category_id'],
            'category_name' => '',
            'age_group' => $_POST['age_group'],
            'image_url' => $image_url
        ];
        
        // 카테고리명 설정
        foreach ($categories as $cat) {
            if ($cat['id'] == $new_product['category_id']) {
                $new_product['category_name'] = $cat['name'];
                break;
            }
        }
        
        $products[] = $new_product;
        save_shop_products_inline($products);
        $message = '<div class="alert alert-success">상품이 성공적으로 추가되었습니다.</div>';
        
    } elseif ($action === 'edit') {
        $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
        
        if ($product_id <= 0) {
            $message = '<div class="alert alert-danger">유효하지 않은 상품 ID입니다.</div>';
            return;
        }
        
        for ($i = 0; $i < count($products); $i++) {
            if ($products[$i]['id'] == $product_id) {
                // 기존 이미지 URL 유지
                $image_url = isset($_POST['current_image_url']) ? $_POST['current_image_url'] : $products[$i]['image_url'];
                
                // 새 파일이 업로드되었는지 확인
                if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
                    // 허용된 MIME 타입과 확장자
                    $allowed_mime_types = [
                        'image/jpeg' => ['jpg', 'jpeg'],
                        'image/png' => ['png'],
                        'image/gif' => ['gif'],
                        'image/webp' => ['webp']
                    ];
                    
                    $file_type = $_FILES['product_image']['type'];
                    $file_size = $_FILES['product_image']['size'];
                    $max_size = 5 * 1024 * 1024; // 5MB
                    $original_name = $_FILES['product_image']['name'];
                    
                    // 파일 확장자 추출 및 검증
                    $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
                    $is_valid_type = false;
                    
                    foreach ($allowed_mime_types as $mime => $extensions) {
                        if ($file_type === $mime && in_array($file_ext, $extensions)) {
                            $is_valid_type = true;
                            break;
                        }
                    }
                    
                    if ($is_valid_type && $file_size <= $max_size) {
                        $upload_dir = 'assets/img/shop/';
                        
                        // 디렉토리가 없으면 생성
                        if (!file_exists($upload_dir)) {
                            mkdir($upload_dir, 0777, true);
                        }
                        
                        // 안전한 파일명 생성 (한글 및 특수문자 처리)
                        $safe_name = preg_replace('/[^a-zA-Z0-9가-힣._-]/', '', pathinfo($original_name, PATHINFO_FILENAME));
                        $safe_name = mb_substr($safe_name, 0, 50); // 파일명 길이 제한
                        
                        // 고유한 파일명 생성: shop_제품명_타임스탬프.확장자
                        $timestamp = date('Ymd_His');
                        $new_file_name = 'shop_' . $safe_name . '_' . $timestamp . '.' . $file_ext;
                        $file_path = $upload_dir . $new_file_name;
                        
                        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $file_path)) {
                            $image_url = $file_path; // 새 이미지로 업데이트
                        } else {
                            $message = '<div class="alert alert-danger">파일 업로드에 실패했습니다. 파일 권한을 확인해주세요.</div>';
                        }
                    } else {
                        if ($file_size > $max_size) {
                            $message = '<div class="alert alert-danger">파일 크기가 너무 큽니다. 최대 5MB까지 허용됩니다. (현재: ' . round($file_size / 1024 / 1024, 2) . 'MB)</div>';
                        } else {
                            $valid_extensions = [];
                            foreach ($allowed_mime_types as $extensions) {
                                $valid_extensions = array_merge($valid_extensions, $extensions);
                            }
                            $message = '<div class="alert alert-danger">지원하지 않는 파일 형식입니다. 허용 형식: ' . strtoupper(implode(', ', $valid_extensions)) . '</div>';
                        }
                    }
                }
                
                $products[$i]['name'] = $_POST['name'];
                $products[$i]['description'] = $_POST['description'];
                $products[$i]['price'] = (int)$_POST['price'];
                $products[$i]['stock_quantity'] = (int)$_POST['stock_quantity'];
                $products[$i]['category_id'] = (int)$_POST['category_id'];
                $products[$i]['age_group'] = $_POST['age_group'];
                $products[$i]['image_url'] = $image_url;
                
                // 카테고리명 업데이트
                foreach ($categories as $cat) {
                    if ($cat['id'] == $products[$i]['category_id']) {
                        $products[$i]['category_name'] = $cat['name'];
                        break;
                    }
                }
                break;
            }
        }
        
        save_shop_products_inline($products);
        $message = '<div class="alert alert-success">상품이 성공적으로 수정되었습니다.</div>';
        
    } elseif ($action === 'delete') {
        $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
        
        if ($product_id <= 0) {
            $message = '<div class="alert alert-danger">유효하지 않은 상품 ID입니다.</div>';
            return;
        }
        
        $products = array_filter($products, function($product) use ($product_id) {
            return $product['id'] != $product_id;
        });
        
        save_shop_products_inline(array_values($products));
        $message = '<div class="alert alert-success">상품이 성공적으로 삭제되었습니다.</div>';
    }
    
    // 업데이트된 상품 목록 다시 로드
    $products = load_shop_products_inline();
}

// 편집할 상품 정보
$edit_product = null;
if (isset($_GET['edit_shop']) && $_GET['edit_shop']) {
    $edit_id = (int)$_GET['edit_shop'];
    foreach ($products as $product) {
        if ($product['id'] == $edit_id) {
            $edit_product = $product;
            break;
        }
    }
}

// POST로 edit_product_id가 넘어온 경우도 처리
if (isset($_POST['edit_product_id']) && $_POST['edit_product_id']) {
    $edit_id = (int)$_POST['edit_product_id'];
    foreach ($products as $product) {
        if ($product['id'] == $edit_id) {
            $edit_product = $product;
            break;
        }
    }
}
?>

<div class="card">
    <div class="card-header">
        <h4 class="mb-0"><i class="fas fa-shopping-cart me-2"></i>와글와글쇼핑 상품 관리</h4>
    </div>
    <div class="card-body">
        <?php echo $message; ?>

        <!-- 상품 추가/수정 폼 -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <?php echo $edit_product ? '상품 수정' : '상품 추가'; ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="post" action="" enctype="multipart/form-data">
                            <input type="hidden" name="shop_action" value="<?php echo $edit_product ? 'edit' : 'add'; ?>">
                            <?php if ($edit_product): ?>
                                <input type="hidden" name="product_id" value="<?php echo $edit_product['id']; ?>">
                            <?php endif; ?>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label">상품명 *</label>
                                    <input type="text" class="form-control" id="name" name="name" 
                                           value="<?php echo $edit_product ? escape_string($edit_product['name']) : ''; ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="category_id" class="form-label">카테고리 *</label>
                                    <select class="form-control" id="category_id" name="category_id" required>
                                        <option value="">카테고리 선택</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>" 
                                                    <?php echo ($edit_product && $edit_product['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                                <?php echo escape_string($category['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">상품 설명 *</label>
                                <textarea class="form-control" id="description" name="description" rows="3" required><?php echo $edit_product ? escape_string($edit_product['description']) : ''; ?></textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="price" class="form-label">가격 (원) *</label>
                                    <input type="number" class="form-control" id="price" name="price" min="0" 
                                           value="<?php echo $edit_product ? $edit_product['price'] : ''; ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="stock_quantity" class="form-label">재고 수량 *</label>
                                    <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" min="0" 
                                           value="<?php echo $edit_product ? $edit_product['stock_quantity'] : ''; ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="age_group" class="form-label">연령대 *</label>
                                    <input type="text" class="form-control" id="age_group" name="age_group" 
                                           value="<?php echo $edit_product ? escape_string($edit_product['age_group']) : ''; ?>" 
                                           placeholder="예: 2-5세" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="product_image" class="form-label">상품 이미지</label>
                                <input type="file" class="form-control" id="product_image" name="product_image" 
                                       accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" onchange="previewImage(this)">
                                <div class="form-text">
                                    <strong>지원 형식:</strong> JPEG, JPG, PNG, GIF, WEBP (최대 5MB)<br>
                                    <strong>파일명 규칙:</strong> shop_원본파일명_날짜시간.확장자<br>
                                    <strong>자동 저장 위치:</strong> <code>assets/img/shop/</code> 폴더
                                </div>
                                
                                <!-- 이미지 미리보기 -->
                                <div id="image-preview" class="mt-3" style="display: none;">
                                    <img id="preview-img" src="" alt="미리보기" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                                    <div class="mt-2">
                                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeImage()">
                                            <i class="fas fa-trash"></i> 이미지 제거
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- 기존 이미지 표시 (수정 모드일 때) -->
                                <?php if ($edit_product && !empty($edit_product['image_url'])): ?>
                                <div id="current-image" class="mt-3">
                                    <label class="form-label">현재 이미지:</label><br>
                                    <img src="<?php echo $base_url; ?>/<?php echo $edit_product['image_url']; ?>" 
                                         alt="현재 상품 이미지" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                                    <input type="hidden" name="current_image_url" value="<?php echo escape_string($edit_product['image_url']); ?>">
                                    <div class="form-text">새 이미지를 선택하지 않으면 기존 이미지가 유지됩니다.</div>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> 
                                    <?php echo $edit_product ? '수정하기' : '추가하기'; ?>
                                </button>
                                <?php if ($edit_product): ?>
                                    <a href="<?php echo $base_url; ?>/index.php?page=admin_dashboard" class="btn btn-secondary">
                                        <i class="fas fa-times"></i> 취소
                                    </a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- 상품 목록 -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">등록된 상품 목록 (총 <?php echo count($products); ?>개)</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>이미지</th>
                                        <th>상품명</th>
                                        <th>카테고리</th>
                                        <th>가격</th>
                                        <th>재고</th>
                                        <th>연령대</th>
                                        <th>관리</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($products as $product): ?>
                                        <tr>
                                            <td><?php echo $product['id']; ?></td>
                                            <td>
                                                <img src="<?php echo $base_url; ?>/<?php echo $product['image_url']; ?>" 
                                                     alt="상품 이미지" class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                            </td>
                                            <td>
                                                <strong><?php echo escape_string($product['name']); ?></strong><br>
                                                <small class="text-muted"><?php echo escape_string(substr($product['description'], 0, 50)); ?>...</small>
                                            </td>
                                            <td>
                                                <span class="badge bg-primary"><?php echo escape_string($product['category_name']); ?></span>
                                            </td>
                                            <td><?php echo format_price($product['price']); ?></td>
                                            <td>
                                                <span class="badge <?php echo $product['stock_quantity'] > 0 ? 'bg-success' : 'bg-danger'; ?>">
                                                    <?php echo $product['stock_quantity']; ?>개
                                                </span>
                                            </td>
                                            <td><?php echo escape_string($product['age_group']); ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <button onclick="editProduct(<?php echo htmlspecialchars(json_encode($product), ENT_QUOTES, 'UTF-8'); ?>)" 
                                                            class="btn btn-outline-primary" title="수정">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <form method="post" action="" style="display: inline-block;" 
                                                          onsubmit="return confirm('이 상품을 삭제하시겠습니까?');">
                                                        <input type="hidden" name="shop_action" value="delete">
                                                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                                        <button type="submit" class="btn btn-outline-danger" title="삭제">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// 이미지 미리보기 함수
function previewImage(input) {
    const file = input.files[0];
    const preview = document.getElementById('image-preview');
    const previewImg = document.getElementById('preview-img');
    const currentImage = document.getElementById('current-image');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
            
            // 기존 이미지 숨기기
            if (currentImage) {
                currentImage.style.display = 'none';
            }
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
        
        // 기존 이미지 다시 표시
        if (currentImage) {
            currentImage.style.display = 'block';
        }
    }
}

// 이미지 제거 함수
function removeImage() {
    const fileInput = document.getElementById('product_image');
    const preview = document.getElementById('image-preview');
    const currentImage = document.getElementById('current-image');
    
    // 파일 입력 초기화
    fileInput.value = '';
    
    // 미리보기 숨기기
    preview.style.display = 'none';
    
    // 기존 이미지 다시 표시
    if (currentImage) {
        currentImage.style.display = 'block';
    }
}
</script>

<script>
function editProduct(product) {
    // 폼의 action을 수정으로 변경
    document.querySelector('input[name="shop_action"]').value = 'edit';
    
    // 숨겨진 product_id 필드 추가 또는 업데이트
    let productIdInput = document.querySelector('input[name="product_id"]');
    if (!productIdInput) {
        productIdInput = document.createElement('input');
        productIdInput.type = 'hidden';
        productIdInput.name = 'product_id';
        document.querySelector('form').appendChild(productIdInput);
    }
    productIdInput.value = product.id;
    
    // 폼 필드에 상품 정보 채우기
    document.getElementById('name').value = product.name;
    document.getElementById('category_id').value = product.category_id;
    document.getElementById('description').value = product.description;
    document.getElementById('price').value = product.price;
    document.getElementById('stock_quantity').value = product.stock_quantity;
    document.getElementById('age_group').value = product.age_group;
    document.getElementById('image_url').value = product.image_url;
    
    // 폼 제목 변경
    document.querySelector('.card-header h5').textContent = '상품 수정';
    
    // 버튼 텍스트 변경
    document.querySelector('button[type="submit"]').innerHTML = '<i class="fas fa-save"></i> 수정하기';
    
    // 취소 버튼 추가 (없으면)
    let cancelBtn = document.querySelector('.btn-secondary');
    if (!cancelBtn) {
        cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.innerHTML = '<i class="fas fa-times"></i> 취소';
        cancelBtn.onclick = function() {
            resetForm();
        };
        document.querySelector('.d-flex.gap-2').appendChild(cancelBtn);
    }
    
    // 폼이 보이도록 스크롤
    document.querySelector('.card-header h5').scrollIntoView({ behavior: 'smooth' });
}

function resetForm() {
    // 폼 초기화
    document.querySelector('form').reset();
    document.querySelector('input[name="shop_action"]').value = 'add';
    
    // product_id 필드 제거
    let productIdInput = document.querySelector('input[name="product_id"]');
    if (productIdInput) {
        productIdInput.remove();
    }
    
    // 폼 제목 변경
    document.querySelector('.card-header h5').textContent = '상품 추가';
    
    // 버튼 텍스트 변경
    document.querySelector('button[type="submit"]').innerHTML = '<i class="fas fa-save"></i> 추가하기';
    
    // 취소 버튼 제거
    let cancelBtn = document.querySelector('.btn-secondary');
    if (cancelBtn) {
        cancelBtn.remove();
    }
}
</script>