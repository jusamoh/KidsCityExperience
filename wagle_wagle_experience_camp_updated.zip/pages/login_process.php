<?php
// login_process.php - 로그인 처리

// 폼에서 전송된 데이터 가져오기
$username = isset($_POST['username']) ? $_POST['username'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// 입력값 검증
if(empty($username) || empty($password)) {
    redirect('index.php?page=login&error=empty');
    exit;
}

// 사용자 정보 가져오기
$user = get_user_by_username($username);

// 사용자가 존재하고 비밀번호가 일치하는지 확인
if($user && password_verify($password, $user['password'])) {
    // 로그인 성공 - 세션에 사용자 정보 저장
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['is_admin'] = $user['is_admin'];
    
    // 로그인 성공 메시지 설정
    set_message('success', '로그인 되었습니다.');
    
    // 관리자인 경우 관리자 대시보드로, 일반 사용자는 홈으로 리다이렉트
    if($user['is_admin']) {
        redirect('index.php?page=admin_dashboard');
    } else {
        redirect('index.php');
    }
} else {
    // 로그인 실패 - 에러 메시지와 함께 로그인 페이지로 리다이렉트
    redirect('index.php?page=login&error=invalid');
}
?>