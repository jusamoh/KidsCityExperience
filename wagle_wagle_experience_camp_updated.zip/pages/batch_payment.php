<?php
// batch_payment.php - 일괄 결제 페이지

// 로그인 확인
if (!is_logged_in()) {
    set_message('로그인 후 이용해주세요.', 'warning');
    redirect('index.php?page=login');
    exit;
}

// 프로그램 ID 목록 가져오기
$program_ids = [];
if (isset($_GET['program_ids'])) {
    $program_ids = explode(',', $_GET['program_ids']);
}

// 프로그램 ID가 없으면 마이페이지로 이동
if (empty($program_ids)) {
    set_message('결제할 프로그램이 선택되지 않았습니다.', 'warning');
    redirect('index.php?page=my_page');
    exit;
}

// 사용자 정보 가져오기
$user_id = $_SESSION['user_id'];
$user = get_user($user_id);

// 결제할 프로그램 정보 및 총 금액 계산
$programs = [];
$total_amount = 0;

foreach ($program_ids as $program_id) {
    $program = get_program($program_id);
    if ($program) {
        $programs[] = $program;
        $total_amount += $program['price'];
    }
}

// 결제 정보 생성
$payment_info = [
    'program_ids' => $program_ids,
    'order_name' => count($programs) > 1 ? 
                   $programs[0]['title'] . ' 외 ' . (count($programs) - 1) . '개 프로그램' : 
                   $programs[0]['title'],
    'amount' => $total_amount,
    'order_id' => 'BATCH_' . time() . '_' . $user_id,
    'customer_name' => $user['name'],
    'customer_email' => $user['email'],
    'customer_phone' => $user['phone']
];

// 세션에 결제 정보 저장
$_SESSION['payment_info'] = $payment_info;
$_SESSION['is_batch_payment'] = true;
?>

<div class="container">
    <h2 class="mb-4">일괄 결제</h2>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">결제 정보</h4>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">주문명:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($payment_info['order_name']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">결제 금액:</div>
                        <div class="col-md-8"><?php echo format_price($payment_info['amount']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">주문 번호:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($payment_info['order_id']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">신청자:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($payment_info['customer_name']); ?></div>
                    </div>
                    
                    <hr>
                    
                    <h5 class="mb-3">결제 대상 프로그램</h5>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>프로그램명</th>
                                    <th>날짜</th>
                                    <th class="text-end">가격</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($programs as $program): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($program['title']); ?></td>
                                    <td><?php echo format_date($program['date']); ?></td>
                                    <td class="text-end"><?php echo format_price($program['price']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <tr class="table-light">
                                    <td colspan="2" class="fw-bold text-end">총 금액:</td>
                                    <td class="fw-bold text-end"><?php echo format_price($total_amount); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <hr>
                    
                    <div class="payment-methods">
                        <h5 class="mb-3">결제 방법 선택</h5>
                        
                        <div class="d-grid gap-2">
                            <button type="button" id="payment-button" class="btn btn-primary btn-lg">
                                <i class="fas fa-credit-card me-2"></i> 카드 결제
                            </button>
                            
                            <button type="button" id="virtual-account-button" class="btn btn-outline-primary btn-lg">
                                <i class="fas fa-university me-2"></i> 가상계좌 입금
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between">
                <a href="index.php?page=my_page" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i> 마이페이지로
                </a>
                
                <a href="index.php?page=cancel_payment" class="btn btn-outline-danger" onclick="return confirm('정말로 결제를 취소하시겠습니까?');">
                    <i class="fas fa-times me-2"></i> 결제 취소
                </a>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">결제 안내</h4>
                </div>
                <div class="card-body">
                    <p><i class="fas fa-info-circle text-primary me-2"></i> 결제 후에는 모든 프로그램 예약이 확정됩니다.</p>
                    <p><i class="fas fa-info-circle text-primary me-2"></i> 최소 참가 인원이 모이지 않으면 프로그램이 취소될 수 있으며, 이 경우 전액 환불됩니다.</p>
                    <p><i class="fas fa-info-circle text-primary me-2"></i> 프로그램 시작 7일 전까지 취소 시 전액 환불되며, 이후에는 환불 규정에 따라 부분 환불됩니다.</p>
                    <p><i class="fas fa-info-circle text-primary me-2"></i> 결제 관련 문의사항은 고객센터(010-1234-5678)로 연락주세요.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 토스페이먼츠 결제 스크립트 -->
<script src="https://js.tosspayments.com/v1/payment"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const clientKey = '<?php echo getenv("TOSS_PAYMENTS_CLIENT_KEY") ?: "test_ck_D5GePWvyJnrK0W0k6q8gLzN97Eoq"; ?>'; // 토스페이먼츠 클라이언트 키
    const tossPayments = TossPayments(clientKey);
    
    // 카드 결제 버튼 클릭 이벤트
    document.getElementById('payment-button').addEventListener('click', function() {
        tossPayments.requestPayment('카드', {
            amount: <?php echo $payment_info['amount']; ?>,
            orderId: '<?php echo $payment_info['order_id']; ?>',
            orderName: '<?php echo addslashes($payment_info['order_name']); ?>',
            customerName: '<?php echo addslashes($payment_info['customer_name']); ?>',
            customerEmail: '<?php echo addslashes($payment_info['customer_email']); ?>',
            customerMobilePhone: '<?php echo addslashes($payment_info['customer_phone']); ?>',
            successUrl: 'http://<?php echo $_SERVER['HTTP_HOST']; ?>/paju/index.php?page=payment_success',
            failUrl: 'http://<?php echo $_SERVER['HTTP_HOST']; ?>/paju/index.php?page=payment_fail'
        }).catch(function(error) {
            if (error.code === 'USER_CANCEL') {
                alert('결제가 취소되었습니다.');
            } else {
                alert('결제 오류가 발생했습니다: ' + error.message);
            }
        });
    });
    
    // 가상계좌 결제 버튼 클릭 이벤트
    document.getElementById('virtual-account-button').addEventListener('click', function() {
        tossPayments.requestPayment('가상계좌', {
            amount: <?php echo $payment_info['amount']; ?>,
            orderId: '<?php echo $payment_info['order_id']; ?>',
            orderName: '<?php echo addslashes($payment_info['order_name']); ?>',
            customerName: '<?php echo addslashes($payment_info['customer_name']); ?>',
            customerEmail: '<?php echo addslashes($payment_info['customer_email']); ?>',
            customerMobilePhone: '<?php echo addslashes($payment_info['customer_phone']); ?>',
            successUrl: 'http://<?php echo $_SERVER['HTTP_HOST']; ?>/paju/index.php?page=payment_success',
            failUrl: 'http://<?php echo $_SERVER['HTTP_HOST']; ?>/paju/index.php?page=payment_fail',
            validHours: 24,
            cashReceipt: {
                type: '소득공제'
            }
        }).catch(function(error) {
            if (error.code === 'USER_CANCEL') {
                alert('결제가 취소되었습니다.');
            } else {
                alert('결제 오류가 발생했습니다: ' + error.message);
            }
        });
    });
});
</script>