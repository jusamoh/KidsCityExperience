<?php
// checkout.php - 주문/결제 페이지

// 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('로그인이 필요합니다.'); window.location.href='?page=login';</script>";
    exit;
}

require_once 'config/database.php';

$user_id = $_SESSION['user_id'];
$conn = get_db_connection();

// 사용자 정보 가져오기
$user_query = "SELECT * FROM users WHERE id = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// 장바구니 상품 목록 가져오기
$cart_items = [];
$total_amount = 0;

$cart_query = "
    SELECT 
        ci.quantity,
        p.id as product_id,
        p.name,
        p.price,
        p.image_url,
        p.stock_quantity,
        (ci.quantity * p.price) as subtotal
    FROM cart_items ci
    JOIN products p ON ci.product_id = p.id
    WHERE ci.user_id = ? AND p.is_active = 1
    ORDER BY ci.created_at DESC
";

$stmt = $conn->prepare($cart_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
    $total_amount += $row['subtotal'];
}

// 장바구니가 비어있으면 이동
if (empty($cart_items)) {
    echo "<script>alert('주문할 상품이 없습니다.'); window.location.href='?page=cart';</script>";
    exit;
}

$shipping_fee = $total_amount >= 50000 ? 0 : 3000;
$final_total = $total_amount + $shipping_fee;

$conn->close();
?>

<div class="container mt-4">
    <!-- 페이지 헤더 -->
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="d-flex align-items-center">
                <i class="fas fa-credit-card text-primary me-2"></i> 
                주문/결제
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="?page=shop">쇼핑</a></li>
                    <li class="breadcrumb-item"><a href="?page=cart">장바구니</a></li>
                    <li class="breadcrumb-item active">주문/결제</li>
                </ol>
            </nav>
        </div>
    </div>

    <form id="orderForm">
        <div class="row">
            <!-- 주문 정보 입력 -->
            <div class="col-lg-8">
                <!-- 배송 정보 -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-shipping-fast"></i> 배송 정보
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="recipient_name" class="form-label">받는 분 성함 *</label>
                                <input type="text" class="form-control" id="recipient_name" name="recipient_name" 
                                       value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">연락처 *</label>
                                <input type="tel" class="form-control" id="phone" name="phone" 
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" 
                                       placeholder="010-1234-5678" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="shipping_address" class="form-label">배송 주소 *</label>
                            <textarea class="form-control" id="shipping_address" name="shipping_address" 
                                      rows="3" placeholder="상세 주소를 입력해주세요" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="delivery_memo" class="form-label">배송 메모</label>
                            <select class="form-select" id="delivery_memo" name="delivery_memo">
                                <option value="">배송 메모를 선택해주세요</option>
                                <option value="문 앞에 놓아주세요">문 앞에 놓아주세요</option>
                                <option value="경비실에 맡겨주세요">경비실에 맡겨주세요</option>
                                <option value="택배함에 넣어주세요">택배함에 넣어주세요</option>
                                <option value="직접 받겠습니다">직접 받겠습니다</option>
                                <option value="기타">기타</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- 결제 방법 -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-credit-card"></i> 결제 방법
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" 
                                           id="payment_card" value="card" checked>
                                    <label class="form-check-label" for="payment_card">
                                        <i class="fas fa-credit-card text-primary"></i> 신용/체크카드
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" 
                                           id="payment_transfer" value="transfer">
                                    <label class="form-check-label" for="payment_transfer">
                                        <i class="fas fa-university text-info"></i> 계좌이체
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 주문 요약 -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-receipt"></i> 주문 요약
                        </h5>
                    </div>
                    <div class="card-body">
                        <!-- 주문 상품 목록 -->
                        <div class="mb-3">
                            <h6 class="border-bottom pb-2">주문 상품 (<?php echo count($cart_items); ?>개)</h6>
                            <?php foreach ($cart_items as $item): ?>
                                <div class="d-flex align-items-center mb-2">
                                    <img src="<?php echo htmlspecialchars($item['image_url'] ?: 'assets/img/program-default.jpg'); ?>" 
                                         alt="<?php echo htmlspecialchars($item['name']); ?>"
                                         class="rounded me-2"
                                         style="width: 40px; height: 40px; object-fit: cover;">
                                    <div class="flex-grow-1">
                                        <div class="small"><?php echo htmlspecialchars($item['name']); ?></div>
                                        <div class="text-muted small">
                                            <?php echo number_format($item['price']); ?>원 × <?php echo $item['quantity']; ?>개
                                        </div>
                                    </div>
                                    <div class="text-primary fw-bold small">
                                        <?php echo number_format($item['subtotal']); ?>원
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- 결제 금액 -->
                        <div class="border-top pt-3">
                            <div class="d-flex justify-content-between mb-2">
                                <span>상품 총액:</span>
                                <span><?php echo number_format($total_amount); ?>원</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>배송비:</span>
                                <span><?php echo $shipping_fee > 0 ? number_format($shipping_fee) . '원' : '무료'; ?></span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-3">
                                <strong>총 결제금액:</strong>
                                <strong class="text-primary h5"><?php echo number_format($final_total); ?>원</strong>
                            </div>

                            <!-- 주문 동의 -->
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="agree_order" required>
                                    <label class="form-check-label small" for="agree_order">
                                        주문 내용을 확인했으며, 구매조건 및 개인정보처리방침에 동의합니다.
                                    </label>
                                </div>
                            </div>

                            <!-- 주문 버튼 -->
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-credit-card"></i> 
                                    <?php echo number_format($final_total); ?>원 결제하기
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
document.getElementById('orderForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const orderData = {
        recipient_name: formData.get('recipient_name'),
        phone: formData.get('phone'),
        shipping_address: formData.get('shipping_address'),
        delivery_memo: formData.get('delivery_memo'),
        payment_method: formData.get('payment_method'),
        total_amount: <?php echo $final_total; ?>
    };
    
    try {
        // 주문 생성
        const response = await fetch('api/create_order.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderData)
        });

        const result = await response.json();
        
        if (result.success) {
            // 결제 처리 (TossPayments)
            if (orderData.payment_method === 'card') {
                // 토스페이먼츠 결제 처리
                proceedToPayment(result.order_id, result.order_number);
            } else {
                // 계좌이체의 경우 주문 완료 페이지로 이동
                window.location.href = `?page=order_complete&order_id=${result.order_id}`;
            }
        } else {
            alert(result.message || '주문 생성에 실패했습니다.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('오류가 발생했습니다.');
    }
});

function proceedToPayment(orderId, orderNumber) {
    // 토스페이먼츠 결제창 호출
    const clientKey = 'test_ck_D4yKeq5bgrp0Rn56PBXr37nO5Wml'; // 테스트 키
    const tossPayments = TossPayments(clientKey);
    
    tossPayments.requestPayment('카드', {
        amount: <?php echo $final_total; ?>,
        orderId: orderNumber,
        orderName: '와글와글쇼핑 주문',
        customerName: document.getElementById('recipient_name').value,
        successUrl: window.location.origin + '/paju/?page=payment_success',
        failUrl: window.location.origin + '/paju/?page=payment_fail',
    });
}
</script>

<!-- 토스페이먼츠 SDK -->
<script src="https://js.tosspayments.com/v1/payment"></script>