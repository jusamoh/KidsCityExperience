<?php
// program_management.php - 프로그램 관리 페이지

// 관리자 권한 확인
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    redirect($base_url . '/index.php?page=login');
    exit;
}
?>

<style>
.sortable-header {
    cursor: pointer;
    user-select: none;
    transition: background-color 0.2s ease;
}

.sortable-header:hover {
    background-color: rgba(0, 0, 0, 0.05);
}

.sortable-header:active {
    transform: translateY(1px);
}

.sort-icon {
    margin-left: 5px;
    font-size: 0.8em;
}
</style>

<?php

// 프로그램 수정 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_program') {
    $program_id = isset($_POST['program_id']) ? intval($_POST['program_id']) : 0;
    $title = isset($_POST['title']) ? $_POST['title'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $price = isset($_POST['price']) ? intval($_POST['price']) : 0;
    $max_participants = isset($_POST['max_participants']) ? intval($_POST['max_participants']) : 0;
    $min_participants = isset($_POST['min_participants']) ? intval($_POST['min_participants']) : 0;
    
    // 데이터베이스 연결
    $conn = get_db_connection();
    
    // 프로그램 상태 확인 - 모집중(active) 또는 준비중(pending) 상태인지 확인
    $check_sql = "SELECT status FROM programs WHERE id = {$program_id}";
    $check_result = $conn->query($check_sql);
    
    if ($check_result && $check_result->num_rows > 0) {
        $program_data = $check_result->fetch_assoc();
        $current_status = $program_data['status'];
        
        if ($current_status != 'active' && $current_status != 'pending') {
            set_message('모집중 또는 준비중 상태의 프로그램만 수정할 수 있습니다.', 'danger');
            $conn->close();
            redirect($base_url . '/index.php?page=program_management');
            exit;
        }
    } else {
        set_message('프로그램을 찾을 수 없습니다.', 'danger');
        $conn->close();
        redirect($base_url . '/index.php?page=program_management');
        exit;
    }
    
    // 기본 검증
    if (empty($title) || empty($description) || $category_id <= 0 || empty($status) || empty($date) || $price < 0 || $max_participants <= 0 || $min_participants <= 0) {
        set_message('모든 필수 필드를 채워주세요.', 'danger');
    } else {
        
        // 프로그램 정보 업데이트
        $title = $conn->real_escape_string($title);
        $description = $conn->real_escape_string($description);
        $status = $conn->real_escape_string($status);
        $date = $conn->real_escape_string($date);
        
        // 이미지 업로드 처리
        $image_path = '';
        $image_updated = false;
        
        if (isset($_FILES['program_image']) && $_FILES['program_image']['name'] != '') {
            // 이미지가 선택된 경우
            if ($_FILES['program_image']['error'] == 0) {
                // 절대 경로로 디렉토리 설정
                $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/paju/uploads/programs/';
                
                // 디렉토리가 없으면 생성 (상대 경로로 접근 가능하도록)
                if (!file_exists('uploads/programs/')) {
                    mkdir('uploads/programs/', 0777, true);
                }
                
                $original_name = $_FILES['program_image']['name'];
                $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
                $file_type = $_FILES['program_image']['type'];
                
                // 허용된 MIME 타입과 확장자
                $allowed_mime_types = [
                    'image/jpeg' => ['jpg', 'jpeg'],
                    'image/png' => ['png'],
                    'image/gif' => ['gif'],
                    'image/webp' => ['webp']
                ];
                
                // 파일 확장자 및 MIME 타입 검증
                $is_valid_type = false;
                foreach ($allowed_mime_types as $mime => $extensions) {
                    if ($file_type === $mime && in_array($file_ext, $extensions)) {
                        $is_valid_type = true;
                        break;
                    }
                }
                
                // 확장자 검사
                if ($is_valid_type) {
                    // 안전한 파일명 생성 (한글 및 특수문자 처리)
                    $safe_name = preg_replace('/[^a-zA-Z0-9가-힣._-]/', '', pathinfo($original_name, PATHINFO_FILENAME));
                    $safe_name = mb_substr($safe_name, 0, 30); // 파일명 길이 제한
                    
                    // 고유한 파일명 생성: program_프로그램ID_파일명_타임스탬프.확장자
                    $timestamp = date('Ymd_His');
                    $new_file_name = 'program_' . $program_id . '_' . $safe_name . '_' . $timestamp . '.' . $file_ext;
                    
                    // 웹에서 접근할 상대 경로 (DB에 저장될 경로)
                    $web_file_path = 'uploads/programs/' . $new_file_name;
                    
                    // 서버에 저장할 절대 경로
                    $target_file_path = $upload_dir . $new_file_name;
                    
                    try {
                        // 디렉토리 권한 확인
                        if (!is_writable(dirname($upload_dir))) {
                            // 디렉토리 권한 변경 시도
                            chmod(dirname($upload_dir), 0777);
                        }
                        
                        if (move_uploaded_file($_FILES['program_image']['tmp_name'], $target_file_path)) {
                            $image_path = $web_file_path; // 상대 경로 저장
                            $image_updated = true;
                        } else {
                            // 실패 원인 디버깅
                            $error_message = '이미지 업로드 실패. ';
                            switch ($_FILES['program_image']['error']) {
                                case UPLOAD_ERR_INI_SIZE:
                                case UPLOAD_ERR_FORM_SIZE:
                                    $error_message .= '파일이 너무 큽니다.';
                                    break;
                                case UPLOAD_ERR_PARTIAL:
                                    $error_message .= '파일이 일부만 업로드되었습니다.';
                                    break;
                                case UPLOAD_ERR_NO_FILE:
                                    $error_message .= '파일이 업로드되지 않았습니다.';
                                    break;
                                case UPLOAD_ERR_NO_TMP_DIR:
                                    $error_message .= '임시 폴더가 없습니다.';
                                    break;
                                case UPLOAD_ERR_CANT_WRITE:
                                    $error_message .= '디스크에 파일을 쓸 수 없습니다.';
                                    break;
                                case UPLOAD_ERR_EXTENSION:
                                    $error_message .= '확장에 의해 파일 업로드가 중지되었습니다.';
                                    break;
                                default:
                                    $error_message .= '알 수 없는 오류가 발생했습니다.';
                            }
                            set_message($error_message, 'danger');
                        }
                    } catch (Exception $e) {
                        set_message('이미지 업로드 중 오류: ' . $e->getMessage(), 'danger');
                    }
                } else {
                    set_message('허용되지 않는 파일 형식입니다. JPG, JPEG, PNG, GIF 파일만 업로드 가능합니다.', 'danger');
                }
            } else {
                // 업로드 에러 코드에 따른 메시지
                $error_code = $_FILES['program_image']['error'];
                $error_message = '파일 업로드 오류 (코드: ' . $error_code . '): ';
                
                switch ($error_code) {
                    case UPLOAD_ERR_INI_SIZE:
                    case UPLOAD_ERR_FORM_SIZE:
                        $error_message .= '파일이 너무 큽니다.';
                        break;
                    case UPLOAD_ERR_PARTIAL:
                        $error_message .= '파일이 일부만 업로드되었습니다.';
                        break;
                    case UPLOAD_ERR_NO_FILE:
                        $error_message .= '파일이 업로드되지 않았습니다.';
                        break;
                    case UPLOAD_ERR_NO_TMP_DIR:
                        $error_message .= '임시 폴더가 없습니다.';
                        break;
                    case UPLOAD_ERR_CANT_WRITE:
                        $error_message .= '디스크에 파일을 쓸 수 없습니다.';
                        break;
                    case UPLOAD_ERR_EXTENSION:
                        $error_message .= '확장에 의해 파일 업로드가 중지되었습니다.';
                        break;
                    default:
                        $error_message .= '알 수 없는 오류가 발생했습니다.';
                }
                
                set_message($error_message, 'danger');
            }
        }
        
        // 데이터베이스 테이블 구조 확인 (max_participants 컬럼 존재 여부 확인)
        $check_max = $conn->query("SHOW COLUMNS FROM programs LIKE 'max_participants'");
        $has_max = $check_max && $check_max->num_rows > 0;
        
        // 이미지 경로를 포함한 업데이트 쿼리 작성
        $sql = "UPDATE programs SET 
                title = '{$title}',
                description = '{$description}',
                category_id = {$category_id},
                status = '{$status}',
                date = '{$date}',
                price = {$price}";
        
        // max_participants 컬럼이 존재하는 경우에만 추가
        if ($has_max) {
            $sql .= ", max_participants = {$max_participants}";
        }
        
        // min_participants 컬럼이 존재하는지 확인하고 추가
        $check_min = $conn->query("SHOW COLUMNS FROM programs LIKE 'min_participants'");
        if ($check_min && $check_min->num_rows > 0) {
            $sql .= ", min_participants = {$min_participants}";
        }
        
        // 이미지가 업데이트된 경우에만 이미지 경로 업데이트
        if ($image_updated) {
            $image_path = $conn->real_escape_string($image_path);
            $sql .= ", image_path = '{$image_path}'";
        }
        
        $sql .= " WHERE id = {$program_id}";
                
        if ($conn->query($sql)) {
            set_message('프로그램이 성공적으로 수정되었습니다.', 'success');
        } else {
            set_message('프로그램 수정 중 오류가 발생했습니다: ' . $conn->error, 'danger');
        }
        
        $conn->close();
    }
    
    // 현재 페이지로 리다이렉트
    redirect($base_url . '/index.php?page=program_management');
    exit;
}

// 종료/취소된 프로그램 포함 여부 확인
$include_completed = isset($_GET['include_completed']) && $_GET['include_completed'] === '1';

// 정렬 매개변수 처리
$sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'status';
$order = isset($_GET['order']) && $_GET['order'] === 'desc' ? 'desc' : 'asc';

// 허용된 정렬 컬럼
$allowed_sorts = ['id', 'title', 'category_name', 'date', 'price', 'status'];
if (!in_array($sort_by, $allowed_sorts)) {
    $sort_by = 'status';
}

// 프로그램 목록 가져오기 (정렬 적용)
$programs = get_programs_with_sort(null, $include_completed, $sort_by, $order);
$categories = get_categories();
?>

<div class="container">
    <h2 class="mb-4">프로그램 관리</h2>
    
    <?php 
    // 시스템 메시지 표시
    $message = get_message();
    if($message): 
    ?>
    <div class="alert alert-<?php echo $message['type'] == 'success' ? 'success' : 'danger'; ?> mb-4">
        <?php echo escape_string($message['text']); ?>
    </div>
    <?php endif; ?>
    
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">체험 프로그램 목록</h5>
                <div>
                    <?php if (!$include_completed): ?>
                    <a href="<?php echo $base_url; ?>/index.php?page=program_management&include_completed=1" class="btn btn-outline-secondary btn-sm me-2">
                        <i class="fas fa-eye"></i> 종료/취소된 프로그램 보기
                    </a>
                    <?php else: ?>
                    <a href="<?php echo $base_url; ?>/index.php?page=program_management" class="btn btn-outline-secondary btn-sm me-2">
                        <i class="fas fa-eye-slash"></i> 진행 중인 프로그램만 보기
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo $base_url; ?>/index.php?page=add_program" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus-circle"></i> 새 프로그램 추가
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if (empty($programs)): ?>
            <div class="alert alert-info">
                등록된 프로그램이 없습니다.
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <?php 
                            // 정렬 URL 생성 함수
                            function get_sort_url($column, $current_sort, $current_order, $include_completed) {
                                global $base_url;
                                $new_order = ($current_sort === $column && $current_order === 'asc') ? 'desc' : 'asc';
                                $completed_param = $include_completed ? '&include_completed=1' : '';
                                return $base_url . '/index.php?page=program_management&sort=' . $column . '&order=' . $new_order . $completed_param;
                            }
                            
                            // 정렬 아이콘 표시 함수
                            function get_sort_icon($column, $current_sort, $current_order) {
                                if ($current_sort === $column) {
                                    return $current_order === 'asc' ? ' <i class="fas fa-sort-up"></i>' : ' <i class="fas fa-sort-down"></i>';
                                }
                                return ' <i class="fas fa-sort text-muted"></i>';
                            }
                            ?>
                            <th class="sortable-header">
                                <a href="<?php echo get_sort_url('id', $sort_by, $order, $include_completed); ?>" class="text-decoration-none text-dark d-block">
                                    ID<span class="sort-icon"><?php echo get_sort_icon('id', $sort_by, $order); ?></span>
                                </a>
                            </th>
                            <th class="sortable-header">
                                <a href="<?php echo get_sort_url('title', $sort_by, $order, $include_completed); ?>" class="text-decoration-none text-dark d-block">
                                    제목<span class="sort-icon"><?php echo get_sort_icon('title', $sort_by, $order); ?></span>
                                </a>
                            </th>
                            <th class="sortable-header">
                                <a href="<?php echo get_sort_url('category_name', $sort_by, $order, $include_completed); ?>" class="text-decoration-none text-dark d-block">
                                    카테고리<span class="sort-icon"><?php echo get_sort_icon('category_name', $sort_by, $order); ?></span>
                                </a>
                            </th>
                            <th class="sortable-header">
                                <a href="<?php echo get_sort_url('date', $sort_by, $order, $include_completed); ?>" class="text-decoration-none text-dark d-block">
                                    날짜<span class="sort-icon"><?php echo get_sort_icon('date', $sort_by, $order); ?></span>
                                </a>
                            </th>
                            <th class="sortable-header">
                                <a href="<?php echo get_sort_url('price', $sort_by, $order, $include_completed); ?>" class="text-decoration-none text-dark d-block">
                                    가격<span class="sort-icon"><?php echo get_sort_icon('price', $sort_by, $order); ?></span>
                                </a>
                            </th>
                            <th>참가 연령</th>
                            <th class="sortable-header">
                                <a href="<?php echo get_sort_url('status', $sort_by, $order, $include_completed); ?>" class="text-decoration-none text-dark d-block">
                                    상태<span class="sort-icon"><?php echo get_sort_icon('status', $sort_by, $order); ?></span>
                                </a>
                            </th>
                            <th>신청/정원</th>
                            <th>관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($programs as $program): 
                            // 프로그램 카테고리 이름 가져오기
                            $category_name = '';
                            foreach($categories as $category) {
                                if ($category['id'] == $program['category_id']) {
                                    $category_name = $category['name'];
                                    break;
                                }
                            }
                            
                            // 현재 신청자 수 직접 계산
                            $conn = get_db_connection();
                            $prog_id = $conn->real_escape_string($program['id']);
                            $sql = "SELECT COUNT(*) as count FROM registrations WHERE program_id = {$prog_id}";
                            $result = $conn->query($sql);
                            $current_participants = 0;
                            if ($result && $result->num_rows > 0) {
                                $current_participants = $result->fetch_assoc()['count'];
                            }
                            $conn->close();
                        ?>
                        <tr>
                            <td><?php echo $program['id']; ?></td>
                            <td><?php echo $program['title']; ?></td>
                            <td><?php echo $category_name; ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($program['date'])); ?></td>
                            <td><?php echo format_price($program['price']); ?></td>
                            <td><?php echo isset($program['min_age']) ? $program['min_age'] : '0'; ?>~<?php echo isset($program['max_age']) ? $program['max_age'] : '0'; ?>세</td>
                            <td>
                                <?php if($program['status'] == 'active'): ?>
                                    <span class="badge bg-success">모집중</span>
                                <?php elseif($program['status'] == 'pending'): ?>
                                    <span class="badge bg-warning text-dark">준비중</span>
                                <?php elseif($program['status'] == 'completed'): ?>
                                    <span class="badge bg-secondary">종료됨</span>
                                <?php elseif($program['status'] == 'canceled'): ?>
                                    <span class="badge bg-danger">취소됨</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo $program['status']; ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $current_participants; ?> / <?php echo isset($program['max_participants']) ? $program['max_participants'] : '제한없음'; ?></td>
                            <td>
                                <?php if($program['status'] == 'active' || $program['status'] == 'pending'): ?>
                                <button type="button" class="btn btn-sm btn-primary edit-program" data-bs-toggle="modal" data-bs-target="#editProgramModal" 
                                data-id="<?php echo $program['id']; ?>"
                                data-title="<?php echo htmlspecialchars($program['title']); ?>"
                                data-description="<?php echo htmlspecialchars($program['description']); ?>"
                                data-category="<?php echo $program['category_id']; ?>"
                                data-status="<?php echo $program['status']; ?>"
                                data-date="<?php echo date('Y-m-d\TH:i', strtotime($program['date'])); ?>"
                                data-price="<?php echo $program['price']; ?>"
                                data-capacity="<?php echo isset($program['max_participants']) ? $program['max_participants'] : '20'; ?>"
                                data-min="<?php echo $program['min_participants']; ?>"
                                data-image="<?php echo isset($program['image_path']) ? $program['image_path'] : ''; ?>">
                                    <i class="fas fa-edit"></i> 수정
                                </button>
                                <?php else: ?>
                                <button type="button" class="btn btn-sm btn-secondary" disabled>
                                    <i class="fas fa-lock"></i> 수정불가
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="text-end mb-5">
        <a href="<?php echo $base_url; ?>/index.php?page=admin_dashboard" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i> 관리자 대시보드로 돌아가기
        </a>
    </div>
</div>

<!-- 프로그램 수정 모달 -->
<div class="modal fade" id="editProgramModal" tabindex="-1" aria-labelledby="editProgramModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post" action="<?php echo $base_url; ?>/index.php?page=program_management" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_program">
                <input type="hidden" name="program_id" id="edit_program_id">
                
                <div class="modal-header">
                    <h5 class="modal-title" id="editProgramModalLabel">프로그램 수정</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_title" class="form-label">프로그램 제목</label>
                        <input type="text" class="form-control" id="edit_title" name="title" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="program_image" class="form-label">프로그램 이미지</label>
                        <input type="file" class="form-control" id="program_image" name="program_image" accept="image/*">
                        <div class="form-text">이미지를 변경하려면 새 이미지를 선택하세요. 선택하지 않으면 기존 이미지가 유지됩니다.</div>
                        <div id="current_image_preview" class="mt-2 d-none">
                            <p>현재 이미지:</p>
                            <img src="" id="preview_current_image" style="max-width: 200px; max-height: 150px;" class="img-thumbnail">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_category_id" class="form-label">카테고리</label>
                        <select class="form-select" id="edit_category_id" name="category_id" required>
                            <option value="">카테고리 선택</option>
                            <?php foreach($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">프로그램 설명</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="5" required></textarea>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_date" class="form-label">날짜 및 시간</label>
                            <input type="datetime-local" class="form-control" id="edit_date" name="date" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_price" class="form-label">가격 (원)</label>
                            <input type="number" class="form-control" id="edit_price" name="price" min="0" required>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="edit_status" class="form-label">상태</label>
                            <select class="form-select" id="edit_status" name="status" required>
                                <option value="active">모집중</option>
                                <option value="pending">준비중</option>
                                <option value="completed">종료됨</option>
                                <option value="canceled">취소됨</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_max_participants" class="form-label">최대 정원</label>
                            <input type="number" class="form-control" id="edit_max_participants" name="max_participants" min="1" required>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_min_participants" class="form-label">최소 인원</label>
                            <input type="number" class="form-control" id="edit_min_participants" name="min_participants" min="1" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">취소</button>
                    <button type="submit" class="btn btn-primary">저장</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// 프로그램 수정 모달 데이터 설정
document.addEventListener('DOMContentLoaded', function() {
    const editButtons = document.querySelectorAll('.edit-program');
    
    // 이미지 미리보기 기능 추가
    const programImageInput = document.getElementById('program_image');
    if (programImageInput) {
        programImageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                // 선택한 파일 경로와 정보를 표시
                const fileName = file.name;
                const fileSize = (file.size / 1024).toFixed(2) + ' KB';
                
                // 파일의 전체 경로는 보안상의 이유로 브라우저에서 제한됨
                // 하지만 파일명과 크기는 표시 가능
                let fullPath = '';
                
                // 파일 경로를 최대한 얻으려는 시도
                // Internet Explorer의 경우
                if (programImageInput.value) {
                    fullPath = programImageInput.value;
                } 
                // 대부분의 브라우저에서는 파일명만 얻을 수 있음
                else {
                    fullPath = fileName;
                }
                
                const fileInfo = `${fullPath} (${fileSize})`;
                
                // 파일 정보를 표시할 요소 생성 또는 업데이트
                let fileInfoElement = document.getElementById('file_info');
                if (!fileInfoElement) {
                    fileInfoElement = document.createElement('div');
                    fileInfoElement.id = 'file_info';
                    fileInfoElement.className = 'mt-2 small text-muted';
                    programImageInput.parentNode.appendChild(fileInfoElement);
                }
                fileInfoElement.textContent = `선택된 파일: ${fileInfo}`;
                
                // 파일 경로를 hidden input에 저장
                let filePathInput = document.getElementById('selected_file_path');
                if (!filePathInput) {
                    filePathInput = document.createElement('input');
                    filePathInput.type = 'hidden';
                    filePathInput.id = 'selected_file_path';
                    filePathInput.name = 'selected_file_path';
                    programImageInput.parentNode.appendChild(filePathInput);
                }
                filePathInput.value = fullPath;
                
                // 이미지 미리보기
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewDiv = document.getElementById('current_image_preview');
                    previewDiv.classList.remove('d-none');
                    document.getElementById('preview_current_image').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    }
    
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const title = this.getAttribute('data-title');
            const description = this.getAttribute('data-description');
            const category = this.getAttribute('data-category');
            const status = this.getAttribute('data-status');
            const date = this.getAttribute('data-date');
            const price = this.getAttribute('data-price');
            const capacity = this.getAttribute('data-capacity');
            const min = this.getAttribute('data-min');
            const imagePath = this.getAttribute('data-image');
            
            document.getElementById('edit_program_id').value = id;
            document.getElementById('edit_title').value = title;
            document.getElementById('edit_description').value = description;
            document.getElementById('edit_category_id').value = category;
            document.getElementById('edit_status').value = status;
            document.getElementById('edit_date').value = date;
            document.getElementById('edit_price').value = price;
            document.getElementById('edit_max_participants').value = capacity;
            document.getElementById('edit_min_participants').value = min;
            
            // 이미지 미리보기 설정
            const previewDiv = document.getElementById('current_image_preview');
            const previewImg = document.getElementById('preview_current_image');
            
            if (imagePath && imagePath !== '') {
                previewDiv.classList.remove('d-none');
                previewImg.src = imagePath;
            } else {
                previewDiv.classList.add('d-none');
                previewImg.src = '';
            }
        });
    });
});
</script>