<?php
// payment_fail.php - 결제 실패 페이지
session_start();

// 실패 정보 받기
$code = $_GET['code'] ?? '';
$message = $_GET['message'] ?? '결제가 취소되었습니다.';
$orderId = $_GET['orderId'] ?? '';
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>결제 실패 - 파주 체험 Camp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body text-center p-5">
                        <i class="fas fa-times-circle text-danger mb-3" style="font-size: 4rem;"></i>
                        <h2 class="text-danger mb-3">결제 실패</h2>
                        <p class="mb-4"><?php echo htmlspecialchars($message); ?></p>
                        
                        <?php if (!empty($orderId)): ?>
                            <div class="alert alert-warning">
                                <strong>주문번호:</strong> <?php echo htmlspecialchars($orderId); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($code)): ?>
                            <div class="alert alert-info">
                                <small><strong>오류 코드:</strong> <?php echo htmlspecialchars($code); ?></small>
                            </div>
                        <?php endif; ?>
                        
                        <div class="d-grid gap-2">
                            <a href="../index.php?page=cart" class="btn btn-primary">
                                <i class="fas fa-arrow-left"></i> 장바구니로 돌아가기
                            </a>
                            <a href="../index.php?page=shop" class="btn btn-outline-primary">
                                <i class="fas fa-shopping-cart"></i> 쇼핑 계속하기
                            </a>
                            <a href="../index.php" class="btn btn-outline-secondary">
                                <i class="fas fa-home"></i> 홈으로 가기
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>