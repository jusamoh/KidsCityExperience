<?php
// order_complete.php - 주문 완료 페이지

// 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 로그인 확인
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('잘못된 접근입니다.'); window.location.href='?page=login';</script>";
    exit;
}

require_once 'config/database.php';

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($order_id <= 0) {
    echo "<script>alert('잘못된 주문 정보입니다.'); window.location.href='?page=shop';</script>";
    exit;
}

$conn = get_db_connection();

// 주문 정보 조회 (본인 주문만)
$order_query = "
    SELECT o.*, 
           (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as item_count
    FROM orders o
    WHERE o.id = ? AND o.user_id = ?
";

$order_stmt = $conn->prepare($order_query);
$order_stmt->bind_param("ii", $order_id, $user_id);
$order_stmt->execute();
$order_result = $order_stmt->get_result();

if ($order_result->num_rows === 0) {
    echo "<script>alert('주문 정보를 찾을 수 없습니다.'); window.location.href='?page=shop';</script>";
    exit;
}

$order = $order_result->fetch_assoc();

// 주문 상품 목록 조회
$items_query = "
    SELECT oi.*, p.name, p.image_url
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
    ORDER BY oi.id
";

$items_stmt = $conn->prepare($items_query);
$items_stmt->bind_param("i", $order_id);
$items_stmt->execute();
$items_result = $items_stmt->get_result();

$order_items = [];
while ($item = $items_result->fetch_assoc()) {
    $order_items[] = $item;
}

$conn->close();

// 배송비 계산
$subtotal = array_sum(array_map(function($item) { 
    return $item['quantity'] * $item['price']; 
}, $order_items));
$shipping_fee = $subtotal >= 50000 ? 0 : 3000;
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- 주문 완료 헤더 -->
            <div class="text-center mb-5">
                <div class="mb-4">
                    <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                </div>
                <h1 class="text-success mb-3">주문이 완료되었습니다!</h1>
                <p class="text-muted">
                    주문번호: <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                </p>
                <p class="text-muted">
                    주문일시: <?php echo date('Y년 m월 d일 H:i', strtotime($order['order_date'])); ?>
                </p>
            </div>

            <!-- 주문 정보 카드 -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-shopping-bag"></i> 주문 상품 정보
                    </h5>
                </div>
                <div class="card-body">
                    <?php foreach ($order_items as $index => $item): ?>
                        <div class="d-flex align-items-center <?php echo $index > 0 ? 'border-top pt-3 mt-3' : ''; ?>">
                            <img src="<?php echo htmlspecialchars($item['image_url'] ?: 'assets/img/program-default.jpg'); ?>" 
                                 alt="<?php echo htmlspecialchars($item['name']); ?>"
                                 class="rounded me-3"
                                 style="width: 80px; height: 80px; object-fit: cover;">
                            
                            <div class="flex-grow-1">
                                <h6 class="mb-1"><?php echo htmlspecialchars($item['name']); ?></h6>
                                <div class="text-muted">
                                    <?php echo number_format($item['price']); ?>원 × <?php echo $item['quantity']; ?>개
                                </div>
                            </div>
                            
                            <div class="text-end">
                                <div class="fw-bold text-primary">
                                    <?php echo number_format($item['quantity'] * $item['price']); ?>원
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 결제 정보 카드 -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-credit-card"></i> 결제 정보
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="d-flex justify-content-between mb-2">
                                <span>상품 총액:</span>
                                <span><?php echo number_format($subtotal); ?>원</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>배송비:</span>
                                <span><?php echo $shipping_fee > 0 ? number_format($shipping_fee) . '원' : '무료'; ?></span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <strong>총 결제금액:</strong>
                                <strong class="text-primary"><?php echo number_format($order['total_amount']); ?>원</strong>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-2">
                                <strong>결제 방법:</strong> 
                                <?php 
                                switch($order['payment_method']) {
                                    case 'card': echo '신용/체크카드'; break;
                                    case 'transfer': echo '계좌이체'; break;
                                    default: echo '기타';
                                }
                                ?>
                            </div>
                            <div class="mb-2">
                                <strong>결제 상태:</strong> 
                                <span class="badge <?php echo $order['payment_status'] === 'completed' ? 'bg-success' : 'bg-warning'; ?>">
                                    <?php 
                                    switch($order['payment_status']) {
                                        case 'completed': echo '결제완료'; break;
                                        case 'pending': echo '결제대기'; break;
                                        case 'failed': echo '결제실패'; break;
                                        default: echo '확인중';
                                    }
                                    ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 배송 정보 카드 -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-truck"></i> 배송 정보
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-2">
                                <strong>받는 분:</strong> <?php echo htmlspecialchars($order['recipient_name']); ?>
                            </div>
                            <div class="mb-2">
                                <strong>연락처:</strong> <?php echo htmlspecialchars($order['phone']); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-2">
                                <strong>배송 상태:</strong> 
                                <span class="badge bg-info">
                                    <?php 
                                    switch($order['status']) {
                                        case 'pending': echo '주문접수'; break;
                                        case 'processing': echo '상품준비중'; break;
                                        case 'shipped': echo '배송중'; break;
                                        case 'delivered': echo '배송완료'; break;
                                        case 'cancelled': echo '주문취소'; break;
                                        default: echo '확인중';
                                    }
                                    ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <strong>배송 주소:</strong><br>
                        <?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?>
                    </div>
                </div>
            </div>

            <!-- 안내 메시지 -->
            <div class="alert alert-info">
                <h6><i class="fas fa-info-circle"></i> 주문 안내</h6>
                <ul class="mb-0">
                    <li>주문 확인 후 1-2일 내에 상품을 발송해드립니다.</li>
                    <li>배송 조회는 마이페이지에서 확인하실 수 있습니다.</li>
                    <li>문의사항이 있으시면 고객센터로 연락주세요.</li>
                </ul>
            </div>

            <!-- 액션 버튼 -->
            <div class="text-center">
                <a href="?page=shop" class="btn btn-primary me-3">
                    <i class="fas fa-shopping-cart"></i> 계속 쇼핑하기
                </a>
                <a href="?page=my_page" class="btn btn-outline-primary">
                    <i class="fas fa-user"></i> 마이페이지
                </a>
            </div>
        </div>
    </div>
</div>