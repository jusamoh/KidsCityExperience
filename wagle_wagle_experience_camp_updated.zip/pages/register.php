<?php
// register.php - 회원가입 페이지
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">회원가입</h4>
                </div>
                <div class="card-body">
                    <?php if(isset($_GET['error'])): ?>
                        <div class="alert alert-danger">
                            <?php if($_GET['error'] == 'username_exists'): ?>
                                이미 사용중인 아이디입니다.
                            <?php elseif($_GET['error'] == 'password_mismatch'): ?>
                                비밀번호가 일치하지 않습니다.
                            <?php else: ?>
                                입력 정보를 확인해주세요.
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <form action="index.php?page=register_process" method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">아이디</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="username" name="username" required
                                       pattern="[a-zA-Z0-9]{4,20}" title="영문, 숫자로 4~20자 이내로 입력하세요" 
                                       value="<?php echo isset($_GET['error']) && isset($_SESSION['form_data']) ? htmlspecialchars($_SESSION['form_data']['username']) : ''; ?>">
                                <button type="button" class="btn btn-outline-primary" id="check-username-btn">중복확인</button>
                            </div>
                            <div id="username-feedback"></div>
                            <small class="text-muted">영문, 숫자로 4~20자 이내로 입력하세요.</small>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">비밀번호</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <small class="text-muted">최소 6자 이상 입력하세요.</small>
                        </div>
                        <div class="mb-3">
                            <label for="password_confirm" class="form-label">비밀번호 확인</label>
                            <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                        </div>
                        <div class="mb-3">
                            <label for="name" class="form-label">이름</label>
                            <input type="text" class="form-control" id="name" name="name" required 
                                   value="<?php echo isset($_GET['error']) && isset($_SESSION['form_data']) ? htmlspecialchars($_SESSION['form_data']['name']) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">이메일</label>
                            <input type="email" class="form-control" id="email" name="email" required 
                                   value="<?php echo isset($_GET['error']) && isset($_SESSION['form_data']) ? htmlspecialchars($_SESSION['form_data']['email']) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">휴대폰 번호</label>
                            <input type="tel" class="form-control" id="phone" name="phone" placeholder="010-0000-0000" required 
                                   value="<?php echo isset($_GET['error']) && isset($_SESSION['form_data']) ? htmlspecialchars($_SESSION['form_data']['phone']) : ''; ?>">
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="agree_terms" name="agree_terms" required
                                  <?php echo isset($_GET['error']) && isset($_SESSION['form_data']) && isset($_SESSION['form_data']['agree_terms']) && $_SESSION['form_data']['agree_terms'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="agree_terms">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#termsModal">이용약관</a>과 
                                <a href="#" data-bs-toggle="modal" data-bs-target="#privacyModal">개인정보처리방침</a>에 동의합니다.
                            </label>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">가입하기</button>
                        </div>
                    </form>
                </div>
                <div class="card-footer text-center">
                    <p class="mb-0">이미 계정이 있으신가요? <a href="index.php?page=login">로그인</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const usernameInput = document.getElementById('username');
    const checkUsernameBtn = document.getElementById('check-username-btn');
    const usernameFeedback = document.getElementById('username-feedback');
    const submitButton = document.querySelector('button[type="submit"]');
    let isUsernameChecked = false;
    let isUsernameValid = false;
    
    // 아이디 입력란 변경 시 중복 확인 상태 초기화
    usernameInput.addEventListener('input', function() {
        isUsernameChecked = false;
        isUsernameValid = false;
        usernameFeedback.innerHTML = '';
        usernameFeedback.className = '';
        checkFormValidity();
    });
    
    // 중복 확인 버튼 클릭 시 AJAX 요청
    checkUsernameBtn.addEventListener('click', function() {
        const username = usernameInput.value.trim();
        
        // 패턴 검사 (4~20자, 영문자와 숫자만 허용)
        const pattern = /^[a-zA-Z0-9]{4,20}$/;
        if (!pattern.test(username)) {
            usernameFeedback.innerHTML = '아이디는 영문자와 숫자로 4~20자 이내로 입력하세요.';
            usernameFeedback.className = 'text-danger mt-1';
            isUsernameChecked = true;
            isUsernameValid = false;
            checkFormValidity();
            return;
        }
        
        // 로딩 표시
        usernameFeedback.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> 확인 중...';
        usernameFeedback.className = 'text-primary mt-1';
        
        // AJAX 요청
        fetch(`<?php echo $base_url; ?>/index.php?page=check_username&username=${username}`)
            .then(response => response.json())
            .then(data => {
                isUsernameChecked = true;
                isUsernameValid = data.available;
                
                if (data.available) {
                    usernameFeedback.innerHTML = '✓ ' + data.message;
                    usernameFeedback.className = 'text-success mt-1';
                } else {
                    usernameFeedback.innerHTML = '✗ ' + data.message;
                    usernameFeedback.className = 'text-danger mt-1';
                }
                
                checkFormValidity();
            })
            .catch(error => {
                usernameFeedback.innerHTML = '서버 오류가 발생했습니다. 다시 시도해주세요.';
                usernameFeedback.className = 'text-danger mt-1';
                console.error('Error:', error);
                isUsernameChecked = false;
                checkFormValidity();
            });
    });
    
    // 폼 제출 전 중복 확인 여부 체크
    document.querySelector('form').addEventListener('submit', function(event) {
        if (!isUsernameChecked || !isUsernameValid) {
            event.preventDefault();
            usernameFeedback.innerHTML = '아이디 중복 확인을 먼저 진행해주세요.';
            usernameFeedback.className = 'text-danger mt-1';
        }
    });
    
    // 폼 유효성 검사 함수
    function checkFormValidity() {
        if (isUsernameChecked && isUsernameValid) {
            submitButton.disabled = false;
        } else {
            submitButton.disabled = false; // 일단 비활성화 하지 않음 (서버에서도 검증함)
        }
    }
});
</script>

<!-- 이용약관 모달 -->
<div class="modal fade" id="termsModal" tabindex="-1" aria-labelledby="termsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="termsModalLabel">이용약관</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i> 본 약관은 파주 체험 Camp 웹사이트 및 서비스 이용에 관한 조건과 제한을 규정합니다.
                </div>
                
                <div class="mb-4">
                    <h6><strong>제1조 (목적)</strong></h6>
                    <p class="small">이 약관은 파주 체험 Camp(이하 "회사"라 함)가 제공하는 영유아 체험 프로그램 서비스(이하 "서비스"라 함)를 이용함에 있어 회사와 이용자의 권리, 의무 및 책임사항을 규정함을 목적으로 합니다.</p>
                </div>
                
                <div class="mb-4">
                    <h6><strong>제2조 (정의)</strong></h6>
                    <ol class="small">
                        <li>"서비스"란 회사가 제공하는 영유아 체험 프로그램 및 관련 서비스를 의미합니다.</li>
                        <li>"이용자"란 이 약관에 따라 회사가 제공하는 서비스를 받는 회원 및 비회원을 말합니다.</li>
                        <li>"회원"이란 회사에 개인정보를 제공하여 회원등록을 한 자로서, 회사의 정보를 지속적으로 제공받으며 회사가 제공하는 서비스를 계속적으로 이용할 수 있는 자를 말합니다.</li>
                        <li>"비회원"이란 회원에 가입하지 않고 회사가 제공하는 서비스를 이용하는 자를 말합니다.</li>
                        <li>"프로그램"이란 회사가 제공하는 각종 영유아 체험 활동을 말합니다.</li>
                    </ol>
                </div>
                
                <div class="mb-4">
                    <h6><strong>제3조 (약관의 효력 및 변경)</strong></h6>
                    <ol class="small">
                        <li>이 약관은 서비스 화면에 게시하거나 기타의 방법으로 이용자에게 공지함으로써 효력이 발생합니다.</li>
                        <li>회사는 필요한 경우 이 약관을 변경할 수 있으며, 변경된 약관은 제1항과 같은 방법으로 공지함으로써 효력이 발생합니다.</li>
                        <li>이용자는 변경된 약관에 동의하지 않을 경우 서비스 이용을 중단하고 회원 탈퇴를 요청할 수 있으며, 변경된 약관의 효력 발생일 이후에도 서비스를 계속 이용할 경우 약관의 변경사항에 동의한 것으로 간주됩니다.</li>
                    </ol>
                </div>
                
                <div class="mb-4">
                    <h6><strong>제4조 (서비스의 제공 및 변경)</strong></h6>
                    <ol class="small">
                        <li>회사는 다음과 같은 서비스를 제공합니다:
                            <ul class="mt-2">
                                <li>영유아 대상 체험 프로그램 정보 제공</li>
                                <li>체험 프로그램 예약 및 결제 서비스</li>
                                <li>체험 프로그램 관련 커뮤니티 서비스</li>
                                <li>기타 회사가 정하는 서비스</li>
                            </ul>
                        </li>
                        <li>회사는 운영상, 기술상의 필요에 따라 제공하고 있는 서비스를 변경할 수 있습니다.</li>
                        <li>회사는 서비스의 변경, 중단으로 발생하는 문제에 대해서는 책임을 지지 않습니다.</li>
                    </ol>
                </div>
                
                <div class="mb-4">
                    <h6><strong>제5조 (회원가입)</strong></h6>
                    <ol class="small">
                        <li>이용자는 회사가 정한 가입 양식에 따라 회원정보를 기입한 후 이 약관에 동의한다는 의사표시를 함으로써 회원가입을 신청합니다.</li>
                        <li>회사는 전항과 같이 회원으로 가입할 것을 신청한 이용자 중 다음 각 호에 해당하지 않는 한 회원으로 등록합니다.</li>
                        <li>회원가입계약의 성립 시기는 회사의 승낙이 회원에게 도달한 시점으로 합니다.</li>
                    </ol>
                </div>
                
                <div class="mb-4">
                    <h6><strong>제6조 (결제 및 환불)</strong></h6>
                    <ol class="small">
                        <li>프로그램 이용 요금 및 결제 방법은 각 프로그램별로 회사가 정한 내용에 따릅니다.</li>
                        <li>환불 규정은 회사의 환불정책에 따르며, 자세한 내용은 환불정책 페이지에서 확인할 수 있습니다.</li>
                        <li>결제 후 회사의 사정으로 프로그램이 취소되는 경우, 전액 환불해 드립니다.</li>
                    </ol>
                </div>
                
                <div class="mb-4">
                    <h6><strong>부칙</strong></h6>
                    <p class="small">이 약관은 2025년 1월 1일부터 시행합니다.</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">닫기</button>
            </div>
        </div>
    </div>
</div>

<!-- 개인정보처리방침 모달 -->
<div class="modal fade" id="privacyModal" tabindex="-1" aria-labelledby="privacyModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="privacyModalLabel">개인정보 처리방침</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i> 파주 체험 Camp는 이용자의 개인정보를 중요시하며, 「개인정보 보호법」을 준수하기 위해 노력하고 있습니다.
                </div>
                
                <div class="mb-4">
                    <h6><strong>1. 개인정보의 처리 목적</strong></h6>
                    <p class="small">파주 체험 Camp는 다음의 목적을 위하여 개인정보를 처리합니다.</p>
                    <ol class="small">
                        <li>회원 가입 및 관리: 회원제 서비스 이용에 따른 본인확인, 개인 식별, 불량회원의 부정이용 방지와 비인가 사용방지, 가입의사 확인, 연령확인, 불만처리 등 민원처리, 고지사항 전달</li>
                        <li>프로그램 신청 및 결제 서비스: 프로그램 신청, 결제, 환불, 프로그램 운영 관련 정보 제공</li>
                        <li>마케팅 및 광고에의 활용: 신규 서비스 개발 및 맞춤 서비스 제공, 이벤트 등 광고성 정보 전달, 접속빈도 파악 또는 회원의 서비스 이용에 대한 통계</li>
                    </ol>
                </div>
                
                <div class="mb-4">
                    <h6><strong>2. 개인정보의 처리 및 보유기간</strong></h6>
                    <p class="small">파주 체험 Camp는 법령에 따른 개인정보 보유·이용 기간 또는 정보주체로부터 개인정보를 수집 시에 동의 받은 개인정보 보유·이용 기간 내에서 개인정보를 처리·보유합니다.</p>
                    <ul class="small">
                        <li>회원 정보: 회원 탈퇴 시까지</li>
                        <li>프로그램 신청 정보: 프로그램 종료 후 1년</li>
                        <li>결제 정보: 전자상거래법에 따라 5년간 보관</li>
                    </ul>
                </div>
                
                <div class="mb-4">
                    <h6><strong>3. 개인정보의 제3자 제공</strong></h6>
                    <p class="small">파주 체험 Camp는 정보주체의 개인정보를 제1조(개인정보의 처리 목적)에서 명시한 범위 내에서만 처리하며, 정보주체의 동의, 법률의 특별한 규정 등 개인정보 보호법 제17조 및 제18조에 해당하는 경우에만 개인정보를 제3자에게 제공합니다.</p>
                </div>
                
                <div class="mb-4">
                    <h6><strong>4. 처리하는 개인정보 항목</strong></h6>
                    <p class="small">파주 체험 Camp는 다음의 개인정보 항목을 처리하고 있습니다.</p>
                    <ul class="small">
                        <li>회원가입: 아이디, 비밀번호, 이름, 연락처, 이메일</li>
                        <li>프로그램 신청: 신청자 정보, 아동 정보, 프로그램 참여 이력</li>
                        <li>결제 정보: 결제 수단, 결제 금액, 결제 일시</li>
                    </ul>
                </div>
                
                <div class="mb-4">
                    <h6><strong>5. 개인정보보호책임자</strong></h6>
                    <p class="small">파주 체험 Camp는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 정보주체의 불만처리 및 피해구제를 위하여 아래와 같이 개인정보 보호책임자를 지정하고 있습니다.</p>
                    <ul class="small">
                        <li>성명: 홍길동</li>
                        <li>직책: 개인정보 보호담당자</li>
                        <li>연락처: 02-123-4567, privacy@paju.kr</li>
                    </ul>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">닫기</button>
            </div>
        </div>
    </div>
</div>