<?php
// register_process.php - 회원가입 처리

// 폼에서 전송된 데이터 가져오기
$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$password_confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$agree_terms = isset($_POST['agree_terms']) ? true : false;

// 폼 데이터를 세션에 저장 (오류 발생 시 재사용)
$_SESSION['form_data'] = [
    'username' => $username,
    'name' => $name,
    'email' => $email,
    'phone' => $phone,
    'agree_terms' => $agree_terms
];

// 기본적인 입력 검증
if(empty($username) || empty($password) || empty($password_confirm) || 
   empty($name) || empty($email) || empty($phone) || !$agree_terms) {
    redirect('index.php?page=register&error=empty');
    exit;
}

// 아이디 유효성 검사 (영문, 숫자 4-20자)
if(!preg_match('/^[a-zA-Z0-9]{4,20}$/', $username)) {
    redirect('index.php?page=register&error=invalid_username');
    exit;
}

// 비밀번호 일치 여부 확인
if($password !== $password_confirm) {
    redirect('index.php?page=register&error=password_mismatch');
    exit;
}

// 비밀번호 길이 확인
if(strlen($password) < 6) {
    redirect('index.php?page=register&error=password_short');
    exit;
}

// 이메일 형식 확인
if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirect('index.php?page=register&error=invalid_email');
    exit;
}

// 이미 존재하는 사용자 이름인지 확인
$existing_user = get_user_by_username($username);
if($existing_user) {
    redirect('index.php?page=register&error=username_exists');
    exit;
}

// 사용자 추가
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$user_data = [
    'username' => $username,
    'password' => $hashed_password,
    'name' => $name,
    'email' => $email,
    'phone' => $phone,
    'is_admin' => 0, // 일반 사용자로 등록
    'created_at' => date('Y-m-d H:i:s')
];

// 데이터베이스에 사용자 추가
$user_id = add_user($user_data);

if($user_id) {
    // 회원가입 성공 메시지 설정
    set_message('success', '회원가입이 완료되었습니다. 로그인해주세요.');
    redirect('index.php?page=login');
} else {
    // 회원가입 실패
    set_message('error', '회원가입 중 오류가 발생했습니다. 다시 시도해주세요.');
    redirect('index.php?page=register');
}
?>