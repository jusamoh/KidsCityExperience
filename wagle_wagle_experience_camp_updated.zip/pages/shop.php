<?php
// shop.php - 와글와글쇼핑 메인 페이지

// 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/database.php';

// 데이터베이스 연결
$conn = get_db_connection();

// 쇼핑몰 테이블 생성 (처음 접속시)
try {
    // 쇼핑 카테고리 테이블 생성
    $conn->query("CREATE TABLE IF NOT EXISTS shop_categories (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // 상품 테이블 생성
    $conn->query("CREATE TABLE IF NOT EXISTS products (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(200) NOT NULL,
        description TEXT,
        price DECIMAL(10,0) NOT NULL,
        stock_quantity INT DEFAULT 0,
        category_id INT,
        image_url VARCHAR(500),
        age_group VARCHAR(50),
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES shop_categories(id)
    )");

    // 장바구니 테이블 생성
    $conn->query("CREATE TABLE IF NOT EXISTS cart_items (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT,
        product_id INT,
        quantity INT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        UNIQUE KEY unique_user_product (user_id, product_id)
    )");

    // 주문 테이블 생성
    $conn->query("CREATE TABLE IF NOT EXISTS orders (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT,
        order_number VARCHAR(50) UNIQUE,
        total_amount DECIMAL(10,0) NOT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        shipping_address TEXT,
        phone VARCHAR(20),
        recipient_name VARCHAR(100),
        payment_method VARCHAR(50),
        payment_status VARCHAR(20) DEFAULT 'pending',
        order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )");

    // 주문 상세 테이블 생성
    $conn->query("CREATE TABLE IF NOT EXISTS order_items (
        id INT PRIMARY KEY AUTO_INCREMENT,
        order_id INT,
        product_id INT,
        quantity INT,
        price DECIMAL(10,0),
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    // 기본 카테고리 데이터 확인 및 추가
    $category_check = $conn->query("SELECT COUNT(*) as count FROM shop_categories");
    $category_count = $category_check->fetch_assoc()['count'];
    
    if ($category_count == 0) {
        $categories = [
            ['도서/교재', '유아 및 어린이를 위한 교육 도서와 교재'],
            ['교구/완구', '창의력과 학습을 도와주는 교육용 교구 및 완구'],
            ['미술용품', '그리기, 만들기 등 창작 활동을 위한 미술 도구'],
            ['음악교구', '음악 감상과 연주를 위한 악기 및 교구'],
            ['체육용품', '신체 발달을 위한 운동 기구 및 체육 도구']
        ];
        
        foreach ($categories as $cat) {
            $stmt = $conn->prepare("INSERT INTO shop_categories (name, description) VALUES (?, ?)");
            $stmt->bind_param("ss", $cat[0], $cat[1]);
            $stmt->execute();
        }
    }

    // 상품 데이터 확인 및 추가 (장바구니 데이터 보존을 위해 삭제하지 않음)
    $product_check = $conn->query("SELECT COUNT(*) as count FROM products");
    $product_count = $product_check->fetch_assoc()['count'];
    
    if ($product_count == 0) {
        // 상품이 없을 때만 추가
    
    $products = [
        ['갈색 곰아 갈색 곰아 무엇을 보고 있니?', '에릭 칼의 대표작으로 색깔과 동물을 배울 수 있는 영어 그림책', 15000, 10, 1, '2-5세', 'assets/img/shop/brown_bear.jpg'],
        ['무지개 물고기', '친구와의 우정을 배울 수 있는 아름다운 그림책', 18000, 10, 1, '3-7세', 'assets/img/shop/rainbow-fish.jpg'],
        ['The Very Hungry Caterpillar', '에릭 칼의 유명한 영어 그림책', 16000, 10, 1, '2-6세', 'assets/img/shop/The Very Hungry Caterpillar.jpg'],
        ['원목 블록 세트 (100피스)', '상상력과 창의력을 기르는 천연 원목 블록', 45000, 10, 2, '3-8세', 'assets/img/programs/program-1.jpg'],
        ['퍼즐 매트 (알파벳)', 'EVA 소재의 안전한 알파벳 학습 매트', 32000, 10, 2, '2-7세', 'assets/img/programs/program-61.jpg'],
        ['유아용 크레파스 24색', '안전한 소재로 만든 유아 전용 크레파스', 12000, 10, 3, '2-8세', 'assets/img/programs/program-3.jpg'],
        ['안전 가위 세트', '둥근 날로 안전하게 만들어진 유아용 가위', 8000, 10, 3, '4-8세', 'assets/img/programs/program-default.jpg'],
        ['미니 실로폰', '음감 발달을 위한 아이들용 실로폰', 35000, 10, 4, '3-10세', 'assets/img/programs/program-4.jpg'],
        ['아동용 키보드', '음악적 감성을 기르는 키보드', 42000, 10, 4, '4-10세', 'assets/img/programs/program-10.jpg'],
        ['균형 잡기 보드', '균형감각과 코어 근육 발달을 위한 보드', 55000, 10, 5, '4-10세', 'assets/img/programs/program-5.jpg'],
        ['소프트 공 세트 (6개)', '부드러운 재질의 안전한 놀이용 공', 25000, 10, 5, '1-6세', 'assets/img/programs/program-11.jpg']
    ];
    
        foreach ($products as $prod) {
            $stmt = $conn->prepare("INSERT INTO products (name, description, price, stock_quantity, category_id, age_group, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssiisss", $prod[0], $prod[1], $prod[2], $prod[3], $prod[4], $prod[5], $prod[6]);
            $stmt->execute();
        }
    }
} catch (Exception $e) {
    error_log("쇼핑몰 테이블 생성 오류: " . $e->getMessage());
}

// 카테고리 목록 - 고정 사용 (중복 방지)
$categories = [
    ['id' => 1, 'name' => '도서/교재'],
    ['id' => 2, 'name' => '교구/완구'],
    ['id' => 3, 'name' => '미술용품'],
    ['id' => 4, 'name' => '음악교구'],
    ['id' => 5, 'name' => '체육용품']
];

// 선택된 카테고리
$selected_category = isset($_GET['category']) ? (int)$_GET['category'] : 0;

// 상품 데이터 로드 함수
function load_shop_products() {
    $shop_products_file = __DIR__ . '/../data/shop_products.json';
    
    // 기본 상품 데이터
    $default_products = [
        ['id' => 1, 'name' => '갈색 곰아 갈색 곰아 무엇을 보고 있니?', 'description' => '에릭 칼의 대표작으로 색깔과 동물을 배울 수 있는 영어 그림책', 'price' => 15000, 'stock_quantity' => 10, 'category_name' => '도서/교재', 'category_id' => 1, 'age_group' => '2-5세', 'image_url' => 'assets/img/shop/brown_bear.jpg'],
        ['id' => 2, 'name' => '무지개 물고기', 'description' => '친구와의 우정을 배울 수 있는 아름다운 그림책', 'price' => 18000, 'stock_quantity' => 10, 'category_name' => '도서/교재', 'category_id' => 1, 'age_group' => '3-7세', 'image_url' => 'assets/img/shop/rainbow-fish.jpg'],
        ['id' => 3, 'name' => '원목 블록 세트 (100피스)', 'description' => '상상력과 창의력을 기르는 천연 원목 블록', 'price' => 45000, 'stock_quantity' => 10, 'category_name' => '교구/완구', 'category_id' => 2, 'age_group' => '3-8세', 'image_url' => 'assets/img/programs/program-1.jpg'],
        ['id' => 4, 'name' => '퍼즐 매트 (알파벳)', 'description' => 'EVA 소재의 안전한 알파벳 학습 매트', 'price' => 32000, 'stock_quantity' => 10, 'category_name' => '교구/완구', 'category_id' => 2, 'age_group' => '2-7세', 'image_url' => 'assets/img/programs/program-61.jpg'],
        ['id' => 5, 'name' => '유아용 크레파스 24색', 'description' => '안전한 소재로 만든 유아 전용 크레파스', 'price' => 12000, 'stock_quantity' => 10, 'category_name' => '미술용품', 'category_id' => 3, 'age_group' => '2-8세', 'image_url' => 'assets/img/programs/program-3.jpg'],
        ['id' => 6, 'name' => '안전 가위 세트', 'description' => '둥근 날로 안전하게 만들어진 유아용 가위', 'price' => 8000, 'stock_quantity' => 10, 'category_name' => '미술용품', 'category_id' => 3, 'age_group' => '4-8세', 'image_url' => 'assets/img/programs/program-default.jpg'],
        ['id' => 7, 'name' => '미니 실로폰', 'description' => '음감 발달을 위한 아이들용 실로폰', 'price' => 35000, 'stock_quantity' => 10, 'category_name' => '음악교구', 'category_id' => 4, 'age_group' => '3-10세', 'image_url' => 'assets/img/programs/program-4.jpg'],
        ['id' => 8, 'name' => '아동용 키보드', 'description' => '음악적 감성을 기르는 키보드', 'price' => 42000, 'stock_quantity' => 10, 'category_name' => '음악교구', 'category_id' => 4, 'age_group' => '4-10세', 'image_url' => 'assets/img/programs/program-10.jpg'],
        ['id' => 9, 'name' => '균형 잡기 보드', 'description' => '균형감각과 코어 근육 발달을 위한 보드', 'price' => 55000, 'stock_quantity' => 10, 'category_name' => '체육용품', 'category_id' => 5, 'age_group' => '4-10세', 'image_url' => 'assets/img/programs/program-5.jpg'],
        ['id' => 10, 'name' => '소프트 공 세트 (6개)', 'description' => '부드러운 재질의 안전한 놀이용 공', 'price' => 25000, 'stock_quantity' => 10, 'category_name' => '체육용품', 'category_id' => 5, 'age_group' => '1-6세', 'image_url' => 'assets/img/programs/program-11.jpg']
    ];
    
    if (file_exists($shop_products_file)) {
        $data = file_get_contents($shop_products_file);
        return json_decode($data, true) ?: $default_products;
    }
    
    return $default_products;
}

// 상품 목록 로드
$all_products = load_shop_products();

// 카테고리 필터 적용
$products = [];
if ($selected_category == 0) {
    $products = $all_products;
} else {
    foreach ($all_products as $product) {
        if ($product['category_id'] == $selected_category) {
            $products[] = $product;
        }
    }
}

$conn->close();
?>

<!-- 체험프로그램 스타일 헤더 -->
<div class="bg-light py-5 mb-4 position-relative" style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);">
    <div class="container text-center">
        <h1 class="display-3 fw-bold text-primary mb-4">와글와글쇼핑</h1>
        <p class="lead text-muted mb-4">
            아이들의 성장과 발달을 돕는 교육용품으로<br>
            함께 성장해요
        </p>
        
        <!-- 특징 박스들 -->
        <div class="row justify-content-center mb-4">
            <div class="col-md-2">
                <div class="btn btn-warning btn-lg fw-bold rounded-pill px-4 py-2 mb-2">
                    교육적
                </div>
            </div>
            <div class="col-md-2">
                <div class="btn btn-success btn-lg fw-bold rounded-pill px-4 py-2 mb-2">
                    전문가 추천
                </div>
            </div>
            <div class="col-md-2">
                <div class="btn btn-info btn-lg fw-bold rounded-pill px-4 py-2 mb-2">
                    품질 보증
                </div>
            </div>
        </div>
        
        <h3 class="h4 text-dark mb-4">어떤 재미있는 상품을 찾아볼까요?</h3>
    </div>
</div>

<div class="container" style="margin-top: -30px;">


    <!-- 카테고리 선택 -->
    <div class="card border-0 shadow-sm mb-4" style="background: #f8f9fa;">
        <div class="card-body p-4">
            <div class="text-center mb-4">
                <h4 class="text-dark fw-bold mb-2">카테고리별 베스트 상품</h4>
                <p class="text-muted">전문가가 추천하는 카테고리별 엄선된 상품들을 만나보세요</p>
            </div>
            <div class="d-flex flex-wrap justify-content-center gap-2">
                <a href="?page=shop" 
                   class="btn <?php echo $selected_category == 0 ? 'btn-dark' : 'btn-outline-dark'; ?> btn-lg fw-bold rounded-pill px-4 py-2" style="font-size: 1.5rem; font-weight: 900;">
                    전체 상품
                </a>
                <?php 
                foreach ($categories as $category): 
                ?>
                    <a href="?page=shop&category=<?php echo $category['id']; ?>" 
                       class="btn <?php echo $selected_category == $category['id'] ? 'btn-primary' : 'btn-outline-primary'; ?> btn-lg fw-bold rounded-pill px-4 py-2" style="font-size: 1.5rem; font-weight: 900;">
                        <?php echo htmlspecialchars($category['name']); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- 상품 그리드 -->
    <div class="row">
        <?php if (empty($products)): ?>
            <div class="col-12 text-center py-5">

                <h4 class="text-muted">상품이 없습니다</h4>
                <p class="text-muted">곧 새로운 상품들이 추가될 예정입니다.</p>
            </div>
        <?php else: ?>
            <?php foreach ($products as $product): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 border-0 shadow-sm stable-card">
                        <!-- 상품 이미지 -->
                        <div class="position-relative">
                            <img src="<?php echo htmlspecialchars($product['image_url'] ?: 'assets/img/shop/brown_bear.jpg'); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 style="height: 200px; object-fit: cover; width: 100%;"
                                 onerror="this.src='assets/img/shop/brown_bear.jpg'">
                            
                            <!-- 재고 상태 배지 -->
                            <div class="position-absolute top-0 end-0 m-2">
                                <?php if ($product['stock_quantity'] <= 0): ?>
                                    <span class="badge bg-danger">품절</span>
                                <?php elseif ($product['stock_quantity'] <= 5): ?>
                                    <span class="badge bg-warning text-dark">재고부족</span>
                                <?php else: ?>
                                    <span class="badge bg-success">판매중</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="card-body p-4 d-flex flex-column">
                            <!-- 카테고리 및 연령대 -->
                            <div class="mb-2">
                                <small class="text-muted">
                                    <?php echo htmlspecialchars($product['category_name']); ?>
                                    <?php if ($product['age_group']): ?>
                                        | <?php echo htmlspecialchars($product['age_group']); ?>
                                    <?php endif; ?>
                                </small>
                            </div>

                            <!-- 상품명 -->
                            <h5 class="card-title">
                                <?php echo htmlspecialchars($product['name']); ?>
                            </h5>

                            <!-- 상품 설명 -->
                            <p class="card-text text-muted small">
                                <?php echo htmlspecialchars(mb_substr($product['description'], 0, 80) . '...'); ?>
                            </p>

                            <!-- 가격 -->
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h4 class="text-primary mb-0">
                                        <?php echo number_format($product['price']); ?>원
                                    </h4>
                                    <small class="text-muted">재고: <?php echo $product['stock_quantity']; ?>개</small>
                                </div>

                                <!-- 액션 버튼 -->
                                <div class="mt-3">
                                    <?php if ($product['stock_quantity'] > 0): ?>
                                        <div class="btn-group w-100" role="group">
                                            <button type="button" 
                                                    class="btn btn-outline-primary"
                                                    onclick="addToCart(<?php echo $product['id']; ?>)">
                                                담기
                                            </button>
                                            <button type="button" 
                                                    class="btn btn-primary"
                                                    onclick="buyNow(<?php echo $product['id']; ?>)">
                                                구매
                                            </button>
                                        </div>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-secondary w-100" disabled>
                                            품절
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- 장바구니 추가 모달 -->
<div class="modal fade" id="cartModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-shopping-cart text-success"></i> 장바구니
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <p class="mb-3">상품이 장바구니에 추가되었습니다!</p>
                <div class="d-grid gap-2">
                    <a href="?page=cart" class="btn btn-primary">
                        <i class="fas fa-shopping-cart"></i> 장바구니 보기
                    </a>
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        계속 쇼핑하기
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// 장바구니에 상품 추가
async function addToCart(productId) {
    try {
        const response = await fetch('api/cart_add.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: 1
            })
        });

        const result = await response.json();
        
        if (result.success) {
            // 장바구니 카운트 업데이트
            if (window.updateCartCount) {
                window.updateCartCount();
            }
            // 성공 메시지와 함께 모달 표시
            const modal = new bootstrap.Modal(document.getElementById('cartModal'));
            modal.show();
            
            // 추가적인 시각적 피드백
            console.log('상품이 장바구니에 추가되었습니다!');
        } else {
            if (result.message === 'login_required') {
                alert('로그인이 필요합니다.');
                window.location.href = '?page=login';
            } else {
                alert(result.message || '장바구니 추가에 실패했습니다.');
                console.error('장바구니 추가 실패:', result.message);
            }
        }
    } catch (error) {
        console.error('Error:', error);
        alert('오류가 발생했습니다.');
    }
}

// 즉시 구매
async function buyNow(productId) {
    try {
        // 먼저 장바구니에 추가
        const response = await fetch('api/cart_add.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: 1
            })
        });

        const result = await response.json();
        
        if (result.success) {
            // 장바구니로 이동하여 바로 결제 진행
            window.location.href = '?page=cart';
        } else {
            if (result.message === 'login_required') {
                alert('로그인이 필요합니다.');
                window.location.href = '?page=login';
            } else {
                alert(result.message || '구매에 실패했습니다.');
            }
        }
    } catch (error) {
        console.error('Error:', error);
        alert('오류가 발생했습니다.');
    }
}

// 장바구니 개수 업데이트
async function updateCartCount() {
    try {
        const response = await fetch('api/cart_count.php');
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('cart-count').textContent = result.count;
        }
    } catch (error) {
        console.error('Cart count update error:', error);
    }
}

// 페이지 로드시 장바구니 개수 업데이트
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
});
</script>

<style>
.product-card {
    transition: none !important;
    transform: none !important;
    border: 1px solid #e0e0e0;
}

.product-card:hover {
    transform: none !important;
    box-shadow: none !important;
}

.btn-group .btn {
    flex: 1;
}
</style>