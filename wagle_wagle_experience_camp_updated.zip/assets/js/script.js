/**
 * 와글와글 체험Camp 메인 자바스크립트 파일
 * 쇼핑몰 방식 - PHP 필터링으로 떨림 없음
 */

// JavaScript 필터링 완전 제거
// 모든 카테고리 필터링은 PHP로 처리됨

/**
 * 필터링 결과 카운트 업데이트
 */
function updateFilterCount(count) {
    const countElement = document.getElementById('program-count');
    if (countElement) {
        countElement.textContent = count;
    }
}

/**
 * 토스트 메시지 초기화
 */
function initToasts() {
    const toasts = document.querySelectorAll('.toast');
    
    toasts.forEach(toast => {
        const bsToast = new bootstrap.Toast(toast, {
            autohide: true,
            delay: 3000
        });
        bsToast.show();
    });
}

/**
 * 결제 옵션 선택 기능 초기화
 */
function initPaymentOptions() {
    const paymentOptions = document.querySelectorAll('.payment-option');
    const paymentMethodInput = document.getElementById('payment-method');
    
    if (paymentOptions.length === 0 || !paymentMethodInput) return;
    
    paymentOptions.forEach(option => {
        option.addEventListener('click', function() {
            paymentOptions.forEach(opt => opt.classList.remove('selected'));
            this.classList.add('selected');
            
            const method = this.getAttribute('data-method');
            paymentMethodInput.value = method;
        });
    });
}

/**
 * 폼 유효성 검사 초기화
 */
function initFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    if (forms.length === 0) return;
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
}

/**
 * 숫자 입력 필드 제한 (숫자만 입력 가능)
 */
function numberOnly(input) {
    input.value = input.value.replace(/[^0-9]/g, '');
}

/**
 * 전화번호 형식 자동 변환 (000-0000-0000)
 */
function formatPhoneNumber(input) {
    let value = input.value.replace(/[^0-9]/g, '');
    
    if (value.length > 3 && value.length <= 7) {
        value = value.slice(0, 3) + '-' + value.slice(3);
    } else if (value.length > 7) {
        value = value.slice(0, 3) + '-' + value.slice(3, 7) + '-' + value.slice(7, 11);
    }
    
    input.value = value;
}

/**
 * 토스페이먼츠 결제 모듈 초기화
 */
function initTossPayments(clientKey, amount, orderId, orderName, successUrl, failUrl) {
    if (typeof TossPayments === 'undefined') return;
    
    const tossPayments = TossPayments(clientKey);
    
    document.getElementById('payment-button').addEventListener('click', function() {
        const customerName = document.getElementById('customer-name').value;
        const customerEmail = document.getElementById('customer-email').value;
        
        if (!customerName || !customerEmail) {
            alert('이름과 이메일을 입력해주세요.');
            return;
        }
        
        tossPayments.requestPayment('카드', {
            amount: amount,
            orderId: orderId,
            orderName: orderName,
            customerName: customerName,
            customerEmail: customerEmail,
            successUrl: window.location.origin + successUrl,
            failUrl: window.location.origin + failUrl
        });
    });
}

/**
 * 이미지 프리뷰 표시 (파일 업로드 시)
 */
function showImagePreview(input, previewId) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            const preview = document.getElementById(previewId);
            if (preview) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

/**
 * 다중 프로그램 선택 처리
 */
function handleProgramSelection(checkbox, price) {
    const totalElement = document.getElementById('total-price');
    const selectedCount = document.getElementById('selected-count');
    
    if (!totalElement || !selectedCount) return;
    
    let total = parseInt(totalElement.getAttribute('data-price') || 0);
    let count = parseInt(selectedCount.textContent || 0);
    
    if (checkbox.checked) {
        total += price;
        count++;
    } else {
        total -= price;
        count--;
    }
    
    totalElement.setAttribute('data-price', total);
    totalElement.textContent = total.toLocaleString() + '원';
    selectedCount.textContent = count;
    
    // 선택된 프로그램이 없으면 신청 버튼 비활성화
    const submitButton = document.getElementById('submit-button');
    if (submitButton) {
        submitButton.disabled = count === 0;
    }
}

/**
 * 주소 검색 (다음 우편번호 서비스)
 */
function searchAddress() {
    if (typeof daum === 'undefined' || !daum.Postcode) {
        alert('주소 검색 서비스를 사용할 수 없습니다.');
        return;
    }
    
    new daum.Postcode({
        oncomplete: function(data) {
            const fullAddress = data.address;
            const extraAddress = '';
            
            if (data.addressType === 'R') {
                if (data.bname !== '') {
                    extraAddress += data.bname;
                }
                if (data.buildingName !== '') {
                    extraAddress += (extraAddress !== '' ? ', ' + data.buildingName : data.buildingName);
                }
                fullAddress += (extraAddress !== '' ? ' (' + extraAddress + ')' : '');
            }
            
            document.getElementById('postcode').value = data.zonecode;
            document.getElementById('address').value = fullAddress;
            
            document.getElementById('detail-address').focus();
        }
    }).open();
}