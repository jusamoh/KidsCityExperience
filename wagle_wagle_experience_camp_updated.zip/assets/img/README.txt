이 폴더에는 프로그램 이미지 파일들이 들어가야 합니다.

필요한 이미지 파일들:
1. program-1.jpg - 상추 키우기 체험 프로그램 이미지
2. program-2.jpg - 고추 모종 심기 체험 프로그램 이미지
3. program-3.jpg - 깻잎 향기 체험 프로그램 이미지
4. program-4.jpg - The Very Hungry Caterpillar 연극놀이 프로그램 이미지
5. program-5.jpg - Brown Bear, Brown Bear 역할놀이 프로그램 이미지
6. program-6.jpg - 영아 스포츠 놀이 프로그램 이미지
...
program-default.jpg - 기본 프로그램 이미지 (다른 이미지가 없을 때 표시됨)

각 파일은 800x500 픽셀 크기의 jpg 이미지 파일이어야 합니다.
해당 파일들을 C:/xampp/htdocs/paju/assets/img/ 경로에 복사하세요.

이미지 추천:
- program-1.jpg: 상추, 도시 텃밭 관련 이미지
- program-2.jpg: 고추 모종, 식물 관련 이미지
- program-3.jpg: 깻잎, 향신료 관련 이미지
- program-4.jpg: 아이들과 책, 애벌레 관련 이미지
- program-5.jpg: 아이들과 곰, 역할놀이 관련 이미지
- program-6.jpg: 아기 스포츠/놀이 관련 이미지
- program-default.jpg: 아이들과 놀이/체험 관련 이미지

이미지는 인터넷에서 저작권 문제 없는 이미지를 다운로드하시거나, 직접 촬영하신 이미지를 사용하시면 됩니다.
추천 사이트: Unsplash, Pexels, Pixabay 등의 무료 이미지 사이트