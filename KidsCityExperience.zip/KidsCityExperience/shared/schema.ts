import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users Schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

// Program Categories
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  description: true,
});

// Programs Schema
export const programs = pgTable("programs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  categoryId: integer("category_id").notNull(),
  minAge: integer("min_age").notNull(), // in months
  maxAge: integer("max_age").notNull(), // in months
  date: timestamp("date").notNull(),
  location: text("location").notNull(),
  price: integer("price").notNull(), // in KRW
  maxParticipants: integer("max_participants").notNull(),
  minParticipants: integer("min_participants").notNull(),
  duration: integer("duration").notNull(), // in minutes
  imageUrl: text("image_url"),
  status: text("status").notNull().default("pending"), // "confirmed", "pending", "canceled"
});

export const insertProgramSchema = createInsertSchema(programs).pick({
  title: true,
  description: true,
  categoryId: true,
  minAge: true,
  maxAge: true,
  date: true,
  location: true,
  price: true,
  maxParticipants: true,
  minParticipants: true,
  duration: true,
  imageUrl: true,
  status: true,
});

// Registrations Schema
export const registrations = pgTable("registrations", {
  id: serial("id").primaryKey(),
  programId: integer("program_id").notNull(),
  childName: text("child_name").notNull(),
  childAge: integer("child_age").notNull(), // in months
  parentName: text("parent_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  paymentStatus: text("payment_status").default("pending").notNull(), // "pending", "paid", "canceled"
  paymentMethod: text("payment_method"),
  paymentId: text("payment_id"),
  paidAmount: integer("paid_amount"),
});

export const insertRegistrationSchema = createInsertSchema(registrations).pick({
  programId: true,
  childName: true,
  childAge: true,
  parentName: true,
  phone: true,
  email: true,
  notes: true,
});

// Payment Schema
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  registrationId: integer("registration_id").notNull(),
  amount: integer("amount").notNull(),
  method: text("method").notNull(), // "card", "vbank", "phone", etc.
  status: text("status").notNull(), // "ready", "paid", "canceled", "failed"
  paymentKey: text("payment_key"), // Toss Payments key
  orderId: text("order_id").notNull(), // unique order ID
  orderName: text("order_name").notNull(), // product name
  requestedAt: timestamp("requested_at").defaultNow().notNull(),
  approvedAt: timestamp("approved_at"),
  receiptUrl: text("receipt_url"),
  extraData: text("extra_data"), // JSON string for additional data
});

export const insertPaymentSchema = createInsertSchema(payments).pick({
  registrationId: true,
  amount: true,
  method: true,
  status: true,
  paymentKey: true,
  orderId: true,
  orderName: true,
  approvedAt: true,
  receiptUrl: true,
  extraData: true,
});

// Type Exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Program = typeof programs.$inferSelect;
export type InsertProgram = z.infer<typeof insertProgramSchema>;

export type Registration = typeof registrations.$inferSelect;
export type InsertRegistration = z.infer<typeof insertRegistrationSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

// Extended schemas for the frontend
export const registrationFormSchema = insertRegistrationSchema.extend({
  agreement: z.boolean().refine((val) => val === true, {
    message: "개인정보 수집 및 이용에 동의해주세요.",
  }),
});

export type RegistrationFormData = z.infer<typeof registrationFormSchema>;

// Payment Schema for Toss Payments
export const tossPaymentSchema = z.object({
  amount: z.number().min(1000, "결제 금액은 최소 1,000원 이상이어야 합니다."),
  orderId: z.string().min(1, "주문 ID가 필요합니다."),
  orderName: z.string().min(1, "주문명이 필요합니다."),
  customerEmail: z.string().email("유효한 이메일 주소가 필요합니다."),
  customerName: z.string().min(1, "고객 이름이 필요합니다."),
  successUrl: z.string().url("성공 URL이 필요합니다."),
  failUrl: z.string().url("실패 URL이 필요합니다."),
});

export type TossPaymentRequest = z.infer<typeof tossPaymentSchema>;

// Payment Verification
export const paymentVerificationSchema = z.object({
  paymentKey: z.string().min(1, "결제 키가 필요합니다."),
  orderId: z.string().min(1, "주문 ID가 필요합니다."),
  amount: z.number().min(1, "결제 금액이 필요합니다."),
});

export type PaymentVerification = z.infer<typeof paymentVerificationSchema>;
