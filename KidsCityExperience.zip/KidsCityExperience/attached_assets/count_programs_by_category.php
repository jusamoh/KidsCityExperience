// 특정 카테고리에 속한 프로그램 개수 가져오기
function count_programs_by_category($category_id) {
    $conn = get_db_connection();
    $category_id = $conn->real_escape_string($category_id);
    
    $sql = "SELECT COUNT(*) as count FROM programs WHERE category_id = {$category_id}";
    $result = $conn->query($sql);
    
    $count = 0;
    if ($result && $result->num_rows > 0) {
        $count = $result->fetch_assoc()['count'];
    }
    
    $conn->close();
    return $count;
}