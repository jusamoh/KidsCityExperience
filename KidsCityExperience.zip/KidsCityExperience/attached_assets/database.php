<?php
// database.php - 데이터베이스 연결 및 함수

// 데이터베이스 연결 정보
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'paju_db';

// 데이터베이스 연결 함수
function get_db_connection() {
    global $db_host, $db_user, $db_password, $db_name;
    
    // 데이터베이스 연결
    $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
    
    // 연결 오류 확인
    if ($conn->connect_error) {
        // 데이터베이스가 없으면 생성 시도
        $temp_conn = new mysqli($db_host, $db_user, $db_password);
        if (!$temp_conn->connect_error) {
            $temp_conn->query("CREATE DATABASE IF NOT EXISTS $db_name");
            $temp_conn->close();
            
            // 새로 생성된 데이터베이스에 연결
            $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
        }
        
        // 여전히 연결 오류가 있으면 오류 표시
        if ($conn->connect_error) {
            die("데이터베이스 연결 실패: " . $conn->connect_error);
        }
    }
    
    // 한글 깨짐 방지
    $conn->set_charset("utf8mb4");
    
    return $conn;
}

// 테이블 생성 함수
function create_tables_if_not_exist() {
    $conn = get_db_connection();
    
    // 카테고리 테이블
    $sql = "CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($sql);
    
    // 프로그램 테이블
    $sql = "CREATE TABLE IF NOT EXISTS programs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        category_id INT NOT NULL,
        date DATE,
        location VARCHAR(255),
        min_age INT DEFAULT 0,
        max_age INT DEFAULT 24,
        price DECIMAL(10,2),
        max_participants INT DEFAULT 20,
        min_participants INT DEFAULT 5,
        duration INT DEFAULT 60,
        status VARCHAR(50) DEFAULT 'active',
        image_url VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (category_id)
    )";
    $conn->query($sql);
    
    // 카테고리 변경 기록 테이블
    $sql = "CREATE TABLE IF NOT EXISTS program_categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        program_id INT NOT NULL,
        category_id INT NOT NULL,
        changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (program_id),
        INDEX (category_id)
    )";
    $conn->query($sql);
    
    // 사용자 테이블
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        is_admin TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($sql);
    
    // 등록 테이블
    $sql = "CREATE TABLE IF NOT EXISTS registrations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        program_id INT NOT NULL,
        child_name VARCHAR(255) NOT NULL,
        child_age INT NOT NULL,
        parent_name VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        email VARCHAR(255) NOT NULL,
        notes TEXT DEFAULT NULL,
        payment_status VARCHAR(50) DEFAULT 'pending',
        payment_method VARCHAR(50) DEFAULT NULL,
        payment_id VARCHAR(255) DEFAULT NULL,
        paid_amount DECIMAL(10,2) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (program_id)
    )";
    $conn->query($sql);
    
    // 결제 테이블
    $sql = "CREATE TABLE IF NOT EXISTS payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        registration_id INT NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        amount DECIMAL(10,2) NOT NULL,
        method VARCHAR(50) NOT NULL,
        order_id VARCHAR(255) NOT NULL,
        order_name VARCHAR(255) NOT NULL,
        payment_key VARCHAR(255) DEFAULT NULL,
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        approved_at TIMESTAMP NULL DEFAULT NULL,
        receipt_url VARCHAR(255) DEFAULT NULL,
        extra_data TEXT DEFAULT NULL,
        INDEX (registration_id)
    )";
    $conn->query($sql);
    
    // 기본 데이터 추가
    add_default_data($conn);
    
    $conn->close();
}

// 기본 데이터 추가 함수
function add_default_data($conn) {
    // 관리자 계정이 없으면 추가
    $result = $conn->query("SELECT id FROM users WHERE username = 'admin' LIMIT 1");
    if ($result->num_rows == 0) {
        // 비밀번호 해싱 (admin)
        $hashed_password = password_hash('admin', PASSWORD_DEFAULT);
        $conn->query("INSERT INTO users (username, password, is_admin) VALUES ('admin', '$hashed_password', 1)");
    }
    
    // 카테고리가 없으면 기본 카테고리 추가
    $result = $conn->query("SELECT id FROM categories LIMIT 1");
    if ($result->num_rows == 0) {
        $categories = [
            ['name' => '도시텃밭 체험', 'description' => '아이들이 식물을 심고 가꾸는 경험을 통해 자연과 교감하고 성장의 기쁨을 느낄 수 있는 프로그램입니다.'],
            ['name' => '영어놀이', 'description' => '그림책을 활용한 연극 놀이와 다양한 활동을 통해 영어에 자연스럽게 노출되고 흥미를 갖게 하는 프로그램입니다.'],
            ['name' => '신체놀이', 'description' => '다양한 신체 활동을 통해 대근육과 소근육 발달을 돕고, 협동심과 사회성을 기를 수 있는 프로그램입니다.']
        ];
        
        foreach ($categories as $category) {
            $name = $conn->real_escape_string($category['name']);
            $description = $conn->real_escape_string($category['description']);
            $conn->query("INSERT INTO categories (name, description) VALUES ('$name', '$description')");
        }
    }
    
    // 프로그램이 없으면 기본 프로그램 추가
    $result = $conn->query("SELECT id FROM programs LIMIT 1");
    if ($result->num_rows == 0) {
        $programs = [
            [
                'title' => '상추 키우기 체험',
                'description' => '한국 도시텃밭의 대표 작물인 상추를 직접 심고 가꾸는 체험입니다. 아이들이 식물의 성장 과정을 관찰하고 수확의 기쁨을 경험할 수 있습니다.',
                'category_id' => 1,
                'date' => '2025-06-15',
                'location' => '파주 체험 Camp 본사 옥상 정원',
                'min_age' => 12,
                'max_age' => 24,
                'price' => 30000,
                'max_participants' => 10,
                'min_participants' => 4,
                'duration' => 60,
                'status' => 'active'
            ],
            [
                'title' => '방울토마토 재배 체험',
                'description' => '아이들이 좋아하는 방울토마토를 직접 심고 가꾸는 체험입니다. 수확한 토마토는 집에 가져가서 가족과 함께 먹을 수 있습니다.',
                'category_id' => 1,
                'date' => '2025-06-22',
                'location' => '파주 체험 Camp 본사 옥상 정원',
                'min_age' => 12,
                'max_age' => 24,
                'price' => 35000,
                'max_participants' => 10,
                'min_participants' => 4,
                'duration' => 60,
                'status' => 'active'
            ],
            [
                'title' => '고추 모종 심기 체험',
                'description' => '한국 음식에 빠질 수 없는 고추 모종을 심고 가꾸는 체험입니다. 아이들이 한국 식문화에 대해 배울 수 있는 좋은 기회입니다.',
                'category_id' => 1,
                'date' => '2025-07-05',
                'location' => '파주 체험 Camp 본사 옥상 정원',
                'min_age' => 18,
                'max_age' => 24,
                'price' => 35000,
                'max_participants' => 8,
                'min_participants' => 3,
                'duration' => 60,
                'status' => 'active'
            ],
            [
                'title' => '깻잎 향기 체험',
                'description' => '한국 특유의 향신 채소인 깻잎을 재배하는 체험입니다. 아이들이 다양한 식물의 향을 맡고 감각을 발달시킬 수 있습니다.',
                'category_id' => 1,
                'date' => '2025-07-12',
                'location' => '파주 체험 Camp 본사 옥상 정원',
                'min_age' => 18,
                'max_age' => 24,
                'price' => 30000,
                'max_participants' => 8,
                'min_participants' => 3,
                'duration' => 60,
                'status' => 'active'
            ],
            [
                'title' => 'The Very Hungry Caterpillar 연극놀이',
                'description' => '에릭 칼의 유명한 그림책 \"배고픈 애벌레\"를 활용한 영어 연극 놀이입니다. 아이들이 책 속 캐릭터가 되어보며 영어를 자연스럽게 익힐 수 있습니다.',
                'category_id' => 2,
                'date' => '2025-06-20',
                'location' => '파주 체험 Camp 본사 교육실',
                'min_age' => 18,
                'max_age' => 24,
                'price' => 40000,
                'max_participants' => 8,
                'min_participants' => 4,
                'duration' => 50,
                'status' => 'active'
            ]
        ];
        
        foreach ($programs as $program) {
            $title = $conn->real_escape_string($program['title']);
            $description = $conn->real_escape_string($program['description']);
            $category_id = (int)$program['category_id'];
            $date = $conn->real_escape_string($program['date']);
            $location = $conn->real_escape_string($program['location']);
            $min_age = (int)$program['min_age'];
            $max_age = (int)$program['max_age'];
            $price = (float)$program['price'];
            $max_participants = (int)$program['max_participants'];
            $min_participants = (int)$program['min_participants'];
            $duration = (int)$program['duration'];
            $status = $conn->real_escape_string($program['status']);
            
            $conn->query("INSERT INTO programs (title, description, category_id, date, location, min_age, max_age, price, max_participants, min_participants, duration, status) 
                        VALUES ('$title', '$description', $category_id, '$date', '$location', $min_age, $max_age, $price, $max_participants, $min_participants, $duration, '$status')");
        }
    }
}
?>