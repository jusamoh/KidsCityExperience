<?php
// XAMPP 파일 다운로드 페이지
$zip_file = 'xampp_files_download.zip';

if (file_exists($zip_file)) {
    // 파일 다운로드 헤더 설정
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($zip_file) . '"');
    header('Content-Length: ' . filesize($zip_file));
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: public');
    
    // 파일 출력
    readfile($zip_file);
    exit;
} else {
    // 파일이 없을 경우 에러 메시지
    http_response_code(404);
    echo "파일을 찾을 수 없습니다.";
}
?>