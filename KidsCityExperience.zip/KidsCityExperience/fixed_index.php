<?php
// index.php - 메인 진입점
// 세션이 시작되지 않은 경우에만 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';
require_once 'includes/functions.php';

// 데이터베이스 테이블 자동 생성
create_tables_if_not_exist();

// 현재 페이지 파라미터 가져오기
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// 헤더 표시
include 'includes/header.php';

// 페이지 내용 표시
switch ($page) {
    case 'home':
        include 'pages/home.php';
        break;
    case 'program_selection':
        include 'pages/program_selection.php';
        break;
    case 'program_detail':
        include 'pages/program_detail.php';
        break;
    case 'registration':
        include 'pages/registration.php';
        break;
    case 'program_registration':
        include 'pages/program_registration.php';
        break;
    case 'multi_registration':
        include 'pages/multi_registration.php';
        break;
    case 'login':
        include 'pages/login.php';
        break;
    case 'register':
        include 'pages/register.php';
        break;
    case 'my_page':
        // 로그인 확인
        if (!isset($_SESSION['user_id'])) {
            redirect('index.php?page=login');
        }
        include 'pages/my_page.php';
        break;
    case 'admin_dashboard':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/admin_dashboard.php';
        break;
    case 'category_management':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/category_management.php';
        break;
    case 'faq':
        include 'pages/faq.php';
        break;
    case 'how_to_use':
        include 'pages/how_to_use.php';
        break;
    case 'refund_policy':
        include 'pages/refund_policy.php';
        break;
    case 'terms_of_service':
        include 'pages/terms_of_service.php';
        break;
    case 'privacy_policy':
        include 'pages/privacy_policy.php';
        break;
    case 'add_program':
        // 관리자 권한 확인
        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            redirect('index.php?page=login');
        }
        include 'pages/add_program.php';
        break;
    case 'payment_success':
        include 'pages/payment_success.php';
        break;
    case 'payment_fail':
        include 'pages/payment_fail.php';
        break;
    default:
        include 'pages/not_found.php';
}

// 푸터 표시
include 'includes/footer.php';
?>