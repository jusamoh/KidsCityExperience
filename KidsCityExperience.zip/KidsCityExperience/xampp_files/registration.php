<?php
require_once 'config.php';
$currentPage = 'registration';

// 프로그램 ID 확인
$programId = isset($_GET['program_id']) ? intval($_GET['program_id']) : 0;

if ($programId <= 0) {
    header('Location: index.php');
    exit;
}

// 프로그램 정보 조회
$stmt = $pdo->prepare("SELECT p.*, c.name as category_name, 
                       (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id AND r.payment_status = 'paid') as current_participants 
                       FROM programs p 
                       JOIN categories c ON p.category_id = c.id 
                       WHERE p.id = ?");
$stmt->execute([$programId]);
$program = $stmt->fetch();

if (!$program) {
    header('Location: index.php');
    exit;
}

// 등록 가능 여부 확인
$isAvailable = ($program['status'] !== 'canceled' && $program['current_participants'] < $program['max_participants']);

// 오류 메시지 초기화
$errors = [];
$success = false;
$registrationId = 0;

// 폼 제출 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 입력값 가져오기
    $childName = isset($_POST['child_name']) ? trim($_POST['child_name']) : '';
    $childAge = isset($_POST['child_age']) ? intval($_POST['child_age']) : 0;
    $parentName = isset($_POST['parent_name']) ? trim($_POST['parent_name']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : null;
    
    // 유효성 검사
    if (empty($childName)) {
        $errors[] = '아이 이름을 입력해주세요.';
    }
    
    if ($childAge < $program['min_age'] || $childAge > $program['max_age']) {
        $errors[] = '아이 나이는 ' . $program['min_age'] . '~' . $program['max_age'] . '개월 사이여야 합니다.';
    }
    
    if (empty($parentName)) {
        $errors[] = '보호자 이름을 입력해주세요.';
    }
    
    if (empty($phone)) {
        $errors[] = '연락처를 입력해주세요.';
    } elseif (!preg_match('/^[0-9]{3}-[0-9]{3,4}-[0-9]{4}$/', $phone) && !preg_match('/^[0-9]{10,11}$/', $phone)) {
        $errors[] = '유효한 연락처 형식이 아닙니다.';
    }
    
    if (empty($email)) {
        $errors[] = '이메일을 입력해주세요.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = '유효한 이메일 형식이 아닙니다.';
    }
    
    // 오류가 없으면 등록 정보 저장
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // 등록 정보 저장
            $stmt = $pdo->prepare("INSERT INTO registrations 
                                  (program_id, child_name, child_age, parent_name, phone, email, notes, payment_status) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([
                $programId,
                $childName,
                $childAge,
                $parentName,
                $phone,
                $email,
                $notes
            ]);
            
            $registrationId = $pdo->lastInsertId();
            
            $pdo->commit();
            $success = true;
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = '등록 중 오류가 발생했습니다: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>프로그램 신청 - 키즈 익스플로러</title>
    <meta name="description" content="<?= htmlspecialchars($program['title']) ?> 프로그램에 참가 신청하세요.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            color: #333;
            background-color: #f9f9f9;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
        }
        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
            color: #f05a7a;
        }
        .nav-link {
            font-weight: 600;
            color: #333;
            margin: 0 10px;
        }
        .nav-link:hover {
            color: #f05a7a;
        }
        .registration-header {
            background: linear-gradient(to right, #4ecdc4, #f05a7a);
            color: white;
            padding: 50px 0;
            margin-bottom: 30px;
        }
        .registration-form {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .program-summary {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .info-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .info-item:last-child {
            border-bottom: none;
        }
        .status-badge {
            border-radius: 20px;
            padding: 5px 12px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            margin-bottom: 10px;
        }
        .status-confirmed {
            background-color: #d4f7e8;
            color: #16a868;
        }
        .status-pending {
            background-color: #fff1d0;
            color: #ffa600;
        }
        .status-canceled {
            background-color: #ffe0e0;
            color: #ff4a4a;
        }
        .btn-primary {
            background-color: #f05a7a;
            border-color: #f05a7a;
        }
        .btn-primary:hover {
            background-color: #d84a68;
            border-color: #d84a68;
        }
        .form-control:focus {
            border-color: #f05a7a;
            box-shadow: 0 0 0 0.25rem rgba(240, 90, 122, 0.25);
        }
        .footer {
            background-color: #333;
            color: #f9f9f9;
            padding: 50px 0;
            margin-top: 50px;
        }
        .payment-container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">키즈 익스플로러</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">홈</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="programs.php">프로그램</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">소개</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">로그인</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="registration-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="display-5 fw-bold">프로그램 신청</h1>
                    <p class="lead"><?= htmlspecialchars($program['title']) ?></p>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <?php if (!$isAvailable): ?>
            <div class="alert alert-warning">
                <?php if ($program['status'] === 'canceled'): ?>
                    <strong>취소된 프로그램입니다.</strong> 다른 프로그램을 이용해주세요.
                <?php else: ?>
                    <strong>신청이 마감되었습니다.</strong> 다른 프로그램을 이용해주세요.
                <?php endif; ?>
                <p class="mt-3"><a href="index.php" class="btn btn-primary">다른 프로그램 보기</a></p>
            </div>
        <?php elseif ($success): ?>
            <!-- 결제 화면 표시 -->
            <div class="payment-container">
                <h2 class="mb-4">신청이 완료되었습니다!</h2>
                <p>결제를 진행해 주세요.</p>
                
                <div class="mb-4">
                    <h4 class="mb-3">프로그램: <?= htmlspecialchars($program['title']) ?></h4>
                    <p class="lead mb-3">가격: <strong><?= number_format($program['price']) ?>원</strong></p>
                </div>
                
                <div id="payment-button-container" class="mb-4">
                    <button id="payment-button" class="btn btn-primary btn-lg px-5">결제하기</button>
                </div>
                
                <div class="mt-4 text-muted">
                    <small>* 최소 참가자 수(<?= $program['min_participants'] ?>명)가 모이지 않으면 프로그램이 취소될 수 있습니다.</small><br>
                    <small>* 프로그램 취소 시 전액 환불됩니다.</small>
                </div>
            </div>
            
            <!-- 토스페이먼츠 결제 스크립트 -->
            <script src="https://js.tosspayments.com/v1"></script>
            <script>
                var tossPayments = TossPayments('<?= $TOSS_PAYMENTS_CLIENT_KEY ?>');
                
                var button = document.getElementById('payment-button');
                button.addEventListener('click', function() {
                    // 결제 데이터 가져오기
                    fetch('api/payments_prepare.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'registrationId=<?= $registrationId ?>'
                    })
                    .then(function(response) {
                        return response.json();
                    })
                    .then(function(data) {
                        if (data.success) {
                            // 토스페이먼츠 결제창 호출
                            tossPayments.requestPayment('카드', data.paymentData);
                        } else {
                            alert('결제 준비 중 오류가 발생했습니다: ' + data.message);
                        }
                    })
                    .catch(function(error) {
                        alert('결제 준비 중 오류가 발생했습니다.');
                        console.error(error);
                    });
                });
            </script>
        <?php else: ?>
            <div class="row">
                <!-- 등록 양식 -->
                <div class="col-lg-8">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger mb-4">
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?= $error ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <div class="registration-form">
                        <h2 class="mb-4">참가자 정보</h2>
                        
                        <form method="post">
                            <div class="mb-3">
                                <label for="child_name" class="form-label">아이 이름 <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="child_name" name="child_name" required value="<?= isset($_POST['child_name']) ? htmlspecialchars($_POST['child_name']) : '' ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="child_age" class="form-label">아이 나이 (개월) <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="child_age" name="child_age" min="<?= $program['min_age'] ?>" max="<?= $program['max_age'] ?>" required value="<?= isset($_POST['child_age']) ? htmlspecialchars($_POST['child_age']) : $program['min_age'] ?>">
                                <small class="text-muted">이 프로그램은 <?= $program['min_age'] ?>~<?= $program['max_age'] ?>개월 아이를 대상으로 합니다.</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="parent_name" class="form-label">보호자 이름 <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="parent_name" name="parent_name" required value="<?= isset($_POST['parent_name']) ? htmlspecialchars($_POST['parent_name']) : '' ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="phone" class="form-label">연락처 <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="phone" name="phone" required placeholder="010-1234-5678" value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">이메일 <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" required value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                            </div>
                            
                            <div class="mb-4">
                                <label for="notes" class="form-label">특이사항</label>
                                <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="알레르기, 기타 주의사항 등"><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?></textarea>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="terms" required>
                                <label class="form-check-label" for="terms">이용약관 및 개인정보 처리방침에 동의합니다. <span class="text-danger">*</span></label>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg px-5">신청하기</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- 프로그램 요약 정보 -->
                <div class="col-lg-4">
                    <div class="program-summary">
                        <h3><?= htmlspecialchars($program['title']) ?></h3>
                        
                        <?php if ($program['status'] === 'confirmed'): ?>
                            <span class="status-badge status-confirmed">확정된 프로그램</span>
                        <?php elseif ($program['status'] === 'pending'): ?>
                            <span class="status-badge status-pending">모집중</span>
                        <?php endif; ?>
                        
                        <div class="info-item">
                            <strong>대상 연령:</strong> <?= $program['min_age'] ?>개월 ~ <?= $program['max_age'] ?>개월
                        </div>
                        
                        <div class="info-item">
                            <strong>일시:</strong> <?= date('Y년 m월 d일 H:i', strtotime($program['date'])) ?>
                        </div>
                        
                        <div class="info-item">
                            <strong>소요 시간:</strong> <?= $program['duration'] ?>분
                        </div>
                        
                        <div class="info-item">
                            <?php if(isset($program['image_url']) && !empty($program['image_url'])): ?>
                            <strong>이미지:</strong> <?= htmlspecialchars($program['image_url']) ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="info-item">
                            <strong>참가비:</strong> <?= number_format($program['price']) ?>원
                        </div>
                        
                        <div class="mt-4 text-muted">
                            <small>* 최소 참가자 수(<?= $program['min_participants'] ?>명)가 모이지 않으면 프로그램이 취소될 수 있습니다.</small><br>
                            <small>* 프로그램 취소 시 전액 환불됩니다.</small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h3>키즈 익스플로러</h3>
                    <p>아이의 호기심과 발달을 돕는 체험 프로그램</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h4>링크</h4>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white">홈</a></li>
                        <li><a href="programs.php" class="text-white">프로그램</a></li>
                        <li><a href="about.php" class="text-white">소개</a></li>
                        <li><a href="contact.php" class="text-white">문의하기</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h4>연락처</h4>
                    <p>서울특별시 강남구 123번길 45<br>
                    전화: 02-123-4567<br>
                    이메일: info@kidsexplorer.kr</p>
                </div>
            </div>
            <hr class="mt-4 mb-4 bg-light">
            <div class="text-center">
                <p>© 2025 키즈 익스플로러. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>