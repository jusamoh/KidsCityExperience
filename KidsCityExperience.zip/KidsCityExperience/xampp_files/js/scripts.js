// 파주 체험 Camp - 자바스크립트 함수

// 문서가 로드되면 실행
document.addEventListener('DOMContentLoaded', function() {
    // 모바일 내비게이션 토글
    const navbarToggler = document.querySelector('.navbar-toggler');
    if (navbarToggler) {
        navbarToggler.addEventListener('click', function() {
            const navbarCollapse = document.querySelector('.navbar-collapse');
            navbarCollapse.classList.toggle('show');
        });
    }
    
    // 결제 모달 초기화
    initPaymentModal();
    
    // 프로그램 필터링
    initProgramFilter();
    
    // 다중 프로그램 선택
    initMultiProgramSelection();
    
    // 폼 검증
    initFormValidation();
});

// 결제 모달 초기화
function initPaymentModal() {
    const paymentMethods = document.querySelectorAll('.payment-method-card');
    if (paymentMethods.length === 0) return;
    
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            // 선택된 클래스 제거
            paymentMethods.forEach(m => m.classList.remove('selected'));
            // 현재 클릭한 방법에 선택된 클래스 추가
            this.classList.add('selected');
            
            // 결제 방식 값 설정
            const paymentMethodInput = document.getElementById('payment_method');
            if (paymentMethodInput) {
                paymentMethodInput.value = this.dataset.method;
            }
        });
    });
    
    // 결제 버튼 이벤트
    const paymentButton = document.getElementById('payment_button');
    if (paymentButton) {
        paymentButton.addEventListener('click', function(e) {
            e.preventDefault();
            processPayment();
        });
    }
    
    // 결제 에러 메시지 닫기
    const paymentErrorClose = document.querySelector('.payment-error-close');
    if (paymentErrorClose) {
        paymentErrorClose.addEventListener('click', function() {
            document.querySelector('.payment-error').style.display = 'none';
        });
    }
}

// 프로그램 필터링
function initProgramFilter() {
    const categoryButtons = document.querySelectorAll('.category-filter .btn');
    if (categoryButtons.length === 0) return;
    
    categoryButtons.forEach(button => {
        button.addEventListener('click', function() {
            const categoryId = this.dataset.category;
            const programCards = document.querySelectorAll('.program-card');
            
            if (categoryId === 'all') {
                // 모든 프로그램 표시
                programCards.forEach(card => {
                    card.closest('.col-md-4').style.display = 'block';
                });
            } else {
                // 선택된 카테고리에 맞는 프로그램만 표시
                programCards.forEach(card => {
                    if (card.dataset.category === categoryId) {
                        card.closest('.col-md-4').style.display = 'block';
                    } else {
                        card.closest('.col-md-4').style.display = 'none';
                    }
                });
            }
            
            // 활성화 버튼 스타일 변경
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // 필터링 결과 카운트 업데이트
            updateProgramCount();
        });
    });
}

// 필터링된 프로그램 수 업데이트
function updateProgramCount() {
    const visiblePrograms = document.querySelectorAll('.program-card').length;
    const programCountElement = document.getElementById('program-count');
    if (programCountElement) {
        programCountElement.textContent = visiblePrograms;
    }
}

// 다중 프로그램 선택
function initMultiProgramSelection() {
    const programCheckboxes = document.querySelectorAll('.program-checkbox');
    if (programCheckboxes.length === 0) return;
    
    programCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateSelectedPrograms();
        });
    });
}

// 선택된 프로그램 업데이트
function updateSelectedPrograms() {
    const selectedPrograms = document.querySelectorAll('.program-checkbox:checked');
    const selectedCount = document.getElementById('selected-count');
    const selectedList = document.getElementById('selected-programs');
    const totalAmount = document.getElementById('total-amount');
    
    if (!selectedCount || !selectedList || !totalAmount) return;
    
    // 선택된 프로그램 수 업데이트
    selectedCount.textContent = selectedPrograms.length;
    
    // 선택된 프로그램 목록 초기화
    selectedList.innerHTML = '';
    
    // 총 금액 계산
    let total = 0;
    
    // 선택된 프로그램 목록 생성
    selectedPrograms.forEach(program => {
        const programId = program.value;
        const programName = program.dataset.title;
        const programPrice = parseInt(program.dataset.price);
        
        // 목록에 추가
        const listItem = document.createElement('li');
        listItem.className = 'list-group-item d-flex justify-content-between align-items-center';
        listItem.innerHTML = `
            <span>${programName}</span>
            <span class="badge bg-primary rounded-pill">${formatPrice(programPrice)}</span>
        `;
        selectedList.appendChild(listItem);
        
        // 총 금액에 추가
        total += programPrice;
    });
    
    // 총 금액 업데이트
    totalAmount.textContent = formatPrice(total);
    
    // 신청 버튼 활성화/비활성화
    const registerButton = document.getElementById('register-button');
    if (registerButton) {
        registerButton.disabled = selectedPrograms.length === 0;
    }
}

// 가격 포맷팅 (1000 -> 1,000원)
function formatPrice(price) {
    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + '원';
}

// 폼 검증
function initFormValidation() {
    const registrationForm = document.getElementById('registration-form');
    if (!registrationForm) return;
    
    registrationForm.addEventListener('submit', function(e) {
        let isValid = true;
        
        // 필수 필드 검증
        const requiredFields = registrationForm.querySelectorAll('[required]');
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('is-invalid');
            } else {
                field.classList.remove('is-invalid');
            }
        });
        
        // 이메일 형식 검증
        const emailField = registrationForm.querySelector('input[type="email"]');
        if (emailField && emailField.value) {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(emailField.value)) {
                isValid = false;
                emailField.classList.add('is-invalid');
            }
        }
        
        // 전화번호 형식 검증
        const phoneField = registrationForm.querySelector('input[name="phone"]');
        if (phoneField && phoneField.value) {
            const phonePattern = /^01[0-9]-\d{3,4}-\d{4}$/;
            if (!phonePattern.test(phoneField.value)) {
                isValid = false;
                phoneField.classList.add('is-invalid');
            }
        }
        
        // 아이 나이 검증
        const ageField = registrationForm.querySelector('input[name="child_age"]');
        if (ageField && ageField.value) {
            const age = parseInt(ageField.value);
            const minAge = parseInt(ageField.dataset.minAge || 0);
            const maxAge = parseInt(ageField.dataset.maxAge || 24);
            
            if (isNaN(age) || age < minAge || age > maxAge) {
                isValid = false;
                ageField.classList.add('is-invalid');
            }
        }
        
        if (!isValid) {
            e.preventDefault();
            alert('입력 정보를 확인해주세요.');
        }
    });
}

// 결제 처리
function processPayment() {
    const paymentMethodInput = document.getElementById('payment_method');
    const registrationIdInput = document.getElementById('registration_id');
    const paymentAmountInput = document.getElementById('payment_amount');
    
    if (!paymentMethodInput || !registrationIdInput || !paymentAmountInput) {
        showPaymentError('결제 정보를 찾을 수 없습니다.');
        return;
    }
    
    const paymentMethod = paymentMethodInput.value;
    if (!paymentMethod) {
        showPaymentError('결제 방법을 선택해주세요.');
        return;
    }
    
    const registrationId = registrationIdInput.value;
    const amount = parseFloat(paymentAmountInput.value);
    
    // 페이지 이동 또는 AJAX 요청
    window.location.href = `payment_process.php?registration_id=${registrationId}&payment_method=${paymentMethod}&amount=${amount}`;
}

// 결제 에러 표시
function showPaymentError(message) {
    const errorElement = document.querySelector('.payment-error');
    const errorMessageElement = document.querySelector('.payment-error-message');
    
    if (errorElement && errorMessageElement) {
        errorMessageElement.textContent = message;
        errorElement.style.display = 'block';
    } else {
        alert(`결제 오류: ${message}`);
    }
}

// 카테고리 관리
function addCategory() {
    const categoryNameInput = document.getElementById('category_name');
    const categoryDescInput = document.getElementById('category_description');
    
    if (!categoryNameInput || !categoryDescInput) return;
    
    const categoryName = categoryNameInput.value.trim();
    const categoryDescription = categoryDescInput.value.trim();
    
    if (!categoryName) {
        alert('카테고리 이름을 입력해주세요.');
        return;
    }
    
    // AJAX 요청 대신 페이지 제출
    const form = document.getElementById('category_form');
    if (form) {
        form.submit();
    }
}

// 카테고리 삭제
function deleteCategory(categoryId) {
    if (confirm('이 카테고리를 삭제하시겠습니까? 관련된 프로그램은 유지됩니다.')) {
        window.location.href = `index.php?page=category_management&action=delete&id=${categoryId}`;
    }
}

// 프로그램 카테고리 변경
function changeProgramCategory(programId, currentCategoryId) {
    const newCategorySelect = document.getElementById(`category_select_${programId}`);
    if (!newCategorySelect) return;
    
    const newCategoryId = newCategorySelect.value;
    if (newCategoryId === currentCategoryId) {
        alert('프로그램이 이미 해당 카테고리에 속해 있습니다.');
        return;
    }
    
    window.location.href = `index.php?page=category_management&action=change_program_category&program_id=${programId}&category_id=${newCategoryId}`;
}