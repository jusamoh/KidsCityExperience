<?php
require_once 'config.php';
$currentPage = 'programs';

// 카테고리 필터
$categoryId = isset($_GET['category']) ? intval($_GET['category']) : 0;

// 카테고리 조회
$stmt = $pdo->query("SELECT * FROM categories");
$categories = $stmt->fetchAll();

// 프로그램 조회 쿼리
$query = "SELECT p.*, c.name as category_name, 
          (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id AND r.payment_status = 'paid') as current_participants 
          FROM programs p 
          JOIN categories c ON p.category_id = c.id";
          
if ($categoryId > 0) {
    $query .= " WHERE p.category_id = :categoryId";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':categoryId', $categoryId, PDO::PARAM_INT);
    $stmt->execute();
} else {
    $stmt = $pdo->query($query);
}

$programs = $stmt->fetchAll();

// 현재 프로그램 상태에 따라 분류
$pendingPrograms = array_filter($programs, function($program) { return $program['status'] === 'pending'; });
$confirmedPrograms = array_filter($programs, function($program) { return $program['status'] === 'confirmed'; });
$canceledPrograms = array_filter($programs, function($program) { return $program['status'] === 'canceled'; });
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>프로그램 - 키즈 익스플로러</title>
    <meta name="description" content="2세 이하 영유아를 위한 다양한 체험 프로그램을 확인하세요. 도시텃밭 체험, 영어놀이 체험, 스포츠 및 놀이 체험을 통해 아이의 발달을 도와줍니다.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            color: #333;
            background-color: #f9f9f9;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
        }
        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
            color: #f05a7a;
        }
        .nav-link {
            font-weight: 600;
            color: #333;
            margin: 0 10px;
        }
        .nav-link:hover {
            color: #f05a7a;
        }
        .programs-header {
            background: linear-gradient(to right, #4ecdc4, #f05a7a);
            color: white;
            padding: 50px 0;
            margin-bottom: 30px;
        }
        .category-filter {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .program-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            transition: transform 0.3s ease;
        }
        .program-card:hover {
            transform: translateY(-5px);
        }
        .program-image {
            height: 200px;
            background-size: cover;
            background-position: center;
        }
        .program-body {
            padding: 20px;
        }
        .status-badge {
            border-radius: 20px;
            padding: 5px 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-confirmed {
            background-color: #d4f7e8;
            color: #16a868;
        }
        .status-pending {
            background-color: #fff1d0;
            color: #ffa600;
        }
        .status-canceled {
            background-color: #ffe0e0;
            color: #ff4a4a;
        }
        .btn-primary {
            background-color: #f05a7a;
            border-color: #f05a7a;
        }
        .btn-primary:hover {
            background-color: #d84a68;
            border-color: #d84a68;
        }
        .btn-outline-primary {
            color: #f05a7a;
            border-color: #f05a7a;
        }
        .btn-outline-primary:hover {
            background-color: #f05a7a;
            color: white;
        }
        .progress-container {
            width: 100%;
            background-color: #e0e0e0;
            border-radius: 10px;
            margin: 10px 0;
        }
        .progress-bar {
            height: 10px;
            border-radius: 10px;
            background: linear-gradient(to right, #4ecdc4, #f05a7a);
        }
        .section-title {
            position: relative;
            display: inline-block;
            margin-bottom: 30px;
        }
        .section-title:after {
            content: '';
            position: absolute;
            width: 50%;
            height: 4px;
            left: 25%;
            bottom: -10px;
            background: linear-gradient(to right, #4ecdc4, #f05a7a);
            border-radius: 2px;
        }
        .footer {
            background-color: #333;
            color: #f9f9f9;
            padding: 50px 0;
            margin-top: 50px;
        }
        .category-pills .btn {
            margin-right: 5px;
            margin-bottom: 10px;
            border-radius: 30px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">키즈 익스플로러</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">홈</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="programs.php">프로그램</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">소개</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">로그인</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="programs-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-5 fw-bold">프로그램</h1>
                    <p class="lead">영유아의 발달을 돕는 다양한 체험 프로그램을 만나보세요</p>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- 카테고리 필터 -->
        <div class="category-filter">
            <h4 class="mb-3">카테고리</h4>
            <div class="category-pills">
                <a href="programs.php" class="btn <?= $categoryId === 0 ? 'btn-primary' : 'btn-outline-primary' ?>">전체</a>
                
                <?php foreach ($categories as $category): ?>
                    <a href="programs.php?category=<?= $category['id'] ?>" class="btn <?= $categoryId === $category['id'] ? 'btn-primary' : 'btn-outline-primary' ?>">
                        <?= htmlspecialchars($category['name']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- 확정된 프로그램 -->
        <?php if (count($confirmedPrograms) > 0): ?>
        <section class="mt-5">
            <h2 class="section-title text-center">확정된 프로그램</h2>
            <div class="row">
                <?php foreach ($confirmedPrograms as $program): ?>
                <div class="col-md-4 mb-4">
                    <div class="program-card">
                        <div class="program-image" style="background-image: url('<?= htmlspecialchars($program['image_url']) ?>');"></div>
                        <div class="program-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="status-badge status-confirmed">확정</span>
                                <small><?= date('Y년 m월 d일', strtotime($program['date'])) ?></small>
                            </div>
                            <h4><?= htmlspecialchars($program['title']) ?></h4>
                            <p class="mb-2"><?= substr(htmlspecialchars($program['description']), 0, 100) ?>...</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-bold"><?= number_format($program['price']) ?>원</span>
                                <a href="program_detail.php?id=<?= $program['id'] ?>" class="btn btn-sm btn-primary">상세보기</a>
                            </div>
                            <div class="mt-3">
                                <small>현재 <?= $program['current_participants'] ?>/<?= $program['max_participants'] ?> 참가자</small>
                                <div class="progress-container">
                                    <div class="progress-bar" style="width: <?= ($program['current_participants'] / $program['max_participants']) * 100 ?>%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>
        
        <!-- 모집중인 프로그램 -->
        <?php if (count($pendingPrograms) > 0): ?>
        <section class="mt-5">
            <h2 class="section-title text-center">신청 모집 중인 프로그램</h2>
            <div class="row">
                <?php foreach ($pendingPrograms as $program): ?>
                <div class="col-md-4 mb-4">
                    <div class="program-card">
                        <div class="program-image" style="background-image: url('<?= htmlspecialchars($program['image_url']) ?>');"></div>
                        <div class="program-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="status-badge status-pending">모집중</span>
                                <small><?= date('Y년 m월 d일', strtotime($program['date'])) ?></small>
                            </div>
                            <h4><?= htmlspecialchars($program['title']) ?></h4>
                            <p class="mb-2"><?= substr(htmlspecialchars($program['description']), 0, 100) ?>...</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-bold"><?= number_format($program['price']) ?>원</span>
                                <a href="program_detail.php?id=<?= $program['id'] ?>" class="btn btn-sm btn-primary">상세보기</a>
                            </div>
                            <div class="mt-3">
                                <small><?= $program['current_participants'] ?>/<?= $program['min_participants'] ?> 최소 참가자 필요</small>
                                <div class="progress-container">
                                    <div class="progress-bar" style="width: <?= ($program['current_participants'] / $program['min_participants']) * 100 ?>%"></div>
                                </div>
                                <small class="text-muted">* 최소 인원 미달 시 취소될 수 있습니다.</small>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>
        
        <!-- 취소된 프로그램 -->
        <?php if (count($canceledPrograms) > 0): ?>
        <section class="mt-5">
            <h2 class="section-title text-center">취소된 프로그램</h2>
            <div class="row">
                <?php foreach ($canceledPrograms as $program): ?>
                <div class="col-md-4 mb-4">
                    <div class="program-card">
                        <div class="program-image" style="background-image: url('<?= htmlspecialchars($program['image_url']) ?>');"></div>
                        <div class="program-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="status-badge status-canceled">취소됨</span>
                                <small><?= date('Y년 m월 d일', strtotime($program['date'])) ?></small>
                            </div>
                            <h4><?= htmlspecialchars($program['title']) ?></h4>
                            <p class="mb-2"><?= substr(htmlspecialchars($program['description']), 0, 100) ?>...</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-bold"><?= number_format($program['price']) ?>원</span>
                                <a href="program_detail.php?id=<?= $program['id'] ?>" class="btn btn-sm btn-secondary">상세보기</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>
        
        <?php if (count($programs) === 0): ?>
        <div class="alert alert-info mt-4">
            <p class="mb-0 text-center">선택한 카테고리에 프로그램이 없습니다.</p>
        </div>
        <?php endif; ?>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h3>키즈 익스플로러</h3>
                    <p>아이의 호기심과 발달을 돕는 체험 프로그램</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h4>링크</h4>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white">홈</a></li>
                        <li><a href="programs.php" class="text-white">프로그램</a></li>
                        <li><a href="about.php" class="text-white">소개</a></li>
                        <li><a href="contact.php" class="text-white">문의하기</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h4>연락처</h4>
                    <p>서울특별시 강남구 123번길 45<br>
                    전화: 02-123-4567<br>
                    이메일: info@kidsexplorer.kr</p>
                </div>
            </div>
            <hr class="mt-4 mb-4 bg-light">
            <div class="text-center">
                <p>© 2025 키즈 익스플로러. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>