-- 자녀 정보 테이블 생성
CREATE TABLE IF NOT EXISTS children (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    age INT NOT NULL,
    gender ENUM('남', '여') NOT NULL,
    birth_date DATE,
    notes TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id)
);

-- 샘플 자녀 데이터 추가
INSERT INTO children (user_id, name, age, gender, birth_date) VALUES 
(2, '김하늘', 2, '여', '2021-05-10'),
(2, '김별', 2, '남', '2021-02-15'),
(2, '김땅', 1, '남', '2022-08-22'),
(3, '이별', 1, '여', '2022-03-05'),
(3, '이하늘', 2, '여', '2021-01-30'),
(3, '이땅', 1, '남', '2022-07-18'),
(4, '박별', 2, '남', '2021-04-12'),
(4, '박하늘', 1, '여', '2022-06-25'),
(4, '박땅', 1, '여', '2022-11-03');