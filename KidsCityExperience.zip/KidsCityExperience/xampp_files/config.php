<?php
// Database configuration
$host = 'localhost';
$dbname = 'paju_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("DB 연결 실패: " . $e->getMessage());
}

// Toss Payments API 설정
$TOSS_PAYMENTS_API_URL = 'https://api.tosspayments.com/v1';
$TOSS_PAYMENTS_SECRET_KEY = 'test_sk_D4yKeq5bgrpKRd0JYbLVGX0lzW6Y'; // 테스트 키, 실제 운영 시 변경 필요
$TOSS_PAYMENTS_CLIENT_KEY = 'test_ck_D4yKeq5bgrp0Rn56PBXr37nO5Wml'; // 테스트 키, 실제 운영 시 변경 필요

// 사이트 설정
$SITE_URL = 'http://localhost/kid_explorer';
?>