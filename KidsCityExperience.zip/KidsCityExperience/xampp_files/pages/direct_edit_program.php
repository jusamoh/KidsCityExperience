<?php
// direct_edit_program.php - 프로그램 직접 수정 페이지

// 관리자 권한 확인
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    redirect($base_url . '/index.php?page=login');
    exit;
}

$program_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($program_id <= 0) {
    set_message('유효하지 않은 프로그램 ID입니다.', 'danger');
    redirect($base_url . '/index.php?page=edit_programs');
    exit;
}

// 데이터베이스 연결
$conn = get_db_connection();

// 프로그램 정보 가져오기
$sql = "SELECT * FROM programs WHERE id = {$program_id}";
$result = $conn->query($sql);

if (!($result && $result->num_rows > 0)) {
    set_message('프로그램을 찾을 수 없습니다.', 'danger');
    $conn->close();
    redirect($base_url . '/index.php?page=edit_programs');
    exit;
}

$program = $result->fetch_assoc();

// 카테고리 목록 가져오기
$categories = [];
$sql = "SELECT id, name FROM categories ORDER BY name";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

// POST 요청 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_program') {
    // 폼 데이터 가져오기
    $title = isset($_POST['title']) ? $_POST['title'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $price = isset($_POST['price']) ? intval($_POST['price']) : 0;
    $max_participants = isset($_POST['max_participants']) ? intval($_POST['max_participants']) : 0;
    $min_participants = isset($_POST['min_participants']) ? intval($_POST['min_participants']) : 0;
    $min_age = isset($_POST['min_age']) ? intval($_POST['min_age']) : 0;
    $max_age = isset($_POST['max_age']) ? intval($_POST['max_age']) : 0;
    
    // 기본 검증
    if (empty($title) || empty($description) || $category_id <= 0 || empty($status) || empty($date) || $price < 0) {
        set_message('모든 필수 필드를 채워주세요.', 'danger');
    } else {
        // 데이터 이스케이프 처리
        $title = $conn->real_escape_string($title);
        $description = $conn->real_escape_string($description);
        $status = $conn->real_escape_string($status);
        
        // 날짜 형식 변환 (YYYY-MM-DD HH:MM:SS)
        try {
            $date_obj = new DateTime($date);
            $date = $date_obj->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            set_message('날짜 형식이 올바르지 않습니다.', 'danger');
            $conn->close();
            redirect($base_url . '/index.php?page=direct_edit_program&id=' . $program_id);
            exit;
        }
        
        $date = $conn->real_escape_string($date);
        
        // 이미지 업로드 처리
        $image_updated = false;
        $image_path = $program['image_path']; // 기본값으로 기존 이미지 경로 사용
        
        if (isset($_FILES['program_image']) && $_FILES['program_image']['error'] != UPLOAD_ERR_NO_FILE) {
            // 이미지가 선택된 경우
            if ($_FILES['program_image']['error'] == UPLOAD_ERR_OK) {
                $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                $file_type = $_FILES['program_image']['type'];
                
                if (in_array($file_type, $allowed_types)) {
                    // 절대 경로로 디렉토리 설정
                    $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/paju/uploads/programs/';
                    
                    // 디렉토리가 없으면 생성 (상대 경로로 접근 가능하도록)
                    if (!file_exists('uploads/programs/')) {
                        mkdir('uploads/programs/', 0777, true);
                    }
                    
                    $file_name = basename($_FILES['program_image']['name']);
                    $file_name = preg_replace('/[^a-zA-Z0-9가-힣._-]/', '', $file_name);
                    $file_name = time() . '_' . $file_name;
                    $file_path = $upload_dir . $file_name;
                    
                    // 파일 업로드
                    if (move_uploaded_file($_FILES['program_image']['tmp_name'], $file_path)) {
                        // 업로드 성공, 저장할 경로 설정 (상대 경로로 저장)
                        $image_path = 'uploads/programs/' . $file_name;
                        $image_updated = true;
                        error_log("이미지 업로드 성공: $image_path");
                    } else {
                        $error_message = '파일 업로드 실패: ' . error_get_last()['message'];
                        error_log($error_message);
                        set_message($error_message, 'warning');
                    }
                } else {
                    set_message('허용되지 않는 파일 형식입니다. JPG, JPEG, PNG, GIF 파일만 업로드 가능합니다.', 'warning');
                }
            } else {
                $error_code = $_FILES['program_image']['error'];
                $error_message = '파일 업로드 오류 (코드: ' . $error_code . ')';
                error_log($error_message);
                set_message($error_message, 'warning');
            }
        }

        // *** 새로운 SQL 쿼리 구성 - 필드 이름과 값 명시적으로 설정 ***
        $image_path_sql = '';
        if ($image_updated || !empty($image_path)) {
            $image_path_escaped = $conn->real_escape_string($image_path);
            $image_path_sql = ", image_path = '{$image_path_escaped}'";
        }
        
        // 명시적인 업데이트 쿼리 작성
        $sql = "UPDATE programs SET 
                title = '{$title}',
                description = '{$description}',
                category_id = {$category_id},
                status = '{$status}',
                date = '{$date}',
                price = {$price},
                max_participants = {$max_participants},
                min_participants = {$min_participants},
                min_age = {$min_age},
                max_age = {$max_age}
                {$image_path_sql}
                WHERE id = {$program_id}";
        
        // 디버깅
        error_log("SQL 쿼리: " . $sql);
        
        // 쿼리 실행
        if ($conn->query($sql)) {
            set_message('프로그램이 성공적으로 업데이트되었습니다.', 'success');
            
            // 카테고리 변경 기록 (외부 DB용)
            try {
                if (function_exists('saveCategoryChange')) {
                    saveCategoryChange($program_id, $category_id);
                }
            } catch (Exception $e) {
                error_log('카테고리 변경 기록 실패: ' . $e->getMessage());
                set_message('외부 데이터베이스 업데이트 중 오류가 발생했습니다.', 'warning');
            }
            
            // 데이터베이스 연결 닫기
            $conn->close();
            
            // 수정 후 새로고침된 목록 페이지로 이동 (캐싱 문제 방지)
            redirect($base_url . '/index.php?page=edit_programs&updated=true&time=' . time());
            exit;
        } else {
            error_log("SQL 오류: " . $conn->error);
            set_message('프로그램 업데이트 중 오류가 발생했습니다: ' . $conn->error, 'danger');
        }
    }
}

$conn->close();
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">프로그램 직접 수정</h1>
        <div>
            <a href="<?php echo $base_url; ?>/index.php?page=edit_programs" class="btn btn-outline-secondary me-2">
                <i class="fas fa-list me-2"></i> 프로그램 목록
            </a>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">프로그램 정보 수정 - <?php echo htmlspecialchars($program['title']); ?></h5>
        </div>
        <div class="card-body">
            <form action="<?php echo $base_url; ?>/index.php?page=direct_edit_program&id=<?php echo $program_id; ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_program">
                <input type="hidden" name="program_id" value="<?php echo $program_id; ?>">
                
                <div class="mb-4">
                    <h6 class="fw-bold">프로그램 기본 정보</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="title" class="form-label">프로그램 제목 <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($program['title']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="category_id" class="form-label">카테고리 <span class="text-danger">*</span></label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">카테고리 선택</option>
                                <?php foreach($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" <?php echo $program['category_id'] == $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label for="description" class="form-label">프로그램 설명 <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="description" name="description" rows="5" required><?php echo htmlspecialchars($program['description']); ?></textarea>
                </div>
                
                <div class="mb-4">
                    <h6 class="fw-bold">일정 및 참가자 정보</h6>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="date" class="form-label">날짜 및 시간 <span class="text-danger">*</span></label>
                            <input type="datetime-local" class="form-control" id="date" name="date" value="<?php echo date('Y-m-d\TH:i', strtotime($program['date'])); ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label for="status" class="form-label">상태 <span class="text-danger">*</span></label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="active" <?php echo $program['status'] == 'active' ? 'selected' : ''; ?>>모집중</option>
                                <option value="pending" <?php echo $program['status'] == 'pending' ? 'selected' : ''; ?>>준비중</option>
                                <option value="completed" <?php echo $program['status'] == 'completed' ? 'selected' : ''; ?>>종료됨</option>
                                <option value="canceled" <?php echo $program['status'] == 'canceled' ? 'selected' : ''; ?>>취소됨</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="price" class="form-label">가격 <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="number" class="form-control" id="price" name="price" value="<?php echo $program['price']; ?>" min="0" required>
                                <span class="input-group-text">원</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="max_participants" class="form-label">최대 정원 <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="max_participants" name="max_participants" value="<?php echo $program['max_participants']; ?>" min="1" required>
                        </div>
                        <div class="col-md-6">
                            <label for="min_participants" class="form-label">최소 인원 <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="min_participants" name="min_participants" value="<?php echo $program['min_participants']; ?>" min="1" required>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="min_age" class="form-label">최소 연령(세) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="min_age" name="min_age" min="0" value="<?php echo isset($program['min_age']) ? intval($program['min_age']) : 0; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="max_age" class="form-label">최대 연령(세) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="max_age" name="max_age" min="0" value="<?php echo isset($program['max_age']) ? intval($program['max_age']) : 0; ?>" required>
                        </div>
                        <div class="col-md-12">
                            <div class="form-text">아이의 나이를 세(歲)로 입력해주세요. (예: 1세, 2세)</div>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <h6 class="fw-bold">프로그램 이미지</h6>
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label for="program_image" class="form-label">이미지 파일</label>
                            <input type="file" class="form-control" id="program_image" name="program_image" accept="image/*">
                            <div class="form-text">JPG, JPEG, PNG, GIF 파일만 업로드 가능합니다. 파일을 선택하지 않으면 기존 이미지가 유지됩니다.</div>
                        </div>
                        <div class="col-md-4">
                            <?php if (!empty($program['image_path'])): ?>
                            <div class="text-center">
                                <label class="form-label">현재 이미지</label>
                                <div class="border p-2">
                                    <img src="<?php echo $base_url . '/' . $program['image_path']; ?>" alt="현재 프로그램 이미지" class="img-thumbnail" style="max-height: 100px;">
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="text-center">
                                <label class="form-label">현재 이미지</label>
                                <div class="border p-2 text-muted">
                                    <p class="mb-0">이미지 없음</p>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="<?php echo $base_url; ?>/index.php?page=edit_programs" class="btn btn-outline-secondary">취소</a>
                    <button type="submit" class="btn btn-primary">저장</button>
                </div>
            </form>
        </div>
    </div>
</div>