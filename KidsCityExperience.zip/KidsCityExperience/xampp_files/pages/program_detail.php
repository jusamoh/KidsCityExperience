<?php
// program_detail.php - 프로그램 상세 정보 페이지

// 프로그램 ID 가져오기
$program_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 프로그램 정보 가져오기
$program = get_program($program_id);

// 프로그램이 없으면 404 페이지로 이동
if (!$program) {
    include 'pages/not_found.php';
    exit;
}

// 현재 카테고리 정보 가져오기
$category = get_category($program['category_id']);

// 프로그램 상태 결정
$status_class = '';
$status_text = '';
$is_available = false;

if ($program['current_participants'] >= $program['max_participants']) {
    $status_class = 'bg-danger';
    $status_text = '마감';
} elseif ($program['status'] === 'active') {
    $status_class = 'bg-success';
    $status_text = '모집중';
    $is_available = true;
} else {
    $status_class = 'bg-warning';
    $status_text = '준비중';
}
?>

<div class="container">
    <!-- 뒤로 가기 버튼 -->
    <div class="mb-3">
        <a href="index.php?page=program_selection" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i> 프로그램 목록으로
        </a>
    </div>
    
    <div class="row">
        <div class="col-md-8">
            <!-- 프로그램 상세 정보 카드 -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h1 class="h3 mb-0"><?php echo $program['title']; ?></h1>
                        <span class="badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                    </div>
                </div>
                
                <div class="card-body">
                    <!-- 프로그램 이미지 -->
                    <img src="<?php echo $base_url; ?>/<?php echo !empty($program['image_path']) ? $program['image_path'] : 'assets/img/program-default.jpg'; ?>" class="img-fluid rounded mb-4" alt="<?php echo $program['title']; ?>" onerror="this.src='<?php echo $base_url; ?>/assets/img/program-default.jpg'">
                    
                    <!-- 카테고리 -->
                    <?php if ($category): ?>
                        <div class="mb-3">
                            <span class="badge bg-primary"><?php echo $category['name']; ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <!-- 중요 안내 -->
                    <div class="alert alert-info mb-4">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>프로그램 개설에 필요한 최소 참석인원: <?php echo $program['min_participants']; ?>명</strong>
                        <br><small>최소 인원이 모집되어야 프로그램이 확정됩니다.</small>
                    </div>
                    
                    <!-- 프로그램 설명 -->
                    <h5 class="mb-3">프로그램 소개</h5>
                    <p><?php echo nl2br($program['description']); ?></p>
                    
                    <!-- 상세 정보 -->
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <h5 class="mb-3">일정 및 장소</h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex">
                                    <div class="me-3"><i class="far fa-calendar-alt text-primary"></i></div>
                                    <div>
                                        <strong>날짜 및 시간</strong><br>
                                        <?php echo format_date($program['date']); ?>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex">
                                    <div class="me-3"><i class="fas fa-clock text-primary"></i></div>
                                    <div>
                                        <strong>소요 시간</strong><br>
                                        <?php echo $program['duration']; ?>분
                                    </div>
                                </li>

                            </ul>
                        </div>
                        
                        <div class="col-md-6">
                            <h5 class="mb-3">참가 정보</h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex">
                                    <div class="me-3"><i class="fas fa-child text-primary"></i></div>
                                    <div>
                                        <strong>참가 연령</strong><br>
                                        <?php echo $program['min_age']; ?>~<?php echo $program['max_age']; ?>세
                                    </div>
                                </li>
                                <li class="list-group-item d-flex">
                                    <div class="me-3"><i class="fas fa-users text-primary"></i></div>
                                    <div>
                                        <strong>참가 인원</strong><br>
                                        <?php echo $program['current_participants']; ?>/<?php echo $program['max_participants']; ?>명
                                        (최소 <?php echo $program['min_participants']; ?>명)
                                    </div>
                                </li>
                                <li class="list-group-item d-flex">
                                    <div class="me-3"><i class="fas fa-tag text-primary"></i></div>
                                    <div>
                                        <strong>참가비</strong><br>
                                        <span class="fw-bold text-primary"><?php echo format_price($program['price']); ?></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                    <?php if ($is_available): ?>
                        <div class="mt-4">
                            <h5 class="mb-3">신청 현황</h5>
                            <div class="progress mb-2" style="height: 20px;">
                                <?php
                                $percentage = ($program['current_participants'] / $program['max_participants']) * 100;
                                ?>
                                <div class="progress-bar" role="progressbar" style="width: <?php echo $percentage; ?>%;" 
                                    aria-valuenow="<?php echo $program['current_participants']; ?>" 
                                    aria-valuemin="0" 
                                    aria-valuemax="<?php echo $program['max_participants']; ?>">
                                    <?php echo $program['current_participants']; ?>/<?php echo $program['max_participants']; ?>
                                </div>
                            </div>
                            <small class="text-muted">
                                <?php 
                                $remaining = $program['max_participants'] - $program['current_participants'];
                                echo "남은 인원: {$remaining}명";
                                ?>
                            </small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- 프로그램 신청 안내 -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0">신청 안내</h5>
                </div>
                <div class="card-body">
                    <ul class="mb-0">
                        <li>프로그램은 <strong>최소 인원(<?php echo $program['min_participants']; ?>명)이 모집되어야 확정</strong>됩니다.</li>
                        <li>신청 후 <strong>결제가 완료</strong>되어야 최종 접수됩니다.</li>
                        <li>취소 및 환불은 프로그램 시작 3일 전까지 가능합니다.</li>
                        <li>자세한 환불 규정은 <a href="index.php?page=refund_policy">환불 정책</a> 페이지를 참고해주세요.</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- 신청 버튼 카드 -->
            <div class="card shadow-sm mb-4 position-sticky" style="top: 20px;">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0">프로그램 신청</h5>
                </div>
                <div class="card-body text-center">
                    <h4 class="mb-4"><?php echo format_price($program['price']); ?></h4>
                    
                    <?php if ($is_available): ?>
                        <a href="index.php?page=registration&program_id=<?php echo $program['id']; ?>" class="btn btn-primary btn-lg d-block mb-3">
                            <i class="fas fa-edit me-2"></i> 지금 신청하기
                        </a>
                        <small class="text-muted">신청 후 3일 이내 결제 필요</small>
                    <?php else: ?>
                        <button class="btn btn-secondary btn-lg d-block mb-3" disabled>
                            <i class="fas fa-ban me-2"></i> 신청 불가
                        </button>
                        <?php if ($program['current_participants'] >= $program['max_participants']): ?>
                            <small class="text-danger">모집이 마감되었습니다.</small>
                        <?php else: ?>
                            <small class="text-warning">현재 준비 중인 프로그램입니다.</small>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <div class="card-footer bg-white">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-info-circle text-primary me-2"></i>
                        <small>궁금한 점은 <a href="index.php?page=faq">자주 묻는 질문</a>을 확인해보세요.</small>
                    </div>
                </div>
            </div>
            
            <!-- 다른 프로그램 추천 -->
            <?php
            // 같은 카테고리의 다른 프로그램 가져오기
            $related_programs = get_programs($program['category_id']);
            
            // 현재 프로그램 제외하고 최대 3개만 표시
            $related_programs = array_filter($related_programs, function($p) use ($program_id) {
                return $p['id'] != $program_id;
            });
            
            $related_programs = array_slice($related_programs, 0, 3);
            
            if (!empty($related_programs)):
            ?>
            <div class="card shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0">다른 프로그램</h5>
                </div>
                <div class="card-body p-3">
                    <?php foreach($related_programs as $related): ?>
                        <div class="card mb-2">
                            <div class="row g-0">
                                <div class="col-4">
                                    <img src="assets/img/program-<?php echo $related['id']; ?>.jpg" 
                                         class="img-fluid rounded-start" 
                                         alt="<?php echo $related['title']; ?>"
                                         style="height: 100%; object-fit: cover;"
                                         onerror="this.src='assets/img/program-default.jpg'">
                                </div>
                                <div class="col-8">
                                    <div class="card-body p-2">
                                        <h6 class="card-title mb-1"><?php echo $related['title']; ?></h6>
                                        <p class="card-text small mb-1"><?php echo format_price($related['price']); ?></p>
                                        <a href="index.php?page=program_detail&id=<?php echo $related['id']; ?>" class="btn btn-sm btn-outline-primary">자세히</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>