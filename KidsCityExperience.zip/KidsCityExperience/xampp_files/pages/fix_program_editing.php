<?php
// 프로그램 수정 기능 디버깅 및 수정을 위한 코드
// XAMPP 환경에서 테이블 구조 확인

$conn = get_db_connection();

// 프로그램 테이블 구조 확인
$sql = "DESCRIBE programs";
$result = $conn->query($sql);

echo "<h2>프로그램 테이블 구조</h2>";
if ($result && $result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>필드</th><th>타입</th><th>Null</th><th>키</th><th>기본값</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['Field']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Null']}</td>";
        echo "<td>{$row['Key']}</td>";
        echo "<td>{$row['Default']}</td>";
        echo "<td>{$row['Extra']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "테이블 구조를 가져올 수 없습니다.";
}

// 샘플 프로그램 데이터 확인
$sql = "SELECT * FROM programs LIMIT 1";
$result = $conn->query($sql);

echo "<h2>샘플 프로그램 데이터</h2>";
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<pre>";
    print_r($row);
    echo "</pre>";
} else {
    echo "프로그램 데이터가 없습니다.";
}

$conn->close();
?>