<?php
// payment_popup.php - 토스페이먼츠 팝업 결제 페이지 (Replit 스타일)

// base_url 확인 (index.php에서 설정되어야 함)
if (!isset($base_url)) {
    // 기본값으로 현재 스크립트 URL에서 추출 (파일명 제외)
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $base_url = $protocol . $_SERVER['HTTP_HOST'];
    
    // 로컬호스트인 경우 경로 추가 (XAMPP 환경)
    if (strpos($_SERVER['HTTP_HOST'], 'localhost') !== false || strpos($_SERVER['HTTP_HOST'], '127.0.0.1') !== false) {
        // 현재 스크립트의 경로에서 파일명과 마지막 디렉토리 제거
        $path = dirname(dirname($_SERVER['PHP_SELF']));
        if ($path != '/' && $path != '\\') {
            $base_url .= $path;
        }
    }
}

// 결제 정보 초기화
$payment_info = null;

// 1. program_ids로 일괄 결제 정보 조회 (여러 프로그램 일괄 결제)
if (isset($_GET['program_ids']) && !empty($_GET['program_ids'])) {
    $program_ids = explode(',', $_GET['program_ids']);
    $total_amount = 0;
    $program_titles = [];
    $registration_ids = [];
    $customer_name = '';
    $customer_email = '';
    $customer_phone = '';
    
    // 현재 로그인한 사용자 정보 가져오기
    $user_id = $_SESSION['user_id'];
    $user = get_user($user_id);
    $user_email = isset($user['email']) ? $user['email'] : '';
    
    // 사용자의 미결제 등록 정보 가져오기
    $registrations = get_user_registrations($user_email);
    $valid_registrations = [];
    
    foreach ($registrations as $registration) {
        // 미결제 상태이고 선택된 프로그램에 해당하는 등록 정보만 처리
        if (isset($registration['payment_status']) && 
            $registration['payment_status'] == 'pending' && 
            in_array($registration['program_id'], $program_ids)) {
            
            $program = get_program($registration['program_id']);
            if ($program) {
                $total_amount += $program['price'];
                $program_titles[] = $program['title'] . ' - ' . $registration['child_name'];
                $registration_ids[] = $registration['id'];
                
                // 고객 정보는 첫 번째 유효한 등록 정보에서 가져옴
                if (empty($customer_name) && isset($registration['parent_name'])) {
                    $customer_name = $registration['parent_name'];
                    $customer_email = $registration['email'];
                    $customer_phone = $registration['phone'];
                }
                
                $valid_registrations[] = [
                    'registration_id' => $registration['id'],
                    'program_id' => $program['id'],
                    'title' => $program['title'],
                    'child_name' => $registration['child_name'],
                    'price' => $program['price']
                ];
            }
        }
    }
    
    if (!empty($valid_registrations)) {
        // 결제 정보 생성
        $batch_order_id = 'BATCH_' . time() . '_' . implode('_', $registration_ids);
        $payment_info = [
            'is_batch' => true,
            'registration_ids' => $registration_ids,
            'program_ids' => $program_ids,
            'registrations' => $valid_registrations,
            'order_name' => count($program_titles) > 1 
                ? $program_titles[0] . ' 외 ' . (count($program_titles) - 1) . '건'
                : $program_titles[0],
            'amount' => $total_amount,
            'order_id' => $batch_order_id,
            'customer_name' => $customer_name,
            'customer_email' => $customer_email,
            'customer_phone' => $customer_phone
        ];
        
        // 세션에 결제 정보 저장
        $_SESSION['payment_info'] = $payment_info;
        
        // 일괄 결제 정보를 DB에 미리 저장 (registration_ids를 콤마로 구분하여 저장)
        $conn = get_db_connection();
        $registration_ids_str = implode(',', $registration_ids);
        
        // 테이블 구조 확인을 위해 컬럼 목록 조회
        $columns_sql = "SHOW COLUMNS FROM `payments`";
        $columns_result = $conn->query($columns_sql);
        $columns = [];
        
        if ($columns_result) {
            while ($column = $columns_result->fetch_assoc()) {
                $columns[] = $column['Field'];
            }
        }
        
        // 기본 필수 필드
        $sql_fields = ["order_id", "registration_id", "amount", "status"];
        $sql_values = ["?", "?", "?", "?"];
        $bind_types = "siis"; // string, integer, integer, string
        $bind_values = [$batch_order_id, $registration_ids[0], $total_amount, 'pending'];
        
        // 선택적 필드 추가 (테이블 구조에 있는 경우에만)
        if (in_array("customer_name", $columns)) {
            $sql_fields[] = "customer_name";
            $sql_values[] = "?";
            $bind_types .= "s";
            $bind_values[] = $customer_name;
        }
        
        if (in_array("customer_email", $columns)) {
            $sql_fields[] = "customer_email";
            $sql_values[] = "?";
            $bind_types .= "s";
            $bind_values[] = $customer_email;
        }
        
        if (in_array("customer_phone", $columns)) {
            $sql_fields[] = "customer_phone";
            $sql_values[] = "?";
            $bind_types .= "s";
            $bind_values[] = $customer_phone;
        }
        
        if (in_array("registration_ids", $columns)) {
            $sql_fields[] = "registration_ids";
            $sql_values[] = "?";
            $bind_types .= "s";
            $bind_values[] = $registration_ids_str;
        }
        
        // created_at 필드는 테이블에 있는 경우에만 추가
        if (in_array("created_at", $columns)) {
            $sql_fields[] = "created_at";
            $sql_values[] = "NOW()";
        }
        
        // SQL 쿼리 조합
        $sql = "INSERT INTO payments (" . implode(", ", $sql_fields) . ") VALUES (" . implode(", ", $sql_values) . ")";
        
        // 동적 바인딩을 위한 준비
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            // 동적 바인딩 (created_at은 NOW()로 처리했으므로 바인딩에서 제외)
            if (!empty($bind_values)) {
                $bind_params = array($bind_types);
                foreach ($bind_values as $key => $value) {
                    $bind_params[] = &$bind_values[$key];
                }
                call_user_func_array(array($stmt, 'bind_param'), $bind_params);
            }
            
            $stmt->execute();
        }
        
        $conn->close();
    }
}
// 2. registration_id로 단일 결제 정보 조회
else if (isset($_GET['registration_id'])) {
    $registration_id = $_GET['registration_id'];
    $registration = get_registration($registration_id);
    
    if ($registration) {
        $program = get_program($registration['program_id']);
        if ($program) {
            // 결제 정보 생성
            $payment_info = [
                'is_batch' => false,
                'registration_id' => $registration['id'],
                'program_id' => $program['id'],
                'order_name' => $program['title'] . ' 신청 - ' . $registration['child_name'],
                'amount' => $program['price'],
                'order_id' => 'ORDER_' . time() . '_' . $registration['id'],
                'customer_name' => $registration['parent_name'],
                'customer_email' => $registration['email'],
                'customer_phone' => $registration['phone']
            ];
            
            // 세션에 결제 정보 저장
            $_SESSION['payment_info'] = $payment_info;
        }
    }
}
// 3. 세션에 이미 저장된 결제 정보 사용
else if (isset($_SESSION['payment_info'])) {
    $payment_info = $_SESSION['payment_info'];
}

// 결제 정보가 없으면 프로그램 선택 페이지로 이동
if (!$payment_info) {
    redirect('index.php?page=program_selection');
}
?>

<div class="modal-like-container">
    <div class="modal-like-dialog">
        <div class="modal-like-content">
            <div class="modal-like-header">
                <h5 class="modal-like-title">프로그램 신청 결제</h5>
                <button type="button" class="btn-close" onclick="window.location.href='index.php?page=my_page'"></button>
            </div>
            <div class="modal-like-body">
                <div class="payment-tabs">
                    <ul class="nav nav-pills payment-tab-nav" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="real-payment-tab" data-bs-toggle="tab" data-bs-target="#real-payment" type="button" role="tab" aria-controls="real-payment" aria-selected="true">실제 결제</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="test-payment-tab" data-bs-toggle="tab" data-bs-target="#test-payment" type="button" role="tab" aria-controls="test-payment" aria-selected="false">테스트 결제</button>
                        </li>
                    </ul>
                    <div class="tab-content payment-tab-content">
                        <div class="tab-pane fade show active" id="real-payment" role="tabpanel" aria-labelledby="real-payment-tab">
                            <div class="payment-info-group">
                                <?php if (isset($payment_info['is_batch']) && $payment_info['is_batch'] === true): ?>
                                <div class="payment-info-item">
                                    <div class="payment-label">일괄 결제 내역</div>
                                    <div class="payment-value">
                                        <div class="batch-programs-list">
                                            <?php foreach ($payment_info['registrations'] as $reg): ?>
                                            <div class="batch-program-item mb-2">
                                                <div class="d-flex justify-content-between">
                                                    <div class="batch-program-title"><?php echo htmlspecialchars($reg['title']); ?> - <?php echo htmlspecialchars($reg['child_name']); ?></div>
                                                    <div class="batch-program-price"><?php echo number_format($reg['price']); ?>원</div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="payment-info-item">
                                    <div class="payment-label">프로그램</div>
                                    <div class="payment-value program-title"><?php echo htmlspecialchars($payment_info['order_name']); ?></div>
                                </div>
                                <?php endif; ?>
                                <div class="payment-info-item mt-3">
                                    <div class="payment-label">총 결제 금액</div>
                                    <div class="payment-value payment-amount fw-bold text-primary"><?php echo number_format($payment_info['amount']); ?>원</div>
                                </div>
                                <div class="payment-info-item">
                                    <div class="payment-label">결제 수단 선택</div>
                                    <div class="payment-value payment-methods">
                                        <div class="payment-method-options">
                                            <button type="button" class="btn payment-method-btn active" data-method="카드">
                                                신용카드
                                            </button>
                                            <button type="button" class="btn payment-method-btn" data-method="가상계좌">
                                                가상계좌
                                            </button>
                                            <button type="button" class="btn payment-method-btn" data-method="계좌이체">
                                                계좌이체
                                            </button>
                                            <button type="button" class="btn payment-method-btn" data-method="휴대폰">
                                                휴대폰
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="test-payment" role="tabpanel" aria-labelledby="test-payment-tab">
                            <div class="test-payment-guide">
                                <p>테스트 모드에서는 실제 결제가 이루어지지 않습니다.</p>
                                <p>개발 및 테스트 목적으로만 사용해주세요.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-like-footer">
                <button type="button" class="btn btn-outline-secondary" onclick="window.location.href='index.php?page=my_page'">취소</button>
                <button type="button" class="btn btn-primary payment-submit-btn">결제하기</button>
            </div>
        </div>
    </div>
</div>

<style>
/* 모달 스타일 - 토스페이먼츠 스타일과 유사하게 */
.modal-like-container {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1050;
}

.modal-like-dialog {
    width: 100%;
    max-width: 480px;
    margin: 1.75rem auto;
}

.modal-like-content {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    background-color: #fff;
    border-radius: 16px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
    outline: 0;
}

.modal-like-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 24px;
    border-bottom: 1px solid #f0f0f0;
}

.modal-like-title {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
    color: #333;
}

.modal-like-body {
    position: relative;
    flex: 1 1 auto;
    padding: 0;
}

.modal-like-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 24px;
    border-top: 1px solid #f0f0f0;
}

/* 결제 탭 스타일 */
.payment-tabs {
    width: 100%;
}

.payment-tab-nav {
    display: flex;
    border-bottom: 1px solid #f0f0f0;
    background-color: #f9f9f9;
    border-radius: 16px 16px 0 0;
}

.payment-tab-nav .nav-link {
    flex: 1;
    text-align: center;
    padding: 12px;
    border: none;
    background: none;
    color: #666;
    border-radius: 0;
    margin: 0;
    font-size: 14px;
}

.payment-tab-nav .nav-link.active {
    color: #333;
    font-weight: 600;
    background-color: #fff;
    border-bottom: 2px solid #3182f6;
}

.payment-tab-content {
    padding: 24px;
}

/* 결제 정보 스타일 */
.payment-info-group {
    margin-bottom: 20px;
}

.payment-info-item {
    margin-bottom: 20px;
}

.payment-label {
    font-size: 14px;
    color: #666;
    margin-bottom: 8px;
}

.payment-value {
    font-size: 16px;
    color: #333;
}

.program-title {
    font-weight: 500;
}

.payment-amount {
    font-size: 22px;
    font-weight: 600;
    color: #ff5c5c;
}

/* 결제 수단 선택 스타일 */
.payment-method-options {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 8px;
}

.payment-method-btn {
    flex: 1 0 calc(50% - 8px);
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 10px;
    background-color: #fff;
    color: #333;
    font-size: 14px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
}

.payment-method-btn:hover {
    border-color: #aaa;
}

.payment-method-btn.active {
    border-color: #ff5c5c;
    background-color: #fff;
    color: #ff5c5c;
    font-weight: 500;
}

/* 결제 버튼 스타일 */
.payment-submit-btn {
    background-color: #ff5c5c;
    border-color: #ff5c5c;
    color: white;
    padding: 10px 24px;
    font-weight: 500;
}

.payment-submit-btn:hover {
    background-color: #ff4040;
    border-color: #ff4040;
}

/* 테스트 결제 안내 */
.test-payment-guide {
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 8px;
    font-size: 14px;
    color: #666;
}
</style>

<!-- 토스페이먼츠 결제 스크립트 -->
<script src="https://js.tosspayments.com/v1/payment"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const clientKey = '<?php echo getenv("TOSS_PAYMENTS_CLIENT_KEY") ?: "test_ck_D5GePWvyJnrK0W0k6q8gLzN97Eoq"; ?>'; // 토스페이먼츠 클라이언트 키
    const tossPayments = TossPayments(clientKey);
    
    // 결제 수단 버튼 클릭 이벤트
    const methodBtns = document.querySelectorAll('.payment-method-btn');
    let selectedMethod = '카드'; // 기본 결제 수단
    
    methodBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            methodBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            selectedMethod = this.getAttribute('data-method');
        });
    });
    
    // 결제하기 버튼 클릭 이벤트
    document.querySelector('.payment-submit-btn').addEventListener('click', function() {
        // 테스트 탭이 활성화되어 있는지 확인
        const isTestMode = document.getElementById('test-payment-tab').classList.contains('active');
        
        // 결제 요청 공통 파라미터
        // 로컬호스트에서도 사용 가능한 하드코딩된 URL 사용 (로컬 테스트 목적)
        const fullDomain = window.location.protocol + '//' + window.location.host;
        const baseUrl = fullDomain + '<?php echo str_replace(dirname($_SERVER['DOCUMENT_ROOT']), '', $_SERVER['DOCUMENT_ROOT']); ?>';
        
        console.log('Payment URL base:', baseUrl);
        
        const paymentParams = {
            amount: <?php echo $payment_info['amount']; ?>,
            orderId: '<?php echo $payment_info['order_id']; ?>',
            orderName: '<?php echo addslashes($payment_info['order_name']); ?>',
            customerName: '<?php echo addslashes($payment_info['customer_name']); ?>',
            customerEmail: '<?php echo addslashes($payment_info['customer_email']); ?>',
            successUrl: fullDomain + '/paju/index.php?page=payment_success',
            failUrl: fullDomain + '/paju/index.php?page=payment_fail'
        };
        
        // 가상계좌 결제인 경우 추가 파라미터
        if (selectedMethod === '가상계좌') {
            paymentParams.validHours = 24;
            paymentParams.cashReceipt = {
                type: '소득공제'
            };
        }
        
        // 결제 요청
        tossPayments.requestPayment(selectedMethod, paymentParams)
            .catch(function(error) {
                if (error.code === 'USER_CANCEL') {
                    alert('결제가 취소되었습니다.');
                } else {
                    alert('결제 오류가 발생했습니다: ' + error.message);
                }
            });
    });
});
</script>