<?php
// 검색어 처리
$search = isset($_GET['search']) ? $_GET['search'] : '';

// 카테고리 필터 처리
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : null;

// 항상 최신 데이터를 가져오기 위해 직접 데이터베이스 쿼리 실행
$conn = get_db_connection();

// 프로그램 가져오기
$programs = [];
$where_clause = "WHERE p.status != 'completed' AND p.status != 'canceled'";

if ($category_filter) {
    $where_clause .= " AND p.category_id = {$category_filter}";
}

$sql = "SELECT 
        p.id, p.title, p.description, p.category_id, p.date, 
        p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
        p.duration, p.status, p.image_path, p.created_at,
        c.name as category_name, 
        (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) as current_participants
        FROM programs p
        LEFT JOIN categories c ON p.category_id = c.id
        {$where_clause}
        ORDER BY 
            CASE p.status 
                WHEN 'active' THEN 1 
                WHEN 'pending' THEN 2 
                ELSE 3 
            END, 
            p.date ASC";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $programs[] = $row;
    }
}

$conn->close();

// 검색어가 있으면 필터링
if (!empty($search)) {
    $filtered_programs = [];
    $search_terms = explode(' ', $search);
    
    foreach ($programs as $program) {
        $match = true;
        
        foreach ($search_terms as $term) {
            $term = trim($term);
            if (empty($term)) continue;
            
            // 제목, 설명에서 검색어 찾기
            $title_match = stripos($program['title'], $term) !== false;
            $desc_match = stripos($program['description'], $term) !== false;
            
            if (!$title_match && !$desc_match) {
                $match = false;
                break;
            }
        }
        
        if ($match) {
            $filtered_programs[] = $program;
        }
    }
    
    $programs = $filtered_programs;
}

// 모든 카테고리 가져오기
$categories = get_categories();

// 중복 카테고리 제거를 위한 배열 생성
$unique_categories = [];
$unique_category_ids = [];

// 중복 없는 카테고리 배열 생성
foreach($categories as $category) {
    if(!in_array($category['id'], $unique_category_ids)) {
        $unique_categories[] = $category;
        $unique_category_ids[] = $category['id'];
    }
}

// 기존 카테고리 배열 교체
$categories = $unique_categories;
?>

<div class="container">
    <h2 class="mb-4">체험 프로그램</h2>
    
    <?php if (!empty($search)): ?>
        <div class="alert alert-info">
            <i class="fas fa-search"></i> "<?php echo htmlspecialchars($search); ?>" 검색 결과: <?php echo count($programs); ?>개 프로그램
            <a href="index.php?page=program_selection" class="float-end">검색 초기화</a>
        </div>
    <?php endif; ?>
    
    <!-- 카테고리 필터 (가로형) -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">카테고리</h5>
        </div>
        <div class="card-body">
            <div class="category-filter d-flex flex-wrap gap-2">
                <a href="index.php?page=program_selection" class="btn btn-outline-primary <?php echo empty($category_filter) ? 'active' : ''; ?>">전체 프로그램</a>
                
                <?php foreach($categories as $category): ?>
                    <a href="index.php?page=program_selection&category=<?php echo $category['id']; ?>" 
                       class="btn btn-outline-primary <?php echo $category_filter == $category['id'] ? 'active' : ''; ?>">
                        <?php echo $category['name']; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-body">
                    <p>
                        총 <span id="program-count" class="fw-bold"><?php echo count($programs); ?></span>개의 프로그램이 있습니다.
                        프로그램은 최소 참가자 수가 충족되어야 진행됩니다.
                    </p>
                </div>
            </div>
            
            <div class="row">
                <?php if(empty($programs)): ?>
                    <div class="col-12">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i> 
                            <?php if(!empty($search)): ?>
                                "<?php echo htmlspecialchars($search); ?>" 검색어에 맞는 프로그램이 없습니다.
                            <?php elseif(!empty($category_filter)): ?>
                                선택한 카테고리에 프로그램이 없습니다.
                            <?php else: ?>
                                등록된 프로그램이 없습니다.
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <?php foreach($programs as $program): 
                        // 프로그램 상태 결정
                        $status_class = '';
                        $status_text = '';
                        
                        if($program['current_participants'] >= $program['max_participants']) {
                            $status_class = 'status-full';
                            $status_text = '마감';
                        } elseif($program['status'] === 'active') {
                            $status_class = 'status-active';
                            $status_text = '모집중';
                        } else {
                            $status_class = 'status-pending';
                            $status_text = '준비중';
                        }
                        
                        // 현재 카테고리 찾기
                        $current_category = null;
                        foreach($categories as $category) {
                            if($category['id'] == $program['category_id']) {
                                $current_category = $category;
                                break;
                            }
                        }
                    ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 program-card" data-category="<?php echo $program['category_id']; ?>">
                            <div class="program-status <?php echo $status_class; ?>"><?php echo $status_text; ?></div>
                            
                            <img src="<?php echo $base_url; ?>/<?php echo !empty($program['image_path']) ? $program['image_path'] : 'assets/img/program-default.jpg'; ?>" class="card-img-top" alt="<?php echo $program['title']; ?>" onerror="this.src='<?php echo $base_url; ?>/assets/img/program-default.jpg'">
                            
                            <div class="card-body">
                                <h5 class="card-title">
                                    <?php 
                                    // 검색어 하이라이트
                                    $title = $program['title'];
                                    if(!empty($search)) {
                                        foreach(explode(' ', $search) as $term) {
                                            $term = trim($term);
                                            if(empty($term)) continue;
                                            $title = preg_replace('/(' . preg_quote($term, '/') . ')/i', '<span class="highlight">$1</span>', $title);
                                        }
                                    }
                                    echo $title; 
                                    ?>
                                </h5>
                                
                                <?php if($current_category): ?>
                                    <span class="badge bg-primary mb-2"><?php echo $current_category['name']; ?></span>
                                <?php endif; ?>
                                
                                <p class="card-text">
                                    <?php 
                                    $description = mb_substr($program['description'], 0, 80) . '...';
                                    // 검색어 하이라이트
                                    if(!empty($search)) {
                                        foreach(explode(' ', $search) as $term) {
                                            $term = trim($term);
                                            if(empty($term)) continue;
                                            $description = preg_replace('/(' . preg_quote($term, '/') . ')/i', '<span class="highlight">$1</span>', $description);
                                        }
                                    }
                                    echo $description;
                                    ?>
                                </p>
                                
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <p class="mb-0"><i class="far fa-calendar-alt"></i> <?php echo format_date($program['date']); ?></p>
                                    <p class="mb-0"><i class="fas fa-child"></i> <?php echo isset($program['min_age']) ? $program['min_age'] : '0'; ?>~<?php echo isset($program['max_age']) ? $program['max_age'] : '0'; ?>세</p>
                                </div>
                            </div>
                            
                            <div class="card-footer">
                                <div class="d-flex justify-content-between align-items-center">
                                    <strong class="text-primary"><?php echo format_price($program['price']); ?></strong>
                                    <a href="index.php?page=program_detail&id=<?php echo $program['id']; ?>" class="btn btn-primary btn-sm">자세히 보기</a>
                                </div>
                                
                                <!-- 최소 인원 정보 -->
                                <div class="alert alert-info p-2 mt-2 mb-2 text-center">
                                    <small><i class="fas fa-users me-1"></i> 프로그램 개설에 필요한 최소인원: <strong><?php echo $program['min_participants']; ?>명</strong></small>
                                </div>
                                
                                <div class="progress mt-2">
                                    <?php 
                                    $percentage = ($program['current_participants'] / $program['max_participants']) * 100;
                                    ?>
                                    <div class="progress-bar" role="progressbar" style="width: <?php echo $percentage; ?>%;" aria-valuenow="<?php echo $program['current_participants']; ?>" aria-valuemin="0" aria-valuemax="<?php echo $program['max_participants']; ?>">
                                        <?php echo $program['current_participants']; ?>/<?php echo $program['max_participants']; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>