<?php
// add_program.php - 프로그램 추가 페이지

// 관리자 권한 확인
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    redirect($base_url . '/index.php?page=login');
    exit;
}

// 카테고리 목록 가져오기
$categories = get_categories();

// 프로그램 추가 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_program') {
    $title = isset($_POST['title']) ? $_POST['title'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
    $price = isset($_POST['price']) ? (int)$_POST['price'] : 0;
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $time = isset($_POST['time']) ? $_POST['time'] : '';
    $max_participants = isset($_POST['max_participants']) ? (int)$_POST['max_participants'] : 0;
    $min_participants = isset($_POST['min_participants']) ? (int)$_POST['min_participants'] : 0;
    $target_age = isset($_POST['target_age']) ? $_POST['target_age'] : '';
    $status = isset($_POST['status']) ? $_POST['status'] : 'pending';
    
    // 이미지 업로드 처리
    $image_path = '';
    $image_uploaded = false;
    
    if (isset($_FILES['program_image']) && $_FILES['program_image']['name'] != '') {
        // 이미지가 선택된 경우
        if ($_FILES['program_image']['error'] == 0) {
            // 업로드 디렉토리 설정
            $upload_dir = 'uploads/programs/';
            
            // 디렉토리가 없으면 생성
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_name = basename($_FILES['program_image']['name']);
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            $allowed_exts = array('jpg', 'jpeg', 'png', 'gif');
            
            // 확장자 검사
            if (in_array($file_ext, $allowed_exts)) {
                // 파일명 중복 방지를 위한 고유 이름 생성
                $new_file_name = 'program_' . time() . '_' . rand(1000, 9999) . '.' . $file_ext;
                $target_file_path = $upload_dir . $new_file_name;
                
                if (move_uploaded_file($_FILES['program_image']['tmp_name'], $target_file_path)) {
                    $image_path = $target_file_path;
                    $image_uploaded = true;
                } else {
                    $errors[] = '이미지 업로드 중 오류가 발생했습니다.';
                }
            } else {
                $errors[] = '허용되지 않는 파일 형식입니다. JPG, JPEG, PNG, GIF 파일만 업로드 가능합니다.';
            }
        } else {
            $errors[] = '파일 업로드 중 오류가 발생했습니다 (오류 코드: ' . $_FILES['program_image']['error'] . ')';
        }
    }
    
    // 날짜와 시간 결합
    $datetime = $date . ' ' . $time;
    
    // 유효성 검사
    $errors = [];
    
    if (empty($title)) {
        $errors[] = '프로그램 제목을 입력해주세요.';
    }
    
    if (empty($description)) {
        $errors[] = '프로그램 설명을 입력해주세요.';
    }
    
    if ($category_id <= 0) {
        $errors[] = '카테고리를 선택해주세요.';
    }
    
    if ($price < 0) {
        $errors[] = '가격은 0 이상이어야 합니다.';
    }
    
    if (empty($date) || empty($time)) {
        $errors[] = '날짜와 시간을 입력해주세요.';
    }
    
    if ($max_participants <= 0) {
        $errors[] = '최대 참가자 수를 입력해주세요.';
    }
    
    if ($min_participants <= 0 || $min_participants > $max_participants) {
        $errors[] = '최소 참가자 수는 0보다 크고 최대 참가자 수보다 작거나 같아야 합니다.';
    }
    
    // 오류가 없으면 프로그램 추가
    if (empty($errors)) {
        $program_data = [
            'title' => $title,
            'description' => $description,
            'category_id' => $category_id,
            'price' => $price,
            'date' => $datetime,
            'max_participants' => $max_participants,
            'min_participants' => $min_participants,
            'target_age' => $target_age,
            'status' => $status
        ];
        
        // 이미지가 업로드된 경우 이미지 경로 추가
        if ($image_uploaded) {
            $program_data['image_path'] = $image_path;
        }
        
        $result = add_program($program_data);
        
        if ($result) {
            // 프로그램 추가 성공 시 프로그램 목록 페이지로 리다이렉션
            redirect($base_url . '/index.php?page=program_selection&success=added');
            exit;
        } else {
            $errors[] = '프로그램 추가 중 오류가 발생했습니다.';
        }
    }
}
?>

<div class="container">
    <h2 class="mb-4">프로그램 추가</h2>
    
    <?php if(isset($errors) && !empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <form action="<?php echo $base_url; ?>/index.php?page=add_program" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add_program">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="title" class="form-label">프로그램 제목 <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" required value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>">
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="category_id" class="form-label">카테고리 <span class="text-danger">*</span></label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="">카테고리 선택</option>
                            <?php foreach($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" <?php echo (isset($_POST['category_id']) && $_POST['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                    <?php echo $category['name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">프로그램 설명 <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="description" name="description" rows="4" required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                </div>
                
                <div class="mb-3">
                    <label for="program_image" class="form-label">프로그램 이미지</label>
                    <input type="file" class="form-control" id="program_image" name="program_image" accept="image/*">
                    <div class="form-text">프로그램을 대표하는 이미지를 업로드하세요. (JPG, JPEG, PNG, GIF 파일만 가능)</div>
                    <div id="image_preview_container" class="mt-2 d-none">
                        <p>선택된 이미지 미리보기:</p>
                        <img id="image_preview" src="" alt="이미지 미리보기" class="img-thumbnail" style="max-width: 300px; max-height: 200px;">
                    </div>
                    <div id="file_info" class="mt-2 small text-muted"></div>
                </div>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="price" class="form-label">가격 (원) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="price" name="price" min="0" required value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price']) : ''; ?>">
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <label for="date" class="form-label">날짜 <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="date" name="date" required value="<?php echo isset($_POST['date']) ? htmlspecialchars($_POST['date']) : ''; ?>">
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <label for="time" class="form-label">시간 <span class="text-danger">*</span></label>
                        <input type="time" class="form-control" id="time" name="time" required value="<?php echo isset($_POST['time']) ? htmlspecialchars($_POST['time']) : ''; ?>">
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="max_participants" class="form-label">최대 참가자 수 <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="max_participants" name="max_participants" min="1" required value="<?php echo isset($_POST['max_participants']) ? htmlspecialchars($_POST['max_participants']) : ''; ?>">
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <label for="min_participants" class="form-label">최소 참가자 수 <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="min_participants" name="min_participants" min="1" required value="<?php echo isset($_POST['min_participants']) ? htmlspecialchars($_POST['min_participants']) : ''; ?>">
                        <div class="form-text">프로그램 확정에 필요한 최소 인원</div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <label for="status" class="form-label">상태 <span class="text-danger">*</span></label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="pending" <?php echo (!isset($_POST['status']) || $_POST['status'] == 'pending') ? 'selected' : ''; ?>>준비중</option>
                            <option value="active" <?php echo (isset($_POST['status']) && $_POST['status'] == 'active') ? 'selected' : ''; ?>>모집중</option>
                            <option value="confirmed" <?php echo (isset($_POST['status']) && $_POST['status'] == 'confirmed') ? 'selected' : ''; ?>>확정</option>
                            <option value="canceled" <?php echo (isset($_POST['status']) && $_POST['status'] == 'canceled') ? 'selected' : ''; ?>>취소됨</option>
                        </select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="target_age" class="form-label">대상 연령</label>
                        <input type="text" class="form-control" id="target_age" name="target_age" placeholder="예: 0~3세" value="<?php echo isset($_POST['target_age']) ? htmlspecialchars($_POST['target_age']) : ''; ?>">
                        <div class="form-text">한국식 나이로 입력해주세요. (예: 1세, 2~3세, 영아 0~1세, 유아 2~5세)</div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="<?php echo $base_url; ?>/index.php?page=program_selection" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-1"></i> 프로그램 목록으로
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus-circle me-1"></i> 프로그램 추가
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// 이미지 미리보기 및 파일 정보 표시 기능
document.addEventListener('DOMContentLoaded', function() {
    const programImageInput = document.getElementById('program_image');
    const imagePreviewContainer = document.getElementById('image_preview_container');
    const imagePreview = document.getElementById('image_preview');
    const fileInfoDiv = document.getElementById('file_info');
    
    if (programImageInput) {
        programImageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                // 선택한 파일 경로와 정보 표시
                const fileName = file.name;
                const fileSize = (file.size / 1024).toFixed(2) + ' KB';
                
                // 파일의 전체 경로는 보안상의 이유로 브라우저에서 제한됨
                // 하지만 파일명과 크기는 표시 가능
                let fullPath = '';
                
                // 파일 경로를 최대한 얻으려는 시도
                // Internet Explorer의 경우
                if (programImageInput.value) {
                    fullPath = programImageInput.value;
                } 
                // 대부분의 브라우저에서는 파일명만 얻을 수 있음
                else {
                    fullPath = fileName;
                }
                
                // 파일 정보 표시
                fileInfoDiv.textContent = `선택된 파일: ${fullPath} (${fileSize})`;
                
                // 이미지 미리보기
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreviewContainer.classList.remove('d-none');
                }
                reader.readAsDataURL(file);
            } else {
                // 파일 선택 취소 시
                fileInfoDiv.textContent = '';
                imagePreviewContainer.classList.add('d-none');
                imagePreview.src = '';
            }
        });
    }
});
</script>