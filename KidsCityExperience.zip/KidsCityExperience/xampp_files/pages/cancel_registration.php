<?php
// cancel_registration.php - 프로그램 신청 취소 처리

// 로그인 확인
if (!is_logged_in()) {
    set_message('로그인 후 이용해주세요.', 'warning');
    redirect('index.php?page=login');
    exit;
}

// 1. 임시 등록 취소 (세션에 저장된 등록 정보)
if (isset($_GET['temp_id'])) {
    $temp_id = $_GET['temp_id'];
    
    // 세션에서 해당 신청 내역 찾기
    if (isset($_SESSION['registrations']) && is_array($_SESSION['registrations'])) {
        $found = false;
        $updated_registrations = [];
        
        foreach ($_SESSION['registrations'] as $reg) {
            if ($reg['id'] == $temp_id) {
                $found = true;
                // 이 등록은 건너뛰기 (취소)
                continue;
            }
            // 나머지 등록은 유지
            $updated_registrations[] = $reg;
        }
        
        if ($found) {
            // 업데이트된 등록 내역으로 세션 갱신
            $_SESSION['registrations'] = $updated_registrations;
            set_message('프로그램 신청이 취소되었습니다.', 'success');
        } else {
            set_message('해당 신청 내역을 찾을 수 없습니다.', 'danger');
        }
    } else {
        set_message('신청 내역이 없습니다.', 'danger');
    }
}
// 2. 실제 등록 취소 (데이터베이스에 저장된 등록 정보)
else if (isset($_GET['registration_id'])) {
    $registration_id = $_GET['registration_id'];
    
    // 데이터베이스에서 등록 정보 취소 처리
    // (실제 데이터베이스 연동 시 구현)
    // 임시로 세션에 취소 내역 저장
    if (!isset($_SESSION['canceled_registrations'])) {
        $_SESSION['canceled_registrations'] = [];
    }
    $_SESSION['canceled_registrations'][] = $registration_id;
    
    set_message('프로그램 신청이 취소되었습니다.', 'success');
} else {
    set_message('잘못된 접근입니다.', 'danger');
}

// 마이페이지로 리다이렉트
redirect('index.php?page=my_page');
exit;
?>