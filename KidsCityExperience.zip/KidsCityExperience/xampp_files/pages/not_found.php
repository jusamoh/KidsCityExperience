<?php
// not_found.php - 404 페이지 (페이지를 찾을 수 없음)
?>

<div class="container">
    <div class="row justify-content-center my-5">
        <div class="col-md-8 text-center">
            <div class="card shadow-sm py-5">
                <div class="card-body">
                    <h1 class="display-1 fw-bold text-primary mb-4">404</h1>
                    <h2 class="mb-4">페이지를 찾을 수 없습니다</h2>
                    <p class="lead mb-5">요청하신 페이지를 찾을 수 없습니다. URL을 확인하시거나 아래 버튼을 통해 홈으로 이동해 주세요.</p>
                    
                    <div class="d-flex justify-content-center gap-3">
                        <a href="index.php" class="btn btn-primary">
                            <i class="fas fa-home me-2"></i> 홈으로 이동
                        </a>
                        <a href="javascript:history.back()" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i> 이전 페이지로
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="mt-4">
                <p>도움이 필요하시면 아래 링크를 이용해 주세요:</p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="index.php?page=program_selection" class="text-decoration-none">프로그램 목록</a>
                    <span class="text-muted">|</span>
                    <a href="index.php?page=faq" class="text-decoration-none">자주 묻는 질문</a>
                    <span class="text-muted">|</span>
                    <a href="index.php?page=how_to_use" class="text-decoration-none">이용 방법</a>
                </div>
            </div>
        </div>
    </div>
</div>