<?php
// category_management.php - 카테고리 관리 페이지

// 관리자 권한 확인
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    redirect($base_url . '/index.php?page=login');
    exit;
}

// 카테고리 목록 가져오기
$categories = get_categories();

// 카테고리 추가 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_category') {
    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    
    if (!empty($name)) {
        $result = add_category([
            'name' => $name,
            'description' => $description
        ]);
        
        if ($result) {
            // 카테고리 추가 성공 시 현재 페이지로 리다이렉션
            redirect($base_url . '/index.php?page=category_management&success=added');
            exit;
        } else {
            // 카테고리 추가 실패 시 에러 메시지와 함께 리다이렉션
            redirect($base_url . '/index.php?page=category_management&error=add_failed');
            exit;
        }
    } else {
        // 이름이 비어있으면 에러 메시지와 함께 리다이렉션
        redirect($base_url . '/index.php?page=category_management&error=name_required');
        exit;
    }
}

// 카테고리 삭제 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_category') {
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
    
    if ($category_id > 0) {
        $result = delete_category($category_id);
        
        if ($result) {
            // 카테고리 삭제 성공 시 현재 페이지로 리다이렉션
            redirect($base_url . '/index.php?page=category_management&success=deleted');
            exit;
        } else {
            // 카테고리 삭제 실패 시 에러 메시지와 함께 리다이렉션
            redirect($base_url . '/index.php?page=category_management&error=delete_failed');
            exit;
        }
    } else {
        // 카테고리 ID가 유효하지 않으면 에러 메시지와 함께 리다이렉션
        redirect($base_url . '/index.php?page=category_management&error=invalid_id');
        exit;
    }
}
?>

<div class="container">
    <h2 class="mb-4">카테고리 관리</h2>
    
    <!-- 알림 메시지 -->
    <?php if(isset($_GET['success'])): ?>
        <?php if($_GET['success'] === 'added'): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                카테고리가 성공적으로 추가되었습니다.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif($_GET['success'] === 'deleted'): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                카테고리가 성공적으로 삭제되었습니다.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    
    <?php if(isset($_GET['error'])): ?>
        <?php if($_GET['error'] === 'add_failed'): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                카테고리 추가 중 오류가 발생했습니다.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif($_GET['error'] === 'name_required'): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                카테고리 이름을 입력해주세요.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif($_GET['error'] === 'delete_failed'): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                카테고리 삭제 중 오류가 발생했습니다. 해당 카테고리에 프로그램이 연결되어 있는지 확인해주세요.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif($_GET['error'] === 'invalid_id'): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                유효하지 않은 카테고리 ID입니다.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    
    <div class="row">
        <!-- 카테고리 추가 폼 -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">카테고리 추가</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo $base_url; ?>/index.php?page=category_management" method="post">
                        <input type="hidden" name="action" value="add_category">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">카테고리 이름 <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">설명</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                            <div class="form-text">카테고리에 대한 간략한 설명을 입력하세요.</div>
                        </div>
                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">카테고리 추가</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- 카테고리 목록 -->
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-light">
                    <h5 class="mb-0">카테고리 목록</h5>
                </div>
                <div class="card-body">
                    <?php if(count($categories) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th width="5%">ID</th>
                                        <th width="25%">이름</th>
                                        <th width="45%">설명</th>
                                        <th width="15%">프로그램 수</th>
                                        <th width="10%">관리</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($categories as $category): ?>
                                        <tr>
                                            <td><?php echo $category['id']; ?></td>
                                            <td><?php echo $category['name']; ?></td>
                                            <td><?php echo $category['description']; ?></td>
                                            <td>
                                                <?php 
                                                // 직접 카테고리별 프로그램 개수 계산
                                                $conn = get_db_connection();
                                                $cat_id = $conn->real_escape_string($category['id']);
                                                $sql = "SELECT COUNT(*) as count FROM programs WHERE category_id = {$cat_id}";
                                                $result = $conn->query($sql);
                                                $program_count = 0;
                                                if ($result && $result->num_rows > 0) {
                                                    $program_count = $result->fetch_assoc()['count'];
                                                }
                                                $conn->close();
                                                echo $program_count;
                                                ?>
                                            </td>
                                            <td>
                                                <form action="<?php echo $base_url; ?>/index.php?page=category_management" method="post" class="d-inline" onsubmit="return confirm('이 카테고리를 삭제하시겠습니까? 관련된 프로그램의 카테고리가 변경될 수 있습니다.');">
                                                    <input type="hidden" name="action" value="delete_category">
                                                    <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger">삭제</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info mb-0">
                            등록된 카테고리가 없습니다. 새 카테고리를 추가해주세요.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>