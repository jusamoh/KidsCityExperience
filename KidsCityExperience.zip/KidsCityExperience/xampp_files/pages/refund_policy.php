<?php
// refund_policy.php - 환불정책 페이지
?>

<div class="container">
    <h2 class="mb-4">환불정책</h2>
    
    <div class="card mb-5">
        <div class="card-body">
            <h3 class="card-title mb-4">프로그램 신청 취소 및 환불 규정</h3>
            
            <p class="card-text">파주 체험 Camp는 고객님의 편의를 위해 다음과 같은 환불 정책을 시행하고 있습니다. 프로그램 신청 전 환불 정책을 반드시 확인해 주시기 바랍니다.</p>
            
            <div class="table-responsive mt-4">
                <table class="table table-bordered">
                    <thead class="table-primary">
                        <tr>
                            <th>기준</th>
                            <th>환불 비율</th>
                            <th>비고</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>프로그램 시작일 7일 전까지</td>
                            <td>결제 금액의 100%</td>
                            <td>전액 환불</td>
                        </tr>
                        <tr>
                            <td>프로그램 시작일 6~3일 전까지</td>
                            <td>결제 금액의 70%</td>
                            <td>30% 위약금 발생</td>
                        </tr>
                        <tr>
                            <td>프로그램 시작일 2~1일 전까지</td>
                            <td>결제 금액의 50%</td>
                            <td>50% 위약금 발생</td>
                        </tr>
                        <tr>
                            <td>프로그램 당일</td>
                            <td>환불 불가</td>
                            <td>특별한 사유가 있는 경우 문의</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <h5 class="mt-4">특별 환불 규정</h5>
            <ul>
                <li>최소 인원 미달로 프로그램이 취소되는 경우: <strong>100% 환불</strong></li>
                <li>천재지변, 감염병 확산 등으로 인한 불가피한 취소: <strong>100% 환불</strong></li>
                <li>운영사의 사정으로 인한 취소: <strong>100% 환불</strong></li>
            </ul>
        </div>
    </div>
    
    <div class="card mb-5">
        <div class="card-body">
            <h3 class="card-title mb-4">환불 신청 방법</h3>
            
            <ol>
                <li class="mb-3">
                    <strong>온라인 신청</strong>
                    <p>마이페이지 > 신청 내역에서 해당 프로그램의 '환불 신청' 버튼을 클릭하여 온라인으로 환불을 신청할 수 있습니다.</p>
                </li>
                <li class="mb-3">
                    <strong>전화 신청</strong>
                    <p>02-123-4567 (평일 09:00~18:00)로 연락하여 환불 신청을 할 수 있습니다.</p>
                </li>
                <li class="mb-3">
                    <strong>이메일 신청</strong>
                    <p>refund@paju.kr로 이메일을 보내 환불을 신청할 수 있습니다. 이메일에는 반드시 예약자 이름, 연락처, 프로그램명, 결제일, 환불 사유를 포함해 주세요.</p>
                </li>
            </ol>
            
            <div class="alert alert-info mt-3">
                <p class="mb-0"><i class="fas fa-info-circle me-2"></i> 환불 처리는 신청일로부터 영업일 기준 3~5일 이내에 완료됩니다. 카드 결제 취소의 경우 카드사에 따라 취소 확인이 지연될 수 있습니다.</p>
            </div>
        </div>
    </div>
    
    <div class="card mb-5">
        <div class="card-body">
            <h3 class="card-title mb-4">자주 묻는 질문</h3>
            
            <div class="accordion" id="refundFaqAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Q: 프로그램 예약 후 일정 변경은 가능한가요?
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#refundFaqAccordion">
                        <div class="accordion-body">
                            <p>프로그램 시작일 3일 전까지는 일정 변경이 가능합니다. 마이페이지의 신청 내역에서 '일정 변경' 버튼을 클릭하거나 고객센터로 연락해 주세요. 단, 변경 가능한 일정은 해당 프로그램의 다른 회차로 제한됩니다.</p>
                        </div>
                    </div>
                </div>
                
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Q: 아이가 아파서 당일 참여가 어려운 경우 환불이 가능한가요?
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#refundFaqAccordion">
                        <div class="accordion-body">
                            <p>일반적으로 당일 취소는 환불이 불가합니다. 그러나 건강상의 이유로 참여가 불가능한 경우, 진단서나 소견서 제출 시 50%까지 환불이 가능할 수 있습니다. 자세한 사항은 고객센터로 문의해 주세요.</p>
                        </div>
                    </div>
                </div>
                
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            Q: 환불은 얼마나 걸리나요?
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#refundFaqAccordion">
                        <div class="accordion-body">
                            <p>환불 처리는 신청일로부터 영업일 기준 3~5일 이내에 완료됩니다. 실제 결제 취소와 환불금 입금은 결제 방식과 카드사, 은행에 따라 추가로 시간이 소요될 수 있습니다. 카드 결제의 경우 통상 5~7일, 계좌이체의 경우 3~5일 정도 소요됩니다.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6 mb-4 mb-md-0">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4>문의하기</h4>
                    <p>환불 관련 추가 문의가 있으시면 아래 연락처로 문의해주세요.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-phone me-2"></i> 02-123-4567 (평일 9:00-18:00)</li>
                        <li><i class="fas fa-envelope me-2"></i> refund@paju.kr</li>
                    </ul>
                </div>
                <div class="card-footer">
                    <a href="index.php?page=contact" class="btn btn-primary">문의하기</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4>관련 페이지</h4>
                    <p>프로그램 신청 및 이용에 관한 자세한 내용은 아래 페이지에서 확인하실 수 있습니다.</p>
                    <ul class="list-unstyled">
                        <li><a href="index.php?page=how_to_use">이용방법</a></li>
                        <li><a href="index.php?page=faq">자주 묻는 질문</a></li>
                        <li><a href="index.php?page=terms_of_service">이용약관</a></li>
                    </ul>
                </div>
                <div class="card-footer">
                    <a href="index.php?page=how_to_use" class="btn btn-primary">이용방법 보기</a>
                </div>
            </div>
        </div>
    </div>
</div>