<?php
require_once '../includes/header.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// 로그인 상태 확인
check_login();

$user_id = $_SESSION['user_id'];

// 사용자 정보 가져오기
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// 자녀 정보 가져오기
$children = get_user_children($conn, $user_id);

// 자녀 추가 처리
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_child'])) {
    $name = sanitize($_POST['name']);
    $age = intval($_POST['age']);
    $gender = sanitize($_POST['gender']);
    $birth_date = !empty($_POST['birth_date']) ? $_POST['birth_date'] : null;
    $notes = !empty($_POST['notes']) ? sanitize($_POST['notes']) : null;
    
    if (empty($name) || $age <= 0) {
        set_alert('error', '필수 정보를 입력해주세요.');
    } else {
        $result = add_child($conn, $user_id, $name, $age, $gender, $birth_date, $notes);
        if ($result) {
            set_alert('success', '자녀 정보가 추가되었습니다.');
            // 페이지 새로고침
            header("Location: mypage.php");
            exit;
        } else {
            set_alert('error', '자녀 정보 추가 중 오류가 발생했습니다.');
        }
    }
}

// 자녀 삭제 처리
if (isset($_GET['delete_child']) && is_numeric($_GET['delete_child'])) {
    $child_id = intval($_GET['delete_child']);
    $result = delete_child($conn, $child_id, $user_id);
    
    if ($result) {
        set_alert('success', '자녀 정보가 삭제되었습니다.');
    } else {
        set_alert('error', '자녀 정보 삭제 중 오류가 발생했습니다.');
    }
    
    // 페이지 새로고침
    header("Location: mypage.php");
    exit;
}

// 자녀 수정 처리
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_child'])) {
    $child_id = intval($_POST['child_id']);
    $name = sanitize($_POST['name']);
    $age = intval($_POST['age']);
    $gender = sanitize($_POST['gender']);
    $birth_date = !empty($_POST['birth_date']) ? $_POST['birth_date'] : null;
    $notes = !empty($_POST['notes']) ? sanitize($_POST['notes']) : null;
    
    if (empty($name) || $age <= 0) {
        set_alert('error', '필수 정보를 입력해주세요.');
    } else {
        $result = update_child($conn, $child_id, $name, $age, $gender, $birth_date, $notes);
        if ($result) {
            set_alert('success', '자녀 정보가 수정되었습니다.');
            // 페이지 새로고침
            header("Location: mypage.php");
            exit;
        } else {
            set_alert('error', '자녀 정보 수정 중 오류가 발생했습니다.');
        }
    }
}

// 사용자의 프로그램 신청 내역 가져오기
$sql = "SELECT r.*, p.title as program_title, p.start_date, p.start_time 
        FROM registrations r 
        JOIN programs p ON r.program_id = p.id 
        WHERE r.user_id = ? 
        ORDER BY r.registration_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$registrations = $stmt->get_result();
$registrations_array = [];
while ($row = $registrations->fetch_assoc()) {
    $registrations_array[] = $row;
}
$stmt->close();
?>

<div class="container mt-5 mb-5">
    <h2 class="text-center mb-4">마이페이지</h2>
    
    <!-- 사용자 정보 카드 -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">내 정보</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>이름:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                    <p><strong>아이디:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>이메일:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                    <p><strong>연락처:</strong> <?php echo htmlspecialchars($user['phone']); ?></p>
                </div>
            </div>
            <div class="text-end">
                <a href="edit_profile.php" class="btn btn-outline-primary">정보 수정</a>
            </div>
        </div>
    </div>
    
    <!-- 자녀 정보 카드 -->
    <div class="card mb-4">
        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">자녀 정보</h5>
            <button type="button" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#addChildModal">
                + 자녀 추가
            </button>
        </div>
        <div class="card-body">
            <?php if (count($children) > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>이름</th>
                            <th>나이</th>
                            <th>성별</th>
                            <th>생년월일</th>
                            <th>비고</th>
                            <th>관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($children as $child): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($child['name']); ?></td>
                            <td><?php echo $child['age']; ?>세</td>
                            <td><?php echo $child['gender']; ?></td>
                            <td><?php echo $child['birth_date'] ? date('Y-m-d', strtotime($child['birth_date'])) : '-'; ?></td>
                            <td><?php echo htmlspecialchars($child['notes'] ?? '-'); ?></td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary edit-child-btn" 
                                        data-id="<?php echo $child['id']; ?>"
                                        data-name="<?php echo htmlspecialchars($child['name']); ?>"
                                        data-age="<?php echo $child['age']; ?>"
                                        data-gender="<?php echo $child['gender']; ?>"
                                        data-birth="<?php echo $child['birth_date'] ? $child['birth_date'] : ''; ?>"
                                        data-notes="<?php echo htmlspecialchars($child['notes'] ?? ''); ?>"
                                        data-bs-toggle="modal" data-bs-target="#editChildModal">
                                    수정
                                </button>
                                <a href="mypage.php?delete_child=<?php echo $child['id']; ?>" 
                                   class="btn btn-sm btn-outline-danger" 
                                   onclick="return confirm('정말 삭제하시겠습니까?');">
                                    삭제
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-center">등록된 자녀 정보가 없습니다. 자녀 정보를 추가해주세요.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- 프로그램 신청 내역 카드 -->
    <div class="card mb-4">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">프로그램 신청 내역</h5>
        </div>
        <div class="card-body">
            <?php if (count($registrations_array) > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>프로그램</th>
                            <th>일시</th>
                            <th>참여 아이</th>
                            <th>신청 상태</th>
                            <th>결제 상태</th>
                            <th>신청일</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($registrations_array as $reg): ?>
                        <tr>
                            <td><a href="program_detail.php?id=<?php echo $reg['program_id']; ?>"><?php echo htmlspecialchars($reg['program_title']); ?></a></td>
                            <td><?php echo date('Y-m-d', strtotime($reg['start_date'])) . ' ' . date('H:i', strtotime($reg['start_time'])); ?></td>
                            <td><?php echo htmlspecialchars($reg['child_name']); ?> (<?php echo $reg['child_age']; ?>세)</td>
                            <td><?php echo get_status_badge($reg['status']); ?></td>
                            <td><?php echo get_payment_badge($reg['payment_status']); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($reg['registration_date'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-center">프로그램 신청 내역이 없습니다.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- 자녀 추가 모달 -->
<div class="modal fade" id="addChildModal" tabindex="-1" aria-labelledby="addChildModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addChildModalLabel">자녀 정보 추가</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">이름 <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="age" class="form-label">나이 <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="age" name="age" min="0" max="10" required>
                    </div>
                    <div class="mb-3">
                        <label for="gender" class="form-label">성별 <span class="text-danger">*</span></label>
                        <select class="form-select" id="gender" name="gender" required>
                            <option value="남">남</option>
                            <option value="여">여</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="birth_date" class="form-label">생년월일</label>
                        <input type="date" class="form-control" id="birth_date" name="birth_date">
                    </div>
                    <div class="mb-3">
                        <label for="notes" class="form-label">특이사항</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">취소</button>
                    <button type="submit" name="add_child" class="btn btn-primary">추가</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- 자녀 정보 수정 모달 -->
<div class="modal fade" id="editChildModal" tabindex="-1" aria-labelledby="editChildModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editChildModalLabel">자녀 정보 수정</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="child_id" id="edit_child_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_name" class="form-label">이름 <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="edit_name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_age" class="form-label">나이 <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="edit_age" name="age" min="0" max="10" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_gender" class="form-label">성별 <span class="text-danger">*</span></label>
                        <select class="form-select" id="edit_gender" name="gender" required>
                            <option value="남">남</option>
                            <option value="여">여</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="edit_birth_date" class="form-label">생년월일</label>
                        <input type="date" class="form-control" id="edit_birth_date" name="birth_date">
                    </div>
                    <div class="mb-3">
                        <label for="edit_notes" class="form-label">특이사항</label>
                        <textarea class="form-control" id="edit_notes" name="notes" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">취소</button>
                    <button type="submit" name="edit_child" class="btn btn-primary">저장</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 자녀 정보 수정 버튼 클릭 시 모달에 데이터 채우기
    const editButtons = document.querySelectorAll('.edit-child-btn');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            const age = this.getAttribute('data-age');
            const gender = this.getAttribute('data-gender');
            const birth = this.getAttribute('data-birth');
            const notes = this.getAttribute('data-notes');
            
            document.getElementById('edit_child_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_age').value = age;
            
            const genderSelect = document.getElementById('edit_gender');
            for (let i = 0; i < genderSelect.options.length; i++) {
                if (genderSelect.options[i].value === gender) {
                    genderSelect.selectedIndex = i;
                    break;
                }
            }
            
            document.getElementById('edit_birth_date').value = birth;
            document.getElementById('edit_notes').value = notes;
        });
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>