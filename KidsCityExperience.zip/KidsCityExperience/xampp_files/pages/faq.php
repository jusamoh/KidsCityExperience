<?php
// faq.php - 자주 묻는 질문
?>

<div class="container">
    <h2 class="mb-4">자주 묻는 질문</h2>
    
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="accordion" id="faqAccordion">
                <!-- 프로그램 신청 관련 -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <strong>프로그램 신청 관련</strong>
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <div class="mb-4">
                                <h5>Q: 프로그램은 어떻게 신청하나요?</h5>
                                <p>A: 홈페이지에서 원하는 프로그램을 선택한 후 '자세히 보기'를 클릭하여 프로그램 상세 페이지로 이동합니다. 
                                    상세 페이지에서 '신청하기' 버튼을 클릭하여 신청 양식을 작성하시면 됩니다. 로그인 후 신청 가능합니다.</p>
                            </div>
                            
                            <div class="mb-4">
                                <h5>Q: 회원가입은 필수인가요?</h5>
                                <p>A: 프로그램 신청을 위해서는 회원가입이 필요합니다. 회원가입을 통해 프로그램 신청 내역을 관리하고 결제 정보를 안전하게 보호할 수 있습니다.</p>
                            </div>
                            
                            <div>
                                <h5>Q: 한 번에 여러 프로그램을 신청할 수 있나요?</h5>
                                <p>A: 네, '다중 프로그램 신청' 기능을 통해 여러 프로그램을 한 번에 신청하고 결제할 수 있습니다.
                                    메인 메뉴에서 '체험프로그램'을 클릭한 후, 좌측 메뉴에서 '다중 프로그램 신청'을 선택하세요.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 결제 및 환불 -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            <strong>결제 및 환불</strong>
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <div class="mb-4">
                                <h5>Q: 어떤 결제 방법을 지원하나요?</h5>
                                <p>A: 신용카드, 계좌이체, 가상계좌, 휴대폰 결제 등 다양한 결제 방법을 지원합니다.</p>
                            </div>
                            
                            <div class="mb-4">
                                <h5>Q: 결제 후 환불은 어떻게 하나요?</h5>
                                <p>A: 마이페이지에서 신청 내역을 확인하고 '환불 신청' 버튼을 클릭하여 환불을 신청할 수 있습니다. 
                                    환불 정책에 따라 프로그램 시작일로부터의 기간에 따라 환불 금액이 달라질 수 있습니다.</p>
                            </div>
                            
                            <div>
                                <h5>Q: 환불 정책은 어떻게 되나요?</h5>
                                <p>A: 프로그램 시작일 7일 전까지는 100% 환불, 3일 전까지는 70% 환불, 당일 취소는 환불이 불가합니다. 
                                    단, 최소 인원 미달로 프로그램이 취소될 경우 100% 환불됩니다. 자세한 내용은 <a href="index.php?page=refund_policy">환불정책</a> 페이지를 참고해주세요.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 프로그램 운영 -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <strong>프로그램 운영</strong>
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <div class="mb-4">
                                <h5>Q: 프로그램은 언제 확정되나요?</h5>
                                <p>A: 각 프로그램마다 최소 인원이 모집되면 진행이 확정됩니다. 최소 인원은 프로그램마다 다르며, 상세 페이지에서 확인하실 수 있습니다.
                                    프로그램 확정 시 등록된 연락처로 안내 메시지가 발송됩니다.</p>
                            </div>
                            
                            <div class="mb-4">
                                <h5>Q: 프로그램 진행 시간은 어떻게 되나요?</h5>
                                <p>A: 각 프로그램마다 진행 시간이 다릅니다. 프로그램 상세 페이지에서 소요 시간을 확인하실 수 있습니다.
                                    대부분의 프로그램은 45~60분 정도 소요됩니다.</p>
                            </div>
                            
                            <div>
                                <h5>Q: 준비물은 따로 있나요?</h5>
                                <p>A: 기본적인 체험 도구는 모두 제공됩니다. 프로그램별로 필요한 준비물이 있다면 프로그램 상세 페이지에 안내되어 있으며, 
                                    프로그램 확정 시 안내 메시지를 통해서도 알려드립니다.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 기타 문의 -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingFour">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            <strong>기타 문의</strong>
                        </button>
                    </h2>
                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <div class="mb-4">
                                <h5>Q: 체험 프로그램 장소는 어디인가요?</h5>
                                <p>A: 대부분의 프로그램은 파주 체험 Camp 본사(서울시 강남구 테헤란로 123)에서 진행됩니다. 
                                    각 프로그램별 정확한 장소는 프로그램 상세 페이지에서 확인하실 수 있습니다.</p>
                            </div>
                            
                            <div class="mb-4">
                                <h5>Q: 아이와 함께 참여해야 하나요?</h5>
                                <p>A: 네, 모든 프로그램은 영유아의 안전과 학습 효과를 위해 보호자와 함께 참여하는 것을 원칙으로 합니다.</p>
                            </div>
                            
                            <div>
                                <h5>Q: 추가 문의사항은 어디로 연락하면 되나요?</h5>
                                <p>A: 전화(02-123-4567) 또는 이메일(info@paju.kr)로 문의해주시면 신속하게 답변드리겠습니다. 
                                    홈페이지 내 문의하기 기능을 통해서도 문의하실 수 있습니다.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4>이용방법 안내</h4>
                    <p>파주 체험 Camp 이용 방법에 대해 자세히 알아보세요.</p>
                    <p>프로그램 신청부터 체험 참여까지의 과정을 안내해드립니다.</p>
                </div>
                <div class="card-footer">
                    <a href="index.php?page=how_to_use" class="btn btn-primary">이용방법 보기</a>
                </div>
            </div>
        </div>
    </div>
</div>