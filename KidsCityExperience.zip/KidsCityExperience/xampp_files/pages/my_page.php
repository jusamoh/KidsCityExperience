<?php
// my_page.php - 사용자 마이페이지
// 로그인 확인은 index.php에서 처리됨

// 사용자 정보 가져오기
$user_id = $_SESSION['user_id'];
$user = get_user($user_id);

// 사용자 정보에서 이메일 가져오기
$user_email = isset($user['email']) ? $user['email'] : '';

// 사용자 신청 내역 가져오기 (이메일로만 조회 - 데이터베이스 호환성 문제 해결)
$registrations = get_user_registrations($user_email);
?>

<div class="container">
    <h2 class="mb-4">마이페이지</h2>
    
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">내 정보</h5>
                </div>
                <div class="card-body">
                    <p><strong>아이디:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                    <p><strong>이름:</strong> <?php echo !empty($user['name']) ? htmlspecialchars($user['name']) : '<span class="text-muted">정보를 입력해주세요</span>'; ?></p>
                    <p><strong>이메일:</strong> <?php echo !empty($user['email']) ? htmlspecialchars($user['email']) : '<span class="text-muted">정보를 입력해주세요</span>'; ?></p>
                    <p><strong>휴대폰:</strong> <?php echo !empty($user['phone']) ? htmlspecialchars($user['phone']) : '<span class="text-muted">정보를 입력해주세요</span>'; ?></p>
                    <p><strong>가입일:</strong> <?php echo format_date($user['created_at']); ?></p>
                    <a href="index.php?page=edit_profile" class="btn btn-outline-primary">정보 수정</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">신청 내역</h5>
                </div>
                <div class="card-body">
                    <?php 
                    // 세션에 신규 신청 알림이 있는지 확인 (UX 개선용)
                    $new_registration = isset($_SESSION['program_registered']) && $_SESSION['program_registered'] === true;
                    
                    if(empty($registrations)): ?>
                        <div class="alert alert-info">
                            아직 신청한 체험 프로그램이 없습니다.
                            <br>
                            <a href="index.php?page=program_selection" class="btn btn-primary mt-2">프로그램 찾아보기</a>
                        </div>
                    <?php else: ?>
                        <?php if($new_registration): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> 프로그램 신청이 완료되었습니다. 결제를 진행해주세요.
                        </div>
                        <?php 
                        // 신청 완료 알림 플래그 초기화 (중복 표시 방지)
                        $_SESSION['program_registered'] = false;
                        ?>
                        <?php endif; ?>
                        
                        <!-- 미결제 신청 내역이 있는 경우 일괄 결제 버튼 표시 -->
                        <?php
                        $total_pending_amount = 0;
                        $pending_program_ids = [];
                        $has_pending_registrations = false;
                        $unique_programs = [];
                        
                        // 표시할 등록 정보
                        $display_registrations = $registrations;
                        
                        // 중복 제거 및 정리된 등록 정보 생성
                        $organized_registrations = [];
                        $program_counts = [];
                        
                        if(!empty($display_registrations)) {
                            // 프로그램별 등록 내역 정리
                            foreach($display_registrations as $reg) {
                                $program_id = isset($reg['program_id']) ? $reg['program_id'] : 0;
                                
                                // 이미 추가된 프로그램이면 건너뛰기 (중복 방지)
                                if(isset($program_counts[$program_id])) {
                                    $program_counts[$program_id]++;
                                    continue;
                                }
                                
                                $program = get_program($program_id);
                                if($program) {
                                    // 등록 정보에 가격 추가
                                    $reg['price'] = $program['price'];
                                    $organized_registrations[] = $reg;
                                    $program_counts[$program_id] = 1;
                                    
                                    // 미결제 내역 확인 및 합산
                                    $payment_status = isset($reg['payment_status']) ? $reg['payment_status'] : 'pending';
                                    if($payment_status == 'pending') {
                                        $has_pending_registrations = true;
                                        $total_pending_amount += $program['price'];
                                        if(!in_array($program_id, $pending_program_ids)) {
                                            $pending_program_ids[] = $program_id;
                                        }
                                    }
                                }
                            }
                        }
                        
                        // 정리된 등록 정보로 교체
                        $display_registrations = $organized_registrations;
                        
                        if($has_pending_registrations):
                        ?>
                        <div class="card mb-3">
                            <div class="card-body bg-light">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <h5 class="mb-0">미결제 신청 내역</h5>
                                        <p class="mb-0">총 결제 금액: <strong><?php echo format_price($total_pending_amount); ?></strong></p>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <a href="index.php?page=payment_popup&program_ids=<?php echo implode(',', $pending_program_ids); ?>" class="btn btn-success">
                                            <i class="fas fa-credit-card me-1"></i> 일괄 결제하기
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>프로그램</th>
                                        <th>신청일</th>
                                        <th>참가자명</th>
                                        <th>참가비</th>
                                        <th>결제상태</th>
                                        <th>액션</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    // 표시할 등록 정보 설정 - 세션 변수 확인
                                    $has_session_registration = isset($_SESSION['temp_registrations']) && !empty($_SESSION['temp_registrations']);
                                    $all_registrations = $has_session_registration ? array_merge($registrations, $_SESSION['temp_registrations']) : $registrations;
                                    $display_registrations = $registrations; // 세션 등록 정보는 사용하지 않음
                                    
                                    foreach($display_registrations as $reg): 
                                        $program = isset($reg['program_id']) ? get_program($reg['program_id']) : null;
                                        $payment_status_class = '';
                                        $payment_status_text = '';
                                        
                                        $payment_status = isset($reg['payment_status']) ? $reg['payment_status'] : 'pending';
                                        
                                        switch($payment_status) {
                                            case 'pending':
                                                $payment_status_class = 'warning';
                                                $payment_status_text = '미결제';
                                                break;
                                            case 'completed':
                                                $payment_status_class = 'success';
                                                $payment_status_text = '결제완료';
                                                break;
                                            case 'canceled':
                                                $payment_status_class = 'secondary';
                                                $payment_status_text = '취소됨';
                                                break;
                                            case 'refunded':
                                                $payment_status_class = 'info';
                                                $payment_status_text = '환불됨';
                                                break;
                                            default:
                                                $payment_status_class = 'danger';
                                                $payment_status_text = '오류';
                                        }
                                        ?>
                                        <tr>
                                            <td>
                                                <a href="index.php?page=program_detail&id=<?php echo $reg['program_id']; ?>">
                                                    <?php echo htmlspecialchars($reg['program_title'] ?? $program['title']); ?>
                                                </a>
                                            </td>
                                            <td><?php echo format_date($reg['created_at']); ?></td>
                                            <td><?php echo htmlspecialchars($reg['child_name']); ?></td>
                                            <td><?php echo isset($reg['price']) ? format_price($reg['price']) : (isset($program['price']) ? format_price($program['price']) : '-'); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $payment_status_class; ?>">
                                                    <?php echo $payment_status_text; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if($payment_status == 'pending'): ?>
                                                    <div class="btn-group">
                                                        <?php if(strpos($reg['id'], 'temp_') === 0): ?>
                                                        <!-- 임시 등록 정보의 경우 결제 페이지로 이동 -->
                                                        <a href="index.php?page=payment_popup&program_id=<?php echo $reg['program_id']; ?>" class="btn btn-sm btn-primary">결제하기</a>
                                                        <!-- 임시 등록 정보 취소 버튼 -->
                                                        <a href="index.php?page=cancel_registration&temp_id=<?php echo $reg['id']; ?>" 
                                                           class="btn btn-sm btn-outline-danger"
                                                           onclick="return confirm('정말로 이 프로그램 신청을 취소하시겠습니까?');">취소</a>
                                                        <?php else: ?>
                                                        <!-- 실제 등록 정보의 경우 등록 ID로 결제 페이지 이동 -->
                                                        <a href="index.php?page=payment_popup&registration_id=<?php echo $reg['id']; ?>" class="btn btn-sm btn-primary">결제하기</a>
                                                        <!-- 실제 등록 정보 취소 버튼 -->
                                                        <a href="index.php?page=cancel_registration&registration_id=<?php echo $reg['id']; ?>" 
                                                           class="btn btn-sm btn-outline-danger"
                                                           onclick="return confirm('정말로 이 프로그램 신청을 취소하시겠습니까?');">취소</a>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php elseif($payment_status == 'completed'): ?>
                                                    <a href="index.php?page=program_detail&id=<?php echo $reg['program_id']; ?>" class="btn btn-sm btn-info">프로그램 보기</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>