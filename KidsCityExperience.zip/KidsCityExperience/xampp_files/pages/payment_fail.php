<?php
// payment_fail.php - 결제 실패 처리 페이지

// 토스페이먼츠에서 전달받은 파라미터 확인
$code = isset($_GET['code']) ? $_GET['code'] : '';
$message = isset($_GET['message']) ? $_GET['message'] : '알 수 없는 오류가 발생했습니다.';
$orderId = isset($_GET['orderId']) ? $_GET['orderId'] : '';

// 에러 로그 기록
error_log("결제 실패: 주문번호: {$orderId}, 오류코드: {$code}, 메시지: {$message}");

// 결제 실패 메시지 설정
set_message('결제 중 오류가 발생했습니다: ' . $message, 'danger');

// 마이페이지로 이동
redirect('index.php?page=my_page');
?>