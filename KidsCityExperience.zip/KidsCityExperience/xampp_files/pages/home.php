<?php
// home.php - 메인 홈페이지

// 항상 최신 데이터를 가져오기 위해 직접 데이터베이스 쿼리 실행
$conn = get_db_connection();

// 모집중인 프로그램 가져오기 (간단하고 확실한 방법)
$active_programs = [];
$active_sql = "SELECT 
            p.id, p.title, p.description, p.category_id, p.date, 
            p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
            p.duration, p.status, p.image_path, p.created_at,
            c.name as category_name,
            (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id) as current_participants
            FROM programs p
            LEFT JOIN categories c ON p.category_id = c.id
            ORDER BY p.date ASC";

$active_result = $conn->query($active_sql);
if ($active_result && $active_result->num_rows > 0) {
    while ($row = $active_result->fetch_assoc()) {
        $active_programs[] = $row;
    }
}

// 디버깅: 프로그램 개수 확인
echo "<!-- DEBUG: 전체 프로그램 수: " . count($active_programs) . " -->";
if (!empty($active_programs)) {
    echo "<!-- DEBUG: 첫 번째 프로그램 제목: " . $active_programs[0]['title'] . " -->";
}

// 준비중인 프로그램 직접 조회
$pending_programs = [];
$pending_sql = "SELECT 
                p.id, p.title, p.description, p.category_id, p.date, 
                p.min_age, p.max_age, p.price, p.max_participants, p.min_participants, 
                p.duration, p.status, p.image_path, p.created_at,
                c.name as category_name, 
                COALESCE((SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id), 0) as current_participants
                FROM programs p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.status IN ('pending', '준비중')
                ORDER BY p.date ASC";

$pending_result = $conn->query($pending_sql);
if ($pending_result && $pending_result->num_rows > 0) {
    while ($row = $pending_result->fetch_assoc()) {
        $pending_programs[] = $row;
    }
}

$conn->close();
?>

<style>
.carousel-container {
    overflow: hidden;
    position: relative;
}

.carousel-wrapper {
    display: flex;
    transition: transform 0.3s ease;
    gap: 1rem;
}

.carousel-item {
    flex: 0 0 calc(33.333% - 0.67rem);
    min-width: 0;
}

.carousel-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    z-index: 10;
    border-radius: 50%;
    width: 45px;
    height: 45px;
    padding: 0;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}

.carousel-btn-prev {
    left: -22px;
}

.carousel-btn-next {
    right: -22px;
}

.carousel-btn:hover {
    transform: translateY(-50%) scale(1.1);
}

@media (max-width: 768px) {
    .carousel-item {
        flex: 0 0 calc(50% - 0.5rem);
    }
}

@media (max-width: 576px) {
    .carousel-item {
        flex: 0 0 100%;
    }
}
</style>

<script>
let carouselPosition = {
    active: 0,
    pending: 0
};

function moveCarousel(type, direction) {
    const wrapper = document.getElementById(type + '-wrapper');
    const items = wrapper.querySelectorAll('.carousel-item');
    const totalItems = items.length;
    const visibleItems = window.innerWidth <= 576 ? 1 : (window.innerWidth <= 768 ? 2 : 3);
    const maxPosition = Math.max(0, totalItems - visibleItems);
    
    carouselPosition[type] += direction;
    
    if (carouselPosition[type] < 0) {
        carouselPosition[type] = 0;
    } else if (carouselPosition[type] > maxPosition) {
        carouselPosition[type] = maxPosition;
    }
    
    const translateX = -carouselPosition[type] * (100 / visibleItems);
    wrapper.style.transform = `translateX(${translateX}%)`;
    
    // 버튼 표시/숨김 업데이트
    updateCarouselButtons(type, maxPosition);
}

function updateCarouselButtons(type, maxPosition) {
    const prevBtn = document.querySelector('.carousel-btn-prev');
    const nextBtn = document.querySelector('.carousel-btn-next');
    
    if (prevBtn && nextBtn) {
        prevBtn.style.display = carouselPosition[type] === 0 ? 'none' : 'block';
        nextBtn.style.display = carouselPosition[type] >= maxPosition ? 'none' : 'block';
    }
}

// 윈도우 리사이즈 시 캐러셀 위치 재조정
window.addEventListener('resize', function() {
    ['active', 'pending'].forEach(type => {
        const wrapper = document.getElementById(type + '-wrapper');
        if (wrapper) {
            carouselPosition[type] = 0;
            wrapper.style.transform = 'translateX(0%)';
            
            const items = wrapper.querySelectorAll('.carousel-item');
            const totalItems = items.length;
            const visibleItems = window.innerWidth <= 576 ? 1 : (window.innerWidth <= 768 ? 2 : 3);
            const maxPosition = Math.max(0, totalItems - visibleItems);
            updateCarouselButtons(type, maxPosition);
        }
    });
});

// 모집중인 프로그램 모달 표시 함수
function showActivePrograms() {
    document.getElementById('activeProgramsModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeActivePrograms() {
    document.getElementById('activeProgramsModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// 모달 외부 클릭 시 닫기
window.onclick = function(event) {
    const modal = document.getElementById('activeProgramsModal');
    if (event.target == modal) {
        closeActivePrograms();
    }
}
</script>

<!-- 모집중인 프로그램 모달 -->
<div id="activeProgramsModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-check-circle me-2"></i> 현재 모집중인 프로그램 (<?php echo count($active_programs); ?>개)</h2>
            <button type="button" class="btn btn-outline-secondary" onclick="closeActivePrograms()">
                <i class="fas fa-arrow-left me-1"></i> 뒤로 가기
            </button>
        </div>
        <div class="modal-body">
            <?php if (!empty($active_programs)): ?>
                <div class="row g-4">
                    <?php foreach($active_programs as $program): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 program-card position-relative">
                            <div class="program-status status-active">모집중</div>
                            <img src="<?php echo $base_url; ?>/<?php echo !empty($program['image_path']) ? $program['image_path'] : 'assets/img/program-default.jpg'; ?>" class="card-img-top" alt="<?php echo $program['title']; ?>" onerror="this.src='<?php echo $base_url; ?>/assets/img/program-default.jpg'">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $program['title']; ?></h5>
                                <p class="card-text small">
                                    <?php echo mb_substr($program['description'], 0, 150) . '...'; ?>
                                </p>
                                <div class="d-flex justify-content-between mb-2">
                                    <span><i class="far fa-calendar-alt text-primary me-1"></i> <?php echo format_date($program['date']); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-users text-info me-1"></i> <?php echo $program['current_participants']; ?> / <?php echo $program['max_participants']; ?>명</span>
                                    <span><i class="fas fa-child text-warning me-1"></i> <?php echo $program['min_age']; ?>-<?php echo $program['max_age']; ?>세</span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fw-bold text-primary"><?php echo format_price($program['price']); ?></span>
                                    <a href="index.php?page=program_detail&id=<?php echo $program['id']; ?>" class="btn btn-sm btn-primary">자세히 보기</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info text-center">
                    <i class="fas fa-info-circle me-2"></i> 현재 모집 중인 프로그램이 없습니다.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.modal {
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: #fefefe;
    margin: 2% auto;
    padding: 0;
    border: none;
    border-radius: 10px;
    width: 95%;
    max-width: 1200px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

.modal-header {
    background: linear-gradient(45deg, #28a745, #20c997);
    color: white;
    padding: 20px 30px;
    border-radius: 10px 10px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    margin: 0;
    font-size: 1.5rem;
}

.close {
    color: white;
    font-size: 35px;
    font-weight: bold;
    cursor: pointer;
    line-height: 1;
}

.close:hover {
    opacity: 0.7;
}

.modal-body {
    padding: 30px;
}

.card-header:hover {
    background-color: #1e7e34 !important;
    transition: background-color 0.3s ease;
}
</style>

<div class="container">
    <!-- 히어로 섹션 -->
    <section class="py-5 mb-5">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="display-4 fw-bold mb-4">유아, 어린이를 위한<br>특별한 체험 프로그램</h1>
                <p class="lead mb-4">파주 체험 Camp에서 아이들의 창의력과 상상력을 키우는 다양한 체험 프로그램을 만나보세요.</p>
                <div class="d-flex flex-wrap gap-2">
                    <a href="index.php?page=program_selection" class="btn btn-primary btn-lg">
                        <i class="fas fa-th-list me-2"></i> 프로그램 둘러보기
                    </a>
                    <a href="index.php?page=how_to_use" class="btn btn-outline-primary btn-lg">
                        <i class="fas fa-info-circle me-2"></i> 이용 방법
                    </a>
                </div>
            </div>
            <div class="col-md-6 mt-4 mt-md-0">
                <img src="<?php echo $base_url; ?>/assets/img/hero-image.jpg" alt="유아 어린이 체험 프로그램" class="img-fluid rounded-3 shadow" onerror="this.src='<?php echo $base_url; ?>/assets/img/program-default.jpg'">
            </div>
        </div>
    </section>
    
    <!-- 프로그램 카테고리 섹션 -->
    <section class="mb-5">
        <h2 class="text-center mb-4">체험 프로그램</h2>
        <div class="row g-4">
            <?php
            $categories = get_categories();
            foreach($categories as $category):
            ?>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="display-3 mb-3 text-primary">
                            <?php
                            // 카테고리별 아이콘 표시
                            $icon = "fas fa-seedling";
                            if (strpos(strtolower($category['name']), '영어') !== false) {
                                $icon = "fas fa-book";
                            } else if (strpos(strtolower($category['name']), '신체') !== false) {
                                $icon = "fas fa-running";
                            }
                            ?>
                            <i class="<?php echo $icon; ?>"></i>
                        </div>
                        <h3 class="card-title"><?php echo $category['name']; ?></h3>
                        <p class="card-text"><?php echo $category['description']; ?></p>
                        <a href="index.php?page=program_selection&category=<?php echo $category['id']; ?>" class="btn btn-outline-primary">
                            프로그램 보기
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    
    <!-- 체험 프로그램 섹션 -->
    <section class="mb-5">
        <!-- 모집 중인 프로그램 -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white" style="cursor: pointer;" onclick="showActivePrograms()">
                <h3 class="h5 mb-0">
                    <i class="fas fa-check-circle me-2"></i> 
                    현재 모집중인 프로그램 (<?php echo count($active_programs); ?>개)
                    <i class="fas fa-expand-alt float-end" title="큰 화면으로 보기"></i>
                </h3>
            </div>
            <div class="card-body p-3">
                <?php if (empty($active_programs)): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i> 현재 모집 중인 프로그램이 없습니다.
                    </div>
                <?php else: ?>
                    <!-- 프로그램 컨테이너 (3개만 표시) -->
                    <div class="row g-3">
                        <?php 
                        $displayed_count = 0;
                        foreach($active_programs as $program): 
                            if ($displayed_count >= 3) break;
                        ?>
                        <div class="col-md-4">
                            <div class="card h-100 program-card position-relative">
                                <div class="program-status status-active">모집중</div>
                                <img src="<?php echo $base_url; ?>/<?php echo !empty($program['image_path']) ? $program['image_path'] : 'assets/img/program-default.jpg'; ?>" class="card-img-top" alt="<?php echo $program['title']; ?>" onerror="this.src='<?php echo $base_url; ?>/assets/img/program-default.jpg'">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $program['title']; ?></h5>
                                    <p class="card-text small">
                                        <?php echo mb_substr($program['description'], 0, 100) . '...'; ?>
                                    </p>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span><i class="far fa-calendar-alt text-primary me-1"></i> <?php echo format_date($program['date']); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="fw-bold text-primary"><?php echo format_price($program['price']); ?></span>
                                        <a href="index.php?page=program_detail&id=<?php echo $program['id']; ?>" class="btn btn-sm btn-primary">자세히 보기</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php 
                        $displayed_count++;
                        endforeach; 
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- 준비 중인 프로그램 -->
        <div class="card">
            <div class="card-header bg-warning text-dark">
                <h3 class="h5 mb-0"><i class="fas fa-hourglass-half me-2"></i> 준비중인 프로그램</h3>
            </div>
            <div class="card-body p-3">
                <div class="row g-4">
                    <?php
                    $pending_programs = get_pending_programs(3);
                    
                    if (empty($pending_programs)): 
                    ?>
                    <div class="col-12">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i> 현재 준비 중인 프로그램이 없습니다.
                        </div>
                    </div>
                    <?php else: ?>
                        <?php foreach($pending_programs as $program): ?>
                        <div class="col-md-4">
                            <div class="card h-100 program-card position-relative">
                                <div class="program-status status-pending">준비중</div>
                                <img src="<?php echo $base_url; ?>/<?php echo !empty($program['image_path']) ? $program['image_path'] : 'assets/img/program-default.jpg'; ?>" class="card-img-top" alt="<?php echo $program['title']; ?>" onerror="this.src='<?php echo $base_url; ?>/assets/img/program-default.jpg'">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $program['title']; ?></h5>
                                    <p class="card-text small">
                                        <?php echo mb_substr($program['description'], 0, 100) . '...'; ?>
                                    </p>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span><i class="far fa-calendar-alt text-primary me-1"></i> <?php echo format_date($program['date']); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="fw-bold text-primary"><?php echo format_price($program['price']); ?></span>
                                        <a href="index.php?page=program_detail&id=<?php echo $program['id']; ?>" class="btn btn-sm btn-primary">자세히 보기</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-4">
            <a href="index.php?page=program_selection" class="btn btn-outline-primary">
                모든 프로그램 보기 <i class="fas fa-arrow-right ms-2"></i>
            </a>
        </div>
    </section>
    
    <!-- 프로그램 특징 섹션 -->
    <section class="mb-5 py-5 bg-light rounded-3">
        <div class="text-center mb-5">
            <h2 class="mb-3">파주 체험 Camp의 특별함</h2>
            <p class="lead">아이들의 성장과 발달을 위한 최적의 체험 환경을 제공합니다</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="text-center">
                    <div class="display-4 text-primary mb-3">
                        <i class="fas fa-child"></i>
                    </div>
                    <h3>연령별 맞춤 프로그램</h3>
                    <p>0~24개월 영유아의 발달 단계에 맞춘 체험 활동으로 감각 발달을 촉진합니다.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="display-4 text-primary mb-3">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>소규모 그룹 운영</h3>
                    <p>최대 10명 이내의 소규모 그룹으로 진행되어 아이 한 명 한 명에게 충분한 관심을 기울입니다.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="display-4 text-primary mb-3">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3>안전한 체험 환경</h3>
                    <p>무독성, 친환경 재료만을 사용하며 체계적인 안전 관리로 아이들이 안심하고 체험할 수 있습니다.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- 참여 방법 섹션 -->
    <section class="mb-5">
        <h2 class="text-center mb-4">참여 방법</h2>
        
        <div class="row g-4">
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <span class="fs-4">1</span>
                        </div>
                        <h5 class="card-title">프로그램 선택</h5>
                        <p class="card-text small">다양한 체험 프로그램 중 아이의 연령과 관심사에 맞는 프로그램을 선택하세요.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <span class="fs-4">2</span>
                        </div>
                        <h5 class="card-title">신청서 작성</h5>
                        <p class="card-text small">간단한 신청서 작성으로 프로그램에 참여 신청을 완료합니다.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <span class="fs-4">3</span>
                        </div>
                        <h5 class="card-title">결제 완료</h5>
                        <p class="card-text small">편리한 온라인 결제 시스템으로 간편하게 결제를 진행합니다.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <span class="fs-4">4</span>
                        </div>
                        <h5 class="card-title">체험 참여</h5>
                        <p class="card-text small">예약한 날짜에 방문하여 즐거운 체험 활동에 참여합니다.</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-4">
            <a href="index.php?page=how_to_use" class="btn btn-outline-primary">
                자세한 이용 방법 보기 <i class="fas fa-arrow-right ms-2"></i>
            </a>
        </div>
    </section>
    
    <!-- 신청하기 버튼 -->
    <section class="text-center py-5 mb-5 bg-primary text-white rounded-3">
        <h2 class="mb-3">지금 바로 체험 프로그램에 참여하세요</h2>
        <p class="lead mb-4">아이와 함께하는 특별한 추억을 만들어 드립니다.</p>
        <a href="index.php?page=program_selection" class="btn btn-light btn-lg">
            <i class="fas fa-mouse-pointer me-2"></i> 프로그램 신청하기
        </a>
    </section>
</div>