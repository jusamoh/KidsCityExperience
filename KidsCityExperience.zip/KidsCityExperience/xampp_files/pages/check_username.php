<?php
// check_username.php - 아이디 중복 확인 API
// 이미 헤더가 출력되었으므로 별도의 header 호출 없이 진행

// 헤더 출력 전 버퍼 제거 (헤더와 본문이 섞이는 것 방지)
ob_clean();

// JSON 응답 설정
header('Content-Type: application/json');

$response = ['available' => false];

// GET 파라미터로 전달된 username 가져오기
if(isset($_GET['username'])) {
    $username = $_GET['username'];
    
    // 사용자 이름 검증 (4~20자, 영문자와 숫자만 허용)
    $pattern = '/^[a-zA-Z0-9]{4,20}$/';
    if (!preg_match($pattern, $username)) {
        $response['message'] = '아이디는 영문자와 숫자로 4~20자 이내로 입력하세요.';
        echo json_encode($response);
        exit;
    }
    
    // 데이터베이스에서 중복 확인
    $is_available = !check_username_exists($username);
    
    if($is_available) {
        $response = [
            'available' => true,
            'message' => '사용 가능한 아이디입니다.'
        ];
    } else {
        $response = [
            'available' => false,
            'message' => '이미 사용중인 아이디입니다.'
        ];
    }
}

echo json_encode($response);
// 스크립트 종료로 다른 출력물이 섞이지 않도록 함
exit;
?>