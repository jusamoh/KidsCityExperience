<?php
// update_program.php - 프로그램 수정 처리 페이지

// 관리자 권한 확인
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    redirect($base_url . '/index.php?page=login');
    exit;
}

// POST 요청 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_program') {
    // 폼 데이터 가져오기
    $program_id = isset($_POST['program_id']) ? intval($_POST['program_id']) : 0;
    $title = isset($_POST['title']) ? $_POST['title'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $price = isset($_POST['price']) ? intval($_POST['price']) : 0;
    
    // 데이터베이스 컬럼명에 맞게 변수명 조정
    $max_participants = isset($_POST['max_participants']) ? intval($_POST['max_participants']) : 0; 
    $min_participants = isset($_POST['min_participants']) ? intval($_POST['min_participants']) : 0;
    
    // 데이터베이스 연결
    $conn = get_db_connection();
    
    // 디버깅용 로그
    error_log("프로그램 수정 요청: ID=$program_id, 제목=$title, 상태=$status");
    
    // 프로그램 존재 여부 확인
    $check_sql = "SELECT * FROM programs WHERE id = {$program_id}";
    $check_result = $conn->query($check_sql);
    
    if (!($check_result && $check_result->num_rows > 0)) {
        set_message('프로그램을 찾을 수 없습니다.', 'danger');
        redirect($base_url . '/index.php?page=edit_programs');
        exit;
    }
    
    // 기존 프로그램 데이터
    $existing_program = $check_result->fetch_assoc();
    
    // 기본 검증
    if (empty($title) || empty($description) || $category_id <= 0 || empty($status) || empty($date) || $price < 0) {
        set_message('모든 필수 필드를 채워주세요.', 'danger');
        redirect($base_url . '/index.php?page=edit_programs');
        exit;
    }
    
    // 데이터 이스케이프 처리
    $title = $conn->real_escape_string($title);
    $description = $conn->real_escape_string($description);
    $status = $conn->real_escape_string($status);
    
    // 날짜 형식 변환 (YYYY-MM-DD HH:MM:SS)
    try {
        $date_obj = new DateTime($date);
        $date = $date_obj->format('Y-m-d H:i:s');
    } catch (Exception $e) {
        set_message('날짜 형식이 올바르지 않습니다.', 'danger');
        redirect($base_url . '/index.php?page=edit_programs');
        exit;
    }
    
    $date = $conn->real_escape_string($date);
    
    // 이미지 업로드 처리
    $image_updated = false;
    $image_path = $existing_program['image_path']; // 기본값으로 기존 이미지 경로 사용
    
    if (isset($_FILES['program_image']) && $_FILES['program_image']['error'] != UPLOAD_ERR_NO_FILE) {
        // 이미지가 선택된 경우
        if ($_FILES['program_image']['error'] == UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            $file_type = $_FILES['program_image']['type'];
            
            if (in_array($file_type, $allowed_types)) {
                // 절대 경로로 디렉토리 설정
                $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/paju/uploads/programs/';
                
                // 디렉토리가 없으면 생성 (상대 경로로 접근 가능하도록)
                if (!file_exists('uploads/programs/')) {
                    mkdir('uploads/programs/', 0777, true);
                }
                
                $file_name = basename($_FILES['program_image']['name']);
                $file_name = preg_replace('/[^a-zA-Z0-9가-힣._-]/', '', $file_name);
                $file_name = time() . '_' . $file_name;
                $file_path = $upload_dir . $file_name;
                
                // 파일 업로드
                if (move_uploaded_file($_FILES['program_image']['tmp_name'], $file_path)) {
                    // 업로드 성공, 저장할 경로 설정 (상대 경로로 저장)
                    $image_path = 'uploads/programs/' . $file_name;
                    $image_updated = true;
                    error_log("이미지 업로드 성공: $image_path");
                } else {
                    $error_message = '파일 업로드 실패: ' . error_get_last()['message'];
                    error_log($error_message);
                    set_message($error_message, 'warning');
                }
            } else {
                set_message('허용되지 않는 파일 형식입니다. JPG, JPEG, PNG, GIF 파일만 업로드 가능합니다.', 'warning');
            }
        } else {
            $error_code = $_FILES['program_image']['error'];
            $error_message = '파일 업로드 오류 (코드: ' . $error_code . ')';
            error_log($error_message);
            set_message($error_message, 'warning');
        }
    }
    
    // 데이터베이스 테이블 구조 확인 (필요한 컬럼 존재 여부 확인)
    $check_max = $conn->query("SHOW COLUMNS FROM programs LIKE 'max_participants'");
    $has_max = $check_max && $check_max->num_rows > 0;
    
    $check_min = $conn->query("SHOW COLUMNS FROM programs LIKE 'min_participants'");
    $has_min = $check_min && $check_min->num_rows > 0;
    
    $check_min_age = $conn->query("SHOW COLUMNS FROM programs LIKE 'min_age'");
    $has_min_age = $check_min_age && $check_min_age->num_rows > 0;
    
    $check_max_age = $conn->query("SHOW COLUMNS FROM programs LIKE 'max_age'");
    $has_max_age = $check_max_age && $check_max_age->num_rows > 0;
    
    // 기본 쿼리 구성
    $sql = "UPDATE programs SET 
            title = '{$title}',
            description = '{$description}',
            category_id = {$category_id},
            status = '{$status}',
            date = '{$date}',
            price = {$price}";
    
    // 각 컬럼이 있는 경우에만 추가
    if ($has_max) {
        $sql .= ", max_participants = {$max_participants}";
    }
    
    if ($has_min) {
        $sql .= ", min_participants = {$min_participants}";
    }
    
    // 새 이미지가 업로드된 경우에만 이미지 경로 업데이트
    if ($image_updated) {
        $image_path = $conn->real_escape_string($image_path);
        $sql .= ", image_path = '{$image_path}'";
    }
    
    $sql .= " WHERE id = {$program_id}";
    
    // 디버깅
    error_log("SQL 쿼리: " . $sql);
    
    // 쿼리 실행
    if ($conn->query($sql)) {
        set_message('프로그램이 성공적으로 업데이트되었습니다.', 'success');
        
        // 카테고리 변경 기록 (외부 DB용)
        try {
            if (function_exists('saveCategoryChange')) {
                saveCategoryChange($program_id, $category_id);
            }
        } catch (Exception $e) {
            error_log('카테고리 변경 기록 실패: ' . $e->getMessage());
            set_message('외부 데이터베이스 업데이트 중 오류가 발생했습니다.', 'warning');
        }
    } else {
        error_log("SQL 오류: " . $conn->error);
        set_message('프로그램 업데이트 중 오류가 발생했습니다: ' . $conn->error, 'danger');
    }
    
    $conn->close();
    
    // 성공 여부와 관계없이 목록 페이지로 리다이렉트
    redirect($base_url . '/index.php?page=edit_programs');
    exit;
} else {
    // 잘못된 접근
    set_message('잘못된 접근입니다.', 'danger');
    redirect($base_url . '/index.php?page=edit_programs');
    exit;
}