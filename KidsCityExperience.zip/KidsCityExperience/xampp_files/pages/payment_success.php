<?php
// payment_success.php - 결제 성공 처리 페이지

// 토스페이먼츠에서 전달받은 파라미터 확인
$paymentKey = isset($_GET['paymentKey']) ? $_GET['paymentKey'] : '';
$orderId = isset($_GET['orderId']) ? $_GET['orderId'] : '';
$amount = isset($_GET['amount']) ? intval($_GET['amount']) : 0;

// 결제 정보 검증
if (empty($paymentKey) || empty($orderId) || $amount <= 0) {
    set_message('결제 정보가 올바르지 않습니다.', 'danger');
    redirect('index.php?page=my_page');
    exit;
}

// 데이터베이스 연결
$conn = get_db_connection();

// 결제 정보 조회
$sql = "SELECT * FROM payments WHERE order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $orderId);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $payment = $result->fetch_assoc();
    
    // 이미 처리된 결제인지 확인
    if ($payment['status'] === 'completed') {
        set_message('이미 처리된 결제입니다.', 'info');
        redirect('index.php?page=my_page');
        exit;
    }
    
    // 금액 검증
    if ($payment['amount'] != $amount) {
        set_message('결제 금액이 일치하지 않습니다.', 'danger');
        redirect('index.php?page=my_page');
        exit;
    }
    
    // 토스페이먼츠 API로 결제 승인 요청
    $secretKey = getenv('TOSS_PAYMENTS_SECRET_KEY') ?: 'test_sk_O6BYq7GWPVvN4JbxAMwVN5E1yNZJ';
    
    // Basic Auth 헤더 생성
    $authorization = base64_encode($secretKey . ':');
    
    // API 엔드포인트 URL
    $url = 'https://api.tosspayments.com/v1/payments/' . $paymentKey;
    
    // CURL 요청 초기화
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Basic ' . $authorization,
        'Content-Type: application/json'
    ));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
        'orderId' => $orderId,
        'amount' => $amount
    )));
    
    // API 요청 실행
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    // CURL 오류 확인
    if (curl_errno($ch)) {
        error_log('Curl error: ' . curl_error($ch));
        set_message('결제 승인 중 오류가 발생했습니다: ' . curl_error($ch), 'danger');
        redirect('index.php?page=my_page');
        exit;
    }
    
    curl_close($ch);
    
    // API 응답 처리
    $responseData = json_decode($response, true);
    
    // 응답 확인
    if ($httpCode >= 200 && $httpCode < 300 && isset($responseData['paymentKey'])) {
        // 결제 정보 업데이트
        $sql = "UPDATE payments SET 
                payment_key = ?, 
                payment_method = ?, 
                status = 'completed', 
                paid_at = NOW()
                WHERE order_id = ?";
                
        $stmt = $conn->prepare($sql);
        $paymentMethod = $responseData['method'] ?? '';
        $stmt->bind_param("sss", $paymentKey, $paymentMethod, $orderId);
        $stmt->execute();
        
        // 등록 정보 업데이트
        // 일괄 결제인지 확인 (order_id가 'BATCH_'로 시작하는지 확인)
        if (strpos($orderId, 'BATCH_') === 0) {
            // 일괄 결제인 경우
            // 결제와 연결된 등록 ID 목록 가져오기
            $sql = "SELECT registration_ids FROM payments WHERE order_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $orderId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $paymentData = $result->fetch_assoc();
                $registrationIds = $paymentData['registration_ids'];
                
                if (!empty($registrationIds)) {
                    // 콤마로 구분된 등록 ID를 배열로 변환
                    $registrationIdArray = explode(',', $registrationIds);
                    
                    foreach ($registrationIdArray as $registrationId) {
                        // 각 등록 정보 업데이트
                        $sql = "UPDATE registrations SET 
                                payment_status = 'completed',
                                updated_at = NOW()
                                WHERE id = ?";
                                
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $registrationId);
                        $stmt->execute();
                        
                        // 프로그램 참가자 수 갱신
                        $sql = "SELECT program_id FROM registrations WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $registrationId);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result && $result->num_rows > 0) {
                            $registration = $result->fetch_assoc();
                            $programId = $registration['program_id'];
                            
                            // 프로그램 상태 업데이트
                            if (function_exists('update_program_status_by_registration')) {
                                update_program_status_by_registration($programId);
                            }
                        }
                    }
                }
            }
        } else {
            // 단일 결제인 경우 (기존 코드)
            $registrationId = $payment['registration_id'];
            if ($registrationId) {
                $sql = "UPDATE registrations SET 
                        payment_status = 'completed',
                        updated_at = NOW()
                        WHERE id = ?";
                        
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $registrationId);
                $stmt->execute();
                
                // 프로그램 참가자 수 갱신 함수 호출 (있는 경우)
                $sql = "SELECT program_id FROM registrations WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $registrationId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result && $result->num_rows > 0) {
                    $registration = $result->fetch_assoc();
                    $programId = $registration['program_id'];
                    
                    // 프로그램 상태 업데이트 함수가 있는 경우 호출
                    if (function_exists('update_program_status_by_registration')) {
                        update_program_status_by_registration($programId);
                    }
                }
            }
        }
        
        // 성공 메시지 설정
        set_message('결제가 성공적으로 완료되었습니다.', 'success');
    } else {
        // 오류 메시지
        $errorMessage = isset($responseData['message']) ? $responseData['message'] : '알 수 없는 오류가 발생했습니다.';
        set_message('결제 승인 중 오류가 발생했습니다: ' . $errorMessage, 'danger');
        error_log('Payment API Error: ' . $response);
    }
} else {
    set_message('결제 정보를 찾을 수 없습니다.', 'danger');
}

$conn->close();

// 마이페이지로 이동
redirect('index.php?page=my_page');
?>