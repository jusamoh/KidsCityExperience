<?php
// program_registration_detail.php - 프로그램별 신청자 목록 페이지

// 관리자 권한 확인
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    redirect($base_url . '/index.php?page=login');
    exit;
}

// 프로그램 ID 가져오기
$program_id = isset($_GET['program_id']) ? intval($_GET['program_id']) : 0;

// 프로그램 정보 가져오기
$program = get_program($program_id);

// 프로그램이 없으면 관리자 대시보드로 리다이렉트
if (!$program) {
    set_message('존재하지 않는 프로그램입니다.', 'danger');
    redirect($base_url . '/index.php?page=admin_dashboard');
    exit;
}

// 프로그램의 신청자 목록 가져오기
$registrations = get_program_registrations($program_id);

// 총 신청자 수와 결제 완료 수 계산
$total_registrations = count($registrations);
$paid_registrations = 0;

foreach ($registrations as $reg) {
    if ($reg['payment_status'] == 'paid' || $reg['payment_status'] == 'completed') {
        $paid_registrations++;
    }
}

// 프로그램 확정 여부 계산
$is_confirmed = ($program['status'] == 'active' && $paid_registrations >= $program['min_participants']);
?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>프로그램 신청자 목록</h2>
        <a href="<?php echo $base_url; ?>/index.php?page=admin_dashboard" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i> 관리자 대시보드로 돌아가기
        </a>
    </div>
    
    <!-- 프로그램 정보 카드 -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0"><?php echo $program['title']; ?></h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>카테고리:</strong> <?php echo $program['category_name']; ?></p>
                    <p><strong>일자:</strong> <?php echo format_date($program['date']); ?></p>
                    <p><strong>가격:</strong> <?php echo format_price($program['price']); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>상태:</strong> 
                        <?php if($program['status'] == 'active'): ?>
                            <span class="badge bg-success">모집중</span>
                        <?php elseif($program['status'] == 'pending'): ?>
                            <span class="badge bg-warning text-dark">준비중</span>
                        <?php elseif($program['status'] == 'completed'): ?>
                            <span class="badge bg-secondary">종료됨</span>
                        <?php elseif($program['status'] == 'canceled'): ?>
                            <span class="badge bg-danger">취소됨</span>
                        <?php else: ?>
                            <span class="badge bg-secondary"><?php echo $program['status']; ?></span>
                        <?php endif; ?>
                    </p>
                    <p><strong>프로그램 확정 여부:</strong> 
                        <?php if($is_confirmed): ?>
                            <span class="badge bg-success">확정</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">미확정</span>
                        <?php endif; ?>
                    </p>
                    <p><strong>신청 현황:</strong> <?php echo $total_registrations; ?>/<?php echo $program['max_participants']; ?> (결제완료: <?php echo $paid_registrations; ?>/<?php echo $program['min_participants']; ?> 최소)</p>
                </div>
            </div>
            
            <!-- 신청 현황 프로그레스 바 -->
            <div class="mt-3">
                <h6>신청 현황</h6>
                <div class="progress mb-3" style="height: 15px;">
                    <?php $percentage = ($total_registrations / $program['max_participants']) * 100; ?>
                    <div class="progress-bar" role="progressbar" style="width: <?php echo $percentage; ?>%;" 
                        aria-valuenow="<?php echo $total_registrations; ?>" 
                        aria-valuemin="0" 
                        aria-valuemax="<?php echo $program['max_participants']; ?>">
                        <?php echo $total_registrations; ?>/<?php echo $program['max_participants']; ?>
                    </div>
                </div>
                
                <h6>결제 현황</h6>
                <div class="progress" style="height: 15px;">
                    <?php 
                    $percentage = ($program['min_participants'] > 0) ? 
                        ($paid_registrations / $program['min_participants']) * 100 : 0; 
                    $bg_class = $percentage >= 100 ? 'bg-success' : 'bg-primary';
                    ?>
                    <div class="progress-bar <?php echo $bg_class; ?>" role="progressbar" style="width: <?php echo min(100, $percentage); ?>%;" 
                        aria-valuenow="<?php echo $paid_registrations; ?>" 
                        aria-valuemin="0" 
                        aria-valuemax="<?php echo $program['min_participants']; ?>">
                        <?php echo $paid_registrations; ?>/<?php echo $program['min_participants']; ?> (최소)
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 신청자 목록 테이블 -->
    <div class="card shadow-sm">
        <div class="card-header bg-light">
            <h5 class="mb-0">신청자 목록 (<?php echo $total_registrations; ?>명)</h5>
        </div>
        <div class="card-body">
            <?php if ($total_registrations > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>아동 이름</th>
                            <th>아동 연령</th>
                            <th>보호자 이름</th>
                            <th>연락처</th>
                            <th>이메일</th>
                            <th>신청일</th>
                            <th>결제 상태</th>
                            <th>결제 금액</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($registrations as $reg): ?>
                        <tr>
                            <td><?php echo $reg['id']; ?></td>
                            <td><?php echo $reg['child_name']; ?></td>
                            <td><?php echo $reg['child_age']; ?>개월</td>
                            <td><?php echo $reg['parent_name']; ?></td>
                            <td><?php echo $reg['phone']; ?></td>
                            <td><?php echo $reg['email']; ?></td>
                            <td><?php echo date('Y-m-d', strtotime($reg['created_at'])); ?></td>
                            <td>
                                <?php if($reg['payment_status'] == 'paid' || $reg['payment_status'] == 'completed'): ?>
                                    <span class="badge bg-success">결제 완료</span>
                                <?php elseif($reg['payment_status'] == 'ready'): ?>
                                    <span class="badge bg-warning text-dark">결제 대기</span>
                                <?php elseif($reg['payment_status'] == 'canceled'): ?>
                                    <span class="badge bg-danger">결제 취소</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">미결제</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php 
                                if ($reg['paid_amount']) {
                                    echo format_price($reg['paid_amount']);
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="alert alert-info">
                아직 이 프로그램에 신청한 사용자가 없습니다.
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>