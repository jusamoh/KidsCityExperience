<?php
// edit_profile.php - 사용자 정보 수정 페이지
// 로그인 확인은 index.php에서 처리됨

// 사용자 정보 가져오기
$user_id = $_SESSION['user_id'];
$user = get_user($user_id);

// 업데이트 메시지
$update_message = '';

// 폼 제출 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 폼 데이터 가져오기
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    
    // 간단한 유효성 검사
    $errors = [];
    
    // 이메일 형식 확인
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = '유효한 이메일 주소를 입력해주세요.';
    }
    
    // 휴대폰 번호 형식 확인 (간단한 정규식)
    if (!empty($phone) && !preg_match('/^[0-9]{2,3}-?[0-9]{3,4}-?[0-9]{4}$/', $phone)) {
        $errors[] = '유효한 휴대폰 번호를 입력해주세요. (예: 010-1234-5678)';
    }
    
    // 오류가 없으면 사용자 정보 업데이트
    if (empty($errors)) {
        // 현재 users 테이블에 name, email, phone 필드가 있는지 확인
        $conn = get_db_connection();
        $columns = [];
        $result = $conn->query("SHOW COLUMNS FROM users");
        while ($row = $result->fetch_assoc()) {
            $columns[] = $row['Field'];
        }
        
        // 필드가 없으면 추가
        if (!in_array('name', $columns)) {
            $conn->query("ALTER TABLE users ADD COLUMN name VARCHAR(100) DEFAULT NULL");
        }
        if (!in_array('email', $columns)) {
            $conn->query("ALTER TABLE users ADD COLUMN email VARCHAR(255) DEFAULT NULL");
        }
        if (!in_array('phone', $columns)) {
            $conn->query("ALTER TABLE users ADD COLUMN phone VARCHAR(20) DEFAULT NULL");
        }
        
        // 사용자 정보 업데이트
        $user_id = $_SESSION['user_id'];
        $name = $conn->real_escape_string($name);
        $email = $conn->real_escape_string($email);
        $phone = $conn->real_escape_string($phone);
        
        $sql = "UPDATE users SET name = '{$name}', email = '{$email}', phone = '{$phone}' WHERE id = {$user_id}";
        $result = $conn->query($sql);
        
        if ($result) {
            $update_message = '<div class="alert alert-success">회원 정보가 성공적으로 업데이트되었습니다.</div>';
            // 업데이트된 사용자 정보 다시 가져오기
            $user = get_user($user_id);
        } else {
            $update_message = '<div class="alert alert-danger">회원 정보 업데이트 중 오류가 발생했습니다.</div>';
        }
        
        $conn->close();
    }
}
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">회원 정보 수정</h4>
                </div>
                <div class="card-body">
                    <?php 
                    // 업데이트 메시지 표시
                    echo $update_message;
                    
                    // 오류 메시지 표시
                    if (!empty($errors)): 
                    ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <form method="post" action="">
                        <div class="mb-3">
                            <label for="username" class="form-label">아이디</label>
                            <input type="text" class="form-control" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                            <small class="text-muted">아이디는 변경할 수 없습니다.</small>
                        </div>
                        <div class="mb-3">
                            <label for="name" class="form-label">이름</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">이메일</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">휴대폰 번호</label>
                            <input type="tel" class="form-control" id="phone" name="phone" placeholder="010-0000-0000" value="<?php echo htmlspecialchars($user['phone']); ?>">
                        </div>
                        <div class="d-flex justify-content-between">
                            <a href="index.php?page=my_page" class="btn btn-outline-secondary">취소</a>
                            <button type="submit" class="btn btn-primary">정보 수정</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>