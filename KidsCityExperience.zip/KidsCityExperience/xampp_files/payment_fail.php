<?php
require_once 'config.php';
$currentPage = 'payment_fail';

// 주문 ID 확인
$orderId = isset($_GET['orderId']) ? $_GET['orderId'] : '';
$errorMessage = isset($_GET['message']) ? $_GET['message'] : '결제 처리 중 오류가 발생했습니다.';
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>결제 실패 - 키즈 익스플로러</title>
    <meta name="description" content="프로그램 신청 결제가 실패했습니다.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            color: #333;
            background-color: #f9f9f9;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
        }
        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
            color: #f05a7a;
        }
        .nav-link {
            font-weight: 600;
            color: #333;
            margin: 0 10px;
        }
        .nav-link:hover {
            color: #f05a7a;
        }
        .fail-header {
            background: linear-gradient(to right, #f05a7a, #ff8a65);
            color: white;
            padding: 50px 0;
            margin-bottom: 30px;
        }
        .fail-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .btn-primary {
            background-color: #f05a7a;
            border-color: #f05a7a;
        }
        .btn-primary:hover {
            background-color: #d84a68;
            border-color: #d84a68;
        }
        .icon-error {
            width: 80px;
            height: 80px;
            background-color: #ffe0e0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
        }
        .icon-error svg {
            width: 40px;
            height: 40px;
            fill: #ff4a4a;
        }
        .footer {
            background-color: #333;
            color: #f9f9f9;
            padding: 50px 0;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">키즈 익스플로러</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">홈</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="programs.php">프로그램</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">소개</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">로그인</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="fail-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-5 fw-bold">결제가 실패했습니다</h1>
                    <p class="lead">프로그램 결제 중 문제가 발생했습니다.</p>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="fail-content text-center">
                    <div class="icon-error">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 11c-.55 0-1-.45-1-1V8c0-.55.45-1 1-1s1 .45 1 1v4c0 .55-.45 1-1 1zm1 4h-2v-2h2v2z"/>
                        </svg>
                    </div>
                    
                    <h2 class="mb-4">결제 실패</h2>
                    <p class="lead mb-4"><?= htmlspecialchars($errorMessage) ?></p>
                    
                    <?php if ($orderId): ?>
                    <div class="mb-4">
                        <p>주문번호: <strong><?= htmlspecialchars($orderId) ?></strong></p>
                    </div>
                    <?php endif; ?>
                    
                    <div class="alert alert-info mb-4">
                        <p class="mb-0">다시 시도하거나 다른 결제 수단으로 진행해 주세요. 문제가 계속되면 고객센터로 문의해 주세요.</p>
                    </div>
                    
                    <div class="d-grid gap-3 col-md-8 mx-auto">
                        <?php if ($orderId): ?>
                            <?php
                            // 주문 ID로 등록 정보 조회
                            $stmt = $pdo->prepare("SELECT r.program_id 
                                                FROM payments p 
                                                JOIN registrations r ON p.registration_id = r.id 
                                                WHERE p.order_id = ?");
                            $stmt->execute([$orderId]);
                            $registration = $stmt->fetch();
                            
                            if ($registration):
                            ?>
                                <a href="program_detail.php?id=<?= $registration['program_id'] ?>" class="btn btn-primary">프로그램 페이지로 돌아가기</a>
                            <?php else: ?>
                                <a href="index.php" class="btn btn-primary">홈으로 돌아가기</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="index.php" class="btn btn-primary">홈으로 돌아가기</a>
                        <?php endif; ?>
                        <a href="contact.php" class="btn btn-outline-secondary">고객센터 문의</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h3>키즈 익스플로러</h3>
                    <p>아이의 호기심과 발달을 돕는 체험 프로그램</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h4>링크</h4>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white">홈</a></li>
                        <li><a href="programs.php" class="text-white">프로그램</a></li>
                        <li><a href="about.php" class="text-white">소개</a></li>
                        <li><a href="contact.php" class="text-white">문의하기</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h4>연락처</h4>
                    <p>서울특별시 강남구 123번길 45<br>
                    전화: 02-123-4567<br>
                    이메일: info@kidsexplorer.kr</p>
                </div>
            </div>
            <hr class="mt-4 mb-4 bg-light">
            <div class="text-center">
                <p>© 2025 키즈 익스플로러. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>