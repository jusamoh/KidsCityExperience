# 파주 체험 Camp - XAMPP용 설치 가이드

## 소개
이 폴더에는 XAMPP 환경에서 실행하기 위해 최적화된 파주 체험 Camp 웹사이트의 PHP 버전이 포함되어 있습니다.
기존의 Node.js/React 기반 코드를 순수 PHP, HTML, CSS로 변환하여 XAMPP에서 쉽게 실행할 수 있도록 했습니다.

## 설치 방법

1. XAMPP 설치
   - XAMPP가 아직 설치되지 않은 경우 [XAMPP 웹사이트](https://www.apachefriends.org/)에서 다운로드하여 설치하세요.

2. 파일 복사
   - `xampp_files` 폴더의 내용을 `C:\xampp\htdocs\paju` 폴더에 복사하세요.
   - 폴더가 없는 경우 직접 생성하세요: `C:\xampp\htdocs\paju`

3. XAMPP 실행
   - XAMPP Control Panel을 실행합니다.
   - Apache와 MySQL 서비스를 시작합니다.

4. 웹사이트 접속
   - 웹 브라우저를 열고 `http://localhost/paju` 주소로 접속합니다.
   - 첫 접속 시 자동으로 필요한 데이터베이스와 테이블이 생성됩니다.

## 관리자 계정 정보
- 사용자명: admin
- 비밀번호: admin

## 주요 기능
- 카테고리별 프로그램 필터링
- 카테고리 관리 (관리자용)
- 프로그램 신청 및 결제
- 사용자 관리
- 검색 기능

## 파일 및 폴더 구조
- `index.php`: 메인 진입점
- `config/`: 데이터베이스 연결 및 설정 파일
- `includes/`: 공통 함수 및 헤더/푸터 파일
- `pages/`: 각 페이지 관련 PHP 파일
- `assets/`: CSS, JavaScript, 이미지 파일

## 문제 해결
- 데이터베이스 연결 오류: XAMPP Control Panel에서 MySQL이 실행 중인지 확인하세요.
- 권한 오류: 폴더 권한을 확인하세요. `assets/img` 폴더는 쓰기 권한이 필요합니다.
- PHP 버전: PHP 7.4 이상을 사용하세요.

## 기술 스택
- PHP 7.4+
- MySQL
- HTML5
- CSS3
- JavaScript
- Bootstrap 5

이 설치 가이드에 대해 질문이 있으시면 연락주세요.