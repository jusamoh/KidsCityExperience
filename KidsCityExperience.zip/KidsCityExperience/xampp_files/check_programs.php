<?php
// check_programs.php - 프로그램 개수 확인 스크립트
include 'config/database.php';
include 'includes/functions.php';

$conn = get_db_connection();

// 전체 프로그램 수
$total_sql = "SELECT COUNT(*) as total FROM programs";
$total_result = $conn->query($total_sql);
$total_count = $total_result ? $total_result->fetch_assoc()['total'] : 0;

// 모집중인 프로그램 수 (다양한 상태값 확인)
$active_sql = "SELECT COUNT(*) as count, status FROM programs GROUP BY status";
$active_result = $conn->query($active_sql);

echo "<h2>XAMPP 환경 프로그램 현황</h2>";
echo "<p><strong>전체 프로그램 수:</strong> {$total_count}개</p>";

echo "<h3>상태별 프로그램 개수:</h3>";
if ($active_result && $active_result->num_rows > 0) {
    echo "<ul>";
    while ($row = $active_result->fetch_assoc()) {
        echo "<li><strong>{$row['status']}:</strong> {$row['count']}개</li>";
    }
    echo "</ul>";
}

// 모집중 상태로 간주되는 프로그램들
$recruiting_sql = "SELECT id, title, status FROM programs WHERE status IN ('active', '모집중') OR status LIKE '%모집%'";
$recruiting_result = $conn->query($recruiting_sql);

if ($recruiting_result && $recruiting_result->num_rows > 0) {
    echo "<h3>모집중인 프로그램 목록 ({$recruiting_result->num_rows}개):</h3>";
    echo "<ol>";
    while ($row = $recruiting_result->fetch_assoc()) {
        echo "<li>ID: {$row['id']}, 제목: {$row['title']}, 상태: {$row['status']}</li>";
    }
    echo "</ol>";
} else {
    echo "<p><strong>모집중인 프로그램이 없습니다.</strong></p>";
}

$conn->close();
?>