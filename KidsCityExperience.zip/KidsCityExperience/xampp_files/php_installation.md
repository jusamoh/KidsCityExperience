# XAMPP에 파주 체험 Camp 설치 가이드

## 폴더 구조 설정

1. XAMPP의 `htdocs` 폴더에 `paju` 폴더를 생성합니다:
   ```
   C:\xampp\htdocs\paju
   ```

2. 다음 폴더를 생성합니다:
   ```
   C:\xampp\htdocs\paju\assets     # 이미지, CSS, JavaScript 파일
   C:\xampp\htdocs\paju\config     # 데이터베이스 설정
   C:\xampp\htdocs\paju\includes   # 공통 함수와 클래스
   C:\xampp\htdocs\paju\pages      # 페이지 파일
   ```

## 데이터베이스 설정

1. XAMPP Control Panel에서 MySQL 서비스를 시작합니다.
2. MySQL Admin 버튼을 클릭하여 phpMyAdmin을 엽니다.
3. 왼쪽 패널에서 "New" 클릭 → 데이터베이스 이름으로 "paju_db" 입력 → "Create" 버튼 클릭

## 파일 복사

1. 제공된 파일들을 각 폴더에 복사합니다.
2. 웹브라우저에서 `http://localhost/paju` 주소로 접속합니다.

## 데이터베이스 테이블 생성

웹 페이지 첫 실행 시 필요한 테이블이 자동 생성됩니다. 또는 아래 SQL 스크립트를 실행할 수 있습니다:

```sql
-- phpMyAdmin에서 실행할 SQL 스크립트

-- 카테고리 테이블
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 프로그램 테이블
CREATE TABLE IF NOT EXISTS programs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  category_id INT NOT NULL,
  date DATE,
  location VARCHAR(255),
  min_age INT DEFAULT 0,
  max_age INT DEFAULT 24,
  price DECIMAL(10,2),
  status VARCHAR(50) DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (category_id)
);

-- 카테고리 변경 기록 테이블
CREATE TABLE IF NOT EXISTS program_categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  program_id INT NOT NULL,
  category_id INT NOT NULL,
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (program_id),
  INDEX (category_id)
);

-- 사용자 테이블
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  is_admin TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 기본 관리자 계정 생성
INSERT INTO users (username, password, is_admin) VALUES ('admin', '$2y$10$3UqF0kbj.W9gQP37h1dvXOf7K7HH0kJ65M1zQfZD7.RKoBq1YXTV.', 1);
-- 비밀번호: admin
```