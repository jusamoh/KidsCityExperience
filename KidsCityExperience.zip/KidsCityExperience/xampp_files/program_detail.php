<?php
require_once 'config.php';
$currentPage = 'program_detail';

// 프로그램 ID 확인
$programId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($programId <= 0) {
    header('Location: index.php');
    exit;
}

// 프로그램 정보 조회
$stmt = $pdo->prepare("SELECT p.*, c.name as category_name, 
                       (SELECT COUNT(*) FROM registrations r WHERE r.program_id = p.id AND r.payment_status = 'paid') as current_participants 
                       FROM programs p 
                       JOIN categories c ON p.category_id = c.id 
                       WHERE p.id = ?");
$stmt->execute([$programId]);
$program = $stmt->fetch();

if (!$program) {
    header('Location: index.php');
    exit;
}

// 프로그램 진행 가능성 계산
$progressPercentage = min(100, ($program['current_participants'] / $program['min_participants']) * 100);
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($program['title']) ?> - 키즈 익스플로러</title>
    <meta name="description" content="<?= htmlspecialchars(substr($program['description'], 0, 150)) ?>...">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            color: #333;
            background-color: #f9f9f9;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
        }
        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
            color: #f05a7a;
        }
        .nav-link {
            font-weight: 600;
            color: #333;
            margin: 0 10px;
        }
        .nav-link:hover {
            color: #f05a7a;
        }
        .program-header {
            background: linear-gradient(to right, #4ecdc4, #f05a7a);
            color: white;
            padding: 50px 0;
            margin-bottom: 30px;
        }
        .program-image {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .program-info {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .program-description {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .program-register {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            position: sticky;
            top: 100px;
        }
        .info-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .info-item:last-child {
            border-bottom: none;
        }
        .status-badge {
            border-radius: 20px;
            padding: 5px 12px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            margin-bottom: 10px;
        }
        .status-confirmed {
            background-color: #d4f7e8;
            color: #16a868;
        }
        .status-pending {
            background-color: #fff1d0;
            color: #ffa600;
        }
        .status-canceled {
            background-color: #ffe0e0;
            color: #ff4a4a;
        }
        .btn-primary {
            background-color: #f05a7a;
            border-color: #f05a7a;
        }
        .btn-primary:hover {
            background-color: #d84a68;
            border-color: #d84a68;
        }
        .progress-container {
            width: 100%;
            background-color: #e0e0e0;
            border-radius: 10px;
            margin: 10px 0;
        }
        .progress-bar {
            height: 10px;
            border-radius: 10px;
            background: linear-gradient(to right, #4ecdc4, #f05a7a);
        }
        .footer {
            background-color: #333;
            color: #f9f9f9;
            padding: 50px 0;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">키즈 익스플로러</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">홈</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="programs.php">프로그램</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">소개</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">로그인</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="program-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <?php if ($program['status'] === 'confirmed'): ?>
                        <span class="status-badge status-confirmed">확정된 프로그램</span>
                    <?php elseif ($program['status'] === 'pending'): ?>
                        <span class="status-badge status-pending">모집중</span>
                    <?php else: ?>
                        <span class="status-badge status-canceled">취소됨</span>
                    <?php endif; ?>
                    <h1 class="display-5 fw-bold"><?= htmlspecialchars($program['title']) ?></h1>
                    <p class="lead"><?= htmlspecialchars($program['category_name']) ?></p>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="program-image mb-4">
                    <img src="<?= htmlspecialchars($program['image_url']) ?>" class="img-fluid" alt="<?= htmlspecialchars($program['title']) ?>">
                </div>

                <div class="program-description">
                    <h2 class="mb-4">프로그램 설명</h2>
                    <p><?= nl2br(htmlspecialchars($program['description'])) ?></p>
                </div>

                <div class="program-info">
                    <h2 class="mb-4">프로그램 정보</h2>
                    
                    <div class="info-item">
                        <strong>대상 연령:</strong> <?= $program['min_age'] ?>개월 ~ <?= $program['max_age'] ?>개월
                    </div>
                    
                    <div class="info-item">
                        <strong>일시:</strong> <?= date('Y년 m월 d일 H:i', strtotime($program['date'])) ?>
                    </div>
                    
                    <div class="info-item">
                        <strong>소요 시간:</strong> <?= $program['duration'] ?>분
                    </div>
                    
                    <?php if (isset($program['image_url']) && !empty($program['image_url'])): ?>
                    <div class="info-item">
                        <strong>이미지:</strong> <?= htmlspecialchars($program['image_url']) ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="info-item">
                        <strong>참가비:</strong> <?= number_format($program['price']) ?>원
                    </div>
                    
                    <div class="info-item">
                        <strong>참가 인원:</strong> 최소 <?= $program['min_participants'] ?>명 / 최대 <?= $program['max_participants'] ?>명
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="program-register">
                    <h3 class="mb-4">프로그램 신청</h3>
                    
                    <?php if ($program['status'] === 'canceled'): ?>
                        <div class="alert alert-danger">
                            <strong>취소된 프로그램입니다.</strong> 다른 프로그램을 이용해주세요.
                        </div>
                    <?php elseif ($program['current_participants'] >= $program['max_participants']): ?>
                        <div class="alert alert-warning">
                            <strong>신청이 마감되었습니다.</strong> 다른 프로그램을 이용해주세요.
                        </div>
                    <?php else: ?>
                        <div class="mb-4">
                            <p class="mb-1">신청 현황:</p>
                            <?php if ($program['status'] === 'confirmed'): ?>
                                <p><strong><?= $program['current_participants'] ?></strong> / <?= $program['max_participants'] ?> 참가자</p>
                                <div class="progress-container">
                                    <div class="progress-bar" style="width: <?= ($program['current_participants'] / $program['max_participants']) * 100 ?>%"></div>
                                </div>
                            <?php else: ?>
                                <p><strong><?= $program['current_participants'] ?></strong> / <?= $program['min_participants'] ?> 최소 참가자 필요</p>
                                <div class="progress-container">
                                    <div class="progress-bar" style="width: <?= $progressPercentage ?>%"></div>
                                </div>
                                <small class="text-muted">* 최소 인원 미달 시 취소될 수 있습니다.</small>
                            <?php endif; ?>
                        </div>
                        
                        <p class="text-center mb-3">참가비: <strong class="fs-4"><?= number_format($program['price']) ?>원</strong></p>
                        
                        <a href="registration.php?program_id=<?= $program['id'] ?>" class="btn btn-primary w-100 py-3">신청하기</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h3>키즈 익스플로러</h3>
                    <p>아이의 호기심과 발달을 돕는 체험 프로그램</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h4>링크</h4>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white">홈</a></li>
                        <li><a href="programs.php" class="text-white">프로그램</a></li>
                        <li><a href="about.php" class="text-white">소개</a></li>
                        <li><a href="contact.php" class="text-white">문의하기</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h4>연락처</h4>
                    <p>서울특별시 강남구 123번길 45<br>
                    전화: 02-123-4567<br>
                    이메일: info@kidsexplorer.kr</p>
                </div>
            </div>
            <hr class="mt-4 mb-4 bg-light">
            <div class="text-center">
                <p>© 2025 키즈 익스플로러. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>