<?php
// 프로그램 수정 링크를 직접 편집 페이지로 연결하도록 수정하는 스크립트

// 파일 읽기
$file_path = 'pages/edit_programs.php';
$content = file_get_contents($file_path);

// 모달 버튼을 직접 링크로 변경
$pattern = '/<a href="index\.php\?page=direct_edit_program&id=<\?php echo \$program\[\'id\'\]; \?>" class="btn btn-sm btn-primary" .*?<i class="fas fa-edit"><\/i> 수정<\/a>/s';
$replacement = '<a href="index.php?page=direct_edit_program&id=<?php echo $program[\'id\']; ?>" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i> 수정</a>';

$content = preg_replace($pattern, $replacement, $content);

// 파일 저장
file_put_contents($file_path, $content);

echo "프로그램 수정 링크가 성공적으로 업데이트되었습니다.";
?>