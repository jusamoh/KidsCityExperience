<?php
require_once '../config.php';
header('Content-Type: application/json');

// 결제 상세 정보 조회 API
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $orderId = isset($_GET['orderId']) ? $_GET['orderId'] : null;
        
        if (!$orderId) {
            throw new Exception('주문 ID가 필요합니다.');
        }
        
        // 결제 정보 조회
        $stmt = $pdo->prepare("SELECT * FROM payments WHERE order_id = ?");
        $stmt->execute([$orderId]);
        $payment = $stmt->fetch();
        
        if (!$payment) {
            throw new Exception('결제 정보를 찾을 수 없습니다.');
        }
        
        // 등록 및 프로그램 정보 조회
        $stmt = $pdo->prepare("SELECT r.*, p.title as program_title 
                               FROM registrations r 
                               JOIN programs p ON r.program_id = p.id 
                               WHERE r.id = ?");
        $stmt->execute([$payment['registration_id']]);
        $registration = $stmt->fetch();
        
        if (!$registration) {
            throw new Exception('등록 정보를 찾을 수 없습니다.');
        }
        
        // 결제 상세 정보 구성
        $paymentDetails = [
            'paymentId' => $payment['id'],
            'orderId' => $payment['order_id'],
            'amount' => $payment['amount'],
            'method' => $payment['method'],
            'status' => $payment['status'],
            'approvedAt' => $payment['approved_at'],
            'receiptUrl' => $payment['receipt_url'],
            'registrationId' => $registration['id'],
            'programId' => $registration['program_id'],
            'programName' => $registration['program_title'],
            'childName' => $registration['child_name'],
            'parentName' => $registration['parent_name'],
        ];
        
        echo json_encode($paymentDetails);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => '허용되지 않은 메소드입니다.']);
}
?>