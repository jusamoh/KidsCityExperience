<?php
require_once '../config.php';
header('Content-Type: application/json');

// 결제 준비 API - 결제 정보 생성
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // 등록 ID 가져오기
        $registrationId = isset($_POST['registrationId']) ? intval($_POST['registrationId']) : 0;
        
        if ($registrationId <= 0) {
            throw new Exception('유효하지 않은 등록 ID입니다.');
        }
        
        // 등록 정보 조회
        $stmt = $pdo->prepare("SELECT r.*, p.title as program_title, p.price 
                               FROM registrations r 
                               JOIN programs p ON r.program_id = p.id 
                               WHERE r.id = ?");
        $stmt->execute([$registrationId]);
        $registration = $stmt->fetch();
        
        if (!$registration) {
            throw new Exception('등록 정보를 찾을 수 없습니다.');
        }
        
        // 고유한 주문 ID 생성
        $timestamp = time();
        $randomString = bin2hex(random_bytes(8));
        $orderId = "order_{$timestamp}_{$randomString}";
        
        // 주문명 생성
        $orderName = "{$registration['program_title']} 신청 - {$registration['child_name']}";
        
        // 성공/실패 URL
        $successUrl = "{$SITE_URL}/payment_success.php";
        $failUrl = "{$SITE_URL}/payment_fail.php";
        
        // 결제 정보 저장
        $stmt = $pdo->prepare("INSERT INTO payments (registration_id, amount, method, status, order_id, order_name) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $registrationId,
            $registration['price'],
            '',
            'ready',
            $orderId,
            $orderName
        ]);
        
        // 결제 요청 데이터 생성
        $paymentData = [
            'amount' => $registration['price'],
            'orderId' => $orderId,
            'orderName' => $orderName,
            'customerEmail' => $registration['email'],
            'customerName' => $registration['parent_name'],
            'successUrl' => $successUrl,
            'failUrl' => $failUrl
        ];
        
        // 결과 반환
        echo json_encode([
            'success' => true,
            'clientKey' => $TOSS_PAYMENTS_CLIENT_KEY,
            'paymentData' => $paymentData
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => '허용되지 않은 메소드입니다.']);
}
?>