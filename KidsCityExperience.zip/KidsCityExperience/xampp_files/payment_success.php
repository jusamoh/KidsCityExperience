<?php
require_once 'config.php';
$currentPage = 'payment_success';

// 주문 ID 확인
$orderId = isset($_GET['orderId']) ? $_GET['orderId'] : null;

if (!$orderId) {
    header('Location: index.php');
    exit;
}

// 결제 정보 조회
$stmt = $pdo->prepare("SELECT p.*, r.program_id, r.child_name, r.parent_name, 
                       pg.title as program_title, pg.date as program_date 
                       FROM payments p 
                       JOIN registrations r ON p.registration_id = r.id 
                       JOIN programs pg ON r.program_id = pg.id 
                       WHERE p.order_id = ? AND p.status = 'paid'");
$stmt->execute([$orderId]);
$payment = $stmt->fetch();

// 결제 정보가 없거나 결제 상태가 'paid'가 아니면 실패 페이지로 리디렉션
if (!$payment) {
    header('Location: payment_fail.php?orderId=' . urlencode($orderId) . '&message=' . urlencode('결제 정보를 찾을 수 없습니다.'));
    exit;
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>결제 완료 - 키즈 익스플로러</title>
    <meta name="description" content="프로그램 신청 결제가 완료되었습니다.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            color: #333;
            background-color: #f9f9f9;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
        }
        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Quicksand', sans-serif;
            font-weight: 700;
            color: #f05a7a;
        }
        .nav-link {
            font-weight: 600;
            color: #333;
            margin: 0 10px;
        }
        .nav-link:hover {
            color: #f05a7a;
        }
        .success-header {
            background: linear-gradient(to right, #4ecdc4, #f05a7a);
            color: white;
            padding: 50px 0;
            margin-bottom: 30px;
        }
        .success-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .info-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .info-item:last-child {
            border-bottom: none;
        }
        .btn-primary {
            background-color: #f05a7a;
            border-color: #f05a7a;
        }
        .btn-primary:hover {
            background-color: #d84a68;
            border-color: #d84a68;
        }
        .icon-check {
            width: 80px;
            height: 80px;
            background-color: #d4f7e8;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
        }
        .icon-check svg {
            width: 40px;
            height: 40px;
            fill: #16a868;
        }
        .receipt-link {
            color: #f05a7a;
            text-decoration: none;
        }
        .receipt-link:hover {
            text-decoration: underline;
        }
        .footer {
            background-color: #333;
            color: #f9f9f9;
            padding: 50px 0;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">키즈 익스플로러</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">홈</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="programs.php">프로그램</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">소개</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">로그인</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="success-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-5 fw-bold">결제가 완료되었습니다!</h1>
                    <p class="lead">프로그램 신청이 정상적으로 완료되었습니다.</p>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="success-content text-center">
                    <div class="icon-check">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                        </svg>
                    </div>
                    
                    <h2 class="mb-4">결제 성공</h2>
                    <p class="lead mb-5">
                        <?= htmlspecialchars($payment['parent_name']) ?>님, <?= htmlspecialchars($payment['program_title']) ?> 프로그램을 신청해 주셔서 감사합니다!
                    </p>
                    
                    <div class="row mb-5">
                        <div class="col-md-8 mx-auto">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">결제 정보</h5>
                                    
                                    <div class="info-item">
                                        <div class="row">
                                            <div class="col-6 text-start">프로그램</div>
                                            <div class="col-6 text-end fw-bold"><?= htmlspecialchars($payment['program_title']) ?></div>
                                        </div>
                                    </div>
                                    
                                    <div class="info-item">
                                        <div class="row">
                                            <div class="col-6 text-start">참가자명</div>
                                            <div class="col-6 text-end"><?= htmlspecialchars($payment['child_name']) ?></div>
                                        </div>
                                    </div>
                                    
                                    <div class="info-item">
                                        <div class="row">
                                            <div class="col-6 text-start">결제 금액</div>
                                            <div class="col-6 text-end"><?= number_format($payment['amount']) ?>원</div>
                                        </div>
                                    </div>
                                    
                                    <div class="info-item">
                                        <div class="row">
                                            <div class="col-6 text-start">결제 방법</div>
                                            <div class="col-6 text-end"><?= htmlspecialchars($payment['method']) ?></div>
                                        </div>
                                    </div>
                                    
                                    <div class="info-item">
                                        <div class="row">
                                            <div class="col-6 text-start">결제 일시</div>
                                            <div class="col-6 text-end"><?= date('Y년 m월 d일 H:i', strtotime($payment['approved_at'])) ?></div>
                                        </div>
                                    </div>
                                    
                                    <div class="info-item">
                                        <div class="row">
                                            <div class="col-6 text-start">주문번호</div>
                                            <div class="col-6 text-end"><?= htmlspecialchars($payment['order_id']) ?></div>
                                        </div>
                                    </div>
                                    
                                    <?php if ($payment['receipt_url']): ?>
                                    <div class="mt-3">
                                        <a href="<?= htmlspecialchars($payment['receipt_url']) ?>" target="_blank" class="receipt-link">영수증 보기</a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <h5 class="mb-3">프로그램 정보</h5>
                        <p><strong>일시:</strong> <?= date('Y년 m월 d일 H:i', strtotime($payment['program_date'])) ?></p>
                        <?php if (isset($payment['image_url']) && !empty($payment['image_url'])): ?>
                        <p><strong>이미지:</strong> <?= htmlspecialchars($payment['image_url']) ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="alert alert-info mb-4">
                        <p class="mb-0">프로그램 확정 여부는 이메일로 안내해 드립니다.</p>
                    </div>
                    
                    <div class="d-grid gap-2 col-md-6 mx-auto">
                        <a href="index.php" class="btn btn-primary">홈으로 돌아가기</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h3>키즈 익스플로러</h3>
                    <p>아이의 호기심과 발달을 돕는 체험 프로그램</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h4>링크</h4>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white">홈</a></li>
                        <li><a href="programs.php" class="text-white">프로그램</a></li>
                        <li><a href="about.php" class="text-white">소개</a></li>
                        <li><a href="contact.php" class="text-white">문의하기</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h4>연락처</h4>
                    <p>서울특별시 강남구 123번길 45<br>
                    전화: 02-123-4567<br>
                    이메일: info@kidsexplorer.kr</p>
                </div>
            </div>
            <hr class="mt-4 mb-4 bg-light">
            <div class="text-center">
                <p>© 2025 키즈 익스플로러. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>