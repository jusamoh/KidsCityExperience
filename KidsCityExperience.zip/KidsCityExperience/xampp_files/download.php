<?php
// 다운로드 페이지
$file = '../xampp_files_complete.tar.gz';
$fileName = 'paju_experience_camp.tar.gz';

if (file_exists($file)) {
    // 다운로드 헤더 설정
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $fileName . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}
?>