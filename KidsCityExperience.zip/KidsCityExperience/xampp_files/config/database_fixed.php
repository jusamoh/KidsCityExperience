<?php
// database.php - 데이터베이스 연결 및 함수

// 데이터베이스 연결 정보
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'paju_db';

// 데이터베이스 연결 함수
function get_db_connection() {
    global $db_host, $db_user, $db_password, $db_name;
    
    // 데이터베이스 연결
    $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
    
    // 연결 오류 확인
    if ($conn->connect_error) {
        // 데이터베이스가 없으면 생성 시도
        $temp_conn = new mysqli($db_host, $db_user, $db_password);
        if (!$temp_conn->connect_error) {
            $temp_conn->query("CREATE DATABASE IF NOT EXISTS $db_name");
            $temp_conn->close();
            
            // 새로 생성된 데이터베이스에 연결
            $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
        }
        
        // 여전히 연결 오류가 있으면 오류 표시
        if ($conn->connect_error) {
            die("데이터베이스 연결 실패: " . $conn->connect_error);
        }
    }
    
    // 한글 깨짐 방지
    $conn->set_charset("utf8mb4");
    
    return $conn;
}

// 테이블 생성 함수
function create_tables_if_not_exist() {
    $conn = get_db_connection();
    
    // 카테고리 테이블
    $sql = "CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($sql);
    
    // 프로그램 테이블
    $sql = "CREATE TABLE IF NOT EXISTS programs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        category_id INT NOT NULL,
        date DATE,
        /* location 필드는 더 이상 사용하지 않음 */
        min_age INT DEFAULT 0,
        max_age INT DEFAULT 24,
        price DECIMAL(10,2),
        max_participants INT DEFAULT 20,
        min_participants INT DEFAULT 5,
        duration INT DEFAULT 60,
        status VARCHAR(50) DEFAULT 'active',
        image_url VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (category_id)
    )";
    $conn->query($sql);
    
    // 카테고리 변경 기록 테이블
    $sql = "CREATE TABLE IF NOT EXISTS program_categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        program_id INT NOT NULL,
        category_id INT NOT NULL,
        changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (program_id),
        INDEX (category_id)
    )";
    $conn->query($sql);
    
    // 사용자 테이블
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        is_admin TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($sql);
    
    // 등록 테이블
    $sql = "CREATE TABLE IF NOT EXISTS registrations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        program_id INT NOT NULL,
        child_name VARCHAR(255) NOT NULL,
        child_age INT NOT NULL,
        parent_name VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        email VARCHAR(255) NOT NULL,
        notes TEXT DEFAULT NULL,
        payment_status VARCHAR(50) DEFAULT 'pending',
        payment_method VARCHAR(50) DEFAULT NULL,
        payment_id VARCHAR(255) DEFAULT NULL,
        paid_amount DECIMAL(10,2) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (program_id)
    )";
    $conn->query($sql);
    
    // 결제 테이블
    $sql = "CREATE TABLE IF NOT EXISTS payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        registration_id INT NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        amount DECIMAL(10,2) NOT NULL,
        method VARCHAR(50) NOT NULL,
        order_id VARCHAR(255) NOT NULL,
        order_name VARCHAR(255) NOT NULL,
        payment_key VARCHAR(255) DEFAULT NULL,
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        approved_at TIMESTAMP NULL DEFAULT NULL,
        receipt_url VARCHAR(255) DEFAULT NULL,
        extra_data TEXT DEFAULT NULL,
        INDEX (registration_id)
    )";
    $conn->query($sql);
    
    // 기본 데이터 추가
    add_default_data($conn);
    
    $conn->close();
}

// 기본 데이터 추가 함수
function add_default_data($conn) {
    // 관리자 계정이 없으면 추가
    $result = $conn->query("SELECT id FROM users WHERE username = 'admin' LIMIT 1");
    if ($result->num_rows == 0) {
        // 비밀번호 해싱 (admin)
        $hashed_password = password_hash('admin', PASSWORD_DEFAULT);
        $conn->query("INSERT INTO users (username, password, is_admin) VALUES ('admin', '$hashed_password', 1)");
    }
    
    // 카테고리가 없으면 기본 카테고리 추가
    $result = $conn->query("SELECT id FROM categories LIMIT 1");
    if ($result->num_rows == 0) {
        $categories = [
            ['name' => '도시텃밭 체험', 'description' => '아이들이 식물을 심고 가꾸는 경험을 통해 자연과 교감하고 성장의 기쁨을 느낄 수 있는 프로그램입니다.'],
            ['name' => '영어놀이', 'description' => '그림책을 활용한 연극 놀이와 다양한 활동을 통해 영어에 자연스럽게 노출되고 흥미를 갖게 하는 프로그램입니다.'],
            ['name' => '신체놀이', 'description' => '다양한 신체 활동을 통해 대근육과 소근육 발달을 돕고, 협동심과 사회성을 기를 수 있는 프로그램입니다.']
        ];
        
        foreach ($categories as $category) {
            $name = $conn->real_escape_string($category['name']);
            $description = $conn->real_escape_string($category['description']);
            $conn->query("INSERT INTO categories (name, description) VALUES ('$name', '$description')");
        }
    }
    
    // 프로그램이 없으면 기본 프로그램 추가
    $result = $conn->query("SELECT id FROM programs LIMIT 1");
    if ($result->num_rows == 0) {
        $programs = [
            [
                'title' => '상추 키우기 체험',
                'description' => '한국 도시텃밭의 대표 작물인 상추를 직접 심고 가꾸는 체험 프로그램입니다. 아이와 함께 씨앗 심기부터 모종 관리, 수확까지 전 과정을 체험하며 친환경 식물 기르기의 즐거움을 느껴보세요. 수확한 상추로 간단한 샐러드를 만들어 맛보는 시간도 가집니다.',
                'category_id' => 1,
                'date' => '2025-06-07',
                'location' => '서울 강남구 도시농업체험장',
                'min_age' => 12,
                'max_age' => 24,
                'price' => 30000,
                'max_participants' => 10,
                'min_participants' => 6,
                'duration' => 90,
                'status' => 'active'
            ],
            [
                'title' => '방울토마토 수확 체험',
                'description' => '아이들이 가장 좋아하는 방울토마토를 직접 수확하고 맛보는 체험입니다. 방울토마토의 성장 과정을 관찰하고, 수확의 기쁨을 느껴보세요. 수확한 방울토마토로 미니 피자 만들기 활동도 함께 진행됩니다. 아이의 오감을 자극하고 건강한 먹거리의 소중함을 배울 수 있는 시간입니다.',
                'category_id' => 1,
                'date' => '2025-06-10',
                'location' => '서울 마포구 도시농업센터',
                'min_age' => 10,
                'max_age' => 24,
                'price' => 32000,
                'max_participants' => 8,
                'min_participants' => 5,
                'duration' => 100,
                'status' => 'active'
            ],
            [
                'title' => '고추 모종 심기 체험',
                'description' => '한국 요리에 빠질 수 없는 고추 모종을 심고 가꾸는 체험입니다. 다양한 크기와 색깔의 고추 모종을 심고, 식물 성장에 필요한 물과 영양분에 대해 배웁니다. 아이들의 호기심을 자극하고 생명의 소중함을 느낄 수 있는 시간이 될 것입니다. 작은 화분에 심은 고추 모종은 집에 가져가서 계속 관찰할 수 있습니다.',
                'category_id' => 1,
                'date' => '2025-06-14',
                'location' => '서울 송파구 실내 농장',
                'min_age' => 12,
                'max_age' => 24,
                'price' => 28000,
                'max_participants' => 10,
                'min_participants' => 5,
                'duration' => 80,
                'status' => 'active'
            ],
            [
                'title' => '깻잎 향기 체험',
                'description' => '한국 식탁에 자주 오르는 깻잎을 직접 기르고 수확하는 체험입니다. 깻잎의 독특한 향과 다양한 활용법에 대해 배우고, 수확한 깻잎으로 건강한 간식을 만들어봅니다. 아이들에게 한국 전통 식물에 대한 관심과 애정을 키워주는 특별한 시간이 될 것입니다. 깻잎 씨앗 패키지도 선물로 드립니다.',
                'category_id' => 1,
                'date' => '2025-06-17',
                'location' => '서울 노원구 어린이 농장',
                'min_age' => 6,
                'max_age' => 18,
                'price' => 25000,
                'max_participants' => 12,
                'min_participants' => 6,
                'duration' => 70,
                'status' => 'active'
            ],
            [
                'title' => 'The Very Hungry Caterpillar 연극놀이',
                'description' => '세계적으로 유명한 에릭 칼의 "The Very Hungry Caterpillar" 그림책을 활용한 연극놀이입니다. "I am hungry", "I like apples", "Let\'s eat together" 등 쉬운 생활영어 표현을 배우며 배고픈 애벌레가 나비가 되는 과정을 직접 연기해봅니다. 아이들은 과일 소품을 활용하여 먹는 행동을 연기하고, 알에서 나비로 변하는 과정을 몸으로 표현하며 생활영어를 자연스럽게 익힙니다.',
                'category_id' => 2,
                'date' => '2025-06-09',
                'location' => '서울 마포구 키즈카페',
                'min_age' => 10,
                'max_age' => 24,
                'price' => 35000,
                'max_participants' => 8,
                'min_participants' => 4,
                'duration' => 75,
                'status' => 'pending'
            ],
            [
                'title' => 'Brown Bear, Brown Bear 역할놀이',
                'description' => '빌 마틴 주니어의 "Brown Bear, Brown Bear, What Do You See?" 그림책을 활용한 역할놀이입니다. "I see a...", "What color is it?", "I am a..." 같은 쉬운 생활영어 표현을 익히며 다양한 동물 역할을 맡아 연기합니다. 색깔과 동물 이름을 영어로 배우고, 동물 가면을 만들어 쓰고 각 동물의 특징적인 움직임과 소리를 표현하는 활동을 통해 아이들의 언어 발달과 창의력, 표현력을 함께 키웁니다.',
                'category_id' => 2,
                'date' => '2025-06-16',
                'location' => '서울 강동구 어린이도서관',
                'min_age' => 12,
                'max_age' => 24,
                'price' => 32000,
                'max_participants' => 8,
                'min_participants' => 4,
                'duration' => 60,
                'status' => 'pending'
            ],
            [
                'title' => 'Going on a Bear Hunt 모험놀이',
                'description' => '마이클 로젠의 "We\'re Going on a Bear Hunt" 그림책을 활용한 영어 모험놀이입니다. "Let\'s go", "I\'m not scared", "Oh no!" 등의 생활영어 표현을 배우며 실내에 꾸며진 작은 모험 코스를 탐험합니다. 풀숲, 진흙, 강, 숲 등 다양한 환경을 지나가는 모션과 효과음을 함께 표현하며 그림책 속 이야기를 실감나게 체험합니다. 아이들의 상상력과 신체 발달, 영어 표현력을 동시에 키울 수 있는 프로그램입니다.',
                'category_id' => 2,
                'date' => '2025-06-12',
                'location' => '서울 용산구 어린이영어도서관',
                'min_age' => 8,
                'max_age' => 20,
                'price' => 34000,
                'max_participants' => 10,
                'min_participants' => 5,
                'duration' => 70,
                'status' => 'pending'
            ],
            [
                'title' => 'The Rainbow Fish 인형극 놀이',
                'description' => '마르쿠스 피스터의 "The Rainbow Fish" 그림책을 활용한 인형극 놀이입니다. "Please", "Thank you", "Can I have...?", "Let\'s be friends" 등 일상 생활에서 자주 사용하는 영어 표현을 배우며 무지개 물고기 이야기를 인형극으로 만들어봅니다. 아이들은 반짝이는 비늘 소품을 만들고, 물고기 캐릭터 역할을 나누어 맡아 공유와 우정의 가치를 영어로 표현합니다. 영어 표현과 함께 사회성 발달에도 도움을 주는 프로그램입니다.',
                'category_id' => 2,
                'date' => '2025-06-14',
                'location' => '서울 송파구 키즈아트센터',
                'min_age' => 10,
                'max_age' => 22,
                'price' => 36000,
                'max_participants' => 8,
                'min_participants' => 4,
                'duration' => 80,
                'status' => 'pending'
            ],
            [
                'title' => '아기 체조',
                'description' => '전문 강사와 함께하는 영아 발달 체조 프로그램입니다. 대근육과 소근육 발달을 촉진하는 다양한 활동을 진행합니다.',
                'category_id' => 3,
                'date' => '2025-06-11',
                'location' => '파주시 키즈 체육관',
                'min_age' => 6,
                'max_age' => 18,
                'price' => 20000,
                'max_participants' => 10,
                'min_participants' => 5,
                'duration' => 45,
                'status' => 'pending'
            ],
            [
                'title' => '아기 체육 놀이',
                'description' => '다양한 공과 매트 활동을 통해 아이의 대근육 발달과 신체 협응력을 키워요.',
                'category_id' => 3,
                'date' => '2025-05-19',
                'location' => '서울 용산구 키즈체육관',
                'min_age' => 6,
                'max_age' => 18,
                'price' => 28000,
                'max_participants' => 10,
                'min_participants' => 6,
                'duration' => 60,
                'status' => 'canceled'
            ],
            [
                'title' => '오감 놀이터',
                'description' => '다양한 놀이기구와 감각재료를 통해 아이의 오감을 자극하고 발달을 돕는 프로그램이에요.',
                'category_id' => 3,
                'date' => '2025-06-12',
                'location' => '서울 서초구 어린이놀이센터',
                'min_age' => 8,
                'max_age' => 24,
                'price' => 29000,
                'max_participants' => 8,
                'min_participants' => 5,
                'duration' => 70,
                'status' => 'pending'
            ]
        ];
        
        foreach ($programs as $program) {
            $title = $conn->real_escape_string($program['title']);
            $description = $conn->real_escape_string($program['description']);
            $category_id = (int)$program['category_id'];
            $date = $conn->real_escape_string($program['date']);
            $location = $conn->real_escape_string($program['location']);
            $min_age = (int)$program['min_age'];
            $max_age = (int)$program['max_age'];
            $price = (float)$program['price'];
            $max_participants = (int)$program['max_participants'];
            $min_participants = (int)$program['min_participants'];
            $duration = (int)$program['duration'];
            $status = $conn->real_escape_string($program['status']);
            
            $conn->query("INSERT INTO programs (title, description, category_id, date, location, min_age, max_age, price, max_participants, min_participants, duration, status) 
                        VALUES ('$title', '$description', $category_id, '$date', '$location', $min_age, $max_age, $price, $max_participants, $min_participants, $duration, '$status')");
        }
    }
}
?>