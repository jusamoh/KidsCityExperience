<?php
// 세션이 시작되지 않은 경우에만 세션 시작
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 나머지 functions.php 내용...
// 아래에 기존 functions.php의 나머지 내용을 복사해서 붙여넣으세요.
// session_start() 라인만 위의 코드로 대체하고 나머지는 그대로 유지하세요.

// 로그인 상태 확인 함수
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// 관리자 권한 확인 함수
function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == true;
}

// 로그인 필요 페이지 접근 제한
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: /paju/pages/login.php");
        exit;
    }
}

// 관리자 권한 필요 페이지 접근 제한
function requireAdmin() {
    if (!isAdmin()) {
        header("Location: /paju/index.php");
        exit;
    }
}

// 안전한 입력값 처리
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// 에러 메시지 표시
function showError($message) {
    echo '<div class="alert alert-danger" role="alert">' . $message . '</div>';
}

// 성공 메시지 표시
function showSuccess($message) {
    echo '<div class="alert alert-success" role="alert">' . $message . '</div>';
}

// 랜덤 문자열 생성 (주문 ID 등에 사용)
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>