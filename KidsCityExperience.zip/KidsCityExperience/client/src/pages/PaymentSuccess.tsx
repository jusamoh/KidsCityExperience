import { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Receipt, ArrowRight } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface PaymentDetails {
  paymentId: number;
  orderId: string;
  amount: number;
  method: string;
  status: string;
  approvedAt: string;
  receiptUrl: string | null;
  registrationId: number;
  programId: number;
  programName: string;
  childName: string;
  parentName: string;
}

export default function PaymentSuccess() {
  const [, navigate] = useLocation();
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // URL에서 orderId 파라미터 가져오기
  const params = new URLSearchParams(window.location.search);
  const orderId = params.get('orderId');
  const paymentKey = params.get('paymentKey');
  const amount = params.get('amount');

  // 페이지 로드 시 결제 승인 및 정보 조회
  useEffect(() => {
    if (!orderId) {
      setError('주문 정보를 찾을 수 없습니다.');
      setIsLoading(false);
      return;
    }

    const completePayment = async () => {
      try {
        // 결제가 아직 승인되지 않았고, 토스페이먼츠에서 받은 키가 있으면 승인 진행
        if (paymentKey && amount) {
          // 이 부분은 서버에서 자동으로 처리되지만, 직접 요청할 때도 있음
          await apiRequest('POST', '/api/payments/verify', {
            paymentKey,
            orderId,
            amount: Number(amount),
          });
        }

        // 결제 상세 정보 조회
        const response = await apiRequest('GET', `/api/payments/details?orderId=${orderId}`);
        if (!response.ok) {
          throw new Error('결제 정보를 불러오는데 실패했습니다.');
        }
        
        const paymentData = await response.json();
        setPaymentDetails(paymentData);
        
        // 성공 메시지 표시
        toast({
          title: '결제 완료',
          description: '프로그램 등록이 완료되었습니다.',
        });
      } catch (err) {
        console.error('결제 정보 조회 오류:', err);
        setError('결제 정보를 불러오는데 실패했습니다.');
      } finally {
        setIsLoading(false);
      }
    };

    completePayment();
  }, [orderId, paymentKey, amount, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-16 flex items-center justify-center px-4">
      <Card className="w-full max-w-md mx-auto shadow-lg border-0">
        <CardHeader className="text-center pb-0">
          <div className="w-20 h-20 rounded-full bg-green-100 mx-auto mb-4 flex items-center justify-center">
            <CheckCircle className="h-10 w-10 text-green-500" />
          </div>
          <CardTitle className="text-2xl mb-2">결제가 완료되었습니다!</CardTitle>
          <CardDescription>
            등록이 성공적으로 완료되었습니다.
          </CardDescription>
        </CardHeader>
        
        <CardContent className="pt-6">
          {error ? (
            <div className="bg-destructive/10 p-4 rounded-md text-destructive mb-6">
              {error}
            </div>
          ) : paymentDetails ? (
            <div className="space-y-4 mb-6">
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">프로그램</span>
                <span className="font-medium">{paymentDetails.programName}</span>
              </div>
              
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">참가자</span>
                <span className="font-medium">{paymentDetails.childName}</span>
              </div>
              
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">결제 금액</span>
                <span className="font-medium text-primary">{paymentDetails.amount?.toLocaleString()}원</span>
              </div>
              
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">결제 방법</span>
                <span className="font-medium">{paymentDetails.method || '카드 결제'}</span>
              </div>
              
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-muted-foreground">결제 일시</span>
                <span className="font-medium">
                  {paymentDetails.approvedAt ? 
                    new Date(paymentDetails.approvedAt).toLocaleString('ko-KR') : 
                    new Date().toLocaleString('ko-KR')}
                </span>
              </div>
              
              <div className="flex justify-between items-center py-2">
                <span className="text-muted-foreground">주문번호</span>
                <span className="font-medium text-sm">{paymentDetails.orderId}</span>
              </div>
              
              {paymentDetails.receiptUrl && (
                <a 
                  href={paymentDetails.receiptUrl} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center justify-center text-primary hover:underline mt-2"
                >
                  <Receipt className="w-4 h-4 mr-1" />
                  영수증 보기
                </a>
              )}
            </div>
          ) : (
            <div className="bg-yellow-50 p-4 rounded-md text-yellow-800 mb-6 border border-yellow-200">
              결제는 정상적으로 처리되었으나 상세 정보를 불러올 수 없습니다.
            </div>
          )}
          
          <div className="flex flex-col space-y-3 mt-6">
            <Link href="/">
              <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                홈으로 돌아가기
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}