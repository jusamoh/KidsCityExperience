import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import ProgramCard from "@/components/ProgramCard";
import FAQ from "@/components/FAQ";
import { Program, Category } from "@shared/schema";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  
  // Fetch categories
  const { data: categories = [], isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch programs
  const { data: programs = [], isLoading: programsLoading } = useQuery<(Program & { currentParticipants: number })[]>({
    queryKey: ["/api/programs", selectedCategory],
    queryFn: async ({ queryKey }) => {
      const categoryId = queryKey[1];
      const url = categoryId ? `/api/programs?categoryId=${categoryId}` : "/api/programs";
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch programs");
      return res.json();
    },
  });
  
  const handleCategoryClick = (categoryId: number | null) => {
    setSelectedCategory(categoryId);
  };
  
  const isLoading = categoriesLoading || programsLoading;
  
  return (
    <>
      {/* Hero Section */}
      <section className="hero-gradient py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold font-heading text-white mb-6">아이와 함께하는 특별한 체험</h1>
              <p className="text-white text-lg mb-8">유아, 어린이를 위한 도시텃밭, 영어놀이, 스포츠 체험 프로그램을 만나보세요. 아이들의 창의력과 상상력을 키우는 특별한 시간을 선물하세요.</p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  className="bg-white text-primary hover:bg-neutral-light px-6 py-7 rounded-full font-bold w-full sm:w-auto"
                  onClick={() => {
                    const programsSection = document.getElementById('programs');
                    if (programsSection) {
                      programsSection.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                >
                  프로그램 둘러보기
                </Button>
                <Link href="/program-selection">
                  <Button className="bg-accent text-neutral-dark hover:bg-accent/90 px-6 py-7 rounded-full font-bold w-full sm:w-auto">
                    프로그램 신청하기
                  </Button>
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <img 
                src="https://images.unsplash.com/photo-1587271407850-8d438ca9fdf2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="유아들이 함께 놀이하는 모습" 
                className="rounded-2xl shadow-lg w-full max-w-md object-cover" 
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Programs Section */}
      <section id="programs" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold font-heading text-center text-neutral-dark mb-12">체험 프로그램</h2>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Button
              onClick={() => handleCategoryClick(null)}
              className={`rounded-full ${
                selectedCategory === null
                  ? "bg-secondary text-white"
                  : "bg-neutral-light text-neutral-dark hover:bg-secondary hover:text-white"
              }`}
            >
              전체 보기
            </Button>
            
            {isLoading ? (
              <div className="flex justify-center w-full">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : (
              categories.map((category: Category) => (
                <Button
                  key={category.id}
                  onClick={() => handleCategoryClick(category.id)}
                  className={`rounded-full ${
                    selectedCategory === category.id
                      ? "bg-secondary text-white"
                      : "bg-neutral-light text-neutral-dark hover:bg-secondary hover:text-white"
                  }`}
                >
                  {category.name}
                </Button>
              ))
            )}
          </div>
          
          {isLoading ? (
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : programs?.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {programs.map((program: Program & { currentParticipants: number }) => (
                <ProgramCard key={program.id} program={program} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-neutral-dark text-lg">프로그램이 없습니다.</p>
            </div>
          )}
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 bg-neutral-light">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold font-heading text-center text-neutral-dark mb-4">파주 체험 Camp 특징</h2>
          <p className="text-center text-neutral-dark mb-12 max-w-2xl mx-auto">2살 미만 영유아의 발달 특성에 맞춘 맞춤형 체험 프로그램을 진행합니다.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-6 shadow-md text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-child text-primary text-2xl"></i>
              </div>
              <h3 className="font-heading font-bold text-xl mb-3">영유아 맞춤 커리큘럼</h3>
              <p className="text-neutral-dark">0-24개월 영유아의 발달 단계에 맞춘 안전하고 효과적인 체험 프로그램을 제공합니다.</p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 shadow-md text-center">
              <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-users text-secondary text-2xl"></i>
              </div>
              <h3 className="font-heading font-bold text-xl mb-3">소규모 그룹 운영</h3>
              <p className="text-neutral-dark">최대 10명 이하의 소규모로 운영되어 아이 개개인에게 충분한 관심과 케어를 제공합니다.</p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 shadow-md text-center">
              <div className="w-16 h-16 bg-accent/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-shield-alt text-neutral-dark text-2xl"></i>
              </div>
              <h3 className="font-heading font-bold text-xl mb-3">안전한 체험 환경</h3>
              <p className="text-neutral-dark">모든 재료와 교구는 무독성, 친환경 제품만을 사용하여 아이들의 안전을 최우선으로 생각합니다.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 cta-gradient">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold font-heading text-white mb-6">지금 바로 체험 프로그램에 참여하세요</h2>
          <p className="text-white mb-8 max-w-xl mx-auto">아이와 함께하는 특별한 추억을 만들어 드립니다. 프로그램은 수요에 따라 개설되니 미리 신청해주세요!</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              className="bg-white text-primary hover:bg-neutral-light px-8 py-3 rounded-full font-bold w-full sm:w-auto"
              onClick={() => {
                const programsSection = document.getElementById('programs');
                if (programsSection) {
                  programsSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            >
              프로그램 둘러보기
            </Button>
            <Link href="/program-selection">
              <Button className="bg-accent text-neutral-dark hover:bg-accent/90 px-8 py-3 rounded-full font-bold w-full sm:w-auto">
                신청하기
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <FAQ />
    </>
  );
}
