import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Program, Category } from "@shared/schema";
import { Link } from "wouter";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ProgramSelection() {
  const [, navigate] = useLocation();
  const [selectedPrograms, setSelectedPrograms] = useState<number[]>([]);
  const [totalPrice, setTotalPrice] = useState<number>(0);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  
  // 카테고리 목록 조회
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  // 프로그램 목록 조회
  const { data: allPrograms = [], isLoading } = useQuery<(Program & { currentParticipants: number })[]>({
    queryKey: ['/api/programs'],
  });
  
  // 선택된 카테고리에 따라 프로그램 필터링
  const filteredPrograms = selectedCategory === "all" 
    ? allPrograms 
    : allPrograms.filter(program => program.categoryId === parseInt(selectedCategory));
  
  // 프로그램 선택/해제 시 처리
  const handleProgramToggle = (programId: number, price: number, checked: boolean) => {
    if (checked) {
      setSelectedPrograms(prev => [...prev, programId]);
      setTotalPrice(prev => prev + price);
    } else {
      setSelectedPrograms(prev => prev.filter(id => id !== programId));
      setTotalPrice(prev => prev - price);
    }
  };
  
  // 신청하기 버튼 클릭 시 처리
  const handleSubmit = () => {
    // 선택된 프로그램이 없으면 경고
    if (selectedPrograms.length === 0) {
      alert('최소 하나 이상의 프로그램을 선택해주세요.');
      return;
    }
    
    // 단일 프로그램 선택 시
    if (selectedPrograms.length === 1) {
      navigate(`/registration/${selectedPrograms[0]}`);
      return;
    }
    
    // 다중 프로그램 선택 시 - 선택된 프로그램 ID 목록을 쿼리 파라미터로 전달
    const programIds = selectedPrograms.join(',');
    navigate(`/multi-registration?programs=${programIds}`);
  };
  
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold font-heading text-center text-neutral-dark mb-4">프로그램 선택</h2>
        <p className="text-center text-neutral-dark mb-8 max-w-2xl mx-auto">
          참여하고 싶은 프로그램을 선택하고 한 번에 신청해보세요. 여러 프로그램을 함께 신청하면 더 특별한 경험을 할 수 있습니다.
        </p>
        
        {isLoading ? (
          <div className="flex justify-center py-16">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : (
          <>
            <div className="mb-8">
              <Tabs defaultValue="all" onValueChange={setSelectedCategory}>
                <TabsList className="mb-6 flex flex-wrap justify-center gap-2">
                  <TabsTrigger value="all" className="px-4 py-2">전체 프로그램</TabsTrigger>
                  {categories.map((category) => (
                    <TabsTrigger 
                      key={category.id} 
                      value={category.id.toString()}
                      className="px-4 py-2"
                    >
                      {category.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            
              {filteredPrograms.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-24">
                  {filteredPrograms.map((program) => (
                    <Card key={program.id} className="overflow-hidden transition-all duration-300 hover:shadow-lg">
                      <div className="aspect-w-16 aspect-h-9 overflow-hidden">
                        {program.imageUrl && (
                          <img 
                            src={program.imageUrl} 
                            alt={program.title} 
                            className="object-cover w-full h-48"
                          />
                        )}
                      </div>
                      
                      <CardHeader className="p-4">
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-xl font-bold">{program.title}</CardTitle>
                          <div>
                            <Checkbox 
                              id={`program-${program.id}`}
                              checked={selectedPrograms.includes(program.id)}
                              onCheckedChange={(checked) => 
                                handleProgramToggle(program.id, program.price, checked === true)
                              }
                            />
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mt-2">
                          <span className="inline-block px-2 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full">
                            {program.minAge}~{program.maxAge}개월
                          </span>
                          <span className="inline-block px-2 py-1 text-xs font-medium bg-secondary/10 text-secondary rounded-full">
                            {new Date(program.date).toLocaleDateString()} {new Date(program.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <span className="inline-block px-2 py-1 text-xs font-medium bg-neutral-light text-neutral-dark rounded-full">
                            {program.location}
                          </span>
                        </div>
                      </CardHeader>
                      
                      <CardContent className="p-4 pt-0">
                        <p className="text-neutral-dark line-clamp-2 text-sm">
                          {program.description}
                        </p>
                        
                        <div className="mt-3 flex justify-between items-center">
                          <div className="text-lg font-bold text-primary">
                            {program.price.toLocaleString()}원
                          </div>
                          <div className="text-sm text-neutral-dark">
                            참여 가능 인원: {program.currentParticipants}/{program.maxParticipants}명
                          </div>
                        </div>
                        
                        <div className="mt-2">
                          <div className="relative w-full h-2 bg-neutral-light rounded-full overflow-hidden">
                            <div 
                              className={`absolute left-0 top-0 h-full ${
                                program.status === 'confirmed' ? 'bg-green-500' : 
                                program.status === 'pending' ? 'bg-amber-500' : 'bg-red-500'
                              }`}
                              style={{ 
                                width: `${Math.min(100, (program.currentParticipants / program.maxParticipants) * 100)}%` 
                              }}
                            ></div>
                          </div>
                        </div>
                        
                        <div className="mt-2 text-xs text-right">
                          {program.status === 'confirmed' ? (
                            <span className="text-green-600">확정됨</span>
                          ) : program.status === 'pending' ? (
                            <span className="text-amber-600">
                              최소 {program.minParticipants}명 필요 (현재 {program.currentParticipants}명)
                            </span>
                          ) : (
                            <span className="text-red-600">취소됨</span>
                          )}
                        </div>
                      </CardContent>
                      
                      <CardFooter className="p-4 pt-0 flex justify-between">
                        <Link href={`/programs/${program.id}`}>
                          <Button variant="outline" size="sm">
                            상세 보기
                          </Button>
                        </Link>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <p className="text-neutral-dark text-lg mb-4">
                    {selectedCategory === "all" 
                      ? "현재 신청 가능한 프로그램이 없습니다." 
                      : "선택한 카테고리에 해당하는 프로그램이 없습니다."}
                  </p>
                  <Link href="/">
                    <Button className="bg-primary text-white">
                      홈으로 돌아가기
                    </Button>
                  </Link>
                </div>
              )}
            </div>
            
            {filteredPrograms.length > 0 && (
              <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-light p-4 shadow-lg z-10">
                <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
                  <div className="flex flex-col">
                    <span className="text-sm text-neutral-dark">선택된 프로그램: {selectedPrograms.length}개</span>
                    <span className="text-lg font-bold text-primary">총 금액: {totalPrice.toLocaleString()}원</span>
                  </div>
                  <Button 
                    onClick={handleSubmit}
                    className="bg-primary text-white hover:bg-primary/90 px-8 py-3 rounded-full font-bold w-full sm:w-auto"
                    disabled={selectedPrograms.length === 0}
                  >
                    신청하기
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}