import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";

// 회원가입 폼 유효성 검사 스키마
const registerSchema = z.object({
  username: z
    .string()
    .min(4, "아이디는 최소 4자 이상이어야 합니다")
    .max(20, "아이디는 최대 20자까지 가능합니다"),
  password: z
    .string()
    .min(6, "비밀번호는 최소 6자 이상이어야 합니다"),
  passwordConfirm: z
    .string()
    .min(6, "비밀번호 확인은 최소 6자 이상이어야 합니다"),
  name: z
    .string()
    .min(2, "이름은 최소 2자 이상이어야 합니다"),
  phone: z
    .string()
    .min(10, "유효한 전화번호를 입력해주세요")
    .max(13, "유효한 전화번호를 입력해주세요"),
  email: z
    .string()
    .email("유효한 이메일 주소를 입력해주세요"),
}).refine((data) => data.password === data.passwordConfirm, {
  message: "비밀번호와 비밀번호 확인이 일치하지 않습니다",
  path: ["passwordConfirm"],
});

type RegisterFormData = z.infer<typeof registerSchema>;

export default function Register() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  const form = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      passwordConfirm: "",
      name: "",
      phone: "",
      email: "",
    },
  });
  
  const onSubmit = async (data: RegisterFormData) => {
    setIsLoading(true);
    try {
      // 비밀번호 확인 필드 제거
      const { passwordConfirm, ...registerData } = data;
      
      // 회원가입 요청
      await apiRequest("POST", "/api/auth/register", registerData);
      
      toast({
        title: "회원가입 성공",
        description: "회원가입이 완료되었습니다. 로그인해주세요.",
      });
      
      // 로그인 페이지로 이동
      navigate("/login");
    } catch (error: any) {
      toast({
        title: "회원가입 실패",
        description: error.message || "회원가입 처리 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-6 md:p-8">
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-bold font-heading text-neutral-dark">회원가입</h1>
          <p className="text-neutral-dark mt-2">파주 체험 Camp 서비스 이용을 위한 회원가입을 진행해주세요</p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>아이디</FormLabel>
                  <FormControl>
                    <Input placeholder="아이디를 입력하세요" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>비밀번호</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="비밀번호를 입력하세요" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="passwordConfirm"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>비밀번호 확인</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="비밀번호를 다시 입력하세요" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>이름</FormLabel>
                  <FormControl>
                    <Input placeholder="이름을 입력하세요" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>연락처</FormLabel>
                  <FormControl>
                    <Input placeholder="연락처를 입력하세요 (010-0000-0000)" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>이메일</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="이메일을 입력하세요" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary/90 text-white py-3 rounded-full font-bold mt-6"
              disabled={isLoading}
            >
              {isLoading ? "처리 중..." : "가입하기"}
            </Button>
          </form>
        </Form>
        
        <div className="mt-6 text-center">
          <p className="text-neutral-dark">
            이미 계정이 있으신가요?{" "}
            <Link href="/login">
              <span className="text-primary font-medium hover:underline cursor-pointer">로그인하기</span>
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}