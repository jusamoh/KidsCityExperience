import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import CategoryForm from "@/components/CategoryForm";
import { Category, Program } from "@shared/schema";
import { Plus, Pencil, RefreshCw, ArrowLeft, Check, Trash2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function CategoryManagement() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [activeTab, setActiveTab] = useState<string>("categories");
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<number | null>(null);

  // 로그인 및 관리자 권한 확인
  useEffect(() => {
    // 개발 환경에서는 간단히 localStorage를 사용하여 관리자 권한 확인
    // 실제 앱에서는 세션 기반 인증을 사용해야 함
    const isAdmin = localStorage.getItem("admin") === "true";
    
    if (!isAdmin) {
      navigate("/login");
      toast({
        title: "접근 권한 없음",
        description: "관리자만 접근할 수 있는 페이지입니다.",
        variant: "destructive",
      });
    }
  }, [navigate, toast]);

  // 카테고리 목록 조회
  const {
    data: categories,
    isLoading: categoriesLoading,
    error: categoriesError,
  } = useQuery({
    queryKey: ["/api/categories"],
    enabled: true,
  });

  // 프로그램 목록 조회
  const {
    data: programs,
    isLoading: programsLoading,
    error: programsError,
  } = useQuery({
    queryKey: ["/api/programs"],
    enabled: true,
  });

  // 카테고리 추가 뮤테이션
  const addCategoryMutation = useMutation({
    mutationFn: (data: Omit<Category, "id">) => {
      return apiRequest("POST", "/api/categories", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      setShowAddForm(false);
      toast({
        title: "카테고리 추가 완료",
        description: "새로운 카테고리가 추가되었습니다.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "카테고리 추가 실패",
        description: error.message || "카테고리를 추가하는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // 카테고리 수정 뮤테이션
  const updateCategoryMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Omit<Category, "id"> }) => {
      return apiRequest("PUT", `/api/categories/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      setEditingCategory(null);
      toast({
        title: "카테고리 수정 완료",
        description: "카테고리 정보가 수정되었습니다.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "카테고리 수정 실패",
        description: error.message || "카테고리를 수정하는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });
  
  // 카테고리 삭제 뮤테이션
  const deleteCategoryMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/categories/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "카테고리 삭제 완료",
        description: "카테고리가 성공적으로 삭제되었습니다.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "카테고리 삭제 실패",
        description: error.response?.data?.message || "카테고리를 삭제하는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // 프로그램 카테고리 수정 뮤테이션
  const updateProgramCategoryMutation = useMutation({
    mutationFn: ({ programId, categoryId }: { programId: number; categoryId: number }) => {
      return apiRequest("PUT", `/api/programs/${programId}/category`, { categoryId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/programs"] });
      toast({
        title: "카테고리 변경 완료",
        description: "프로그램의 카테고리가 변경되었습니다.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "카테고리 변경 실패",
        description: error.message || "카테고리를 변경하는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // 카테고리 추가 핸들러
  const handleAddCategory = (data: Omit<Category, "id">) => {
    addCategoryMutation.mutate(data);
  };

  // 카테고리 수정 핸들러
  const handleUpdateCategory = (data: Omit<Category, "id">) => {
    if (editingCategory) {
      updateCategoryMutation.mutate({ id: editingCategory.id, data });
    }
  };

  // 프로그램 카테고리 변경 핸들러
  const [updatedPrograms, setUpdatedPrograms] = useState<Record<number, boolean>>({});
  
  const handleCategoryChange = (programId: number, categoryId: string) => {
    updateProgramCategoryMutation.mutate({
      programId,
      categoryId: parseInt(categoryId),
    }, {
      onSuccess: () => {
        // 변경 성공 시 업데이트된 프로그램 목록에 추가
        setUpdatedPrograms(prev => ({
          ...prev,
          [programId]: true
        }));
        
        // 3초 후 표시 제거
        setTimeout(() => {
          setUpdatedPrograms(prev => {
            const newState = { ...prev };
            delete newState[programId];
            return newState;
          });
        }, 3000);
      }
    });
  };

  // 카테고리 테이블 렌더링
  const renderCategoriesTable = () => {
    if (categoriesLoading) {
      return (
        <div className="flex justify-center items-center py-8">
          <RefreshCw className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (categoriesError || !categories) {
      return (
        <div className="text-center py-8 text-red-500">
          카테고리 정보를 불러오는 중 오류가 발생했습니다.
        </div>
      );
    }

    if (categories.length === 0) {
      return (
        <div className="text-center py-8 text-neutral-dark/70">
          등록된 카테고리가 없습니다. 새 카테고리를 추가해주세요.
        </div>
      );
    }

    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[80px]">ID</TableHead>
            <TableHead>카테고리명</TableHead>
            <TableHead className="hidden md:table-cell">설명</TableHead>
            <TableHead className="w-[100px] text-right">관리</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {categories.map((category: Category) => (
            <TableRow key={category.id}>
              <TableCell className="font-medium">{category.id}</TableCell>
              <TableCell>{category.name}</TableCell>
              <TableCell className="hidden md:table-cell max-w-xs truncate">
                {category.description}
              </TableCell>
              <TableCell className="text-right space-x-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setEditingCategory(category)}
                  title="카테고리 수정"
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    if (confirm(`정말로 '${category.name}' 카테고리를 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.`)) {
                      deleteCategoryMutation.mutate(category.id);
                    }
                  }}
                  title="카테고리 삭제"
                  className="hover:text-red-500"
                  disabled={deleteCategoryMutation.isPending}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };

  // 프로그램 카테고리 관리 테이블 렌더링
  const renderProgramsTable = () => {
    if (programsLoading || categoriesLoading) {
      return (
        <div className="flex justify-center items-center py-8">
          <RefreshCw className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (programsError || !programs || categoriesError || !categories) {
      return (
        <div className="text-center py-8 text-red-500">
          프로그램 정보를 불러오는 중 오류가 발생했습니다.
        </div>
      );
    }
    
    // 선택된 카테고리 필터에 따라 프로그램 필터링
    const filteredPrograms = selectedCategoryFilter 
      ? programs.filter(program => program.categoryId === selectedCategoryFilter)
      : programs;

    if (programs.length === 0) {
      return (
        <div className="text-center py-8 text-neutral-dark/70">
          등록된 프로그램이 없습니다.
        </div>
      );
    }
    
    if (filteredPrograms.length === 0) {
      return (
        <div className="text-center py-8 text-neutral-dark/70">
          선택한 카테고리에 해당하는 프로그램이 없습니다.
        </div>
      );
    }

    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[80px]">ID</TableHead>
            <TableHead>프로그램명</TableHead>
            <TableHead className="w-[250px]">현재 카테고리</TableHead>
            <TableHead className="w-[250px]">카테고리 변경</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredPrograms.map((program: Program) => {
            // 현재 카테고리 찾기
            const currentCategory = categories.find(
              (cat: Category) => cat.id === program.categoryId
            );

            return (
              <TableRow key={program.id}>
                <TableCell className="font-medium">{program.id}</TableCell>
                <TableCell>{program.title}</TableCell>
                <TableCell>
                  {currentCategory ? currentCategory.name : "미분류"}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Select
                      defaultValue={program.categoryId?.toString()}
                      onValueChange={(value) => handleCategoryChange(program.id, value)}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="카테고리 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category: Category) => (
                          <SelectItem
                            key={category.id}
                            value={category.id.toString()}
                          >
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {updatedPrograms[program.id] && (
                      <Badge variant="outline" className="ml-2 bg-green-50 text-green-600 border-green-200 animate-pulse flex items-center">
                        <Check className="h-3 w-3 mr-1" />
                        변경됨
                      </Badge>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Button
        variant="ghost"
        className="mb-4"
        onClick={() => navigate("/admin")}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        관리자 대시보드로 돌아가기
      </Button>

      <div className="mb-6">
        <h1 className="text-3xl font-bold text-neutral-dark">카테고리 관리</h1>
        <p className="text-muted-foreground">
          체험 프로그램 카테고리를 추가하고 관리하세요
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-2 mb-6">
          <TabsTrigger value="categories">카테고리 목록</TabsTrigger>
          <TabsTrigger value="programs">프로그램 카테고리 변경</TabsTrigger>
        </TabsList>

        <TabsContent value="categories" className="space-y-4">
          <div className="flex justify-end mb-4">
            <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  새 카테고리 추가
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <CategoryForm
                  onSubmit={handleAddCategory}
                  onCancel={() => setShowAddForm(false)}
                />
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle>카테고리 목록</CardTitle>
              <CardDescription>
                체험 프로그램을 분류하는 카테고리를 관리합니다
              </CardDescription>
            </CardHeader>
            <CardContent>{renderCategoriesTable()}</CardContent>
          </Card>

          {/* 카테고리 수정 다이얼로그 */}
          <Dialog
            open={!!editingCategory}
            onOpenChange={(open) => {
              if (!open) setEditingCategory(null);
            }}
          >
            <DialogContent className="sm:max-w-md">
              {editingCategory && (
                <CategoryForm
                  onSubmit={handleUpdateCategory}
                  initialData={editingCategory}
                  onCancel={() => setEditingCategory(null)}
                />
              )}
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="programs" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>프로그램 카테고리 변경</CardTitle>
              <CardDescription>
                각 프로그램의 카테고리를 변경합니다
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-medium">카테고리 필터</h3>
                  {selectedCategoryFilter && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setSelectedCategoryFilter(null)}
                      className="text-xs h-8"
                    >
                      필터 초기화
                    </Button>
                  )}
                </div>
                <div className="flex flex-wrap gap-2">
                  {categories?.map((category: Category) => (
                    <Badge 
                      key={category.id}
                      variant={selectedCategoryFilter === category.id ? "default" : "outline"} 
                      className="cursor-pointer"
                      onClick={() => setSelectedCategoryFilter(
                        selectedCategoryFilter === category.id ? null : category.id
                      )}
                    >
                      {category.name}
                    </Badge>
                  ))}
                </div>
              </div>
              {renderProgramsTable()}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}