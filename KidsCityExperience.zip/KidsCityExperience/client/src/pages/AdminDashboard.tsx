import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Program } from "@shared/schema";
import { Plus, Folder } from "lucide-react";

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Check if user is admin (in a real app, this would check auth)
  const isAdmin = localStorage.getItem("admin") === "true";
  
  // Programs query
  const { data: programs = [], isLoading: programsLoading } = useQuery<(Program & { currentParticipants: number })[]>({
    queryKey: ["/api/programs"],
    enabled: isAdmin,
  });
  
  // Registrations query
  const { data: registrations = [], isLoading: registrationsLoading } = useQuery<any[]>({
    queryKey: ["/api/registrations"],
    enabled: isAdmin,
  });
  
  // Update program status mutation
  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      return apiRequest("PATCH", `/api/programs/${id}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "상태 변경 완료",
        description: "프로그램 상태가 업데이트되었습니다.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/programs"] });
    },
    onError: (error) => {
      toast({
        title: "상태 변경 실패",
        description: error instanceof Error ? error.message : "프로그램 상태 변경 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });
  
  // Handle status update
  const handleStatusUpdate = (id: number, status: string) => {
    updateStatus.mutate({ id, status });
  };
  
  // If not admin, redirect to login
  if (!isAdmin) {
    navigate("/login");
    return null;
  }
  
  // Loading state
  if (programsLoading || registrationsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">관리자 대시보드</h1>
      
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold">관리 메뉴</h2>
        <div className="space-x-2">
          <Button 
            variant="outline" 
            onClick={() => navigate("/admin/add-program")}
            className="flex items-center"
          >
            <Plus className="mr-1 h-4 w-4" /> 
            새 프로그램 등록
          </Button>
          <Button 
            variant="outline" 
            onClick={() => navigate("/admin/categories")}
            className="flex items-center"
          >
            <Folder className="mr-1 h-4 w-4" />
            카테고리 관리
          </Button>
        </div>
      </div>

      <Tabs defaultValue="programs" className="mb-8">
        <TabsList>
          <TabsTrigger value="programs">프로그램 관리</TabsTrigger>
          <TabsTrigger value="registrations">신청자 관리</TabsTrigger>
        </TabsList>
        
        <TabsContent value="programs">
          <Card>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>프로그램 목록</span>
                <Button onClick={() => navigate("/admin/add-program")}>
                  프로그램 추가
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3">프로그램명</th>
                      <th className="text-left py-2 px-3">일시</th>
                      <th className="text-left py-2 px-3">신청자 수</th>
                      <th className="text-left py-2 px-3">상태</th>
                      <th className="text-left py-2 px-3">관리</th>
                    </tr>
                  </thead>
                  <tbody>
                    {programs?.map((program: Program & { currentParticipants: number }) => (
                      <tr key={program.id} className="border-b hover:bg-neutral-light/50">
                        <td className="py-3 px-3">{program.title}</td>
                        <td className="py-3 px-3">{new Date(program.date).toLocaleDateString()}</td>
                        <td className="py-3 px-3">
                          {program.currentParticipants}/{program.maxParticipants}
                          {program.currentParticipants >= program.minParticipants ? (
                            <span className="text-green-500 ml-2">(최소 인원 달성)</span>
                          ) : (
                            <span className="text-amber-500 ml-2">(최소 인원 미달)</span>
                          )}
                        </td>
                        <td className="py-3 px-3">
                          <StatusBadge status={program.status as "confirmed" | "pending" | "canceled"} />
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleStatusUpdate(program.id, "confirmed")}
                              disabled={program.status === "confirmed"}
                            >
                              확정
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleStatusUpdate(program.id, "pending")}
                              disabled={program.status === "pending"}
                            >
                              대기
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleStatusUpdate(program.id, "canceled")}
                              disabled={program.status === "canceled"}
                            >
                              취소
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="registrations">
          <Card>
            <CardHeader>
              <CardTitle>신청자 목록</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3">프로그램 ID</th>
                      <th className="text-left py-2 px-3">아이 이름</th>
                      <th className="text-left py-2 px-3">아이 월령</th>
                      <th className="text-left py-2 px-3">보호자 이름</th>
                      <th className="text-left py-2 px-3">연락처</th>
                      <th className="text-left py-2 px-3">이메일</th>
                      <th className="text-left py-2 px-3">특이사항</th>
                    </tr>
                  </thead>
                  <tbody>
                    {registrations?.map((registration) => (
                      <tr key={registration.id} className="border-b hover:bg-neutral-light/50">
                        <td className="py-3 px-3">{registration.programId}</td>
                        <td className="py-3 px-3">{registration.childName}</td>
                        <td className="py-3 px-3">{registration.childAge}개월</td>
                        <td className="py-3 px-3">{registration.parentName}</td>
                        <td className="py-3 px-3">{registration.phone}</td>
                        <td className="py-3 px-3">{registration.email}</td>
                        <td className="py-3 px-3">{registration.notes || "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
