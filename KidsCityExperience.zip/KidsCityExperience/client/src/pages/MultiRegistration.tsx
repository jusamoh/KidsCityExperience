import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { registrationFormSchema } from "@shared/schema";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { PaymentModal } from "@/components/PaymentModal";

// 다중 프로그램 등록 형식
const multiRegistrationFormSchema = registrationFormSchema.omit({ programId: true }).extend({
  agreement: z.boolean().refine(val => val === true, {
    message: "개인정보 수집 및 이용에 동의해야 합니다."
  })
});

type MultiRegistrationFormData = z.infer<typeof multiRegistrationFormSchema>;
type Program = {
  id: number;
  title: string;
  description: string;
  date: string;
  location: string;
  price: number;
  minAge: number;
  maxAge: number;
  currentParticipants: number;
};

export default function MultiRegistration() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedPrograms, setSelectedPrograms] = useState<number[]>([]);
  const [registrationId, setRegistrationId] = useState<number | null>(null);
  const [totalPrice, setTotalPrice] = useState<number>(0);
  const [aggregatedProgramName, setAggregatedProgramName] = useState<string>("");
  
  // URL에서 선택된 프로그램 ID 가져오기
  const location = typeof window !== "undefined" ? window.location : { search: "" };
  const searchParams = new URLSearchParams(location.search);
  const programIds = searchParams.get("programs")?.split(",").map(Number) || [];
  
  // 폼 설정
  const form = useForm<MultiRegistrationFormData>({
    resolver: zodResolver(multiRegistrationFormSchema),
    defaultValues: {
      childName: "",
      childAge: 0,
      parentName: "",
      phone: "",
      email: "",
      notes: "",
      agreement: false,
    },
  });
  
  // 선택된 프로그램 조회
  const { data: programs, isLoading } = useQuery({
    queryKey: ['/api/selected-programs', programIds.join(',')],
    queryFn: async () => {
      // 선택된 프로그램 ID가 없으면 빈 배열 반환
      if (programIds.length === 0) return [];
      
      // 각 프로그램 정보 조회
      const promises = programIds.map(async (id) => {
        const res = await fetch(`/api/programs/${id}`, { credentials: 'include' });
        if (!res.ok) throw new Error(`프로그램 ID ${id}를 불러오는 데 실패했습니다.`);
        return res.json();
      });
      
      return Promise.all(promises);
    }
  });
  
  // 프로그램 데이터가 로드되면 상태 업데이트
  useEffect(() => {
    if (programs && programs.length > 0) {
      // 프로그램 ID 목록 설정
      setSelectedPrograms(programs.map((program: Program) => program.id));
      
      // 총 가격 계산
      const total = programs.reduce((sum: number, program: Program) => sum + program.price, 0);
      setTotalPrice(total);
      
      // 결합된 프로그램 이름 생성 (결제 모달용)
      if (programs.length > 1) {
        setAggregatedProgramName(`${programs[0].title} 외 ${programs.length - 1}개`);
      } else if (programs.length === 1) {
        setAggregatedProgramName(programs[0].title);
      }
    }
  }, [programs]);
  
  // 모든 프로그램에 대한 등록 처리 함수
  const handleRegistrations = async (formData: MultiRegistrationFormData) => {
    try {
      // 모든 프로그램에 대해 등록 생성
      const registrationPromises = selectedPrograms.map(async (programId) => {
        const registrationData = {
          ...formData,
          programId
        };
        
        const response = await apiRequest("POST", "/api/registrations", registrationData);
        return await response.json();
      });
      
      // 등록 결과 기다리기
      const registrationResults = await Promise.all(registrationPromises);
      
      // 첫 번째 등록 ID를 결제에 사용
      // (시스템에서 첫 번째 등록에 결제 정보를 연결하고 나머지는 이를 참조하도록 구현 가정)
      const firstRegistration = registrationResults[0];
      return firstRegistration;
    } catch (error) {
      console.error("다중 등록 처리 오류:", error);
      throw error;
    }
  };
  
  // 등록 생성 mutation
  const createRegistrationsMutation = useMutation({
    mutationFn: async (data: MultiRegistrationFormData) => {
      setIsSubmitting(true);
      return handleRegistrations(data);
    },
    onSuccess: (data) => {
      // 등록 완료 후 결제 모달 열기
      setRegistrationId(data.id);
      setIsPaymentModalOpen(true);
      
      toast({
        title: "신청 완료",
        description: "프로그램 신청이 완료되었습니다. 결제를 진행해주세요.",
      });
    },
    onError: (error) => {
      toast({
        title: "신청 실패",
        description: error instanceof Error ? error.message : "프로그램 신청 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });
  
  // 폼 제출 처리
  const onSubmit = (data: MultiRegistrationFormData) => {
    if (selectedPrograms.length === 0) {
      toast({
        title: "신청 오류",
        description: "선택된 프로그램이 없습니다.",
        variant: "destructive",
      });
      return;
    }
    
    createRegistrationsMutation.mutate(data);
  };
  
  // 결제 성공 시 처리
  const handlePaymentSuccess = () => {
    toast({
      title: "결제 완료",
      description: "프로그램 신청 및 결제가 완료되었습니다.",
    });
    navigate("/");
  };
  
  // 결제 모달 닫기
  const handleClosePaymentModal = () => {
    setIsPaymentModalOpen(false);
    navigate("/");
  };
  
  // 선택된 프로그램이 없으면 프로그램 선택 페이지로 이동
  useEffect(() => {
    if (programIds.length === 0 && !isLoading) {
      toast({
        title: "선택된 프로그램 없음",
        description: "프로그램을 먼저 선택해주세요.",
      });
      navigate("/program-selection");
    }
  }, [programIds, isLoading, navigate, toast]);
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold font-heading text-center text-neutral-dark mb-4">다중 프로그램 신청</h2>
        <p className="text-center text-neutral-dark mb-8 max-w-2xl mx-auto">
          선택하신 프로그램을 한 번에 신청하고 결제합니다. 프로그램 확정 또는 취소 시 등록된 연락처로 안내드립니다.
        </p>
        
        {/* 선택된 프로그램 목록 */}
        <div className="max-w-2xl mx-auto mb-8">
          <h3 className="text-xl font-bold mb-4">선택한 프로그램</h3>
          {programs && programs.length > 0 ? (
            <div className="grid gap-4">
              {programs.map((program: Program) => (
                <Card key={program.id} className="overflow-hidden">
                  <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-lg">{program.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-neutral-dark font-medium">일시:</span>{" "}
                        {new Date(program.date).toLocaleDateString()} {new Date(program.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                      <div>
                        <span className="text-neutral-dark font-medium">장소:</span> {program.location}
                      </div>
                      <div>
                        <span className="text-neutral-dark font-medium">대상:</span> {program.minAge}~{program.maxAge}개월
                      </div>
                      <div>
                        <span className="text-neutral-dark font-medium">가격:</span> {program.price.toLocaleString()}원
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              <div className="mt-2 p-4 bg-neutral-light rounded-lg">
                <div className="flex justify-between">
                  <span className="font-bold">총 결제 금액:</span>
                  <span className="font-bold text-primary">{totalPrice.toLocaleString()}원</span>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-center p-4 bg-neutral-light rounded-lg">
              선택된 프로그램이 없습니다. <Button onClick={() => navigate("/program-selection")} variant="link" className="p-0">프로그램 선택으로 이동</Button>
            </p>
          )}
        </div>
        
        {/* 신청 폼 */}
        <div className="max-w-2xl mx-auto bg-neutral-light rounded-2xl p-8 shadow-lg">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="childName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-neutral-dark font-medium mb-2">아이 이름</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="아이 이름을 입력해주세요"
                          className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="childAge"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-neutral-dark font-medium mb-2">아이 월령</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="개월 수"
                          min={0}
                          max={24}
                          className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormDescription>
                        프로그램별 대상 월령을 확인해주세요.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="parentName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-neutral-dark font-medium mb-2">보호자 이름</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="보호자 이름을 입력해주세요"
                          className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-neutral-dark font-medium mb-2">연락처</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="010-0000-0000"
                          className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-neutral-dark font-medium mb-2">이메일</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="이메일 주소를 입력해주세요"
                        className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-neutral-dark font-medium mb-2">특이사항 (선택)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="알레르기나 기타 특이사항이 있다면 알려주세요"
                        rows={3}
                        className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                        {...field}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="agreement"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm text-neutral-dark">
                        개인정보 수집 및 이용에 동의합니다. 수집된 정보는 프로그램 운영 목적으로만 사용되며, 프로그램 종료 후 안전하게 폐기됩니다.
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
              
              <div className="text-center">
                <Button 
                  type="submit" 
                  disabled={isSubmitting || selectedPrograms.length === 0}
                  className="bg-primary text-white hover:bg-primary/90 px-8 py-3 rounded-full font-bold"
                >
                  {isSubmitting ? '처리중...' : '신청하기'}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
      
      {/* 결제 모달 */}
      {registrationId && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={handleClosePaymentModal}
          registrationId={registrationId}
          programName={aggregatedProgramName}
          price={totalPrice}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </section>
  );
}