import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

export default function RefundPolicy() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">환불 정책</h1>
        <p className="text-neutral-dark/70">
          와글와글 체험 프로그램의 환불 정책에 대한 안내입니다.
        </p>
      </div>

      <div className="space-y-8 mb-12">
        <div>
          <h2 className="text-xl font-bold mb-4">환불 기준</h2>
          <p className="mb-4">
            와글와글은 고객님의 편의를 위해 다음과 같은 환불 정책을 운영하고 있습니다. 프로그램 예약 취소 시 환불 금액은 아래 기준에 따라 적용됩니다.
          </p>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-1/2">취소 시점</TableHead>
                <TableHead>환불 금액</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>프로그램 시작일 7일 전까지</TableCell>
                <TableCell>결제 금액의 100% 환불</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>프로그램 시작일 6일 전 ~ 4일 전</TableCell>
                <TableCell>결제 금액의 70% 환불</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>프로그램 시작일 3일 전 ~ 2일 전</TableCell>
                <TableCell>결제 금액의 50% 환불</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>프로그램 시작일 1일 전</TableCell>
                <TableCell>결제 금액의 30% 환불</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>프로그램 시작일 당일</TableCell>
                <TableCell>환불 불가</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-4">프로그램 미확정 시 환불</h2>
          <p className="mb-4">
            최소 인원 미달로 프로그램이 확정되지 않아 취소되는 경우, 결제하신 금액은 전액 환불해 드립니다.
          </p>
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>프로그램 미확정 환불 안내</AlertTitle>
            <AlertDescription>
              프로그램 미확정으로 인한 취소는 프로그램 시작일 최소 3일 전에 안내드리며, 결제하신 방법으로 자동 환불 처리됩니다.
            </AlertDescription>
          </Alert>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-4">불가항력적 상황으로 인한 취소</h2>
          <p className="mb-4">
            천재지변, 재난 상황, 갑작스러운 정부 정책 변화 등 불가항력적인 상황으로 인해 프로그램이 취소되는 경우에는 전액 환불해 드립니다.
          </p>
          <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
            <h3 className="text-sm font-medium text-blue-800 mb-1">불가항력적 상황의 예시</h3>
            <ul className="list-disc pl-5 text-sm text-blue-700">
              <li>태풍, 지진, 홍수 등의 자연재해</li>
              <li>감염병 확산에 따른 정부 지침 변경</li>
              <li>프로그램 장소의 갑작스러운 폐쇄 또는 이용 불가 상황</li>
              <li>강사의 갑작스러운 건강 문제 또는 사고</li>
            </ul>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-4">환불 신청 방법</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
              <h3 className="font-medium mb-2">마이페이지에서 신청</h3>
              <p className="text-sm text-neutral-dark/80">
                프로그램 시작일 3일 전까지는 마이페이지에서 직접 취소 및 환불 신청이 가능합니다.
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
              <h3 className="font-medium mb-2">고객센터 문의</h3>
              <p className="text-sm text-neutral-dark/80">
                프로그램 시작일 2일 전부터는 고객센터(02-123-4567)로 문의하여 환불 신청을 진행해 주세요.
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
              <h3 className="font-medium mb-2">이메일 신청</h3>
              <p className="text-sm text-neutral-dark/80">
                부득이한 경우 이메일(refund@waggle.kr)로 환불 신청이 가능합니다. 이름, 연락처, 프로그램명을 함께 기재해 주세요.
              </p>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-4">환불 처리 소요 시간</h2>
          <p className="mb-4">
            환불 신청이 완료된 후 결제 수단에 따라 환불 처리 시간이 다를 수 있습니다.
          </p>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>결제 수단</TableHead>
                <TableHead>환불 소요 시간</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>신용카드/체크카드</TableCell>
                <TableCell>3~7 영업일</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>계좌이체</TableCell>
                <TableCell>1~3 영업일</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>가상계좌</TableCell>
                <TableCell>1~3 영업일</TableCell>
              </TableRow>
            </TableBody>
          </Table>
          <p className="text-sm text-neutral-dark/60 mt-2">
            * 환불 금액은 원결제 수단으로 환불됩니다.
          </p>
        </div>
      </div>

      <div className="bg-primary/5 rounded-lg p-6 md:p-8">
        <h3 className="text-xl font-bold mb-4">환불 관련 문의</h3>
        <p className="mb-6">환불 정책에 관한 추가 문의사항은 고객센터로 연락해 주세요.</p>
        <div className="flex flex-wrap gap-4">
          <div className="bg-white p-4 rounded-md shadow-sm">
            <p className="text-sm text-neutral-dark/70 mb-1">이메일</p>
            <p className="font-medium">refund@waggle.kr</p>
          </div>
          <div className="bg-white p-4 rounded-md shadow-sm">
            <p className="text-sm text-neutral-dark/70 mb-1">전화번호</p>
            <p className="font-medium">02-123-4567</p>
          </div>
          <div className="bg-white p-4 rounded-md shadow-sm">
            <p className="text-sm text-neutral-dark/70 mb-1">운영시간</p>
            <p className="font-medium">평일 10:00 - 18:00</p>
          </div>
        </div>
      </div>
    </div>
  );
}