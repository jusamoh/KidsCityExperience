import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight, ArrowRight } from "lucide-react";

export default function HowToUse() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">이용방법</h1>
        <p className="text-neutral-dark/70">
          파주 체험 Camp 체험 프로그램 이용 방법에 대한 안내입니다.
        </p>
      </div>

      <div className="grid gap-8 mb-12">
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center flex-shrink-0">
                <span className="text-2xl font-bold text-primary">1</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">프로그램 선택</h3>
                <p className="text-neutral-dark/80 mb-4">
                  메인 페이지나 체험프로그램 페이지에서 원하는 프로그램을 선택하세요. 도시텃밭 체험, 영어놀이 체험, 스포츠 및 놀이 체험 등 다양한 카테고리에서 선택할 수 있습니다.
                </p>
                <Link href="/#programs">
                  <Button variant="outline" className="group">
                    프로그램 살펴보기
                    <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition" />
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center flex-shrink-0">
                <span className="text-2xl font-bold text-primary">2</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">프로그램 신청</h3>
                <p className="text-neutral-dark/80 mb-4">
                  선택한 프로그램의 상세 페이지에서 '신청하기' 버튼을 클릭하여 신청 양식을 작성합니다. 아이 이름, 나이, 부모님 연락처 등의 정보를 입력하세요.
                </p>
                <p className="text-sm text-neutral-dark/60 mb-4">
                  * 회원가입이 되어있지 않다면 먼저 회원가입을 진행해야 합니다.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center flex-shrink-0">
                <span className="text-2xl font-bold text-primary">3</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">결제하기</h3>
                <p className="text-neutral-dark/80 mb-4">
                  프로그램 신청 후 결제 페이지로 이동하여 결제를 진행합니다. 카드 결제, 계좌이체 등 다양한 결제 방법을 선택할 수 있습니다.
                </p>
                <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-4">
                  <h4 className="text-sm font-medium text-yellow-800 mb-1">중요 안내</h4>
                  <p className="text-sm text-yellow-700">
                    프로그램은 최소 인원이 모집되어야 확정됩니다. 신청 후 프로그램 확정 여부를 마이페이지에서 확인하세요.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center flex-shrink-0">
                <span className="text-2xl font-bold text-primary">4</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">신청 확인 및 체험 참여</h3>
                <p className="text-neutral-dark/80 mb-4">
                  결제 완료 후 마이페이지에서 신청 내역을 확인할 수 있습니다. 프로그램 최소 인원이 모집되면 확정 안내 메시지를 받게 됩니다.
                </p>
                <p className="text-neutral-dark/80 mb-4">
                  프로그램 당일에는 지정된 장소에 시간에 맞춰 방문하여 체험에 참여하세요.
                </p>
                <Link href="/my-page">
                  <Button variant="outline" className="group">
                    마이페이지로 이동
                    <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition" />
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="bg-primary/5 rounded-lg p-6 md:p-8">
        <h3 className="text-xl font-bold mb-4">추가 문의사항이 있으신가요?</h3>
        <p className="mb-6">체험 프로그램에 대한 추가 문의사항은 고객센터로 연락해 주세요.</p>
        <div className="flex flex-wrap gap-4">
          <div className="bg-white p-4 rounded-md shadow-sm">
            <p className="text-sm text-neutral-dark/70 mb-1">이메일</p>
            <p className="font-medium">info@paju.kr</p>
          </div>
          <div className="bg-white p-4 rounded-md shadow-sm">
            <p className="text-sm text-neutral-dark/70 mb-1">전화번호</p>
            <p className="font-medium">02-123-4567</p>
          </div>
          <div className="bg-white p-4 rounded-md shadow-sm">
            <p className="text-sm text-neutral-dark/70 mb-1">운영시간</p>
            <p className="font-medium">평일 10:00 - 18:00</p>
          </div>
        </div>
      </div>
    </div>
  );
}