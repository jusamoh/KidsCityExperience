import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { RegistrationFormData, registrationFormSchema } from "@shared/schema";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { PaymentModal } from "@/components/PaymentModal";

export default function Registration() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [registrationId, setRegistrationId] = useState<number | null>(null);
  
  // Fetch program details
  const { data: program, isLoading } = useQuery({
    queryKey: [`/api/programs/${id}`],
  });
  
  // Set up form with react-hook-form and zod validation
  const form = useForm<RegistrationFormData>({
    resolver: zodResolver(registrationFormSchema),
    defaultValues: {
      programId: parseInt(id as string),
      childName: "",
      childAge: 0,
      parentName: "",
      phone: "",
      email: "",
      notes: "",
      agreement: false,
    },
  });
  
  // Create registration mutation
  const createRegistration = useMutation({
    mutationFn: async (data: RegistrationFormData) => {
      setSubmitting(true);
      const result = await apiRequest("POST", "/api/registrations", data);
      return result.json();
    },
    onSuccess: (data) => {
      // 등록 완료 후 결제 모달 열기
      setRegistrationId(data.id);
      setIsPaymentModalOpen(true);
      toast({
        title: "신청 완료",
        description: "프로그램 신청이 완료되었습니다. 결제를 진행해주세요.",
      });
    },
    onError: (error) => {
      toast({
        title: "신청 실패",
        description: error instanceof Error ? error.message : "프로그램 신청 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setSubmitting(false);
    },
  });
  
  const onSubmit = (data: RegistrationFormData) => {
    createRegistration.mutate(data);
  };
  
  // 결제 성공 시 처리
  const handlePaymentSuccess = () => {
    toast({
      title: "결제 완료",
      description: "프로그램 신청 및 결제가 완료되었습니다.",
    });
    navigate("/");
  };
  
  // 결제 모달 닫기
  const handleClosePaymentModal = () => {
    setIsPaymentModalOpen(false);
    navigate("/");
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!program) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold text-center mb-4">프로그램을 찾을 수 없습니다</h2>
            <div className="flex justify-center">
              <Button onClick={() => navigate("/")}>홈으로 돌아가기</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold font-heading text-center text-neutral-dark mb-4">프로그램 신청하기</h2>
        <p className="text-center text-neutral-dark mb-12 max-w-2xl mx-auto">
          아래 양식을 작성하여 프로그램을 신청해주세요. 프로그램 확정 또는 취소 시 등록된 연락처로 안내드립니다.
        </p>
        
        <div className="max-w-2xl mx-auto bg-neutral-light rounded-2xl p-8 shadow-lg">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="programId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-neutral-dark font-medium mb-2">신청 프로그램</FormLabel>
                    <FormControl>
                      <Input
                        disabled
                        value={program.title}
                        className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </FormControl>
                    <FormDescription>
                      참가비: {program.price.toLocaleString()}원
                    </FormDescription>
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="childName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-neutral-dark font-medium mb-2">아이 이름</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="아이 이름을 입력해주세요"
                          className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="childAge"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-neutral-dark font-medium mb-2">아이 월령</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="개월 수"
                          min={0}
                          max={24}
                          className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormDescription>
                        {program.minAge}~{program.maxAge}개월 아이가 참여할 수 있습니다.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="parentName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-neutral-dark font-medium mb-2">보호자 이름</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="보호자 이름을 입력해주세요"
                          className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-neutral-dark font-medium mb-2">연락처</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="010-0000-0000"
                          className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-neutral-dark font-medium mb-2">이메일</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="이메일 주소를 입력해주세요"
                        className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-neutral-dark font-medium mb-2">특이사항 (선택)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="알레르기나 기타 특이사항이 있다면 알려주세요"
                        rows={3}
                        className="w-full px-4 py-3 rounded-xl border border-neutral-light focus:outline-none focus:ring-2 focus:ring-primary"
                        {...field}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="agreement"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm text-neutral-dark">
                        개인정보 수집 및 이용에 동의합니다. 수집된 정보는 프로그램 운영 목적으로만 사용되며, 프로그램 종료 후 안전하게 폐기됩니다.
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
              
              <div className="text-center">
                <Button 
                  type="submit" 
                  disabled={submitting}
                  className="bg-primary text-white hover:bg-primary/90 px-8 py-3 rounded-full font-bold"
                >
                  {submitting ? '처리중...' : '신청하기'}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
      
      {/* 결제 모달 */}
      {program && registrationId && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={handleClosePaymentModal}
          registrationId={registrationId}
          programName={program.title}
          price={program.price}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </section>
  );
}
