import { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { XCircle, ArrowRight, RefreshCcw } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function PaymentFail() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [programId, setProgramId] = useState<string | null>(null);

  // URL에서 에러 메시지와 orderId 파라미터 가져오기
  const params = new URLSearchParams(window.location.search);
  const message = params.get('message') || '결제 처리 중 오류가 발생했습니다.';
  const orderId = params.get('orderId');
  const code = params.get('code');

  // 주문 ID가 있으면 해당 프로그램 정보를 조회
  useEffect(() => {
    if (orderId) {
      const fetchOrderInfo = async () => {
        try {
          // 주문 ID로 결제 정보 조회 시도
          const response = await apiRequest('GET', `/api/payments/order-info?orderId=${orderId}`);
          if (response.ok) {
            const data = await response.json();
            if (data.programId) {
              setProgramId(data.programId.toString());
            }
          }
        } catch (err) {
          console.error('주문 정보 조회 오류:', err);
        }
      };
      
      fetchOrderInfo();
    }
  }, [orderId]);

  // 결제 실패 이유 포맷팅
  const formatErrorMessage = () => {
    if (code) {
      switch (code) {
        case 'PAY_PROCESS_CANCELED':
          return '결제가 취소되었습니다.';
        case 'PAY_PROCESS_ABORTED':
          return '결제 진행 중 문제가 발생했습니다.';
        case 'INVALID_CARD_COMPANY':
          return '유효하지 않은 카드사입니다.';
        case 'INVALID_CARD_NUMBER':
          return '유효하지 않은 카드번호입니다.';
        case 'INVALID_CARD_EXPIRATION':
          return '유효하지 않은 카드 유효기간입니다.';
        case 'INVALID_CARD_PASSWORD':
          return '유효하지 않은 카드 비밀번호입니다.';
        case 'INVALID_CARD_INSTALLMENT_PLAN':
          return '유효하지 않은 할부 개월 수입니다.';
        case 'INVALID_CARD_AUTHENTICATION':
          return '카드 인증에 실패했습니다.';
        case 'INVALID_CARD_POINT':
          return '카드 포인트 오류가 발생했습니다.';
        case 'INSUFFICIENT_CARD_BALANCE':
          return '카드 잔액이 부족합니다.';
        default:
          return message;
      }
    }
    return message;
  };

  const tryAgain = () => {
    if (programId) {
      navigate(`/program/${programId}`);
    } else {
      navigate('/');
    }
    
    toast({
      title: '결제 다시 시도',
      description: '프로그램 페이지로 이동합니다.',
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16 flex items-center justify-center px-4">
      <Card className="w-full max-w-md mx-auto shadow-lg border-0">
        <CardHeader className="text-center pb-0">
          <div className="w-20 h-20 rounded-full bg-red-100 mx-auto mb-4 flex items-center justify-center">
            <XCircle className="h-10 w-10 text-red-500" />
          </div>
          <CardTitle className="text-2xl mb-2">결제에 실패했습니다</CardTitle>
          <CardDescription>
            결제 과정에서 문제가 발생했습니다
          </CardDescription>
        </CardHeader>
        
        <CardContent className="pt-6">
          <div className="bg-red-50 p-4 rounded-md text-red-700 mb-6 border border-red-200">
            <p className="font-medium">{formatErrorMessage()}</p>
            {orderId && <p className="mt-2 text-sm">주문번호: {orderId}</p>}
          </div>
          
          <div className="space-y-4 mb-6">
            <p className="text-center text-muted-foreground">
              결제에 문제가 발생했습니다. 다시 시도하시거나 고객센터로 문의해주세요.
            </p>
            
            {code === 'INSUFFICIENT_CARD_BALANCE' && (
              <div className="bg-yellow-50 p-3 rounded-md text-yellow-700 text-sm border border-yellow-200">
                <p>카드 잔액이 부족합니다. 다른 결제 수단을 이용하시거나 카드사에 문의해주세요.</p>
              </div>
            )}
          </div>
          
          <div className="flex flex-col space-y-3 mt-6">
            <Button 
              onClick={tryAgain}
              className="w-full bg-primary hover:bg-primary/90 text-white"
            >
              <RefreshCcw className="mr-2 h-4 w-4" />
              다시 시도하기
            </Button>
            
            <Link href="/">
              <Button variant="outline" className="w-full">
                홈으로 돌아가기
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            
            {programId && (
              <Link href={`/program/${programId}`}>
                <Button variant="outline" className="w-full">
                  프로그램 상세로 돌아가기
                </Button>
              </Link>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}