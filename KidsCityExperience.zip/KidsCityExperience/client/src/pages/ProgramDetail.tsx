import { useQuery } from "@tanstack/react-query";
import { Link, useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";
import { format } from "date-fns";
import { ko } from "date-fns/locale";

export default function ProgramDetail() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  
  const { data: program, isLoading } = useQuery({
    queryKey: [`/api/programs/${id}`],
  });
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!program) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold text-center mb-4">프로그램을 찾을 수 없습니다</h2>
            <div className="flex justify-center">
              <Link href="/">
                <Button>홈으로 돌아가기</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Map categoryId to category name and class
  const categoryInfo = {
    1: { name: "도시텃밭 체험", bgClass: "bg-secondary/20 text-secondary" },
    2: { name: "영어놀이 체험", bgClass: "bg-primary/20 text-primary" },
    3: { name: "스포츠 및 놀이 체험", bgClass: "bg-accent/30 text-neutral-dark" },
  };
  
  const categoryName = categoryInfo[program.categoryId as keyof typeof categoryInfo]?.name || "기타 체험";
  const categoryBgClass = categoryInfo[program.categoryId as keyof typeof categoryInfo]?.bgClass || "bg-muted text-muted-foreground";
  
  // Format date
  const formattedDate = format(new Date(program.date), "M월 d일 (E) HH:mm", { locale: ko });
  
  // Calculate end time
  const endDate = new Date(program.date);
  endDate.setMinutes(endDate.getMinutes() + program.duration);
  const formattedEndTime = format(endDate, "HH:mm", { locale: ko });
  
  const handleRegisterClick = () => {
    navigate(`/registration/${id}`);
  };
  
  return (
    <section className="py-16 bg-neutral-light">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2">
              <img 
                src={program.imageUrl} 
                alt={`${program.title} 프로그램 상세 보기`} 
                className="w-full h-full object-cover" 
              />
            </div>
            <div className="md:w-1/2 p-8">
              <div className="flex items-center mb-4">
                <span className={`text-sm font-medium ${categoryBgClass} px-3 py-1 rounded-full`}>
                  {categoryName}
                </span>
                <div className="ml-3">
                  <StatusBadge status={program.status as "confirmed" | "pending" | "canceled"} />
                </div>
              </div>
              
              <h2 className="font-heading font-bold text-3xl mb-4">{program.title}</h2>
              
              <div className="flex items-center text-sm text-neutral-dark mb-6">
                <div className="flex items-center mr-4">
                  <i className="fas fa-calendar-alt text-primary mr-2"></i>
                  <span>{formattedDate} - {formattedEndTime}</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-map-marker-alt text-primary mr-2"></i>
                  <span>{program.location}</span>
                </div>
              </div>
              
              <div className="bg-neutral-light rounded-xl p-4 flex justify-between mb-6">
                <div className="text-center">
                  <p className="text-sm text-neutral-dark">연령</p>
                  <p className="font-semibold">{program.minAge}-{program.maxAge}개월</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-neutral-dark">정원</p>
                  <p className="font-semibold">{program.maxParticipants}명</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-neutral-dark">현재 신청</p>
                  <p className="font-semibold text-primary">{program.currentParticipants}명</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-neutral-dark">최소 인원</p>
                  <p className="font-semibold">{program.minParticipants}명</p>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="font-heading font-semibold text-xl mb-3">프로그램 소개</h3>
                <p className="text-neutral-dark whitespace-pre-line">{program.description}</p>
              </div>
              
              <div className="flex flex-col sm:flex-row justify-between items-center">
                <div className="text-2xl font-bold text-primary mb-4 sm:mb-0">{program.price.toLocaleString()}원</div>
                <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                  <Button
                    onClick={() => navigate('/program-selection')}
                    className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white px-6 py-3 rounded-full font-semibold"
                  >
                    목록으로 돌아가기
                  </Button>
                  {program.status === "canceled" ? (
                    <Button
                      disabled
                      className="w-full sm:w-auto bg-neutral-dark text-white px-6 py-3 rounded-full font-semibold"
                    >
                      취소된 프로그램입니다
                    </Button>
                  ) : (
                    <Button
                      onClick={handleRegisterClick}
                      className="w-full sm:w-auto bg-primary text-white hover:bg-primary/90 px-6 py-3 rounded-full font-semibold"
                    >
                      프로그램 신청하기
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
