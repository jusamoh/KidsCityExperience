import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQ() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">자주 묻는 질문</h1>
        <p className="text-neutral-dark/70">
          파주 체험 Camp 체험 프로그램 이용에 관한 자주 묻는 질문과 답변입니다.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <div>
          <h2 className="text-xl font-bold mb-4">프로그램 이용 관련</h2>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger className="text-left">
                2살 미만 영유아 프로그램이란 무엇인가요?
              </AccordionTrigger>
              <AccordionContent>
                2살 미만 영유아 프로그램은 어린 아이들의 성장과 발달을 돕기 위해 특별히 설계된 체험 프로그램입니다. 
                도시텃밭 체험, 영어놀이 체험, 스포츠 및 놀이 체험 등 다양한 카테고리로 구성되어 있으며, 
                모든 활동은 영유아의 안전과 발달 단계를 고려하여 진행됩니다.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger className="text-left">
                참여 가능한 연령대는 어떻게 되나요?
              </AccordionTrigger>
              <AccordionContent>
                각 프로그램마다 참여 가능한 연령대가 다르지만, 주로 6개월에서 24개월(2살) 미만의 영유아를 대상으로 합니다. 
                프로그램 상세 페이지에서 각 체험별 권장 연령을 확인하실 수 있습니다.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger className="text-left">
                프로그램은 어디서 진행되나요?
              </AccordionTrigger>
              <AccordionContent>
                프로그램은 서울시 내 지정된 장소에서 진행됩니다. 각 프로그램마다 진행 장소가 다를 수 있으니, 
                프로그램 상세 페이지에서 장소 정보를 확인해 주세요. 일부 프로그램은 실내에서, 
                일부는 야외(도시텃밭 등)에서 진행될 수 있습니다.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4">
              <AccordionTrigger className="text-left">
                부모님도 함께 참여해야 하나요?
              </AccordionTrigger>
              <AccordionContent>
                네, 모든 프로그램은 영유아의 안전과 효과적인 체험을 위해 부모님(보호자)의 동반 참여가 필수입니다. 
                부모님은 아이와 함께 체험에 참여하며 활동을 도와주시게 됩니다.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger className="text-left">
                프로그램 소요 시간은 얼마나 되나요?
              </AccordionTrigger>
              <AccordionContent>
                프로그램마다 다르지만 대부분 30분에서 1시간 정도 소요됩니다. 영유아의 집중 시간과 체력을 고려하여 
                적절한 시간으로, 쉬는 시간을 포함하여 진행됩니다. 구체적인 시간은 각 프로그램 상세 페이지에서 확인하실 수 있습니다.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
        
        <div>
          <h2 className="text-xl font-bold mb-4">신청 및 결제 관련</h2>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-6">
              <AccordionTrigger className="text-left">
                프로그램은 어떻게 신청하나요?
              </AccordionTrigger>
              <AccordionContent>
                웹사이트 메인 페이지 또는 체험프로그램 페이지에서 원하는 프로그램을 선택한 후, 
                상세 페이지에서 '신청하기' 버튼을 클릭하여 신청할 수 있습니다. 회원가입 후 로그인한 상태에서만 
                신청이 가능하며, 필요한 정보를 입력한 후 결제까지 완료하면 신청이 완료됩니다.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-7">
              <AccordionTrigger className="text-left">
                프로그램이 확정되지 않으면 어떻게 되나요?
              </AccordionTrigger>
              <AccordionContent>
                각 프로그램은 최소 인원이 모집되어야 확정됩니다. 모집 인원이 충족되지 않아 프로그램이 취소될 경우, 
                결제하신 금액은 전액 환불해 드립니다. 프로그램 확정 여부는 마이페이지에서 확인 가능하며, 
                취소 시 등록된 연락처로 별도 안내를 드립니다.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-8">
              <AccordionTrigger className="text-left">
                결제 방법은 어떤 것이 있나요?
              </AccordionTrigger>
              <AccordionContent>
                신용카드, 체크카드, 계좌이체, 가상계좌 등 다양한 결제 방법을 지원합니다. 
                결제 페이지에서 원하는 결제 방법을 선택하실 수 있습니다.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-9">
              <AccordionTrigger className="text-left">
                영수증은 어떻게 받을 수 있나요?
              </AccordionTrigger>
              <AccordionContent>
                결제 완료 후 영수증은 결제 완료 페이지에서 바로 확인하실 수 있으며, 
                마이페이지의 '결제 내역'에서도 언제든지 다시 확인하고 출력하실 수 있습니다.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-10">
              <AccordionTrigger className="text-left">
                예약을 변경하거나 취소할 수 있나요?
              </AccordionTrigger>
              <AccordionContent>
                프로그램 시작 3일 전까지는 마이페이지에서 직접 예약을 변경하거나 취소할 수 있습니다. 
                그 이후에는 고객센터로 문의해 주셔야 하며, 환불 규정에 따라 처리됩니다. 
                자세한 내용은 환불 정책을 참고해 주세요.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </div>
      
      <div className="mb-12">
        <h2 className="text-xl font-bold mb-4">프로그램 종류 관련</h2>
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-11">
            <AccordionTrigger className="text-left">
              도시텃밭 체험은 어떤 활동을 하나요?
            </AccordionTrigger>
            <AccordionContent>
              도시텃밭 체험에서는 상추, 방울토마토, 고추 등 우리나라에서 흔히 볼 수 있는 채소를 
              심고, 가꾸고, 수확하는 과정을 경험합니다. 영유아들은 흙을 만지고, 식물을 관찰하며 
              자연스럽게 생태 감수성을 키울 수 있습니다.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-12">
            <AccordionTrigger className="text-left">
              영어놀이 체험은 무엇을 배우나요?
            </AccordionTrigger>
            <AccordionContent>
              영어놀이 체험은 영어 그림책을 활용한 연극놀이와 인형극으로 구성됩니다. 
              'The Very Hungry Caterpillar', 'Brown Bear, Brown Bear' 등 유명한 영어 그림책을 
              기반으로 한 놀이를 통해 영유아들이 자연스럽게 영어에 노출되고 흥미를 가질 수 있도록 합니다.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-13">
            <AccordionTrigger className="text-left">
              스포츠 및 놀이 체험은 어떤 활동을 포함하나요?
            </AccordionTrigger>
            <AccordionContent>
              스포츠 및 놀이 체험은 영유아의 신체 발달을 돕는 다양한 활동으로 구성됩니다. 
              대근육 발달을 위한 간단한 체육 활동, 오감을 자극하는 감각놀이 등이 포함되어 있습니다. 
              모든 활동은 영유아의 안전을 최우선으로 고려하여 진행됩니다.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
      
      <div>
        <h2 className="text-xl font-bold mb-4">기타 문의</h2>
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-14">
            <AccordionTrigger className="text-left">
              프로그램 진행 중 사진이나 영상을 촬영할 수 있나요?
            </AccordionTrigger>
            <AccordionContent>
              네, 개인적인 용도로 자녀의 사진이나 영상을 촬영하실 수 있습니다. 단, 다른 참가자의 
              얼굴이 포함된 사진은 SNS 등에 공유하실 때 주의해 주시기 바랍니다.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-15">
            <AccordionTrigger className="text-left">
              프로그램에 필요한 준비물이 있나요?
            </AccordionTrigger>
            <AccordionContent>
              기본적인 준비물은 모두 제공됩니다. 다만, 간단한 물티슈나 여분의 옷, 기저귀 등 
              영유아가 필요할 수 있는 기본적인 물품은 준비해 오시는 것을 권장합니다. 
              특별히 준비해야 할 물품이 있는 경우, 프로그램 상세 페이지나 확정 안내 메시지를 통해 
              별도로 안내해 드립니다.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-16">
            <AccordionTrigger className="text-left">
              형제, 자매가 함께 참여할 수 있나요?
            </AccordionTrigger>
            <AccordionContent>
              네, 가능합니다. 단, 참여하는 모든 아이에 대해 각각 신청 및 결제가 필요합니다. 
              또한, 형제, 자매가 함께 참여할 경우 부모님 한 분이 두 아이를 모두 케어하기 어려울 수 있으니, 
              가능하면 보호자 두 분이 함께 참여하시는 것을 권장합니다.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-17">
            <AccordionTrigger className="text-left">
              비가 오면 야외 프로그램은 어떻게 되나요?
            </AccordionTrigger>
            <AccordionContent>
              날씨 상황에 따라 야외 프로그램은 실내 대체 프로그램으로 변경되거나 일정이 변경될 수 있습니다. 
              프로그램 변경이나 취소 시 등록된 연락처로 사전에 안내를 드립니다.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
}