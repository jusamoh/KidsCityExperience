import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function TermsOfService() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">이용약관</h1>
        <p className="text-neutral-dark/70">
          와글와글 체험 프로그램 이용에 관한 약관입니다.
        </p>
      </div>

      <Tabs defaultValue="terms" className="w-full mb-12">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="terms">이용약관</TabsTrigger>
          <TabsTrigger value="privacy">개인정보 처리방침</TabsTrigger>
        </TabsList>
        <TabsContent value="terms">
          <div className="border rounded-md p-6 bg-white">
            <ScrollArea className="h-96 w-full pr-4">
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-bold mb-3">제1조 (목적)</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed">
                    이 약관은 와글와글(이하 "회사"라 함)이 제공하는 체험 프로그램 서비스(이하 "서비스"라 함)의 이용과 관련하여 회사와 이용자 간의 권리, 의무 및 책임사항, 기타 필요한 사항을 규정함을 목적으로 합니다.
                  </p>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제2조 (정의)</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    이 약관에서 사용하는 용어의 정의는 다음과 같습니다.
                  </p>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>"서비스"란 회사가 제공하는 영유아 대상 체험 프로그램 및 이와 관련된 모든 서비스를 의미합니다.</li>
                    <li>"이용자"란 이 약관에 따라 회사가 제공하는 서비스를 이용하는 회원 및 비회원을 말합니다.</li>
                    <li>"회원"이란 회사에 개인정보를 제공하여 회원등록을 한 자로서, 회사가 제공하는 서비스를 이용할 수 있는 자를 말합니다.</li>
                    <li>"비회원"이란 회원으로 가입하지 않고 회사가 제공하는 서비스를 이용하는 자를 말합니다.</li>
                    <li>"프로그램"이란 회사가 제공하는 도시텃밭 체험, 영어놀이 체험, 스포츠 및 놀이 체험 등 각종 체험 활동을 의미합니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제3조 (약관의 게시와 개정)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>회사는 이 약관의 내용을 이용자가 쉽게 알 수 있도록 서비스 초기 화면에 게시합니다.</li>
                    <li>회사는 필요한 경우 관련법령을 위배하지 않는 범위에서 이 약관을 개정할 수 있습니다.</li>
                    <li>회사가 약관을 개정할 경우에는 적용일자 및 개정사유를 명시하여 현행 약관과 함께 서비스 초기 화면에 그 적용일자 7일 이전부터 적용일자 전일까지 공지합니다.</li>
                    <li>이용자는 개정된 약관에 동의하지 않을 경우 회원 탈퇴를 요청할 수 있으며, 개정된 약관의 적용일 이후 계속적으로 서비스를 이용하는 경우에는 약관의 변경사항에 동의한 것으로 간주됩니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제4조 (서비스의 제공 및 변경)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>회사는 다음과 같은 서비스를 제공합니다:
                      <ul className="list-disc pl-6 mt-2 mb-2 space-y-1">
                        <li>영유아 대상 체험 프로그램 정보 제공</li>
                        <li>체험 프로그램 예약 및 결제 서비스</li>
                        <li>체험 프로그램 관련 커뮤니티 서비스</li>
                        <li>기타 회사가 정하는 서비스</li>
                      </ul>
                    </li>
                    <li>회사는 운영상, 기술상의 필요에 따라 제공하고 있는 서비스를 변경할 수 있습니다.</li>
                    <li>회사는 서비스의 변경, 중단으로 발생하는 문제에 대해서는 책임을 지지 않습니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제5조 (회원가입)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>이용자는 회사가 정한 가입 양식에 따라 회원정보를 기입한 후 이 약관에 동의한다는 의사표시를 함으로써 회원가입을 신청합니다.</li>
                    <li>회사는 전항과 같이 회원으로 가입할 것을 신청한 이용자 중 다음 각 호에 해당하지 않는 한 회원으로 등록합니다.
                      <ul className="list-disc pl-6 mt-2 mb-2 space-y-1">
                        <li>가입신청자가 이 약관에 의하여 이전에 회원자격을 상실한 적이 있는 경우</li>
                        <li>실명이 아니거나 타인의 명의를 이용한 경우</li>
                        <li>허위의 정보를 기재하거나, 회사가 요구하는 정보를 제공하지 않은 경우</li>
                        <li>만 14세 미만 아동의 경우 법정대리인의 동의를 얻지 않은 경우</li>
                      </ul>
                    </li>
                    <li>회원가입계약의 성립 시기는 회사의 승낙이 회원에게 도달한 시점으로 합니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제6조 (회원정보의 변경)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>회원은 개인정보 관리화면을 통하여 언제든지 본인의 개인정보를 열람하고 수정할 수 있습니다.</li>
                    <li>회원은 회원가입 시 기재한 사항이 변경되었을 경우 온라인으로 수정을 하거나 전자우편 기타 방법으로 회사에 그 변경사항을 알려야 합니다.</li>
                    <li>제2항의 변경사항을 회사에 알리지 않아 발생한 불이익에 대하여 회사는 책임을 지지 않습니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제7조 (프로그램 예약 및 결제)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>이용자는 서비스를 통해 제공되는 프로그램을 예약하고 결제할 수 있습니다.</li>
                    <li>프로그램 예약 시 이용자는 정확한 정보를 입력해야 하며, 잘못된 정보 입력으로 인한 불이익은 이용자 본인이 부담합니다.</li>
                    <li>프로그램 결제가 완료된 후에도 최소 인원 미달 등의 사유로 프로그램이 취소될 수 있으며, 이 경우 회사는 이용자에게 사전에 안내하고 전액 환불해 드립니다.</li>
                    <li>예약 취소 및 환불에 관한 사항은 회사의 환불 정책에 따릅니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제8조 (회사의 의무)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>회사는 법령과 이 약관이 금지하거나 공서양속에 반하는 행위를 하지 않으며 이 약관이 정하는 바에 따라 지속적이고, 안정적으로 서비스를 제공하는데 최선을 다합니다.</li>
                    <li>회사는 이용자가 안전하게 서비스를 이용할 수 있도록 이용자의 개인정보(신용정보 포함)보호를 위한 보안 시스템을 갖추어야 합니다.</li>
                    <li>회사는 이용자가 원하지 않는 영리목적의 광고성 전자우편을 발송하지 않습니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제9조 (이용자의 의무)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>이용자는 다음 각 호의 행위를 하여서는 안 됩니다.
                      <ul className="list-disc pl-6 mt-2 mb-2 space-y-1">
                        <li>회원가입 신청 또는 변경 시 허위 내용의 등록</li>
                        <li>타인의 정보 도용</li>
                        <li>회사가 게시한 정보의 변경</li>
                        <li>회사가 정한 정보 이외의 정보(컴퓨터 프로그램 등) 등의 송신 또는 게시</li>
                        <li>회사 및 기타 제3자의 저작권 등 지적재산권에 대한 침해</li>
                        <li>회사 및 기타 제3자의 명예를 손상시키거나 업무를 방해하는 행위</li>
                        <li>외설 또는 폭력적인 메시지, 화상, 음성, 기타 공서양속에 반하는 정보를 서비스에 공개 또는 게시하는 행위</li>
                      </ul>
                    </li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제10조 (책임제한)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>회사는 천재지변, 전쟁, 기간통신사업자의 서비스 중지 등 예측하기 어려운 불가항력적 사유로 인한 서비스 제공 중단에 대하여 책임을 지지 않습니다.</li>
                    <li>회사는 이용자의 귀책사유로 인한 서비스 이용의 장애에 대하여 책임을 지지 않습니다.</li>
                    <li>회사는 이용자가 서비스를 통해 게재 또는 전송한 정보, 자료, 사실의 신뢰도, 정확성 등 내용에 관하여 책임을 지지 않습니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제11조 (분쟁해결)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>회사는 이용자가 제기하는 정당한 의견이나 불만을 반영하고 그 피해를 보상처리하기 위하여 고객센터를 설치 운영합니다.</li>
                    <li>회사는 이용자로부터 제출되는 불만사항 및 의견은 우선적으로 그 사항을 처리합니다. 다만, 신속한 처리가 곤란한 경우에는 이용자에게 그 사유와 처리일정을 통보해 드립니다.</li>
                  </ol>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">제12조 (재판권 및 준거법)</h2>
                  <ol className="list-decimal pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>회사와 이용자 간에 발생한 전자상거래 분쟁에 관한 소송은 제소 당시의 이용자의 주소에 의하고, 주소가 없는 경우에는 거소를 관할하는 지방법원의 전속관할로 합니다. 다만, 제소 당시 이용자의 주소 또는 거소가 분명하지 않거나 외국 거주자의 경우에는 민사소송법상의 관할법원에 제기합니다.</li>
                    <li>회사와 이용자 간에 제기된 전자상거래 소송에는 한국법을 적용합니다.</li>
                  </ol>
                </div>

                <div>
                  <p className="text-sm text-neutral-dark/80 mt-4">
                    <strong>부칙</strong><br />
                    이 약관은 2023년 1월 1일부터 적용됩니다.
                  </p>
                </div>
              </div>
            </ScrollArea>
          </div>
        </TabsContent>
        <TabsContent value="privacy">
          <div className="border rounded-md p-6 bg-white">
            <ScrollArea className="h-96 w-full pr-4">
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-bold mb-3">개인정보 처리방침</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed">
                    와글와글(이하 '회사'라 함)은 개인정보보호법, 정보통신망 이용촉진 및 정보보호 등에 관한 법률 등 관련 법령에 따라 이용자의 개인정보를 보호하고, 이와 관련한 고충을 신속하고 원활하게 처리할 수 있도록 다음과 같이 개인정보 처리방침을 수립하여 공개합니다.
                  </p>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">1. 수집하는 개인정보 항목 및 수집방법</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    회사는 회원가입, 프로그램 예약, 고객상담 등을 위해 아래와 같은 개인정보를 수집하고 있습니다.
                  </p>
                  <div className="pl-6">
                    <h3 className="text-sm font-bold mb-2">가. 수집항목</h3>
                    <ul className="list-disc pl-6 text-sm text-neutral-dark/80 space-y-2">
                      <li>필수항목: 아이디, 비밀번호, 이름, 연락처, 이메일</li>
                      <li>선택항목: 자녀 정보(이름, 생년월일), 주소, 서비스 이용 기록, 접속 로그, 쿠키, 결제 기록</li>
                      <li>결제 시 수집하는 정보: 신용카드 정보, 은행계좌 정보, 결제 기록 등</li>
                    </ul>
                  </div>
                  <div className="pl-6 mt-4">
                    <h3 className="text-sm font-bold mb-2">나. 수집방법</h3>
                    <ul className="list-disc pl-6 text-sm text-neutral-dark/80 space-y-2">
                      <li>홈페이지(회원가입, 프로그램 신청, 게시글 작성 등)</li>
                      <li>전화, 이메일을 통한 고객상담</li>
                      <li>이벤트 응모</li>
                    </ul>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">2. 개인정보의 수집 및 이용목적</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    회사는 수집한 개인정보를 다음의 목적을 위해 활용합니다.
                  </p>
                  <ul className="list-disc pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>서비스 제공: 체험 프로그램 예약, 결제, 환불처리</li>
                    <li>회원 관리: 회원제 서비스 이용, 개인식별, 부정이용 방지, 민원처리, 공지사항 전달</li>
                    <li>마케팅 및 광고: 신규 서비스 개발, 이벤트 정보 및 참여기회 제공, 접속빈도 파악, 서비스 이용통계</li>
                  </ul>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">3. 개인정보의 보유 및 이용기간</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    회사는 개인정보 수집 및 이용목적이 달성된 후에는 예외 없이 해당 정보를 지체 없이 파기합니다. 단, 관계법령의 규정에 의하여 보존할 필요가 있는 경우 회사는 아래와 같이 관계법령에서 정한 일정한 기간 동안 회원정보를 보관합니다.
                  </p>
                  <ul className="list-disc pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>계약 또는 청약철회 등에 관한 기록: 5년 (전자상거래 등에서의 소비자보호에 관한 법률)</li>
                    <li>대금결제 및 재화 등의 공급에 관한 기록: 5년 (전자상거래 등에서의 소비자보호에 관한 법률)</li>
                    <li>소비자의 불만 또는 분쟁처리에 관한 기록: 3년 (전자상거래 등에서의 소비자보호에 관한 법률)</li>
                    <li>웹사이트 방문기록: 3개월 (통신비밀보호법)</li>
                  </ul>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">4. 개인정보의 파기절차 및 방법</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    회사는 원칙적으로 개인정보 수집 및 이용목적이 달성된 후에는 해당 정보를 지체 없이 파기합니다. 파기절차 및 방법은 다음과 같습니다.
                  </p>
                  <div className="pl-6">
                    <h3 className="text-sm font-bold mb-2">가. 파기절차</h3>
                    <p className="text-sm text-neutral-dark/80 leading-relaxed">
                      이용자가 회원가입 등을 위해 입력한 정보는 목적이 달성된 후 별도의 DB로 옮겨져(종이의 경우 별도의 서류함) 내부 방침 및 기타 관련 법령에 의한 정보보호 사유에 따라(보유 및 이용기간 참조) 일정 기간 저장된 후 파기됩니다.
                    </p>
                  </div>
                  <div className="pl-6 mt-4">
                    <h3 className="text-sm font-bold mb-2">나. 파기방법</h3>
                    <p className="text-sm text-neutral-dark/80 leading-relaxed">
                      전자적 파일형태로 저장된 개인정보는 기록을 재생할 수 없는 기술적 방법을 사용하여 삭제합니다. 종이에 출력된 개인정보는 분쇄기로 분쇄하거나 소각을 통하여 파기합니다.
                    </p>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">5. 개인정보의 제3자 제공</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    회사는 이용자의 개인정보를 원칙적으로 외부에 제공하지 않습니다. 다만, 아래의 경우에는 예외로 합니다.
                  </p>
                  <ul className="list-disc pl-6 text-sm text-neutral-dark/80 space-y-2">
                    <li>이용자들이 사전에 동의한 경우</li>
                    <li>법령의 규정에 의거하거나, 수사 목적으로 법령에 정해진 절차와 방법에 따라 수사기관의 요구가 있는 경우</li>
                  </ul>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">6. 이용자 및 법정대리인의 권리와 그 행사방법</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    이용자 및 법정 대리인은 언제든지 등록되어 있는 자신 혹은 당해 만 14세 미만 아동의 개인정보를 조회하거나 수정할 수 있으며, 회사의 개인정보 처리에 동의하지 않는 경우 동의를 거부하거나 가입해지(회원탈퇴)를 요청할 수 있습니다.
                  </p>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed">
                    이용자 혹은 만 14세 미만 아동의 개인정보 조회, 수정을 위해서는 '개인정보변경'(또는 '회원정보수정' 등)을, 가입해지(동의철회)를 위해서는 '회원탈퇴'를 클릭하여 본인 확인 절차를 거치신 후 직접 열람, 정정 또는 탈퇴가 가능합니다.
                  </p>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">7. 개인정보 자동 수집 장치의 설치/운영 및 거부에 관한 사항</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    회사는 이용자에게 개별적인 맞춤서비스를 제공하기 위해 이용정보를 저장하고 수시로 불러오는 '쿠키(cookie)'를 사용합니다.
                  </p>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    쿠키는 웹사이트를 운영하는데 이용되는 서버가 이용자의 브라우저에게 보내는 소량의 정보이며 이용자들의 PC 컴퓨터내의 하드디스크에 저장되기도 합니다.
                  </p>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed">
                    이용자는 쿠키 설치에 대한 선택권을 가지고 있습니다. 따라서, 이용자는 웹브라우저에서 옵션을 설정함으로써 모든 쿠키를 허용하거나, 쿠키가 저장될 때마다 확인을 거치거나, 아니면 모든 쿠키의 저장을 거부할 수도 있습니다.
                  </p>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">8. 개인정보 보호책임자</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed mb-3">
                    회사는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 이용자의 불만처리 및 피해구제를 위하여 아래와 같이 개인정보 보호책임자를 지정하고 있습니다.
                  </p>
                  <div className="pl-6">
                    <p className="text-sm text-neutral-dark/80">
                      <strong>▶ 개인정보 보호책임자</strong><br />
                      성명: 홍길동<br />
                      직책: 개인정보 보호팀장<br />
                      연락처: 02-123-4567, privacy@waggle.kr
                    </p>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-bold mb-3">9. 개인정보 처리방침 변경</h2>
                  <p className="text-sm text-neutral-dark/80 leading-relaxed">
                    이 개인정보 처리방침은 2023년 1월 1일부터 적용됩니다. 법령, 정책 또는 보안기술의 변경에 따라 내용의 추가, 삭제 및 수정이 있을 시에는 변경사항의 시행일 7일 전부터 홈페이지의 공지사항을 통하여 고지할 것입니다.
                  </p>
                </div>
              </div>
            </ScrollArea>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}