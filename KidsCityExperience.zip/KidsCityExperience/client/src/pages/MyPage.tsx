import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { PaymentModal } from "@/components/PaymentModal";
import { apiRequest } from "@/lib/queryClient";
import { User, Package, CreditCard, UserCircle } from "lucide-react";

interface UserProfile {
  id: number;
  username: string;
  name: string;
  phone: string;
  email: string;
}

interface UserRegistration {
  id: number;
  programId: number;
  programName: string;
  childName: string;
  childAge: number;
  parentName: string;
  paymentStatus: string;
  createdAt: string;
  price: number;
}

export default function MyPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("profile");
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedRegistration, setSelectedRegistration] = useState<UserRegistration | null>(null);

  // 로그인 상태 확인
  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const response = await fetch("/api/auth/check", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
          credentials: "include",
        });

        if (!response.ok) {
          // 로그인되지 않은 경우 로그인 페이지로 리다이렉트
          navigate("/login");
          toast({
            title: "로그인이 필요합니다",
            description: "마이페이지는 로그인 후 이용 가능합니다.",
            variant: "destructive",
          });
        }
      } catch (error) {
        navigate("/login");
      }
    };

    checkLoginStatus();
  }, [navigate, toast]);

  // 사용자 프로필 정보 가져오기
  const { 
    data: profileData, 
    isLoading: profileLoading,
    error: profileError
  } = useQuery({
    queryKey: ["/api/user/profile"],
    enabled: true,
  });

  // 사용자의 프로그램 신청 내역 가져오기
  const { 
    data: registrationsData, 
    isLoading: registrationsLoading,
    error: registrationsError
  } = useQuery({
    queryKey: ["/api/user/registrations"],
    enabled: true,
  });

  // 로그아웃 처리
  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      
      // 캐시 초기화
      queryClient.clear();
      
      toast({
        title: "로그아웃 성공",
        description: "성공적으로 로그아웃되었습니다.",
      });
      
      // 홈으로 이동
      navigate("/");
    } catch (error) {
      toast({
        title: "로그아웃 실패",
        description: "로그아웃 처리 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    }
  };

  // 신청 취소 처리
  const handleCancelRegistration = async (registrationId: number) => {
    if (!confirm("정말로 프로그램 신청을 취소하시겠습니까?")) {
      return;
    }

    try {
      await apiRequest("POST", `/api/registration/${registrationId}/cancel`, {});
      
      // 데이터 갱신
      queryClient.invalidateQueries({ queryKey: ["/api/user/registrations"] });
      
      toast({
        title: "신청 취소 완료",
        description: "프로그램 신청이 취소되었습니다.",
      });
    } catch (error: any) {
      toast({
        title: "신청 취소 실패",
        description: error.message || "신청 취소 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    }
  };

  // 결제 상태에 따른 배경색 결정
  const getStatusColor = (status: string) => {
    switch(status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "paid":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-blue-100 text-blue-800";
    }
  };

  // 결제 상태를 한글로 변환
  const getStatusText = (status: string) => {
    switch(status) {
      case "pending":
        return "결제 대기";
      case "paid":
        return "결제 완료";
      case "cancelled":
        return "취소됨";
      default:
        return status;
    }
  };

  // 프로필 탭 내용
  const renderProfileTab = () => {
    if (profileLoading) {
      return <div className="p-4 text-center">로딩 중...</div>;
    }

    if (profileError) {
      return (
        <div className="p-4 text-center text-red-500">
          프로필 정보를 불러오는 중 오류가 발생했습니다.
        </div>
      );
    }

    // 개발용 더미 데이터 (실제 데이터가 연결되면 제거해야 함)
    const profile = profileData || {
      id: 1,
      username: "user123",
      name: "홍길동",
      phone: "010-1234-5678",
      email: "user@example.com"
    };

    return (
      <div className="space-y-6">
        <div className="flex flex-col items-center justify-center py-6">
          <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <UserCircle className="w-12 h-12 text-primary" />
          </div>
          <h3 className="text-2xl font-bold">{profile.name}</h3>
          <p className="text-muted-foreground">{profile.username}</p>
        </div>
        
        <div className="grid gap-4">
          <div className="flex flex-col space-y-1.5">
            <label className="text-sm font-medium text-neutral-dark/60">이름</label>
            <div className="p-2 border rounded-md">{profile.name}</div>
          </div>
          
          <div className="flex flex-col space-y-1.5">
            <label className="text-sm font-medium text-neutral-dark/60">아이디</label>
            <div className="p-2 border rounded-md">{profile.username}</div>
          </div>
          
          <div className="flex flex-col space-y-1.5">
            <label className="text-sm font-medium text-neutral-dark/60">이메일</label>
            <div className="p-2 border rounded-md">{profile.email}</div>
          </div>
          
          <div className="flex flex-col space-y-1.5">
            <label className="text-sm font-medium text-neutral-dark/60">연락처</label>
            <div className="p-2 border rounded-md">{profile.phone}</div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-2 pt-4">
          <Button variant="outline" onClick={() => navigate("/")}>
            홈으로
          </Button>
          <Button variant="default" onClick={handleLogout}>
            로그아웃
          </Button>
        </div>
      </div>
    );
  };

  // 프로그램 신청 내역 탭 내용
  const renderRegistrationsTab = () => {
    if (registrationsLoading) {
      return <div className="p-4 text-center">로딩 중...</div>;
    }

    if (registrationsError) {
      return (
        <div className="p-4 text-center text-red-500">
          신청 내역을 불러오는 중 오류가 발생했습니다.
        </div>
      );
    }

    // 개발용 더미 데이터 (실제 데이터가 연결되면 제거해야 함)
    const registrations = registrationsData || [
      {
        id: 1,
        programId: 1,
        programName: "상추 키우기 체험",
        childName: "홍길순",
        childAge: 3,
        parentName: "홍길동",
        paymentStatus: "paid",
        createdAt: "2023-05-15T09:00:00",
        price: 25000
      },
      {
        id: 2,
        programId: 2,
        programName: "페퍼민트 티 만들기",
        childName: "홍길순",
        childAge: 3,
        parentName: "홍길동",
        paymentStatus: "pending",
        createdAt: "2023-05-17T14:00:00",
        price: 30000
      }
    ];

    if (registrations.length === 0) {
      return (
        <div className="p-6 text-center bg-neutral-50 rounded-lg">
          <Package className="w-12 h-12 mx-auto text-neutral-dark/50 mb-2" />
          <h3 className="text-lg font-medium">신청한 프로그램이 없습니다</h3>
          <p className="text-sm text-neutral-dark/70 mt-1 mb-4">
            파주 체험 Camp의 다양한 체험 프로그램을 확인해보세요!
          </p>
          <Button 
            variant="outline" 
            onClick={() => navigate("/program-selection")}
            className="mx-auto"
          >
            프로그램 신청하기
          </Button>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {registrations.map((registration) => (
          <Card key={registration.id} className="overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{registration.programName}</CardTitle>
                  <CardDescription>
                    신청일: {new Date(registration.createdAt).toLocaleDateString()}
                  </CardDescription>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(registration.paymentStatus)}`}>
                  {getStatusText(registration.paymentStatus)}
                </div>
              </div>
            </CardHeader>
            <CardContent className="pb-3">
              <div className="grid gap-1">
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-dark/60">참가자</span>
                  <span className="text-sm font-medium">{registration.childName} ({registration.childAge}세)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-dark/60">보호자</span>
                  <span className="text-sm font-medium">{registration.parentName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-dark/60">금액</span>
                  <span className="text-sm font-medium">{registration.price.toLocaleString()}원</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end space-x-2 pt-0">
              {registration.paymentStatus === "pending" && (
                <>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleCancelRegistration(registration.id)}
                  >
                    신청 취소
                  </Button>
                  <Button 
                    variant="default" 
                    size="sm" 
                    onClick={() => {
                      setSelectedRegistration(registration);
                      setPaymentModalOpen(true);
                    }}
                  >
                    결제하기
                  </Button>
                </>
              )}
              {registration.paymentStatus === "paid" && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => {
                    // 서버에서 제공하는 실제 ID로 수정 (3자리가 아닌 1~10 사이의 ID)
                    // registration.programId가 101과 같은 형식이면 1로 변환
                    const correctedId = registration.programId > 100 ? registration.programId % 100 : registration.programId;
                    navigate(`/programs/${correctedId}`);
                  }}
                >
                  프로그램 상세보기
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-neutral-dark">마이페이지</h1>
        <p className="text-muted-foreground">내 정보와 신청한 프로그램을 확인하세요</p>
      </div>
      
      <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-2 mb-6">
          <TabsTrigger value="profile" className="flex items-center gap-1">
            <User className="w-4 h-4" />
            <span>내 정보</span>
          </TabsTrigger>
          <TabsTrigger value="registrations" className="flex items-center gap-1">
            <Package className="w-4 h-4" />
            <span>신청 내역</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile" className="mt-0">
          <Card>
            <CardContent className="pt-6">
              {renderProfileTab()}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="registrations" className="mt-0">
          {renderRegistrationsTab()}
        </TabsContent>
      </Tabs>

      {/* 결제 모달 */}
      {selectedRegistration && (
        <PaymentModal
          isOpen={paymentModalOpen}
          onClose={() => setPaymentModalOpen(false)}
          registrationId={selectedRegistration.id}
          programName={selectedRegistration.programName}
          price={selectedRegistration.price}
          onSuccess={() => {
            toast({
              title: "결제 완료",
              description: "프로그램 결제가 성공적으로 완료되었습니다.",
            });
            queryClient.invalidateQueries({queryKey: ['/api/user/registrations']});
          }}
        />
      )}
    </div>
  );
}