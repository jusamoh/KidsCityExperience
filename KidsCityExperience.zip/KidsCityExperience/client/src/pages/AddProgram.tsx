import { useState } from 'react';
import { useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { z } from 'zod';
import { insertProgramSchema, Category } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// Form 컴포넌트 import
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

// 추가 검증 규칙이 있는 프로그램 스키마
const programFormSchema = insertProgramSchema.extend({
  date: z.string().min(1, '날짜를 선택해주세요.'),
  price: z.coerce.number().min(1000, '가격은 최소 1,000원 이상이어야 합니다.'),
  minAge: z.coerce.number().min(1, '최소 연령은 1개월 이상이어야 합니다.'),
  maxAge: z.coerce.number().min(1, '최대 연령은 1개월 이상이어야 합니다.'),
  maxParticipants: z.coerce.number().min(1, '최대 참가자 수는 1명 이상이어야 합니다.'),
  minParticipants: z.coerce.number().min(1, '최소 참가자 수는 1명 이상이어야 합니다.'),
  duration: z.coerce.number().min(1, '소요 시간은 1분 이상이어야 합니다.'),
});

type ProgramFormData = z.infer<typeof programFormSchema>;

export default function AddProgram() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // 카테고리 조회
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/categories');
      return response.json();
    }
  });
  
  // 프로그램 등록 mutation
  const createProgramMutation = useMutation({
    mutationFn: async (data: ProgramFormData) => {
      // ISO 문자열 날짜를 Date 객체로 변환
      const formattedData = {
        ...data,
        date: new Date(data.date)
      };
      const response = await apiRequest('POST', '/api/programs', formattedData);
      return response.json();
    },
    onSuccess: () => {
      // 성공 시 캐시된 프로그램 목록 갱신
      queryClient.invalidateQueries({ queryKey: ['/api/programs'] });
      
      toast({
        title: '프로그램 등록 완료',
        description: '새 프로그램이 성공적으로 등록되었습니다.',
      });
      
      // 프로그램 목록 페이지로 이동
      navigate('/admin');
    },
    onError: (error) => {
      console.error('프로그램 등록 오류:', error);
      
      toast({
        title: '프로그램 등록 실패',
        description: '프로그램 등록 중 오류가 발생했습니다. 다시 시도해주세요.',
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    }
  });
  
  // 폼 설정
  const form = useForm<ProgramFormData>({
    resolver: zodResolver(programFormSchema),
    defaultValues: {
      title: '',
      description: '',
      categoryId: undefined,
      minAge: 6,
      maxAge: 24,
      date: '',
      location: '',
      price: 30000,
      maxParticipants: 10,
      minParticipants: 5,
      duration: 60,
      imageUrl: '',
      status: 'pending',
    }
  });
  
  // 폼 제출 처리
  const onSubmit = (data: ProgramFormData) => {
    setIsSubmitting(true);
    createProgramMutation.mutate(data);
  };
  
  // 현재 날짜 + 1주일을 기본 날짜로 설정
  const getMinDate = () => {
    const date = new Date();
    date.setDate(date.getDate() + 1);
    return date.toISOString().split('T')[0];
  };
  
  return (
    <div className="container py-8">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl">새 프로그램 등록</CardTitle>
          <CardDescription>
            새로운 체험 프로그램을 등록하세요. 모든 필수 항목을 작성해주세요.
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* 프로그램명 */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>프로그램명 *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="프로그램 이름을 입력하세요" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 카테고리 */}
                <FormField
                  control={form.control}
                  name="categoryId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>카테고리 *</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        value={field.value?.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="카테고리를 선택하세요" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id.toString()}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 이미지 URL */}
                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>이미지 URL</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="프로그램 이미지 URL을 입력하세요" />
                      </FormControl>
                      <FormDescription>
                        이미지가 없으면 기본 이미지가 사용됩니다.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 장소 */}
                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>장소 *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="프로그램 진행 장소를 입력하세요" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 날짜 */}
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>날짜 *</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="datetime-local" 
                          min={getMinDate()}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 소요시간 */}
                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>소요 시간 (분) *</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" min="1" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 가격 */}
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>가격 (원) *</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" min="1000" step="1000" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 상태 */}
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>상태 *</FormLabel>
                      <Select 
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="상태를 선택하세요" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="pending">대기중</SelectItem>
                          <SelectItem value="confirmed">확정</SelectItem>
                          <SelectItem value="canceled">취소됨</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 최소 나이 */}
                <FormField
                  control={form.control}
                  name="minAge"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>최소 나이 (개월) *</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" min="1" max="36" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 최대 나이 */}
                <FormField
                  control={form.control}
                  name="maxAge"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>최대 나이 (개월) *</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" min="1" max="36" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 최소 참가자 */}
                <FormField
                  control={form.control}
                  name="minParticipants"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>최소 참가자 수 *</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" min="1" max="100" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* 최대 참가자 */}
                <FormField
                  control={form.control}
                  name="maxParticipants"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>최대 참가자 수 *</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" min="1" max="100" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* 설명 */}
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>프로그램 설명 *</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="프로그램에 대한 상세 설명을 입력하세요" 
                        rows={5}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-end space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/admin')}
                  disabled={isSubmitting}
                >
                  취소
                </Button>
                <Button 
                  type="submit"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? '등록 중...' : '프로그램 등록'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}