import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import ProgramDetail from "@/pages/ProgramDetail";
import Registration from "@/pages/Registration";
import ProgramSelection from "@/pages/ProgramSelection";
import MultiRegistration from "@/pages/MultiRegistration";
import AdminDashboard from "@/pages/AdminDashboard";
import AddProgram from "@/pages/AddProgram";
import CategoryManagement from "@/pages/CategoryManagement";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import MyPage from "@/pages/MyPage";
import PaymentSuccess from "@/pages/PaymentSuccess";
import PaymentFail from "@/pages/PaymentFail";
import HowToUse from "@/pages/HowToUse";
import FAQ from "@/pages/FAQ";
import RefundPolicy from "@/pages/RefundPolicy";
import TermsOfService from "@/pages/TermsOfService";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow pt-20">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/programs/:id" component={ProgramDetail} />
          <Route path="/registration/:id" component={Registration} />
          <Route path="/program-selection" component={ProgramSelection} />
          <Route path="/multi-registration" component={MultiRegistration} />
          <Route path="/admin" component={AdminDashboard} />
          <Route path="/admin/add-program" component={AddProgram} />
          <Route path="/admin/categories" component={CategoryManagement} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/mypage" component={MyPage} />
          <Route path="/payment/:id" component={Registration} />
          <Route path="/payment-success" component={PaymentSuccess} />
          <Route path="/payment-fail" component={PaymentFail} />
          <Route path="/how-to-use" component={HowToUse} />
          <Route path="/faq" component={FAQ} />
          <Route path="/refund-policy" component={RefundPolicy} />
          <Route path="/terms-of-service" component={TermsOfService} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
