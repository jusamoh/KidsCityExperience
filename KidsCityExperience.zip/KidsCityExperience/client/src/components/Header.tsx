import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Home, Package, User, LogOut, LogIn, FileText, UserPlus, UserCircle, Search, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // Simple check for admin - in a real app, this would use a context provider
  const isAdmin = localStorage.getItem("admin") === "true";
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/program-selection?search=${encodeURIComponent(searchTerm)}`);
      setSearchOpen(false);
      setSearchTerm("");
    }
  };

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      localStorage.removeItem("admin");
      toast({
        title: "로그아웃 성공",
        description: "성공적으로 로그아웃되었습니다.",
      });
      navigate("/");
    } catch (error) {
      toast({
        title: "로그아웃 실패",
        description: "로그아웃 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50">
      <div className="container mx-auto px-4 py-4">
        {searchOpen && (
          <div className="absolute top-full left-0 right-0 bg-white shadow-md p-4 z-50 border-t">
            <form onSubmit={handleSearch} className="flex items-center max-w-lg mx-auto">
              <input
                type="text"
                placeholder="프로그램 검색..."
                className="flex-1 p-2 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-primary"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                autoFocus
              />
              <button 
                type="submit" 
                className="bg-primary text-white p-2 px-4 rounded-r-md hover:bg-primary/90 transition"
              >
                검색
              </button>
              <button 
                type="button" 
                className="ml-2 p-2 text-neutral-dark hover:text-primary transition"
                onClick={() => setSearchOpen(false)}
              >
                <X className="h-5 w-5" />
              </button>
            </form>
          </div>
        )}
        <div className="flex justify-between items-center">
          <Link href="/">
            <div className="text-4xl font-bold font-heading cursor-pointer">
              <span className="text-primary">파주 체험</span>
              <span className="text-secondary"> Camp</span>
            </div>
          </Link>

          <nav>
            <ul className="flex items-center space-x-6">
              <li>
                <Link href="/">
                  <div className="flex items-center text-neutral-dark hover:text-primary font-medium transition px-3 py-2">
                    <Home className="mr-1 h-4 w-4" />
                    <span>홈</span>
                  </div>
                </Link>
              </li>
              <li>
                <Link href="/#programs">
                  <div className="flex items-center text-neutral-dark hover:text-primary font-medium transition px-3 py-2">
                    <Package className="mr-1 h-4 w-4" />
                    <span>체험프로그램</span>
                  </div>
                </Link>
              </li>
              <li>
                <Link href="/how-to-use">
                  <div className="flex items-center text-neutral-dark hover:text-primary font-medium transition px-3 py-2">
                    <FileText className="mr-1 h-4 w-4" />
                    <span>이용안내</span>
                  </div>
                </Link>
              </li>
              <li>
                <Link href="/faq">
                  <div className="flex items-center text-neutral-dark hover:text-primary font-medium transition px-3 py-2">
                    <User className="mr-1 h-4 w-4" />
                    <span>고객센터</span>
                  </div>
                </Link>
              </li>
              <li>
                <button 
                  onClick={() => setSearchOpen(!searchOpen)}
                  className="flex items-center text-neutral-dark hover:text-primary font-medium transition px-3 py-2"
                >
                  <Search className="mr-1 h-4 w-4" />
                  <span>검색</span>
                </button>
              </li>
              {isAdmin && (
                <li>
                  <Link href="/admin">
                    <div className="flex items-center text-neutral-dark hover:text-primary font-medium transition px-3 py-2">
                      <User className="mr-1 h-4 w-4" />
                      <span>관리자</span>
                    </div>
                  </Link>
                </li>
              )}
              <li>
                {isAdmin ? (
                  <div className="flex items-center space-x-2">
                    <Link href="/mypage">
                      <Button
                        variant="outline"
                        className="border-primary text-primary hover:bg-primary/10 px-4 py-2 rounded-full font-medium flex items-center"
                      >
                        <UserCircle className="mr-1 h-4 w-4" />
                        <span>마이페이지</span>
                      </Button>
                    </Link>
                    <Button
                      variant="default"
                      className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-full font-medium flex items-center"
                      onClick={handleLogout}
                    >
                      <LogOut className="mr-1 h-4 w-4" />
                      <span>로그아웃</span>
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Link href="/register">
                      <Button variant="outline" className="border-primary text-primary hover:bg-primary/10 px-4 py-2 rounded-full font-medium flex items-center">
                        <UserPlus className="mr-1 h-4 w-4" />
                        <span>가입하기</span>
                      </Button>
                    </Link>
                    <Link href="/login">
                      <Button variant="default" className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-full font-medium flex items-center">
                        <LogIn className="mr-1 h-4 w-4" />
                        <span>로그인</span>
                      </Button>
                    </Link>
                  </div>
                )}
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}
