import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const statusBadgeVariants = cva(
  "inline-flex items-center px-3 py-1 rounded-full text-sm font-medium",
  {
    variants: {
      variant: {
        confirmed: "bg-[hsl(var(--status-confirmed))] text-white",
        pending: "bg-[hsl(var(--status-pending))] text-white",
        canceled: "bg-[hsl(var(--status-canceled))] text-white",
      },
    },
    defaultVariants: {
      variant: "pending",
    },
  }
);

export interface StatusBadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof statusBadgeVariants> {
  status: "confirmed" | "pending" | "canceled";
}

export function StatusBadge({
  className,
  variant,
  status,
  ...props
}: StatusBadgeProps) {
  // Map status to Korean text
  const statusText = {
    confirmed: "확정됨",
    pending: "대기중",
    canceled: "취소됨",
  };

  // Map status to title tooltip text
  const statusTitle = {
    confirmed: "확정된 프로그램입니다. 일정대로 진행됩니다.",
    pending: "최소 인원 모집 중입니다. 인원이 모이면 확정됩니다.",
    canceled: "취소된 프로그램입니다.",
  };

  return (
    <span
      className={cn(statusBadgeVariants({ variant: status }), className)}
      title={statusTitle[status]}
      {...props}
    >
      {statusText[status]}
    </span>
  );
}
