import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-neutral-dark py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between mb-8">
          <div className="mb-6 md:mb-0">
            <Link href="/">
              <div className="text-white text-2xl font-bold font-heading mb-4 cursor-pointer">파주 체험 Camp</div>
            </Link>
            <p className="text-neutral-light text-sm max-w-xs">2살 미만 영유아를 위한 도시텃밭, 영어놀이, 스포츠 체험 프로그램을 제공합니다.</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-white font-medium mb-4">프로그램</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/?category=1">
                    <a className="text-neutral-light hover:text-white text-sm transition">도시텃밭 체험</a>
                  </Link>
                </li>
                <li>
                  <Link href="/?category=2">
                    <a className="text-neutral-light hover:text-white text-sm transition">영어놀이 체험</a>
                  </Link>
                </li>
                <li>
                  <Link href="/?category=3">
                    <a className="text-neutral-light hover:text-white text-sm transition">스포츠 및 놀이 체험</a>
                  </Link>
                </li>
                <li>
                  <Link href="/#programs">
                    <a className="text-neutral-light hover:text-white text-sm transition">전체 프로그램</a>
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-medium mb-4">이용안내</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/how-to-use">
                    <a className="text-neutral-light hover:text-white text-sm transition">이용방법</a>
                  </Link>
                </li>
                <li>
                  <Link href="/faq">
                    <a className="text-neutral-light hover:text-white text-sm transition">자주 묻는 질문</a>
                  </Link>
                </li>
                <li>
                  <Link href="/refund-policy">
                    <a className="text-neutral-light hover:text-white text-sm transition">환불 정책</a>
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-service">
                    <a className="text-neutral-light hover:text-white text-sm transition">이용약관</a>
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-medium mb-4">고객센터</h4>
              <ul className="space-y-2">
                <li className="text-neutral-light text-sm">운영시간: 평일 10:00 - 18:00</li>
                <li className="text-neutral-light text-sm">전화: 02-123-4567</li>
                <li className="text-neutral-light text-sm">이메일: info@kidexplorer.kr</li>
                <li>
                  <a href="mailto:info@kidexplorer.kr" className="text-neutral-light hover:text-white text-sm transition">문의하기</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="border-t border-neutral-light/20 pt-6 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-neutral-light text-sm mb-4 sm:mb-0">&copy; {new Date().getFullYear()} 파주 체험 Camp. All rights reserved.</p>
          <div className="flex space-x-4">
            <a href="#" className="text-neutral-light hover:text-white transition">
              <i className="fab fa-instagram text-lg"></i>
            </a>
            <a href="#" className="text-neutral-light hover:text-white transition">
              <i className="fab fa-facebook text-lg"></i>
            </a>
            <a href="#" className="text-neutral-light hover:text-white transition">
              <i className="fab fa-youtube text-lg"></i>
            </a>
            <a href="#" className="text-neutral-light hover:text-white transition">
              <i className="fab fa-twitter text-lg"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
