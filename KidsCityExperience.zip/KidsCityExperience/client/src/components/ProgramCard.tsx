import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Program } from "@shared/schema";
import { format } from "date-fns";
import { ko } from "date-fns/locale";

interface ProgramCardProps {
  program: Program & { currentParticipants: number };
}

export default function ProgramCard({ program }: ProgramCardProps) {
  const {
    id,
    title,
    description,
    categoryId,
    date,
    price,
    maxParticipants,
    currentParticipants,
    status,
    imageUrl,
  } = program;

  // Map categoryId to category name and background class
  const categoryInfo = {
    1: { name: "도시텃밭 체험", bgClass: "bg-secondary/20 text-secondary" },
    2: { name: "영어놀이 체험", bgClass: "bg-primary/20 text-primary" },
    3: { name: "스포츠 및 놀이 체험", bgClass: "bg-accent/30 text-neutral-dark" },
  };

  const categoryName = categoryInfo[categoryId as keyof typeof categoryInfo]?.name || "기타 체험";
  const categoryBgClass = categoryInfo[categoryId as keyof typeof categoryInfo]?.bgClass || "bg-muted text-muted-foreground";

  // Format date
  const formattedDate = format(new Date(date), "M월 d일 (E) HH:mm", { locale: ko });

  return (
    <Card className="program-card bg-white rounded-2xl shadow-lg overflow-hidden border border-neutral-light">
      <div className="relative">
        <img
          src={imageUrl}
          alt={`${title} 프로그램`}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 right-4">
          <StatusBadge status={status as "confirmed" | "pending" | "canceled"} />
        </div>
      </div>
      <CardContent className="p-6">
        <span className={`text-xs font-medium ${categoryBgClass} px-3 py-1 rounded-full`}>
          {categoryName}
        </span>
        <h3 className="font-heading font-bold text-xl mt-3 mb-2">{title}</h3>
        <p className="text-neutral-dark text-sm mb-4">
          {description.length > 70 ? `${description.substring(0, 70)}...` : description}
        </p>
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <i className="fas fa-calendar-alt text-primary mr-2"></i>
            <span className="text-sm">{formattedDate}</span>
          </div>
          <div className="flex items-center">
            <i className="fas fa-user-friends text-primary mr-2"></i>
            <span className="text-sm">
              {currentParticipants}/{maxParticipants}명
            </span>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <span className="font-medium text-lg text-primary">
            {price.toLocaleString()}원
          </span>
          {status === "canceled" ? (
            <Button
              variant="secondary"
              className="bg-neutral-dark text-white hover:bg-neutral-dark/90 px-4 py-2 rounded-full text-sm font-medium"
              disabled
            >
              마감됨
            </Button>
          ) : (
            <Link href={`/programs/${id}`}>
              <Button
                variant="default"
                className="bg-primary text-white hover:bg-primary/90 px-4 py-2 rounded-full text-sm font-medium"
              >
                자세히 보기
              </Button>
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
