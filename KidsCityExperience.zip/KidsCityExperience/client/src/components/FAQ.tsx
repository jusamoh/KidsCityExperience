import { useState } from "react";
import { Disclosure } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
}

const faqItems: FAQItem[] = [
  {
    question: "프로그램 신청 후 취소는 어떻게 하나요?",
    answer: "프로그램 시작 2일 전까지 취소 시 100% 환불, 1일 전 취소 시 50% 환불됩니다. 프로그램 당일 취소는 환불이 불가합니다. 취소는 웹사이트 '마이페이지'에서 가능하며, 문의사항은 고객센터로 연락 주세요."
  },
  {
    question: "최소 인원이 모집되지 않으면 어떻게 되나요?",
    answer: "프로그램별로 최소 인원이 모집되지 않을 경우 프로그램이 취소될 수 있습니다. 취소 시 프로그램 시작 1일 전까지 안내드리며, 100% 환불 또는 다른 프로그램으로 변경 가능합니다."
  },
  {
    question: "아이가 활동에 잘 참여할 수 있을까요?",
    answer: "모든 프로그램은 0-24개월 영유아의 발달 특성에 맞게 설계되었으며, 보호자와 함께 참여하는 방식입니다. 아이의 성향에 따라 적극적으로 참여하지 않더라도 관찰만으로도 충분한 자극과 경험이 될 수 있어요."
  },
  {
    question: "준비물이 있나요?",
    answer: "모든 체험에 필요한 재료와 도구는 저희가 제공합니다. 개인 물병과 여벌옷만 준비해주세요. 체험 활동 중 옷이 더러워질 수 있으니 편안한 복장으로 참여하시길 권장합니다."
  },
  {
    question: "체험 시간은 얼마나 되나요?",
    answer: "대부분의 프로그램은 영유아의 집중 시간을 고려하여 60~90분 내외로 진행됩니다. 프로그램별 상세 시간은 각 프로그램 상세 페이지에서 확인하실 수 있습니다."
  }
];

export default function FAQ() {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems((prevOpenItems) =>
      prevOpenItems.includes(index)
        ? prevOpenItems.filter((i) => i !== index)
        : [...prevOpenItems, index]
    );
  };

  return (
    <section id="faq" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold font-heading text-center text-neutral-dark mb-12">자주 묻는 질문</h2>
        
        <div className="max-w-3xl mx-auto">
          {faqItems.map((item, index) => (
            <div key={index} className="mb-6">
              <button 
                className="flex justify-between items-center w-full text-left font-heading font-semibold text-lg bg-neutral-light rounded-xl p-4 hover:bg-neutral-light/80 transition"
                onClick={() => toggleItem(index)}
              >
                <span>{item.question}</span>
                {openItems.includes(index) ? (
                  <ChevronUp className="text-primary h-5 w-5" />
                ) : (
                  <ChevronDown className="text-primary h-5 w-5" />
                )}
              </button>
              <div className={`bg-neutral-light/50 rounded-b-xl p-4 mt-1 ${openItems.includes(index) ? 'block' : 'hidden'}`}>
                <p className="text-neutral-dark">{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
