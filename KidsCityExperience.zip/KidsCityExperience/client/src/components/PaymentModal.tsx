import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { TossPaymentRequest } from '@shared/schema';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';

declare global {
  interface Window {
    TossPayments?: any;
  }
}

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  registrationId: number;
  programName: string;
  price: number;
  onSuccess?: () => void;
}

// 테스트 카드 정보
const TEST_CARDS = [
  { name: '성공', number: '4949-4949-4949-4949', exp: '12/29', cvc: '123', pwd: '12' },
  { name: '실패: 잔액부족', number: '4000-0000-0000-0000', exp: '12/29', cvc: '123', pwd: '12' },
  { name: '실패: 도난카드', number: '4000-0000-0000-0001', exp: '12/29', cvc: '123', pwd: '12' },
  { name: '실패: 분실카드', number: '4000-0000-0000-0002', exp: '12/29', cvc: '123', pwd: '12' },
  { name: '실패: 한도초과', number: '4000-0000-0000-0003', exp: '12/29', cvc: '123', pwd: '12' },
];

export function PaymentModal({ isOpen, onClose, registrationId, programName, price, onSuccess }: PaymentModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string>('card');
  const { toast } = useToast();
  
  // 오류 메시지 닫기 처리 함수
  const handleCloseError = () => {
    setError(null);
  };
  
  // 오류 메시지 컴포넌트
  const ErrorMessage = ({ message }: { message: string }) => (
    <div className="mt-4 p-3 bg-destructive/10 text-destructive rounded-md text-sm flex justify-between items-start">
      <span>{message}</span>
      <button 
        onClick={handleCloseError}
        className="text-destructive hover:text-destructive/80 ml-2"
        type="button"
        aria-label="닫기"
      >
        ×
      </button>
    </div>
  );

  // 토스페이먼츠 SDK 로드
  useEffect(() => {
    if (!isOpen) return;

    // 이미 로드된 경우 스킵
    if (window.TossPayments) return;

    const script = document.createElement('script');
    script.src = 'https://js.tosspayments.com/v1';
    script.async = true;
    document.body.appendChild(script);

    // 스크립트 로드 완료 확인
    script.onload = () => {
      console.log('토스페이먼츠 SDK 로드 완료');
    };

    script.onerror = () => {
      console.error('토스페이먼츠 SDK 로드 실패');
    };

    return () => {
      // 모달이 닫힐 때 스크립트 제거하지 않음 (다른 곳에서 재사용 가능)
    };
  }, [isOpen]);

  // 결제 요청 처리
  const handlePayment = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // 결제 요청 데이터 가져오기
      const response = await apiRequest('POST', `/api/payments/prepare/${registrationId}`, {});
      const { clientKey, paymentData } = await response.json();

      console.log('결제 요청 데이터:', { clientKey, paymentData });

      // 토스페이먼츠 SDK가 로드될 때까지 대기
      let attempts = 0;
      const maxAttempts = 10;
      
      while (!window.TossPayments && attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 300));
        attempts++;
      }
      
      // 토스페이먼츠 SDK 초기화
      if (!window.TossPayments) {
        throw new Error('토스페이먼츠 SDK를 불러오는 중 오류가 발생했습니다.');
      }

      const tossPayments = new window.TossPayments(clientKey);
      console.log('토스페이먼츠 SDK 초기화 완료');

      // 공통 결제 파라미터
      const commonParams = {
        amount: paymentData.amount,
        orderId: paymentData.orderId,
        orderName: paymentData.orderName,
        customerName: paymentData.customerName,
        customerEmail: paymentData.customerEmail,
        successUrl: `${window.location.origin}/payment-success`,
        failUrl: `${window.location.origin}/payment-fail`,
      };
      
      let paymentParams: any;
      
      // 토스페이먼츠 공식 문서에 따른 결제 수단별 처리
      // 한글로 변환
      let tossMethod = '';
      if (paymentMethod === 'card') {
        tossMethod = '카드';
      } else if (paymentMethod === 'virtualAccount') {
        tossMethod = '가상계좌';
      } else if (paymentMethod === 'phone') {
        tossMethod = '휴대폰';
      } else if (paymentMethod === 'transfer') {
        tossMethod = '계좌이체';
      } else {
        // 기본값은 카드 결제
        tossMethod = '카드';
      }
      
      // 공통 파라미터 사용
      paymentParams = commonParams;
      
      // 가상계좌만 추가 파라미터 필요
      if (tossMethod === '가상계좌') {
        paymentParams.validHours = 72;
        paymentParams.cashReceipt = { type: '소득공제' };
      }

      // 결제 요청 - 한글 메서드로 변경
      tossPayments.requestPayment(tossMethod, paymentParams);

      // 모달 닫기 (토스페이먼츠가 새 창을 열기 때문)
      onClose();
    } catch (error) {
      console.error('결제 요청 오류:', error);
      // 사용자 친화적인 오류 메시지로 변경
      const errorMsg = '일시적인 오류가 발생했습니다. 다시 시도해주세요.';
      setError(errorMsg);
      toast({
        title: '결제 오류',
        description: errorMsg,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // 가상 결제 처리 (테스트용)
  const handleTestPayment = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // 가상 결제 데이터 생성
      const testData = {
        registrationId,
        amount: price,
        paymentKey: `test_payment_${Date.now()}`,
        orderId: `test_order_${Date.now()}`,
      };

      // 가상 결제 완료 API 호출
      const response = await apiRequest('POST', '/api/payments/test-complete', testData);
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: '가상 결제 완료',
          description: '테스트 결제가 성공적으로 처리되었습니다.',
        });
        
        if (onSuccess) {
          onSuccess();
        }
      } else {
        throw new Error(result.message || '가상 결제 처리 중 오류가 발생했습니다.');
      }
      
      onClose();
    } catch (error) {
      console.error('가상 결제 오류:', error);
      setError('가상 결제 중 오류가 발생했습니다.');
      toast({
        title: '가상 결제 오류',
        description: '가상 결제 처리 중 오류가 발생했습니다.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>프로그램 신청 결제</DialogTitle>
          <DialogDescription>
            토스페이먼츠를 통해 안전하게 결제를 진행합니다.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="real" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="real">실제 결제</TabsTrigger>
            <TabsTrigger value="test">테스트 결제</TabsTrigger>
          </TabsList>
          
          <TabsContent value="real" className="space-y-4">
            <div className="py-4">
              <div className="flex justify-between mb-4">
                <span className="text-neutral-dark">프로그램</span>
                <span className="font-semibold">{programName}</span>
              </div>
              <div className="flex justify-between mb-4">
                <span className="text-neutral-dark">결제 금액</span>
                <span className="font-semibold text-primary">{price.toLocaleString()}원</span>
              </div>
              
              <div className="mb-4">
                <p className="mb-2 text-neutral-dark">결제 수단 선택</p>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={paymentMethod === 'card' ? 'default' : 'outline'}
                    onClick={() => setPaymentMethod('card')}
                    size="sm"
                  >
                    신용카드
                  </Button>
                  <Button
                    variant={paymentMethod === 'virtualAccount' ? 'default' : 'outline'}
                    onClick={() => setPaymentMethod('virtualAccount')}
                    size="sm"
                  >
                    가상계좌
                  </Button>
                  <Button
                    variant={paymentMethod === 'transfer' ? 'default' : 'outline'}
                    onClick={() => setPaymentMethod('transfer')}
                    size="sm"
                  >
                    계좌이체
                  </Button>
                  <Button
                    variant={paymentMethod === 'phone' ? 'default' : 'outline'}
                    onClick={() => setPaymentMethod('phone')}
                    size="sm"
                  >
                    휴대폰
                  </Button>
                </div>
              </div>

              {error && <ErrorMessage message={error} />}
              
              <div className="flex justify-end mt-4 space-x-2">
                <Button variant="outline" onClick={onClose} disabled={isLoading}>
                  취소
                </Button>
                <Button onClick={handlePayment} disabled={isLoading} className="bg-primary text-white">
                  {isLoading ? '처리 중...' : '결제하기'}
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="test" className="space-y-4">
            <Alert className="mb-4">
              <AlertDescription>
                이 화면은 결제 기능을 테스트하기 위한 것입니다. 실제 결제는 발생하지 않습니다.
              </AlertDescription>
            </Alert>
            
            <div className="py-4">
              <div className="flex justify-between mb-4">
                <span className="text-neutral-dark">프로그램</span>
                <span className="font-semibold">{programName}</span>
              </div>
              <div className="flex justify-between mb-4">
                <span className="text-neutral-dark">결제 금액</span>
                <span className="font-semibold text-primary">{price.toLocaleString()}원</span>
              </div>
              
              <div className="mb-4">
                <p className="mb-2 font-medium">테스트 카드 정보</p>
                <div className="text-sm space-y-2 bg-muted p-3 rounded-md">
                  {TEST_CARDS.map((card, index) => (
                    <div key={index} className={index !== 0 ? 'pt-2 border-t border-border' : ''}>
                      <p className="font-medium">{card.name}</p>
                      <p>카드번호: {card.number}</p>
                      <p>만료일: {card.exp}, CVC: {card.cvc}, 비밀번호: {card.pwd}</p>
                    </div>
                  ))}
                </div>
              </div>

              {error && <ErrorMessage message={error} />}
              
              <div className="flex justify-end mt-4 space-x-2">
                <Button variant="outline" onClick={onClose} disabled={isLoading}>
                  취소
                </Button>
                <Button 
                  onClick={handleTestPayment} 
                  disabled={isLoading} 
                  className="bg-primary text-white"
                >
                  {isLoading ? '처리 중...' : '가상 결제하기'}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}