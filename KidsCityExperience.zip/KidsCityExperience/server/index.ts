import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
// PostgreSQL을 사용하므로 MySQL DB 초기화 제거
// import { initializeDatabase } from "./mysql-db";

// Windows 환경에서 NODE_ENV가 설정되지 않은 경우 기본값으로 설정
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = "development";
  console.log("NODE_ENV 환경변수가 설정되지 않아 'development'로 자동 설정됨");
}

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // PostgreSQL 데이터베이스 사용
  console.log("Using PostgreSQL database from DATABASE_URL environment variable");
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Replit에서는 5000 포트, 로컬 XAMPP에서는 3000 포트 사용
  const isReplit = process.env.REPL_ID || process.env.REPLIT_CLUSTER;
  const port = isReplit ? 5000 : 3000;
  
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    const message = isReplit 
      ? `serving on port ${port}` 
      : `서버가 ${port} 포트에서 실행 중입니다. http://localhost:${port} 으로 접속하세요.`;
    log(message);
  });
})();
