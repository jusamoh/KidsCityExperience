import axios from 'axios';
import { Payment, PaymentVerification, TossPaymentRequest } from '@shared/schema';
import { storage } from './storage';
import crypto from 'crypto';

// 토스페이먼츠 API 설정
const TOSS_PAYMENTS_API_URL = 'https://api.tosspayments.com/v1';
// 오류를 방지하기 위해 실제 값 또는 테스트 값 사용
const TOSS_PAYMENTS_SECRET_KEY = process.env.TOSS_PAYMENTS_SECRET_KEY || 'test_sk_zXLkKEypNArWmo50nX3lmeaxYG5R';
const TOSS_PAYMENTS_CLIENT_KEY = process.env.TOSS_PAYMENTS_CLIENT_KEY || 'test_ck_ODnyRpQWGrN2JAjbA4XVl5E1em4d';

// 환경에 따른 도메인 설정
const getDomain = (): string => {
  if (process.env.NODE_ENV === 'production') {
    return 'https://yourdomain.com';
  }
  // Replit 환경에서는 실제 도메인을 사용
  if (process.env.REPL_SLUG && process.env.REPL_OWNER) {
    return `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`;
  }
  // 로컬 개발 환경
  return 'http://localhost:5000';
};

// 결제 요청 생성
export const createPaymentRequest = async (registrationId: number): Promise<{
  clientKey: string;
  paymentData: TossPaymentRequest;
}> => {
  // 등록 정보 조회
  const registration = await storage.getRegistration(registrationId);
  if (!registration) {
    throw new Error('등록 정보를 찾을 수 없습니다.');
  }
  
  // 프로그램 정보 조회
  const program = await storage.getProgram(registration.programId);
  if (!program) {
    throw new Error('프로그램 정보를 찾을 수 없습니다.');
  }
  
  // 고유한 주문 ID 생성 (현재 시간 + 랜덤 문자열)
  const timestamp = new Date().getTime();
  const randomString = crypto.randomBytes(8).toString('hex');
  const orderId = `order_${timestamp}_${randomString}`;
  
  // 주문명 생성
  const orderName = `${program.title} 신청 - ${registration.childName}`;
  
  // 호스트 정보
  const domain = getDomain();
  
  // 성공/실패 URL (클라이언트 라우트로 설정)
  const successUrl = `${domain}/payment-success`;
  const failUrl = `${domain}/payment-fail`;
  
  // 결제 데이터 생성
  const paymentData: TossPaymentRequest = {
    amount: program.price,
    orderId,
    orderName,
    customerEmail: registration.email,
    customerName: registration.parentName,
    successUrl,
    failUrl,
  };
  
  // 초기 결제 정보 저장
  await storage.createPayment({
    registrationId: registration.id,
    amount: program.price,
    method: '',
    status: 'ready',
    orderId,
    orderName,
  });
  
  return {
    clientKey: TOSS_PAYMENTS_CLIENT_KEY,
    paymentData,
  };
};

// 결제 검증 및 완료 처리
export const verifyPayment = async (data: PaymentVerification): Promise<Payment> => {
  const { paymentKey, orderId, amount } = data;
  
  try {
    // 결제 조회
    const payment = await storage.getPaymentByOrderId(orderId);
    if (!payment) {
      throw new Error('결제 정보를 찾을 수 없습니다.');
    }
    
    // 금액 확인
    if (payment.amount !== amount) {
      throw new Error('결제 금액이 일치하지 않습니다.');
    }
    
    // 토스페이먼츠 API에 결제 승인 요청
    const basicAuth = Buffer.from(`${TOSS_PAYMENTS_SECRET_KEY}:`).toString('base64');
    
    const response = await axios.post(
      `${TOSS_PAYMENTS_API_URL}/payments/${paymentKey}`,
      { orderId, amount },
      {
        headers: {
          Authorization: `Basic ${basicAuth}`,
          'Content-Type': 'application/json',
        },
      }
    );
    
    const tossResponse = response.data;
    
    // 결제 정보 업데이트
    const updatedPayment = await storage.updatePayment(payment.id, {
      paymentKey,
      method: tossResponse.method,
      status: 'paid',
      approvedAt: new Date(),
      receiptUrl: tossResponse.receipt?.url || '',
      extraData: JSON.stringify(tossResponse),
    });
    
    // 등록 정보에도 결제 상태 업데이트
    await storage.updateRegistrationPayment(payment.registrationId, {
      paymentStatus: 'paid',
      paymentMethod: tossResponse.method,
      paymentId: paymentKey,
      paidAmount: amount,
    });
    
    return updatedPayment;
  } catch (error) {
    console.error('Payment verification failed:', error);
    
    // 결제 실패 처리
    if (paymentKey) {
      try {
        // 토스페이먼츠 API에 결제 취소 요청
        const basicAuth = Buffer.from(`${TOSS_PAYMENTS_SECRET_KEY}:`).toString('base64');
        await axios.post(
          `${TOSS_PAYMENTS_API_URL}/payments/${paymentKey}/cancel`,
          { cancelReason: '결제 검증 실패' },
          {
            headers: {
              Authorization: `Basic ${basicAuth}`,
              'Content-Type': 'application/json',
            },
          }
        );
      } catch (cancelError) {
        console.error('Payment cancellation failed:', cancelError);
      }
    }
    
    throw error;
  }
};

// 테스트 결제 처리 (가상의 결제)
export const handleTestPayment = async (
  registrationId: number,
  amount: number,
  paymentKey: string,
  orderId: string
): Promise<Payment> => {
  try {
    // 등록 정보 조회
    const registration = await storage.getRegistration(registrationId);
    if (!registration) {
      throw new Error('등록 정보를 찾을 수 없습니다.');
    }

    // 주문명 생성 (실제 프로그램 정보는 필요 없음)
    const orderName = `테스트 결제 - ${registration.childName}`;
    
    // 가상 결제 정보 생성
    const payment = await storage.createPayment({
      registrationId,
      amount,
      method: 'CARD',
      status: 'paid',
      paymentKey,
      orderId,
      orderName,
      approvedAt: new Date(),
      receiptUrl: '',
      extraData: JSON.stringify({
        type: 'TEST_PAYMENT',
        testPaymentKey: paymentKey,
        testAmount: amount,
        message: '이것은 테스트 결제입니다.',
      }),
    });
    
    // 등록 정보에도 결제 상태 업데이트
    await storage.updateRegistrationPayment(registrationId, {
      paymentStatus: 'paid',
      paymentMethod: 'CARD',
      paymentId: paymentKey,
      paidAmount: amount,
    });
    
    // 프로그램 상태 확인 로직
    await updateProgramStatusByRegistration(registration.programId);
    
    return payment;
  } catch (error) {
    console.error('Test payment processing failed:', error);
    throw error;
  }
};

// 결제 취소 처리
export const cancelPayment = async (paymentId: number, reason: string): Promise<Payment> => {
  // 결제 정보 조회
  const payment = await storage.getPayment(paymentId);
  if (!payment) {
    throw new Error('결제 정보를 찾을 수 없습니다.');
  }
  
  if (!payment.paymentKey || payment.status !== 'paid') {
    throw new Error('취소할 수 있는 결제가 아닙니다.');
  }
  
  try {
    // 테스트 결제인지 확인
    const isTestPayment = payment.paymentKey.startsWith('test_payment_');
    
    if (!isTestPayment) {
      // 실제 토스페이먼츠 API에 결제 취소 요청
      const basicAuth = Buffer.from(`${TOSS_PAYMENTS_SECRET_KEY}:`).toString('base64');
      
      await axios.post(
        `${TOSS_PAYMENTS_API_URL}/payments/${payment.paymentKey}/cancel`,
        { cancelReason: reason },
        {
          headers: {
            Authorization: `Basic ${basicAuth}`,
            'Content-Type': 'application/json',
          },
        }
      );
    }
    
    // 결제 정보 업데이트
    const updatedPayment = await storage.updatePayment(payment.id, {
      status: 'canceled',
    });
    
    // 등록 정보에도 결제 상태 업데이트
    await storage.updateRegistrationPayment(payment.registrationId, {
      paymentStatus: 'canceled',
    });
    
    return updatedPayment;
  } catch (error) {
    console.error('Payment cancellation failed:', error);
    throw error;
  }
};

// 프로그램 상태 업데이트 함수
async function updateProgramStatusByRegistration(programId: number): Promise<void> {
  try {
    // 프로그램 정보 조회
    const program = await storage.getProgram(programId);
    if (!program) {
      return;
    }
    
    // 결제 완료된 신청 수 조회
    const registrationCount = await storage.getRegistrationCount(programId);
    
    // 최소 참가자 수 충족 시 프로그램 상태 '확정'으로 변경
    if (registrationCount >= program.minParticipants && program.status === 'pending') {
      await storage.updateProgramStatus(programId, 'confirmed');
      console.log(`Program ${programId} has been confirmed with ${registrationCount} registrations.`);
    }
  } catch (error) {
    console.error('Failed to update program status:', error);
  }
}