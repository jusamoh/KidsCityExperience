import {
  User, InsertUser, users,
  Category, InsertCategory, categories,
  Program, InsertProgram, programs,
  Registration, InsertRegistration, registrations,
  Payment, InsertPayment, payments
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<Category>): Promise<Category>;
  
  // Program methods
  getPrograms(): Promise<Program[]>;
  getProgramsByCategory(categoryId: number): Promise<Program[]>;
  getProgram(id: number): Promise<Program | undefined>;
  createProgram(program: InsertProgram): Promise<Program>;
  updateProgramStatus(id: number, status: string): Promise<Program | undefined>;
  updateProgramCategory(id: number, categoryId: number): Promise<Program | undefined>;
  
  // Registration methods
  getRegistrations(): Promise<Registration[]>;
  getRegistrationsByProgram(programId: number): Promise<Registration[]>;
  getRegistration(id: number): Promise<Registration | undefined>;
  createRegistration(registration: InsertRegistration): Promise<Registration>;
  getRegistrationCount(programId: number): Promise<number>;
  updateRegistrationPayment(registrationId: number, paymentInfo: {
    paymentStatus: string;
    paymentMethod?: string;
    paymentId?: string;
    paidAmount?: number;
  }): Promise<Registration | undefined>;

  // Payment methods
  getPayment(id: number): Promise<Payment | undefined>;
  getPaymentByOrderId(orderId: string): Promise<Payment | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: number, paymentInfo: Partial<Payment>): Promise<Payment>;
  getPaymentsByRegistration(registrationId: number): Promise<Payment[]>;
  
  // XAMPP MySQL 데이터베이스 저장 메서드
  saveCategoryChange?(programId: number, categoryId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private programs: Map<number, Program>;
  private registrations: Map<number, Registration>;
  private payments: Map<number, Payment>;
  
  private userId: number;
  private categoryId: number;
  private programId: number;
  private registrationId: number;
  private paymentId: number;
  
  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.programs = new Map();
    this.registrations = new Map();
    this.payments = new Map();
    
    this.userId = 1;
    this.categoryId = 1;
    this.programId = 1;
    this.registrationId = 1;
    this.paymentId = 1;
    
    // Initialize with default data
    this.initializeData();
  }
  
  private initializeData() {
    // Create default admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      isAdmin: true
    });
    
    // Create default categories
    const gardeningCategory = this.createCategory({
      name: "도시텃밭 체험",
      description: "아이들이 식물을 심고 가꾸는 체험을 통해 생명의 소중함을 배워요."
    });
    
    const englishCategory = this.createCategory({
      name: "영어놀이 체험",
      description: "다양한 영어 활동을 통해 자연스럽게 영어에 친숙해져요."
    });
    
    const sportsCategory = this.createCategory({
      name: "스포츠 및 놀이 체험",
      description: "다양한 신체 활동과 놀이를 통해 건강한 발달을 도와요."
    });
    
    // Create sample programs
    const now = new Date();
    const twoWeeksLater = new Date(now);
    twoWeeksLater.setDate(now.getDate() + 14);
    
    // Sample gardening programs with Korea's most popular urban garden crops
    this.createProgram({
      title: "상추 키우기 체험",
      description: "한국 도시텃밭의 대표 작물인 상추를 직접 심고 가꾸는 체험 프로그램입니다. 아이와 함께 씨앗 심기부터 모종 관리, 수확까지 전 과정을 체험하며 친환경 식물 기르기의 즐거움을 느껴보세요. 수확한 상추로 간단한 샐러드를 만들어 맛보는 시간도 가집니다.",
      categoryId: gardeningCategory.id,
      minAge: 12,
      maxAge: 24,
      date: twoWeeksLater,
      location: "서울 강남구 도시농업체험장",
      price: 30000,
      maxParticipants: 10,
      minParticipants: 6,
      duration: 90,
      imageUrl: "https://images.unsplash.com/photo-1556800572-1b8aedf82c5e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "confirmed"
    });
    
    this.createProgram({
      title: "방울토마토 수확 체험",
      description: "아이들이 가장 좋아하는 방울토마토를 직접 수확하고 맛보는 체험입니다. 방울토마토의 성장 과정을 관찰하고, 수확의 기쁨을 느껴보세요. 수확한 방울토마토로 미니 피자 만들기 활동도 함께 진행됩니다. 아이의 오감을 자극하고 건강한 먹거리의 소중함을 배울 수 있는 시간입니다.",
      categoryId: gardeningCategory.id,
      minAge: 10,
      maxAge: 24,
      date: new Date(twoWeeksLater.getTime() + 3 * 24 * 60 * 60 * 1000),
      location: "서울 마포구 도시농업센터",
      price: 32000,
      maxParticipants: 8,
      minParticipants: 5,
      duration: 100,
      imageUrl: "https://images.unsplash.com/photo-1592841200221-a6898f307baa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "confirmed"
    });
    
    this.createProgram({
      title: "고추 모종 심기 체험",
      description: "한국 요리에 빠질 수 없는 고추 모종을 심고 가꾸는 체험입니다. 다양한 크기와 색깔의 고추 모종을 심고, 식물 성장에 필요한 물과 영양분에 대해 배웁니다. 아이들의 호기심을 자극하고 생명의 소중함을 느낄 수 있는 시간이 될 것입니다. 작은 화분에 심은 고추 모종은 집에 가져가서 계속 관찰할 수 있습니다.",
      categoryId: gardeningCategory.id,
      minAge: 12,
      maxAge: 24,
      date: new Date(twoWeeksLater.getTime() + 7 * 24 * 60 * 60 * 1000),
      location: "서울 송파구 실내 농장",
      price: 28000,
      maxParticipants: 10,
      minParticipants: 5,
      duration: 80,
      imageUrl: "https://images.unsplash.com/photo-1596371624386-1cbcd43a3cce?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "confirmed"
    });
    
    this.createProgram({
      title: "깻잎 향기 체험",
      description: "한국 식탁에 자주 오르는 깻잎을 직접 기르고 수확하는 체험입니다. 깻잎의 독특한 향과 다양한 활용법에 대해 배우고, 수확한 깻잎으로 건강한 간식을 만들어봅니다. 아이들에게 한국 전통 식물에 대한 관심과 애정을 키워주는 특별한 시간이 될 것입니다. 깻잎 씨앗 패키지도 선물로 드립니다.",
      categoryId: gardeningCategory.id,
      minAge: 6,
      maxAge: 18,
      date: new Date(twoWeeksLater.getTime() + 10 * 24 * 60 * 60 * 1000),
      location: "서울 노원구 어린이 농장",
      price: 25000,
      maxParticipants: 12,
      minParticipants: 6,
      duration: 70,
      imageUrl: "https://images.unsplash.com/photo-1515708977879-aec7759f0d7d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "confirmed"
    });
    
    // Sample English play programs with storybook theater play
    this.createProgram({
      title: "The Very Hungry Caterpillar 연극놀이",
      description: "세계적으로 유명한 에릭 칼의 'The Very Hungry Caterpillar' 그림책을 활용한 연극놀이입니다. 'I am hungry', 'I like apples', 'Let's eat together' 등 쉬운 생활영어 표현을 배우며 배고픈 애벌레가 나비가 되는 과정을 직접 연기해봅니다. 아이들은 과일 소품을 활용하여 먹는 행동을 연기하고, 알에서 나비로 변하는 과정을 몸으로 표현하며 생활영어를 자연스럽게 익힙니다.",
      categoryId: englishCategory.id,
      minAge: 10,
      maxAge: 24,
      date: new Date(twoWeeksLater.getTime() + 2 * 24 * 60 * 60 * 1000),
      location: "서울 마포구 키즈카페",
      price: 35000,
      maxParticipants: 8,
      minParticipants: 4,
      duration: 75,
      imageUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "pending"
    });
    
    this.createProgram({
      title: "Brown Bear, Brown Bear 역할놀이",
      description: "빌 마틴 주니어의 'Brown Bear, Brown Bear, What Do You See?' 그림책을 활용한 역할놀이입니다. 'I see a...', 'What color is it?', 'I am a...' 같은 쉬운 생활영어 표현을 익히며 다양한 동물 역할을 맡아 연기합니다. 색깔과 동물 이름을 영어로 배우고, 동물 가면을 만들어 쓰고 각 동물의 특징적인 움직임과 소리를 표현하는 활동을 통해 아이들의 언어 발달과 창의력, 표현력을 함께 키웁니다.",
      categoryId: englishCategory.id,
      minAge: 12,
      maxAge: 24,
      date: new Date(twoWeeksLater.getTime() + 9 * 24 * 60 * 60 * 1000),
      location: "서울 강동구 어린이도서관",
      price: 32000,
      maxParticipants: 8,
      minParticipants: 4,
      duration: 60,
      imageUrl: "https://images.unsplash.com/photo-1549737221-bef65e2604a6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "pending"
    });
    
    this.createProgram({
      title: "Going on a Bear Hunt 모험놀이",
      description: "마이클 로젠의 'We're Going on a Bear Hunt' 그림책을 활용한 영어 모험놀이입니다. 'Let's go', 'I'm not scared', 'Oh no!' 등의 생활영어 표현을 배우며 실내에 꾸며진 작은 모험 코스를 탐험합니다. 풀숲, 진흙, 강, 숲 등 다양한 환경을 지나가는 모션과 효과음을 함께 표현하며 그림책 속 이야기를 실감나게 체험합니다. 아이들의 상상력과 신체 발달, 영어 표현력을 동시에 키울 수 있는 프로그램입니다.",
      categoryId: englishCategory.id,
      minAge: 8,
      maxAge: 20,
      date: new Date(twoWeeksLater.getTime() + 5 * 24 * 60 * 60 * 1000),
      location: "서울 용산구 어린이영어도서관",
      price: 34000,
      maxParticipants: 10,
      minParticipants: 5,
      duration: 70,
      imageUrl: "https://images.unsplash.com/photo-1551966775-a4ddc8df052b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "pending"
    });
    
    this.createProgram({
      title: "The Rainbow Fish 인형극 놀이",
      description: "마르쿠스 피스터의 'The Rainbow Fish' 그림책을 활용한 인형극 놀이입니다. 'Please', 'Thank you', 'Can I have...?', 'Let's be friends' 등 일상 생활에서 자주 사용하는 영어 표현을 배우며 무지개 물고기 이야기를 인형극으로 만들어봅니다. 아이들은 반짝이는 비늘 소품을 만들고, 물고기 캐릭터 역할을 나누어 맡아 공유와 우정의 가치를 영어로 표현합니다. 영어 표현과 함께 사회성 발달에도 도움을 주는 프로그램입니다.",
      categoryId: englishCategory.id,
      minAge: 10,
      maxAge: 22,
      date: new Date(twoWeeksLater.getTime() + 7 * 24 * 60 * 60 * 1000),
      location: "서울 송파구 키즈아트센터",
      price: 36000,
      maxParticipants: 8,
      minParticipants: 4,
      duration: 80,
      imageUrl: "https://images.unsplash.com/photo-1594608661623-aa0bd3a69799?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "pending"
    });
    
    // 스포츠 및 놀이 체험 프로그램에 필요한 ID 303 프로그램 직접 추가
    const sportsProgram303 = {
      id: 303,
      title: "아기 체조",
      description: "전문 강사와 함께하는 영아 발달 체조 프로그램입니다. 대근육과 소근육 발달을 촉진하는 다양한 활동을 진행합니다.",
      categoryId: sportsCategory.id,
      minAge: 6,
      maxAge: 18,
      date: new Date(twoWeeksLater.getTime() + 4 * 24 * 60 * 60 * 1000),
      location: "파주시 키즈 체육관",
      price: 20000,
      maxParticipants: 10,
      minParticipants: 5,
      duration: 45,
      imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "pending"
    };
    
    // 메모리 저장소에 직접 추가
    this.programs.set(303, sportsProgram303);
    
    this.createProgram({
      title: "아기 체육 놀이",
      description: "다양한 공과 매트 활동을 통해 아이의 대근육 발달과 신체 협응력을 키워요.",
      categoryId: sportsCategory.id,
      minAge: 6,
      maxAge: 18,
      date: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000),
      location: "서울 용산구 키즈체육관",
      price: 28000,
      maxParticipants: 10,
      minParticipants: 6,
      duration: 60,
      imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "canceled"
    });
    
    this.createProgram({
      title: "오감 놀이터",
      description: "다양한 놀이기구와 감각재료를 통해 아이의 오감을 자극하고 발달을 돕는 프로그램이에요.",
      categoryId: sportsCategory.id,
      minAge: 8,
      maxAge: 24,
      date: new Date(twoWeeksLater.getTime() + 5 * 24 * 60 * 60 * 1000),
      location: "서울 서초구 어린이놀이센터",
      price: 29000,
      maxParticipants: 8,
      minParticipants: 5,
      duration: 70,
      imageUrl: "https://images.unsplash.com/photo-1524503033411-c9566986fc8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      status: "pending"
    });
    
    // Add some registrations
    this.createRegistration({
      programId: 1,
      childName: "김하늘",
      childAge: 15,
      parentName: "김엄마",
      phone: "010-1234-5678",
      email: "kim@example.com",
      notes: "특이사항 없음"
    });
    
    this.createRegistration({
      programId: 1,
      childName: "이슬기",
      childAge: 18,
      parentName: "이아빠",
      phone: "010-2345-6789",
      email: "lee@example.com",
      notes: "알레르기 있음"
    });
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryId++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }
  
  async updateCategory(id: number, categoryUpdate: Partial<Category>): Promise<Category> {
    const category = this.categories.get(id);
    if (!category) {
      throw new Error(`Category with ID ${id} not found`);
    }
    
    const updatedCategory: Category = { ...category, ...categoryUpdate };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }
  
  // Program methods
  async getPrograms(): Promise<Program[]> {
    return Array.from(this.programs.values());
  }
  
  async getProgramsByCategory(categoryId: number): Promise<Program[]> {
    return Array.from(this.programs.values()).filter(
      (program) => program.categoryId === categoryId
    );
  }
  
  async getProgram(id: number): Promise<Program | undefined> {
    return this.programs.get(id);
  }
  
  async createProgram(program: InsertProgram): Promise<Program> {
    const id = this.programId++;
    const newProgram: Program = { ...program, id };
    this.programs.set(id, newProgram);
    return newProgram;
  }
  
  async updateProgramStatus(id: number, status: string): Promise<Program | undefined> {
    const program = this.programs.get(id);
    if (!program) return undefined;
    
    const updatedProgram: Program = { ...program, status };
    this.programs.set(id, updatedProgram);
    return updatedProgram;
  }
  
  async updateProgramCategory(id: number, categoryId: number): Promise<Program | undefined> {
    const program = this.programs.get(id);
    if (!program) return undefined;
    
    const category = this.categories.get(categoryId);
    if (!category) {
      throw new Error(`Category with ID ${categoryId} not found`);
    }
    
    const updatedProgram: Program = { ...program, categoryId };
    this.programs.set(id, updatedProgram);
    return updatedProgram;
  }
  
  // Registration methods
  async getRegistrations(): Promise<Registration[]> {
    return Array.from(this.registrations.values());
  }
  
  async getRegistrationsByProgram(programId: number): Promise<Registration[]> {
    return Array.from(this.registrations.values()).filter(
      (registration) => registration.programId === programId
    );
  }
  
  async getRegistration(id: number): Promise<Registration | undefined> {
    return this.registrations.get(id);
  }
  
  async createRegistration(registration: InsertRegistration): Promise<Registration> {
    const id = this.registrationId++;
    const createdAt = new Date();
    const newRegistration: Registration = { 
      ...registration, 
      id, 
      createdAt,
      paymentStatus: 'pending',
      paymentMethod: null,
      paymentId: null,
      paidAmount: null
    };
    this.registrations.set(id, newRegistration);
    
    // Check if the program needs to be confirmed
    this.updateProgramStatusByRegistration(registration.programId);
    
    return newRegistration;
  }
  
  async getRegistrationCount(programId: number): Promise<number> {
    return (await this.getRegistrationsByProgram(programId)).length;
  }

  async updateRegistrationPayment(registrationId: number, paymentInfo: {
    paymentStatus: string;
    paymentMethod?: string;
    paymentId?: string;
    paidAmount?: number;
  }): Promise<Registration | undefined> {
    const registration = this.registrations.get(registrationId);
    if (!registration) return undefined;
    
    const updatedRegistration: Registration = {
      ...registration,
      paymentStatus: paymentInfo.paymentStatus,
      paymentMethod: paymentInfo.paymentMethod || registration.paymentMethod,
      paymentId: paymentInfo.paymentId || registration.paymentId,
      paidAmount: paymentInfo.paidAmount !== undefined ? paymentInfo.paidAmount : registration.paidAmount
    };
    
    this.registrations.set(registrationId, updatedRegistration);
    return updatedRegistration;
  }
  
  // Payment methods
  async getPayment(id: number): Promise<Payment | undefined> {
    return this.payments.get(id);
  }
  
  async getPaymentByOrderId(orderId: string): Promise<Payment | undefined> {
    return Array.from(this.payments.values()).find(
      (payment) => payment.orderId === orderId
    );
  }
  
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const id = this.paymentId++;
    const requestedAt = new Date();
    const newPayment: Payment = {
      ...payment,
      id,
      requestedAt,
      paymentKey: null,
      approvedAt: null,
      receiptUrl: null,
      extraData: null
    };
    this.payments.set(id, newPayment);
    return newPayment;
  }
  
  async updatePayment(id: number, paymentInfo: Partial<Payment>): Promise<Payment> {
    const payment = this.payments.get(id);
    if (!payment) {
      throw new Error('Payment not found');
    }
    
    const updatedPayment: Payment = { ...payment, ...paymentInfo };
    this.payments.set(id, updatedPayment);
    return updatedPayment;
  }
  
  async getPaymentsByRegistration(registrationId: number): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(
      (payment) => payment.registrationId === registrationId
    );
  }
  
  // Helper method to update program status
  private async updateProgramStatusByRegistration(programId: number): Promise<void> {
    const program = await this.getProgram(programId);
    if (!program) return;
    
    const registrationCount = await this.getRegistrationCount(programId);
    
    if (program.status === "pending" && registrationCount >= program.minParticipants) {
      await this.updateProgramStatus(programId, "confirmed");
    }
  }
}

// XAMPP MySQL을 사용하기 위한 DatabaseStorage 가져오기
import { DatabaseStorage } from './database-storage';

// XAMPP MySQL을 사용하기 위해 데이터베이스 사용을 기본값으로 설정
// 실제 XAMPP 환경에서는 true로 설정해서 사용
const useDatabase = process.env.USE_DATABASE !== 'false';

// 실제 XAMPP 환경에서 데이터베이스 연결이 실패해도 작동할 수 있도록 MemStorage 기본 사용
export const storage = new MemStorage();

// 카테고리 변경을 MySQL에 저장하는 함수
export async function saveCategoryChange(programId: number, categoryId: number): Promise<void> {
  try {
    // XAMPP에서 실행될 때 사용할 코드
    console.log(`XAMPP MySQL에 카테고리 변경 저장 시도: 프로그램 ${programId} -> 카테고리 ${categoryId}`);
    
    try {
      // 현재 환경이 Replit인지 확인 (로컬 XAMPP 환경에서는 실행 안됨)
      if (process.env.REPL_ID || process.env.REPL_SLUG) {
        console.log('현재 Replit 환경에서 실행 중입니다. XAMPP 환경에서 실행하세요.');
        console.log('카테고리 변경 내용은 메모리에만 저장되었습니다.');
        console.log('* XAMPP 환경에서 실행하면 MySQL에 자동으로 저장됩니다.');
        return;
      }
      
      // MySQL DB에 직접 쿼리 실행 - 연결 시도 시간 단축
      const mysql = require('mysql2/promise');
      
      try {
        // 먼저 루트로 연결해서 데이터베이스가 없으면 생성 (타임아웃 1초로 설정)
        let connection = await mysql.createConnection({
          host: 'localhost',
          user: 'root',
          password: '',
          connectTimeout: 1000 // 1초 후 타임아웃
        });
        
        // waggle_db 데이터베이스가 없으면 생성
        await connection.execute(`CREATE DATABASE IF NOT EXISTS waggle_db`);
        await connection.end();
        
        // waggle_db 데이터베이스로 다시 연결 (타임아웃 1초로 설정)
        connection = await mysql.createConnection({
          host: 'localhost',
          user: 'root',
          password: '',
          database: 'waggle_db',
          connectTimeout: 1000 // 1초 후 타임아웃
        });
        
        // program_categories 테이블이 없으면 생성
        await connection.execute(`
          CREATE TABLE IF NOT EXISTS program_categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            program_id INT NOT NULL,
            category_id INT NOT NULL,
            changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (program_id),
            INDEX (category_id)
          )
        `);
        
        // 카테고리 변경 기록 저장
        await connection.execute(
          'INSERT INTO program_categories (program_id, category_id) VALUES (?, ?)',
          [programId, categoryId]
        );
        
        // 프로그램 테이블이 있는지 확인하고 없으면 생성 
        await connection.execute(`
          CREATE TABLE IF NOT EXISTS programs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            category_id INT NOT NULL DEFAULT 1,
            date DATE,
            location VARCHAR(255),
            min_age INT DEFAULT 0,
            max_age INT DEFAULT 24,
            price DECIMAL(10,2),
            status VARCHAR(50) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (category_id)
          )
        `);
        
        // 카테고리 테이블이 없으면 생성
        await connection.execute(`
          CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
          )
        `);
        
        // 프로그램 존재 여부 확인 
        const [rows]: any = await connection.execute(
          'SELECT COUNT(*) as count FROM programs WHERE id = ?',
          [programId]
        );
        
        // 프로그램이 존재하면 업데이트
        if (rows[0].count > 0) {
          await connection.execute(
            'UPDATE programs SET category_id = ? WHERE id = ?',
            [categoryId, programId]
          );
        } else {
          // 프로그램이 없으면 기본 데이터로 추가
          await connection.execute(
            'INSERT INTO programs (id, title, description, category_id) VALUES (?, ?, ?, ?)',
            [programId, `프로그램 ${programId}`, '프로그램 설명', categoryId]
          );
        }
        
        // 카테고리 존재 여부 확인
        const [catRows]: any = await connection.execute(
          'SELECT COUNT(*) as count FROM categories WHERE id = ?',
          [categoryId]
        );
        
        // 카테고리가 없으면 기본 데이터로 추가
        if (catRows[0].count === 0) {
          await connection.execute(
            'INSERT INTO categories (id, name, description) VALUES (?, ?, ?)',
            [categoryId, `카테고리 ${categoryId}`, '카테고리 설명']
          );
        }
        
        connection.end();
        
        console.log(`✓ XAMPP MySQL (waggle_db)에 카테고리 변경이 성공적으로 저장됨: 프로그램 ${programId} -> 카테고리 ${categoryId}`);
      } catch (innerError: any) {
        if (innerError.code === 'ETIMEDOUT' || innerError.code === 'ECONNREFUSED') {
          console.log('MySQL 서버에 연결할 수 없습니다. XAMPP에서 MySQL 서비스가 실행 중인지 확인하세요.');
          console.log('  1. XAMPP Control Panel을 열고 MySQL 서비스가 실행 중인지 확인하세요.');
          console.log('  2. MySQL 서비스가 중지된 경우 [Start] 버튼을 클릭하여 시작하세요.');
          console.log('  3. 카테고리 변경 후 다시 시도하세요.');
        } else {
          console.error('데이터베이스 오류:', innerError.message);
        }
      }
    } catch (dbError: any) {
      console.error('XAMPP MySQL 저장 실패:', dbError);
      console.error('오류 세부정보:', dbError.message);
    }
  } catch (error) {
    console.error('카테고리 변경 저장 중 오류 발생:', error);
  }
}

// MemStorage에 saveCategoryChange 메서드 추가
MemStorage.prototype.saveCategoryChange = async function(programId: number, categoryId: number): Promise<void> {
  // 외부 함수 호출
  await saveCategoryChange(programId, categoryId);
};
