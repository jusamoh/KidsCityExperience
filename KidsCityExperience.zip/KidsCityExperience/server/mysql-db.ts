import mysql from 'mysql2/promise';
import { config } from './config/mysql-config';

// MySQL 연결 풀 생성
export const pool = mysql.createPool({
  host: config.host,
  user: config.user,
  password: config.password,
  database: config.database, // 'ebbing' 데이터베이스 사용
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 데이터베이스 초기화 (테이블 생성)
export async function initializeDatabase() {
  try {
    const connection = await pool.getConnection();
    
    // 사용자 테이블
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        email VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'user'
      )
    `);
    
    // 카테고리 테이블
    await connection.query(`
      CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT
      )
    `);
    
    // 프로그램 테이블
    await connection.query(`
      CREATE TABLE IF NOT EXISTS programs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        date DATE NOT NULL,
        location VARCHAR(255) NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        minAge INT NOT NULL,
        maxAge INT NOT NULL,
        maxParticipants INT NOT NULL,
        categoryId INT NOT NULL,
        status VARCHAR(50) DEFAULT 'active',
        FOREIGN KEY (categoryId) REFERENCES categories(id)
      )
    `);
    
    // 등록 테이블
    await connection.query(`
      CREATE TABLE IF NOT EXISTS registrations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        userId INT,
        programId INT NOT NULL,
        childName VARCHAR(255) NOT NULL,
        childAge INT NOT NULL,
        parentName VARCHAR(255) NOT NULL,
        paymentStatus VARCHAR(50) DEFAULT 'pending',
        paymentMethod VARCHAR(50),
        paymentId VARCHAR(255),
        paidAmount DECIMAL(10, 2),
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (userId) REFERENCES users(id),
        FOREIGN KEY (programId) REFERENCES programs(id)
      )
    `);
    
    // 결제 테이블
    await connection.query(`
      CREATE TABLE IF NOT EXISTS payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        registrationId INT NOT NULL,
        orderId VARCHAR(255) NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        method VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL,
        approvedAt TIMESTAMP,
        receiptUrl VARCHAR(255),
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (registrationId) REFERENCES registrations(id)
      )
    `);
    
    console.log('Database tables initialized successfully');
    connection.release();
    
    await initializeDefaultData();
    
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// 기본 샘플 데이터 추가
async function initializeDefaultData() {
  try {
    const connection = await pool.getConnection();
    
    // 카테고리 기본 데이터 추가
    const [categories] = await connection.query('SELECT * FROM categories');
    if (Array.isArray(categories) && categories.length === 0) {
      await connection.query(`
        INSERT INTO categories (name, description) VALUES 
        ('도시텃밭 체험', '아이들이 식물을 심고 가꾸는 체험을 통해 자연의 소중함을 배웁니다.'),
        ('영어놀이 체험', '영어 그림책을 활용한 역할놀이와 동작활동으로 자연스럽게 영어에 노출됩니다.'),
        ('스포츠 및 놀이 체험', '다양한 신체활동과 오감자극 놀이로 건강한 성장을 돕습니다.')
      `);
    }
    
    // 샘플 프로그램 추가
    const [programs] = await connection.query('SELECT * FROM programs');
    if (Array.isArray(programs) && programs.length === 0) {
      await connection.query(`
        INSERT INTO programs (title, description, date, location, price, minAge, maxAge, maxParticipants, categoryId, status) VALUES 
        ('상추 키우기 체험', '한국 도시텃밭의 대표 작물인 상추를 심고 가꾸는 체험입니다.', '2025-06-01', '서울시 강남구 와글와글 정원', 30000, 12, 24, 10, 1, 'active'),
        ('방울토마토 수확 체험', '아이들이 좋아하는 방울토마토를 직접 수확하는 체험입니다.', '2025-06-08', '서울시 강남구 와글와글 정원', 30000, 12, 24, 10, 1, 'active'),
        ('고추 모종 심기 체험', '우리 음식에 빠질 수 없는 고추 모종을 심는 체험입니다.', '2025-06-15', '서울시 강남구 와글와글 정원', 30000, 12, 24, 10, 1, 'active'),
        ('깻잎 향기 체험', '한국 고유의 향신 채소인 깻잎을 심고 향을 맡아보는 체험입니다.', '2025-06-22', '서울시 강남구 와글와글 정원', 30000, 12, 24, 10, 1, 'active'),
        ('The Very Hungry Caterpillar 연극놀이', '에릭 칼의 명작 그림책을 활용한 영어 연극놀이입니다.', '2025-06-05', '서울시 강남구 와글와글 교실', 35000, 12, 24, 8, 2, 'active'),
        ('Brown Bear, Brown Bear 역할놀이', '빌 마틴 주니어의 인기 그림책을 활용한 영어 역할놀이입니다.', '2025-06-12', '서울시 강남구 와글와글 교실', 35000, 12, 24, 8, 2, 'active'),
        ('Going on a Bear Hunt 모험놀이', '마이클 로젠의 그림책으로 진행하는 영어 모험놀이입니다.', '2025-06-19', '서울시 강남구 와글와글 교실', 35000, 12, 24, 8, 2, 'active'),
        ('The Rainbow Fish 인형극 놀이', '마커스 피스터의 그림책을 주제로 한 인형극 놀이입니다.', '2025-06-26', '서울시 강남구 와글와글 교실', 35000, 12, 24, 8, 2, 'active'),
        ('아기 체육 놀이', '다양한 신체활동을 통해 대근육 발달을 돕는 체험입니다.', '2025-06-07', '서울시 강남구 와글와글 놀이방', 30000, 12, 24, 10, 3, 'active'),
        ('오감 놀이터', '다양한 감각을 자극하는 놀이로 두뇌 발달을 돕는 체험입니다.', '2025-06-14', '서울시 강남구 와글와글 놀이방', 30000, 12, 24, 10, 3, 'active')
      `);
    }
    
    // 관리자 계정 추가
    const [admins] = await connection.query('SELECT * FROM users WHERE role = ?', ['admin']);
    if (Array.isArray(admins) && admins.length === 0) {
      await connection.query(`
        INSERT INTO users (username, password, name, phone, email, role) VALUES 
        ('admin', '$2b$10$JEZ3RDgZ9DLRHNDGSxXE7OWELUr5OQNkodI3IVG5j2FqQlDsHsb/y', '관리자', '010-1234-5678', 'admin@waggle.kr', 'admin')
      `);
    }
    
    connection.release();
    console.log('Default data initialized successfully');
    
  } catch (error) {
    console.error('Failed to initialize default data:', error);
    throw error;
  }
}