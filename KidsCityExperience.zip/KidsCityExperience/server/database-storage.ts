import { 
  User, InsertUser, 
  Category, InsertCategory, 
  Program, InsertProgram,
  Registration, InsertRegistration,
  Payment, InsertPayment
} from "@shared/schema";
import { pool } from "./mysql-db";
import { IStorage } from "./storage";
import { RowDataPacket, ResultSetHeader, OkPacket } from 'mysql2';

// MySQL 데이터베이스를 사용하는 스토리지 클래스
export class DatabaseStorage implements IStorage {
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM users WHERE id = ?', 
        [id]
      );
      return rows.length ? rows[0] as User : undefined;
    } catch (error) {
      console.error('Error in getUser:', error);
      throw error;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM users WHERE username = ?', 
        [username]
      );
      return rows.length ? rows[0] as User : undefined;
    } catch (error) {
      console.error('Error in getUserByUsername:', error);
      throw error;
    }
  }

  async createUser(user: InsertUser): Promise<User> {
    try {
      const [result] = await pool.query<ResultSetHeader>(
        'INSERT INTO users (username, password, name, phone, email, role) VALUES (?, ?, ?, ?, ?, ?)',
        [user.username, user.password, user.name, user.phone, user.email, user.role || 'user']
      );
      
      const id = result.insertId;
      return { id, ...user } as User;
    } catch (error) {
      console.error('Error in createUser:', error);
      throw error;
    }
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>('SELECT * FROM categories');
      return rows as Category[];
    } catch (error) {
      console.error('Error in getCategories:', error);
      throw error;
    }
  }

  async getCategory(id: number): Promise<Category | undefined> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM categories WHERE id = ?',
        [id]
      );
      return rows.length ? rows[0] as Category : undefined;
    } catch (error) {
      console.error('Error in getCategory:', error);
      throw error;
    }
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    try {
      const [result] = await pool.query<ResultSetHeader>(
        'INSERT INTO categories (name, description) VALUES (?, ?)',
        [category.name, category.description]
      );
      
      const id = result.insertId;
      return { id, ...category } as Category;
    } catch (error) {
      console.error('Error in createCategory:', error);
      throw error;
    }
  }

  async updateCategory(id: number, categoryUpdate: Partial<Category>): Promise<Category> {
    try {
      const category = await this.getCategory(id);
      if (!category) {
        throw new Error(`Category with ID ${id} not found`);
      }

      const fieldsToUpdate = [];
      const values = [];

      if (categoryUpdate.name !== undefined) {
        fieldsToUpdate.push('name = ?');
        values.push(categoryUpdate.name);
      }
      if (categoryUpdate.description !== undefined) {
        fieldsToUpdate.push('description = ?');
        values.push(categoryUpdate.description);
      }

      if (fieldsToUpdate.length > 0) {
        values.push(id);
        await pool.query(
          `UPDATE categories SET ${fieldsToUpdate.join(', ')} WHERE id = ?`,
          values
        );
      }

      return { ...category, ...categoryUpdate } as Category;
    } catch (error) {
      console.error('Error in updateCategory:', error);
      throw error;
    }
  }

  // Program methods
  async getPrograms(): Promise<Program[]> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>('SELECT * FROM programs');
      return rows as Program[];
    } catch (error) {
      console.error('Error in getPrograms:', error);
      throw error;
    }
  }

  async getProgramsByCategory(categoryId: number): Promise<Program[]> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM programs WHERE categoryId = ?',
        [categoryId]
      );
      return rows as Program[];
    } catch (error) {
      console.error('Error in getProgramsByCategory:', error);
      throw error;
    }
  }

  async getProgram(id: number): Promise<Program | undefined> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM programs WHERE id = ?',
        [id]
      );
      return rows.length ? rows[0] as Program : undefined;
    } catch (error) {
      console.error('Error in getProgram:', error);
      throw error;
    }
  }

  async createProgram(program: InsertProgram): Promise<Program> {
    try {
      const [result] = await pool.query<ResultSetHeader>(
        `INSERT INTO programs (
          title, description, date, location, price,
          minAge, maxAge, maxParticipants, categoryId, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          program.title, program.description, program.date, program.location, program.price,
          program.minAge, program.maxAge, program.maxParticipants, program.categoryId, program.status || 'active'
        ]
      );
      
      const id = result.insertId;
      return { id, ...program } as Program;
    } catch (error) {
      console.error('Error in createProgram:', error);
      throw error;
    }
  }

  async updateProgramStatus(id: number, status: string): Promise<Program | undefined> {
    try {
      const program = await this.getProgram(id);
      if (!program) {
        return undefined;
      }

      await pool.query(
        'UPDATE programs SET status = ? WHERE id = ?',
        [status, id]
      );

      return { ...program, status } as Program;
    } catch (error) {
      console.error('Error in updateProgramStatus:', error);
      throw error;
    }
  }

  async updateProgramCategory(id: number, categoryId: number): Promise<Program | undefined> {
    try {
      const program = await this.getProgram(id);
      if (!program) {
        return undefined;
      }

      await pool.query(
        'UPDATE programs SET categoryId = ? WHERE id = ?',
        [categoryId, id]
      );

      return { ...program, categoryId } as Program;
    } catch (error) {
      console.error('Error in updateProgramCategory:', error);
      throw error;
    }
  }

  // Registration methods
  async getRegistrations(): Promise<Registration[]> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>('SELECT * FROM registrations');
      return rows as Registration[];
    } catch (error) {
      console.error('Error in getRegistrations:', error);
      throw error;
    }
  }

  async getRegistrationsByProgram(programId: number): Promise<Registration[]> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM registrations WHERE programId = ?',
        [programId]
      );
      return rows as Registration[];
    } catch (error) {
      console.error('Error in getRegistrationsByProgram:', error);
      throw error;
    }
  }

  async getRegistration(id: number): Promise<Registration | undefined> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM registrations WHERE id = ?',
        [id]
      );
      return rows.length ? rows[0] as Registration : undefined;
    } catch (error) {
      console.error('Error in getRegistration:', error);
      throw error;
    }
  }

  async createRegistration(registration: InsertRegistration): Promise<Registration> {
    try {
      const [result] = await pool.query<ResultSetHeader>(
        `INSERT INTO registrations (
          userId, programId, childName, childAge, parentName,
          paymentStatus, paymentMethod, paymentId, paidAmount
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          registration.userId || null, registration.programId, registration.childName,
          registration.childAge, registration.parentName, registration.paymentStatus || 'pending',
          registration.paymentMethod || null, registration.paymentId || null,
          registration.paidAmount || null
        ]
      );
      
      const id = result.insertId;
      const createdAt = new Date().toISOString();
      return { id, createdAt, ...registration } as Registration;
    } catch (error) {
      console.error('Error in createRegistration:', error);
      throw error;
    }
  }

  async getRegistrationCount(programId: number): Promise<number> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT COUNT(*) as count FROM registrations WHERE programId = ? AND paymentStatus = "paid"',
        [programId]
      );
      return rows[0].count;
    } catch (error) {
      console.error('Error in getRegistrationCount:', error);
      throw error;
    }
  }

  async updateRegistrationPayment(
    registrationId: number, 
    paymentInfo: {
      paymentStatus: string;
      paymentMethod?: string;
      paymentId?: string;
      paidAmount?: number;
    }
  ): Promise<Registration | undefined> {
    try {
      const registration = await this.getRegistration(registrationId);
      if (!registration) {
        return undefined;
      }

      const fieldsToUpdate = ['paymentStatus = ?'];
      const values = [paymentInfo.paymentStatus];

      if (paymentInfo.paymentMethod) {
        fieldsToUpdate.push('paymentMethod = ?');
        values.push(paymentInfo.paymentMethod);
      }
      if (paymentInfo.paymentId) {
        fieldsToUpdate.push('paymentId = ?');
        values.push(paymentInfo.paymentId);
      }
      if (paymentInfo.paidAmount) {
        fieldsToUpdate.push('paidAmount = ?');
        values.push(paymentInfo.paidAmount);
      }

      values.push(registrationId);
      await pool.query(
        `UPDATE registrations SET ${fieldsToUpdate.join(', ')} WHERE id = ?`,
        values
      );

      // 결제 상태 변경 후 프로그램 상태도 확인하고 업데이트
      if (paymentInfo.paymentStatus === 'paid') {
        await this.updateProgramStatusByRegistration(registration.programId);
      }

      return { ...registration, ...paymentInfo } as Registration;
    } catch (error) {
      console.error('Error in updateRegistrationPayment:', error);
      throw error;
    }
  }

  // Payment methods
  async getPayment(id: number): Promise<Payment | undefined> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM payments WHERE id = ?',
        [id]
      );
      return rows.length ? rows[0] as Payment : undefined;
    } catch (error) {
      console.error('Error in getPayment:', error);
      throw error;
    }
  }

  async getPaymentByOrderId(orderId: string): Promise<Payment | undefined> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM payments WHERE orderId = ?',
        [orderId]
      );
      return rows.length ? rows[0] as Payment : undefined;
    } catch (error) {
      console.error('Error in getPaymentByOrderId:', error);
      throw error;
    }
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    try {
      const [result] = await pool.query<ResultSetHeader>(
        `INSERT INTO payments (
          registrationId, orderId, amount, method, status, approvedAt, receiptUrl
        ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          payment.registrationId, payment.orderId, payment.amount, payment.method,
          payment.status, payment.approvedAt || null, payment.receiptUrl || null
        ]
      );
      
      const id = result.insertId;
      const createdAt = new Date().toISOString();
      return { id, createdAt, ...payment } as Payment;
    } catch (error) {
      console.error('Error in createPayment:', error);
      throw error;
    }
  }

  async updatePayment(id: number, paymentInfo: Partial<Payment>): Promise<Payment> {
    try {
      const payment = await this.getPayment(id);
      if (!payment) {
        throw new Error(`Payment with ID ${id} not found`);
      }

      const fieldsToUpdate = [];
      const values = [];

      if (paymentInfo.status !== undefined) {
        fieldsToUpdate.push('status = ?');
        values.push(paymentInfo.status);
      }
      if (paymentInfo.approvedAt !== undefined) {
        fieldsToUpdate.push('approvedAt = ?');
        values.push(paymentInfo.approvedAt);
      }
      if (paymentInfo.receiptUrl !== undefined) {
        fieldsToUpdate.push('receiptUrl = ?');
        values.push(paymentInfo.receiptUrl);
      }

      if (fieldsToUpdate.length > 0) {
        values.push(id);
        await pool.query(
          `UPDATE payments SET ${fieldsToUpdate.join(', ')} WHERE id = ?`,
          values
        );
      }

      return { ...payment, ...paymentInfo } as Payment;
    } catch (error) {
      console.error('Error in updatePayment:', error);
      throw error;
    }
  }

  async getPaymentsByRegistration(registrationId: number): Promise<Payment[]> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT * FROM payments WHERE registrationId = ?',
        [registrationId]
      );
      return rows as Payment[];
    } catch (error) {
      console.error('Error in getPaymentsByRegistration:', error);
      throw error;
    }
  }

  // 프로그램 등록 인원에 따른 상태 업데이트
  private async updateProgramStatusByRegistration(programId: number): Promise<void> {
    try {
      const program = await this.getProgram(programId);
      if (!program) return;

      const currentParticipants = await this.getRegistrationCount(programId);
      
      // 최대 인원에 도달하면 "마감"으로 상태 변경
      if (currentParticipants >= program.maxParticipants) {
        await this.updateProgramStatus(programId, 'closed');
      } 
      // 최소 인원(여기서는 3명으로 가정)에 도달하면 "확정"으로 상태 변경
      else if (currentParticipants >= 3 && program.status === 'active') {
        await this.updateProgramStatus(programId, 'confirmed');
      }
    } catch (error) {
      console.error('Error in updateProgramStatusByRegistration:', error);
      throw error;
    }
  }
}