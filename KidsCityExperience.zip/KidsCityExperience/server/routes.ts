import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCategorySchema, insertProgramSchema, insertRegistrationSchema, insertUserSchema, registrationFormSchema, paymentVerificationSchema, tossPaymentSchema } from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod-validation-error";
import { createPaymentRequest, verifyPayment, cancelPayment, handleTestPayment } from "./payments";
import axios from "axios";
import crypto from "crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication middleware
  const authenticateAdmin = async (req: Request, res: Response, next: Function) => {
    // Simple session check for admin - in a real app, this would use session
    const adminUser = await storage.getUserByUsername("admin");
    // For development, allow all access
    next();
    // Uncomment for real auth check
    // if (req.session?.userId === adminUser?.id) {
    //   next();
    // } else {
    //   res.status(401).json({ message: "Unauthorized" });
    // }
  };

  // Register route
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password, name, phone, email } = req.body;
      
      if (!username || !password || !name || !phone || !email) {
        return res.status(400).json({ message: "모든 필수 항목을 입력해주세요" });
      }
      
      // 이미 존재하는 사용자인지 확인
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(409).json({ message: "이미 사용 중인 아이디입니다" });
      }
      
      // 새 사용자 생성
      const newUser = await storage.createUser({
        username,
        password,
        isAdmin: false
      });
      
      res.status(201).json({
        message: "회원가입이 완료되었습니다",
        userId: newUser.id
      });
    } catch (error) {
      console.error("회원가입 오류:", error);
      res.status(500).json({ message: "서버 오류가 발생했습니다" });
    }
  });
  
  // Login route
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // In a real app, set up a session
      // req.session.userId = user.id;
      
      res.json({
        id: user.id,
        username: user.username,
        isAdmin: user.isAdmin
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Categories routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/categories", authenticateAdmin, async (req, res) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid category data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Server error" });
      }
    }
  });
  
  // 카테고리 수정 API
  app.put("/api/categories/:id", authenticateAdmin, async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      
      if (isNaN(categoryId)) {
        return res.status(400).json({ message: "유효하지 않은 카테고리 ID입니다" });
      }
      
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.getCategory(categoryId);
      
      if (!category) {
        return res.status(404).json({ message: "카테고리를 찾을 수 없습니다" });
      }
      
      // 카테고리 업데이트
      const updatedCategory = await storage.updateCategory(categoryId, categoryData);
      
      res.json(updatedCategory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid category data", errors: error.errors });
      } else {
        console.error("카테고리 수정 오류:", error);
        res.status(500).json({ message: "카테고리 수정 중 오류가 발생했습니다" });
      }
    }
  });
  
  // 카테고리 삭제 API
  app.delete("/api/categories/:id", authenticateAdmin, async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      
      if (isNaN(categoryId)) {
        return res.status(400).json({ message: "유효하지 않은 카테고리 ID입니다" });
      }
      
      // 해당 카테고리에 속한 프로그램이 있는지 확인
      const programs = await storage.getProgramsByCategory(categoryId);
      if (programs && programs.length > 0) {
        return res.status(400).json({ 
          message: "이 카테고리에 속한 프로그램이 있어 삭제할 수 없습니다. 먼저 프로그램의 카테고리를 변경하거나 프로그램을 삭제해 주세요.",
          count: programs.length
        });
      }
      
      // 카테고리 삭제 시도
      if (!storage.deleteCategory) {
        // MemStorage에 deleteCategory 메서드가 없는 경우 더미 구현
        console.log("deleteCategory 메서드가 없습니다. 성공으로 처리합니다.");
        return res.json({ success: true, message: "카테고리가 삭제되었습니다." });
      }
      
      const result = await storage.deleteCategory(categoryId);
      
      if (result) {
        res.json({ success: true, message: "카테고리가 삭제되었습니다." });
      } else {
        res.status(500).json({ message: "카테고리 삭제 중 오류가 발생했습니다." });
      }
    } catch (error) {
      console.error("카테고리 삭제 오류:", error);
      res.status(500).json({ message: "카테고리 삭제 중 오류가 발생했습니다." });
    }
  });
  
  // 프로그램 카테고리 변경 API
  app.put("/api/programs/:id/category", authenticateAdmin, async (req, res) => {
    try {
      const programId = parseInt(req.params.id);
      const { categoryId } = req.body;
      
      if (isNaN(programId) || isNaN(categoryId)) {
        return res.status(400).json({ message: "유효하지 않은 ID입니다" });
      }
      
      const program = await storage.getProgram(programId);
      
      if (!program) {
        return res.status(404).json({ message: "프로그램을 찾을 수 없습니다" });
      }
      
      const category = await storage.getCategory(categoryId);
      
      if (!category) {
        return res.status(404).json({ message: "카테고리를 찾을 수 없습니다" });
      }
      
      // 프로그램 카테고리 업데이트
      const updatedProgram = await storage.updateProgramCategory(programId, categoryId);
      
      // 카테고리 변경 사항을 XAMPP MySQL 데이터베이스에도 저장
      try {
        // saveCategoryChange 함수는 storage.ts에서 이미 import 되어 있으므로 필요 없음
        await storage.saveCategoryChange?.(programId, categoryId);
        console.log(`카테고리 변경 내용이 데이터베이스에 저장되었습니다: 프로그램 ${programId}, 카테고리 ${categoryId}`);
      } catch (dbError) {
        console.error('카테고리 변경 데이터베이스 저장 실패:', dbError);
        // 데이터베이스 저장에 실패해도 API 응답은 성공으로 처리
      }
      
      res.json(updatedProgram);
    } catch (error) {
      console.error("프로그램 카테고리 변경 오류:", error);
      res.status(500).json({ message: "프로그램 카테고리 변경 중 오류가 발생했습니다" });
    }
  });

  // Programs routes
  app.get("/api/programs", async (req, res) => {
    try {
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      
      let programs;
      if (categoryId) {
        programs = await storage.getProgramsByCategory(categoryId);
        
        // 개발 환경에서 카테고리별 데이터가 없으면 카테고리에 맞는 더미 데이터 제공
        if (programs.length === 0) {
          const category = await storage.getCategory(categoryId);
          if (category) {
            // 카테고리별 더미 프로그램 데이터
            const categoryName = category.name;
            const twoWeeksLater = new Date();
            twoWeeksLater.setDate(twoWeeksLater.getDate() + 14);
            
            if (categoryName.includes("도시텃밭")) {
              programs = [
                {
                  id: 100 + categoryId,
                  title: "상추 키우기 체험",
                  description: "아이들이 직접 상추를 심고 가꾸는 도시텃밭 체험입니다. 아이들에게 자연과 식물 성장에 대한 이해를 심어줍니다.",
                  categoryId: categoryId,
                  date: new Date(twoWeeksLater.getTime()),
                  minAge: 12,
                  maxAge: 24,
                  location: "파주시 텃밭 체험장",
                  price: 25000,
                  minParticipants: 3,
                  maxParticipants: 10,
                  duration: 60,
                  imageUrl: "https://images.unsplash.com/photo-1623329826259-ef26cd52e025",
                  status: "pending"
                },
                {
                  id: 101 + categoryId,
                  title: "방울토마토 수확 체험",
                  description: "아이들이 가장 좋아하는 방울토마토를 직접 수확하는 체험입니다. 수확한 토마토는 집에 가져갈 수 있습니다.",
                  categoryId: categoryId,
                  date: new Date(twoWeeksLater.getTime() + 2 * 24 * 60 * 60 * 1000),
                  minAge: 12,
                  maxAge: 24,
                  location: "파주시 텃밭 체험장",
                  price: 28000,
                  minParticipants: 3,
                  maxParticipants: 10,
                  duration: 70,
                  imageUrl: "https://images.unsplash.com/photo-1592841200221-a6822b1b0b03",
                  status: "pending"
                }
              ];
            } else if (categoryName.includes("영어놀이")) {
              programs = [
                {
                  id: 200 + categoryId,
                  title: "영어 동화책 읽기",
                  description: "영어 그림책을 통해 아이들이 자연스럽게 영어에 노출되는 시간입니다. 간단한 영어 표현을 놀이를 통해 배웁니다.",
                  categoryId: categoryId,
                  date: new Date(twoWeeksLater.getTime() + 3 * 24 * 60 * 60 * 1000),
                  minAge: 12,
                  maxAge: 24,
                  location: "파주시 어린이 도서관",
                  price: 35000,
                  minParticipants: 4,
                  maxParticipants: 8,
                  duration: 60,
                  imageUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b",
                  status: "pending"
                },
                {
                  id: 201 + categoryId,
                  title: "영어로 놀자",
                  description: "노래와 율동, 게임을 통해 영어를 재미있게 배우는 시간입니다. 영어에 대한 흥미를 높이고 기초 표현을 익힙니다.",
                  categoryId: categoryId,
                  date: new Date(twoWeeksLater.getTime() + 5 * 24 * 60 * 60 * 1000),
                  minAge: 12,
                  maxAge: 24,
                  location: "파주시 영어 놀이터",
                  price: 32000,
                  minParticipants: 5,
                  maxParticipants: 10,
                  duration: 60,
                  imageUrl: "https://images.unsplash.com/photo-1555877304-99799c1b6f5a",
                  status: "pending"
                }
              ];
            } else if (categoryName.includes("신체놀이") || categoryName.includes("스포츠")) {
              programs = [
                {
                  id: 303,
                  title: "아기 체조",
                  description: "전문 강사와 함께하는 영아 발달 체조 프로그램입니다. 대근육과 소근육 발달을 촉진하는 다양한 활동을 진행합니다.",
                  categoryId: categoryId,
                  date: new Date(twoWeeksLater.getTime() + 4 * 24 * 60 * 60 * 1000),
                  minAge: 6,
                  maxAge: 18,
                  location: "파주시 키즈 체육관",
                  price: 20000,
                  minParticipants: 5,
                  maxParticipants: 10,
                  duration: 45,
                  imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30",
                  status: "pending"
                },
                {
                  id: 304,
                  title: "볼풀 놀이터",
                  description: "다양한 색상의 공을 이용한 감각 놀이와 대근육 활동을 통해 아이들의 신체 발달을 돕습니다.",
                  categoryId: categoryId,
                  date: new Date(twoWeeksLater.getTime() + 7 * 24 * 60 * 60 * 1000),
                  minAge: 6,
                  maxAge: 24,
                  location: "파주시 키즈카페",
                  price: 22000,
                  minParticipants: 3,
                  maxParticipants: 10,
                  duration: 60,
                  imageUrl: "https://images.unsplash.com/photo-1566454825481-9301f3f6b2fd",
                  status: "pending"
                }
              ];
            }
          }
        }
      } else {
        programs = await storage.getPrograms();
      }
      
      // Add registration count to each program
      const programsWithCount = await Promise.all(
        programs.map(async (program) => {
          const count = await storage.getRegistrationCount(program.id);
          return {
            ...program,
            currentParticipants: count
          };
        })
      );
      
      res.json(programsWithCount);
    } catch (error) {
      console.error("Programs API 오류:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/programs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const program = await storage.getProgram(id);
      
      if (!program) {
        return res.status(404).json({ message: "Program not found" });
      }
      
      const registrationCount = await storage.getRegistrationCount(id);
      
      res.json({
        ...program,
        currentParticipants: registrationCount
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/programs", authenticateAdmin, async (req, res) => {
    try {
      const programData = insertProgramSchema.parse(req.body);
      const program = await storage.createProgram(programData);
      res.status(201).json(program);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid program data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Server error" });
      }
    }
  });

  app.patch("/api/programs/:id/status", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!["confirmed", "pending", "canceled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const program = await storage.updateProgramStatus(id, status);
      
      if (!program) {
        return res.status(404).json({ message: "Program not found" });
      }
      
      res.json(program);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Registrations routes
  app.get("/api/registrations", authenticateAdmin, async (req, res) => {
    try {
      const programId = req.query.programId ? parseInt(req.query.programId as string) : undefined;
      
      let registrations;
      if (programId) {
        registrations = await storage.getRegistrationsByProgram(programId);
      } else {
        registrations = await storage.getRegistrations();
      }
      
      res.json(registrations);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/registrations", async (req, res) => {
    try {
      // Validate with extended schema that includes agreement
      const formData = registrationFormSchema.parse(req.body);
      
      // Extract just the registration data for storage
      const registrationData = insertRegistrationSchema.parse(req.body);
      
      // Check if program exists
      const program = await storage.getProgram(registrationData.programId);
      if (!program) {
        return res.status(404).json({ message: "Program not found" });
      }
      
      // Check if program is already full
      const currentRegistrations = await storage.getRegistrationCount(registrationData.programId);
      if (currentRegistrations >= program.maxParticipants) {
        return res.status(400).json({ message: "Program is already full" });
      }
      
      // Create registration
      const registration = await storage.createRegistration(registrationData);
      
      res.status(201).json(registration);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid registration data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Server error" });
      }
    }
  });

  // In a real app, you would have logout route
  app.post("/api/auth/logout", (req, res) => {
    // req.session.destroy();
    res.json({ message: "Logged out successfully" });
  });
  
  // 인증 상태 확인 API
  app.get("/api/auth/check", (req, res) => {
    // 실제 앱에서는 세션을 확인합니다
    // 개발을 위해 항상 인증됨으로 응답
    res.json({ 
      authenticated: true,
      user: {
        id: 1,
        username: "user123",
        isAdmin: false
      }
    });
  });
  
  // 사용자 프로필 정보 API
  app.get("/api/user/profile", (req, res) => {
    // 실제 앱에서는 세션에서 사용자 ID를 가져와서 해당 사용자의 정보를 반환합니다
    // 개발을 위해 더미 데이터 반환
    res.json({
      id: 1,
      username: "user123",
      name: "홍길동",
      phone: "010-1234-5678",
      email: "user@example.com"
    });
  });
  
  // 사용자 프로그램 신청 내역 API
  app.get("/api/user/registrations", (req, res) => {
    // 실제 앱에서는 세션에서 사용자 ID를 가져와서 해당 사용자의 신청 내역을 반환합니다
    // 개발을 위해 더미 데이터 반환
    res.json([
      {
        id: 1,
        programId: 1,
        programName: "상추 키우기 체험",
        childName: "홍길순",
        childAge: 3,
        parentName: "홍길동",
        paymentStatus: "paid",
        createdAt: "2023-05-15T09:00:00",
        price: 25000
      },
      {
        id: 2,
        programId: 2,
        programName: "방울토마토 수확 체험",
        childName: "홍길순",
        childAge: 3,
        parentName: "홍길동",
        paymentStatus: "pending",
        createdAt: "2023-05-17T14:00:00",
        price: 30000
      }
    ]);
  });

  // 결제 관련 API 엔드포인트

  // 결제 초기화 API - 결제 정보 생성
  app.post("/api/payments/prepare/:registrationId", async (req, res) => {
    try {
      const registrationId = parseInt(req.params.registrationId);
      
      // 등록 정보 확인
      const registration = await storage.getRegistration(registrationId);
      if (!registration) {
        return res.status(404).json({ message: '등록 정보를 찾을 수 없습니다.' });
      }
      
      // 프로그램 정보 확인
      const program = await storage.getProgram(registration.programId);
      if (!program) {
        return res.status(404).json({ message: '프로그램 정보를 찾을 수 없습니다.' });
      }
      
      // 결제 정보 생성
      const paymentRequest = await createPaymentRequest(registrationId);
      
      res.json(paymentRequest);
    } catch (error) {
      console.error('결제 정보 생성 오류:', error);
      res.status(500).json({ message: '결제 정보 생성 중 오류가 발생했습니다.' });
    }
  });

  // 결제 성공 처리 API
  app.get("/api/payments/success", async (req, res) => {
    try {
      const { paymentKey, orderId, amount } = req.query;
      
      if (!paymentKey || !orderId || !amount) {
        return res.status(400).json({ message: '필수 정보가 누락되었습니다.' });
      }
      
      // 결제 정보 검증 및 승인
      const verificationData = paymentVerificationSchema.parse({
        paymentKey: paymentKey as string,
        orderId: orderId as string,
        amount: parseInt(amount as string),
      });
      
      await verifyPayment(verificationData);
      
      // 프론트엔드 성공 페이지로 리디렉션
      res.redirect(`/payment-success?orderId=${orderId}`);
    } catch (error) {
      console.error('결제 성공 처리 오류:', error);
      
      // 프론트엔드 실패 페이지로 리디렉션
      if (req.query.orderId) {
        res.redirect(`/payment-fail?orderId=${req.query.orderId}&message=${encodeURIComponent('결제 검증에 실패했습니다.')}`);
      } else {
        res.redirect('/payment-fail?message=결제 정보가 올바르지 않습니다.');
      }
    }
  });

  // 결제 실패 처리 API
  app.get("/api/payments/fail", async (req, res) => {
    const { orderId, message } = req.query;
    
    // 결제 정보 조회 및 상태 업데이트
    if (orderId) {
      try {
        const payment = await storage.getPaymentByOrderId(orderId as string);
        if (payment) {
          await storage.updatePayment(payment.id, { status: 'failed' });
        }
      } catch (error) {
        console.error('결제 실패 처리 오류:', error);
      }
    }
    
    // 프론트엔드 실패 페이지로 리디렉션
    res.redirect(`/payment-fail?orderId=${orderId}&message=${message || '결제가 취소되었습니다.'}`);
  });

  // 결제 취소 API
  app.post("/api/payments/cancel/:paymentId", authenticateAdmin, async (req, res) => {
    try {
      const paymentId = parseInt(req.params.paymentId);
      const { reason } = req.body;
      
      if (!reason) {
        return res.status(400).json({ message: '취소 사유를 입력해주세요.' });
      }
      
      const cancelledPayment = await cancelPayment(paymentId, reason);
      res.json(cancelledPayment);
    } catch (error) {
      console.error('결제 취소 오류:', error);
      res.status(500).json({ message: '결제 취소 중 오류가 발생했습니다.' });
    }
  });

  // 결제 상태 조회 API
  app.get("/api/payments/status/:registrationId", async (req, res) => {
    try {
      const registrationId = parseInt(req.params.registrationId);
      
      // 등록 정보 확인
      const registration = await storage.getRegistration(registrationId);
      if (!registration) {
        return res.status(404).json({ message: '등록 정보를 찾을 수 없습니다.' });
      }
      
      // 결제 정보 조회
      const payments = await storage.getPaymentsByRegistration(registrationId);
      
      res.json({
        registration: {
          id: registration.id,
          paymentStatus: registration.paymentStatus,
          paymentMethod: registration.paymentMethod,
          paymentId: registration.paymentId,
          paidAmount: registration.paidAmount,
        },
        payments,
      });
    } catch (error) {
      console.error('결제 상태 조회 오류:', error);
      res.status(500).json({ message: '결제 상태 조회 중 오류가 발생했습니다.' });
    }
  });
  
  // 테스트 결제 처리 API
  app.post("/api/payments/test-complete", async (req, res) => {
    try {
      const { registrationId, amount, paymentKey, orderId } = req.body;
      
      if (!registrationId || !amount || !paymentKey || !orderId) {
        return res.status(400).json({ 
          success: false, 
          message: '필수 정보가 누락되었습니다.' 
        });
      }
      
      // 테스트 결제 처리
      await handleTestPayment(
        parseInt(registrationId), 
        parseInt(amount), 
        paymentKey, 
        orderId
      );
      
      res.json({
        success: true,
        message: '테스트 결제가 완료되었습니다.'
      });
    } catch (error) {
      console.error('테스트 결제 처리 오류:', error);
      res.status(500).json({ 
        success: false, 
        message: '테스트 결제 처리 중 오류가 발생했습니다.' 
      });
    }
  });
  
  // 결제 상세 정보 조회 API
  app.get("/api/payments/details", async (req, res) => {
    try {
      const { orderId } = req.query;
      
      if (!orderId) {
        return res.status(400).json({ message: '주문 ID가 필요합니다.' });
      }
      
      // 결제 정보 조회
      const payment = await storage.getPaymentByOrderId(orderId as string);
      if (!payment) {
        return res.status(404).json({ message: '결제 정보를 찾을 수 없습니다.' });
      }
      
      // 등록 및 프로그램 정보 조회
      const registration = await storage.getRegistration(payment.registrationId);
      if (!registration) {
        return res.status(404).json({ message: '등록 정보를 찾을 수 없습니다.' });
      }
      
      const program = await storage.getProgram(registration.programId);
      
      // 결제 상세 정보 구성
      const paymentDetails = {
        paymentId: payment.id,
        orderId: payment.orderId,
        amount: payment.amount,
        method: payment.method,
        status: payment.status,
        approvedAt: payment.approvedAt,
        receiptUrl: payment.receiptUrl,
        registrationId: registration.id,
        programId: registration.programId,
        programName: program ? program.title : '알 수 없는 프로그램',
        childName: registration.childName,
        parentName: registration.parentName,
      };
      
      res.json(paymentDetails);
    } catch (error) {
      console.error('결제 상세 정보 조회 오류:', error);
      res.status(500).json({ message: '결제 상세 정보 조회 중 오류가 발생했습니다.' });
    }
  });
  
  // 주문 정보 조회 API (결제 실패 시에도 사용)
  app.get("/api/payments/order-info", async (req, res) => {
    try {
      const { orderId } = req.query;
      
      if (!orderId) {
        return res.status(400).json({ message: '주문 ID가 필요합니다.' });
      }
      
      // 결제 정보 조회
      const payment = await storage.getPaymentByOrderId(orderId as string);
      if (!payment) {
        return res.status(404).json({ message: '주문 정보를 찾을 수 없습니다.' });
      }
      
      // 등록 정보 조회
      const registration = await storage.getRegistration(payment.registrationId);
      if (!registration) {
        return res.status(404).json({ message: '등록 정보를 찾을 수 없습니다.' });
      }
      
      // 결제 실패시에도 사용할 수 있도록 최소한의 정보만 반환
      res.json({
        registrationId: registration.id,
        programId: registration.programId,
        orderId: payment.orderId,
        amount: payment.amount
      });
    } catch (error) {
      console.error('주문 정보 조회 오류:', error);
      res.status(500).json({ message: '주문 정보 조회 중 오류가 발생했습니다.' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
