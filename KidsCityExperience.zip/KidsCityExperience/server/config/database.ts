import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from '../../shared/schema';

// 환경 변수에서 데이터베이스 접속 정보 가져오기
const databaseUrl = process.env.DATABASE_URL;
const dbUser = process.env.PGUSER || 'postgres';
const dbPassword = process.env.PGPASSWORD || 'postgres';
const dbName = process.env.PGDATABASE || 'postgres';
const dbHost = process.env.PGHOST || 'localhost';
const dbPort = parseInt(process.env.PGPORT || '5432');

// PostgreSQL 연결 설정
const pool = new Pool({
  connectionString: databaseUrl,
  user: dbUser,
  password: dbPassword,
  database: dbName,
  host: dbHost,
  port: dbPort,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

// Drizzle ORM 설정
export const db = drizzle(pool, { schema });

// XAMPP 환경 (MySQL) 설정을 위한 함수
export const getXamppDbConfig = () => {
  return {
    host: 'localhost',
    user: 'root',
    password: '',  // XAMPP의 기본 MySQL 비밀번호는 빈 문자열
    database: 'kid_explorer',
    port: 3306
  };
};

// XAMPP 환경에서 MySQL 쿼리 실행 함수 (PHP 연동용)
export const getMySqlCreateTablesScript = () => {
  return `
-- 사용자 테이블
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  is_admin BOOLEAN NOT NULL DEFAULT FALSE
);

-- 카테고리 테이블
CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT
);

-- 프로그램 테이블
CREATE TABLE programs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  category_id INT NOT NULL,
  min_age INT NOT NULL,
  max_age INT NOT NULL,
  date DATETIME NOT NULL,
  location VARCHAR(255) NOT NULL,
  price INT NOT NULL,
  max_participants INT NOT NULL,
  min_participants INT NOT NULL,
  duration INT NOT NULL,
  image_url VARCHAR(255),
  status VARCHAR(50) NOT NULL DEFAULT 'pending',
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- 등록 테이블
CREATE TABLE registrations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  program_id INT NOT NULL,
  child_name VARCHAR(255) NOT NULL,
  child_age INT NOT NULL,
  parent_name VARCHAR(255) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  email VARCHAR(255) NOT NULL,
  notes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  payment_status VARCHAR(50) NOT NULL DEFAULT 'pending',
  payment_method VARCHAR(50),
  payment_id VARCHAR(255),
  paid_amount INT,
  FOREIGN KEY (program_id) REFERENCES programs(id)
);

-- 결제 테이블
CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  registration_id INT NOT NULL,
  amount INT NOT NULL,
  method VARCHAR(50) NOT NULL,
  status VARCHAR(50) NOT NULL,
  payment_key VARCHAR(255),
  order_id VARCHAR(255) NOT NULL,
  order_name VARCHAR(255) NOT NULL,
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  approved_at DATETIME,
  receipt_url VARCHAR(255),
  extra_data TEXT,
  FOREIGN KEY (registration_id) REFERENCES registrations(id)
);

-- 기본 관리자 계정 추가
INSERT INTO users (username, password, is_admin) VALUES ('admin', 'admin123', TRUE);

-- 카테고리 추가
INSERT INTO categories (name, description) VALUES 
('도시텃밭 체험', '아이들이 식물을 심고 가꾸는 체험을 통해 생명의 소중함을 배워요.'),
('영어놀이 체험', '다양한 영어 활동을 통해 자연스럽게 영어에 친숙해져요.'),
('스포츠 및 놀이 체험', '다양한 신체 활동과 놀이를 통해 건강한 발달을 도와요.');

-- 현재 날짜 가져오기
SET @now = NOW();
SET @two_weeks_later = DATE_ADD(@now, INTERVAL 14 DAY);
SET @one_week_later = DATE_ADD(@now, INTERVAL 7 DAY);
SET @two_days_later = DATE_ADD(@now, INTERVAL 2 DAY);
SET @five_days_later = DATE_ADD(@now, INTERVAL 5 DAY);
SET @nine_days_later = DATE_ADD(@now, INTERVAL 9 DAY);
SET @five_days_ago = DATE_SUB(@now, INTERVAL 5 DAY);

-- 샘플 프로그램 추가
INSERT INTO programs (title, description, category_id, min_age, max_age, date, location, price, max_participants, min_participants, duration, image_url, status) VALUES
('꼬마 농부 체험', '아이와 함께 상추, 방울토마토 등을 심고 가꾸는 체험을 통해 생명의 소중함을 배워요. 오감을 자극하는 흙과 식물 접촉은 아이의 정서 발달과 집중력 향상에 도움이 됩니다.', 1, 12, 24, @two_weeks_later, '서울 강남구 도시농업체험장', 30000, 10, 6, 90, 'https://images.unsplash.com/photo-1615811361523-6bd03d7748e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500', 'confirmed'),
('신나는 흙놀이', '친환경 흙과 식물을 만지며 감각을 발달시키고 자연을 느껴보는 시간을 가져요.', 1, 6, 18, @one_week_later, '서울 송파구 실내 농장', 25000, 10, 5, 60, 'https://pixabay.com/get/g13bc76a2b167ea83c2fa6d5a5da43992e47edb4f8a37a9d115a99cd292f28c793f334952c0ac8576eee953d7c7ab8d33d7f1d1e90da20bf1f1bfa3f7ee604608_1280.jpg', 'confirmed'),
('영어 감각놀이', '다양한 색상과 촉감의 교구를 활용한 감각놀이와 함께 자연스럽게 영어를 접해요.', 2, 10, 24, @two_days_later, '서울 마포구 키즈카페', 35000, 8, 4, 75, 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500', 'pending'),
('영어 그림책 놀이', '재미있는 영어 그림책과 함께 노래, 율동으로 자연스럽게 영어에 친숙해져요.', 2, 12, 24, @nine_days_later, '서울 강동구 어린이도서관', 32000, 8, 4, 60, 'https://images.unsplash.com/photo-1549737221-bef65e2604a6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500', 'pending'),
('아기 체육 놀이', '다양한 공과 매트 활동을 통해 아이의 대근육 발달과 신체 협응력을 키워요.', 3, 6, 18, @five_days_ago, '서울 용산구 키즈체육관', 28000, 10, 6, 60, 'https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500', 'canceled'),
('오감 놀이터', '다양한 놀이기구와 감각재료를 통해 아이의 오감을 자극하고 발달을 돕는 프로그램이에요.', 3, 8, 24, @five_days_later, '서울 서초구 어린이놀이센터', 29000, 8, 5, 70, 'https://images.unsplash.com/photo-1524503033411-c9566986fc8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500', 'pending');

-- 샘플 등록 추가
INSERT INTO registrations (program_id, child_name, child_age, parent_name, phone, email, notes, payment_status) VALUES
(1, '김하늘', 15, '김엄마', '010-1234-5678', 'kim@example.com', '특이사항 없음', 'paid'),
(1, '이슬기', 18, '이아빠', '010-2345-6789', 'lee@example.com', '알레르기 있음', 'paid');
  `;
};

// PHP 연동을 위한 설정 파일 (config.php)
export const getPhpConfigContent = () => {
  return `<?php
// Database configuration
$host = 'localhost';
$dbname = 'kid_explorer';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("DB 연결 실패: " . $e->getMessage());
}

// Toss Payments API 설정
$TOSS_PAYMENTS_API_URL = 'https://api.tosspayments.com/v1';
$TOSS_PAYMENTS_SECRET_KEY = 'test_sk_D4yKeq5bgrpKRd0JYbLVGX0lzW6Y'; // 테스트 키, 실제 운영 시 변경 필요
$TOSS_PAYMENTS_CLIENT_KEY = 'test_ck_D4yKeq5bgrp0Rn56PBXr37nO5Wml'; // 테스트 키, 실제 운영 시 변경 필요

// 사이트 설정
$SITE_URL = 'http://localhost/kid_explorer';
?>`;
};

// MySQL 데이터베이스 생성 방법 안내 (XAMPP용)
export const getMySqlSetupInstructions = () => {
  return `
# XAMPP 환경에서 데이터베이스 설정하기

1. XAMPP 제어판을 열고 Apache와 MySQL 서비스를 시작합니다.
2. 웹 브라우저에서 http://localhost/phpmyadmin/ 에 접속합니다.
3. 왼쪽 사이드바에서 "New"를 클릭하여 새 데이터베이스를 생성합니다.
4. 데이터베이스 이름으로 "kid_explorer"를 입력하고 인코딩은 "utf8mb4_general_ci"를 선택합니다.
5. "Create" 버튼을 클릭하여 데이터베이스를 생성합니다.
6. 생성된 데이터베이스를 선택한 후 "SQL" 탭을 클릭합니다.
7. 아래 SQL 스크립트를 복사하여 입력창에 붙여넣고 "Go" 버튼을 클릭하여 실행합니다.

\`\`\`sql
${getMySqlCreateTablesScript()}
\`\`\`

8. "htdocs" 폴더에 "kid_explorer" 폴더를 생성하고 그 안에 웹 애플리케이션 파일을 복사합니다.
9. "kid_explorer" 폴더에 "config.php" 파일을 생성하고 아래 내용을 복사하여 저장합니다.

\`\`\`php
${getPhpConfigContent()}
\`\`\`

10. 웹 브라우저에서 http://localhost/kid_explorer/ 에 접속하여 웹 애플리케이션을 실행합니다.
`;
};