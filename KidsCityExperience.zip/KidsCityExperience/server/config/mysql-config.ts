// XAMPP에서 사용하는 기본 MySQL 설정
export const config = {
  host: 'localhost',
  user: 'root',
  password: '',  // XAMPP 기본 설정에서는 비밀번호가 없음
  database: 'waggle_db'  // 새로 생성할 waggle_db 데이터베이스
};