<?php
// edit_programs.php - 모집중/준비중인 프로그램 수정 페이지

// 관리자 권한 확인
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    redirect($base_url . '/index.php?page=login');
    exit;
}

// 모든 카테고리 가져오기
$conn = get_db_connection();
$categories = [];
$sql = "SELECT id, name FROM categories ORDER BY name";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

// 상태별 프로그램 목록 가져오기
$active_programs = [];
$pending_programs = [];
$completed_programs = [];
$canceled_programs = [];

$sql = "SELECT p.*, c.name as category_name 
        FROM programs p 
        LEFT JOIN categories c ON p.category_id = c.id 
        ORDER BY p.date DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['status'] === 'active') {
            $active_programs[] = $row;
        } else if ($row['status'] === 'pending') {
            $pending_programs[] = $row;
        } else if ($row['status'] === 'completed') {
            $completed_programs[] = $row;
        } else if ($row['status'] === 'canceled') {
            $canceled_programs[] = $row;
        }
    }
}
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">프로그램 수정</h1>
    <p class="mb-4">모집중이거나 준비중인 프로그램을 수정합니다.</p>
    
    <!-- 프로그램 목록 (탭 네비게이션) -->
    <ul class="nav nav-tabs" id="programTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="active-tab" data-bs-toggle="tab" data-bs-target="#active" type="button" role="tab">
                모집중 <span class="badge bg-primary"><?php echo count($active_programs); ?></span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab">
                준비중 <span class="badge bg-warning text-dark"><?php echo count($pending_programs); ?></span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="completed-tab" data-bs-toggle="tab" data-bs-target="#completed" type="button" role="tab">
                종료됨 <span class="badge bg-success"><?php echo count($completed_programs); ?></span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="canceled-tab" data-bs-toggle="tab" data-bs-target="#canceled" type="button" role="tab">
                취소됨 <span class="badge bg-danger"><?php echo count($canceled_programs); ?></span>
            </button>
        </li>
    </ul>
    
    <div class="tab-content" id="programTabsContent">
        <!-- 모집중 프로그램 탭 -->
        <div class="tab-pane fade show active" id="active" role="tabpanel">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>제목</th>
                                    <th>카테고리</th>
                                    <th>날짜</th>
                                    <th>가격</th>
                                    <th>신청/정원</th>
                                    <th>수정</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($active_programs as $program): 
                                    $category_name = isset($program['category_name']) ? $program['category_name'] : '미분류';
                                    
                                    // 현재 등록 인원 조회
                                    $conn_temp = get_db_connection();
                                    $count_sql = "SELECT COUNT(*) as count FROM registrations WHERE program_id = {$program['id']}";
                                    $result = $conn_temp->query($count_sql);
                                    
                                    $current_participants = 0;
                                    if ($result && $result->num_rows > 0) {
                                        $current_participants = $result->fetch_assoc()['count'];
                                    }
                                    $conn_temp->close();
                                ?>
                                <tr>
                                    <td><?php echo $program['id']; ?></td>
                                    <td><?php echo $program['title']; ?></td>
                                    <td><?php echo $category_name; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($program['date'])); ?></td>
                                    <td><?php echo format_price($program['price']); ?></td>
                                    <td><?php echo $current_participants; ?> / <?php echo isset($program['max_participants']) ? $program['max_participants'] : '제한없음'; ?></td>
                                    <td>
                                        <a href="index.php?page=direct_edit_program&id=<?php echo $program['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> 수정
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 준비중 프로그램 탭 -->
        <div class="tab-pane fade" id="pending" role="tabpanel">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>제목</th>
                                    <th>카테고리</th>
                                    <th>날짜</th>
                                    <th>가격</th>
                                    <th>신청/정원</th>
                                    <th>수정</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pending_programs as $program): 
                                    $category_name = isset($program['category_name']) ? $program['category_name'] : '미분류';
                                    
                                    // 현재 등록 인원 조회
                                    $conn_temp = get_db_connection();
                                    $count_sql = "SELECT COUNT(*) as count FROM registrations WHERE program_id = {$program['id']}";
                                    $result = $conn_temp->query($count_sql);
                                    
                                    $current_participants = 0;
                                    if ($result && $result->num_rows > 0) {
                                        $current_participants = $result->fetch_assoc()['count'];
                                    }
                                    $conn_temp->close();
                                ?>
                                <tr>
                                    <td><?php echo $program['id']; ?></td>
                                    <td><?php echo $program['title']; ?></td>
                                    <td><?php echo $category_name; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($program['date'])); ?></td>
                                    <td><?php echo format_price($program['price']); ?></td>
                                    <td><?php echo $current_participants; ?> / <?php echo isset($program['max_participants']) ? $program['max_participants'] : '제한없음'; ?></td>
                                    <td>
                                        <a href="index.php?page=direct_edit_program&id=<?php echo $program['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> 수정
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 종료된 프로그램 탭 -->
        <div class="tab-pane fade" id="completed" role="tabpanel">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>제목</th>
                                    <th>카테고리</th>
                                    <th>날짜</th>
                                    <th>가격</th>
                                    <th>신청/정원</th>
                                    <th>수정</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($completed_programs as $program): 
                                    $category_name = isset($program['category_name']) ? $program['category_name'] : '미분류';
                                    
                                    // 현재 등록 인원 조회
                                    $conn_temp = get_db_connection();
                                    $count_sql = "SELECT COUNT(*) as count FROM registrations WHERE program_id = {$program['id']}";
                                    $result = $conn_temp->query($count_sql);
                                    
                                    $current_participants = 0;
                                    if ($result && $result->num_rows > 0) {
                                        $current_participants = $result->fetch_assoc()['count'];
                                    }
                                    $conn_temp->close();
                                ?>
                                <tr>
                                    <td><?php echo $program['id']; ?></td>
                                    <td><?php echo $program['title']; ?></td>
                                    <td><?php echo $category_name; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($program['date'])); ?></td>
                                    <td><?php echo format_price($program['price']); ?></td>
                                    <td><?php echo $current_participants; ?> / <?php echo isset($program['max_participants']) ? $program['max_participants'] : '제한없음'; ?></td>
                                    <td>
                                        <a href="index.php?page=direct_edit_program&id=<?php echo $program['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> 수정
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 취소된 프로그램 탭 -->
        <div class="tab-pane fade" id="canceled" role="tabpanel">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>제목</th>
                                    <th>카테고리</th>
                                    <th>날짜</th>
                                    <th>가격</th>
                                    <th>신청/정원</th>
                                    <th>수정</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($canceled_programs as $program): 
                                    $category_name = isset($program['category_name']) ? $program['category_name'] : '미분류';
                                    
                                    // 현재 등록 인원 조회
                                    $conn_temp = get_db_connection();
                                    $count_sql = "SELECT COUNT(*) as count FROM registrations WHERE program_id = {$program['id']}";
                                    $result = $conn_temp->query($count_sql);
                                    
                                    $current_participants = 0;
                                    if ($result && $result->num_rows > 0) {
                                        $current_participants = $result->fetch_assoc()['count'];
                                    }
                                    $conn_temp->close();
                                ?>
                                <tr>
                                    <td><?php echo $program['id']; ?></td>
                                    <td><?php echo $program['title']; ?></td>
                                    <td><?php echo $category_name; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($program['date'])); ?></td>
                                    <td><?php echo format_price($program['price']); ?></td>
                                    <td><?php echo $current_participants; ?> / <?php echo isset($program['max_participants']) ? $program['max_participants'] : '제한없음'; ?></td>
                                    <td>
                                        <a href="index.php?page=direct_edit_program&id=<?php echo $program['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> 수정
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>